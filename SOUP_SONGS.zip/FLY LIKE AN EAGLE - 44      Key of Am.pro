{title:FLY LIKE AN EAGLE}
{subtitle: 4/4      Key of Am}
{subtitle:Steve Miller (Steve Miller Band)}
 
[Intro]
| N.C. | % | % | % |
   Riff (see tab)
 
 [Am]    [Am7]   [Am]                                [Am] [Am7] [Am]
(Tick, tock, tick) Do, do, do-do
  [Am]    [Am7]   [Am]                                [Am] [Am7] [Am]
(Tick, tock, tick) Do, do, do-do
 [Am]    [Am7]   [Am]                                [Am] [Am7] [Am]
(Tick, tock, tick) Do, do, do-do
 [Am]    [Am7]   [Am]                                [Am] [Am7] [Am]
(Tick, tock, tick) Do, do, do-do 
[Am]Time keeps on slippin', slippin', slippin'
Into the [Am]future
[Am]Time keeps on slippin', slippin', slippin'
Into the [Am]future
 
 
[Chorus]
I want to [Am7]fly like an [Am6]eagle ..[F]. to the [Am]sea
[Am7]Fly like an [Am6]eagle, let my [F]spirit carry [Am]me
I want to [Am7]fly like an [Am6]eagle ..[F]. til I'm [Am]free
[Am7]Oh, Lord, [Am6]through the revo[F]lutio[Am]n
 
 
[Verse]
Feed the [Am7]babies
Who don't [Am6]have enough to eat
Shoe the [F]children
With no [Am]shoes [Am7]on their [Am]feet
House the [Am7]people
[Am6]Livin' in the street
F                    | Am Am7 Am    |
Oh, oh, there's a solution
 
 
[Chorus]
I want to [Am7]fly like an [Am6]eagle ..[F]. to the [Am]sea
[Am7]Fly like an [Am6]eagle, let my [F]spirit carry [Am]me
I want to [Am7]fly like an [Am6]eagle ..[F]. til I'm [Am]free
[Am7]Fly  [Am6]through the revo[F]lutio[Am]n
 
 
[Bridge]
[Am]Time keeps on slippin', slippin', [Am7]slip[Am]pin'
         | Am7 Am     | Am7 Am     |
Into the future
[Am]Time keeps on slippin', slippin', [Am7]slip[Am]pin'
         | Am7 Am     | Am7 Am     |
Into the future
 
[Am]Time keeps on slippin', slippin', [Am7]slip[Am]pin'
         | Am7 Am     | Am7 Am     |
Into the future
[Am]Time keeps on slippin', slippin', [Am7]slip[Am]pin'
         | Am7 Am     | Am7 Am     |
Into the future
 
[Am]Doo, doo-tn-doo-doot, [Am]doo, doo-tn-doo-doot
[Am]Doo, doo-tn-doo-doot, [Am]doo, doo-tn-doo-doot
[Am]Doo, doo-tn-doo-doot, [Am]doo, doo-tn-doo-doot
[Am]Doo, doo-tn-doo-doot, [Am]doo, doo-tn-doo-doot
 
 
[Chorus]
I want to [Am7]fly like an [Am6]eagle ..[F]. to the [Am]sea
[Am7]Fly like an [Am6]eagle, let my [F]spirit carry [Am]me
I want to [Am7]fly like an [Am6]eagle ..[F]. til I'm [Am]free
[Am7]Fly  [Am6]through the revo[F]lutio[Am]n
 
 
[Outro]
| Am | Asus4 | F | Am |
| Am | Asus4 | F | Am |
 
 Am                              | Am |
(Tick, tock, tick) Do, do, do-do (Tick, tock, tick)
 Am                              | Am |
(Tick, tock, tick) Do, do, do-do
 Am                              | Am |
(Tick, tock, tick) Do, do, do-do
 Am                              | Am |
(Tick, tock, tick) Do, do, do-do
 
[Am]Time keeps on slippin', slippin', slippin'
Into the [Am]future
[Am]Time keeps on slippin', slippin', slippin'
Into the [Am]future
(fade out)