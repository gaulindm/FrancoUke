{title:HEY GOOD LOOKIN'  }
{subtitle:(4/4     Key of C)}
{subtitle:(Hank Williams)}
{time:3:35}
{metronome: 172}

{c:KAZOO SONG!}

[D7]/ / / /       [G]/ / / /         
[C]/ / / /     / / / 

Hey [C]Hey Good Lookin',  whatcha got cookin'
[D7]How's about cooking [G7]somethin' up with [C]me 
Hey sweet baby, don't you think maybe
[D7]We could find us a [G7]brand new reci[C]pe [C7]
 
{soc}
     I got a [F]hot rod Ford and a [C]two dollar bill
     And [F]I know a spot right [C]over the hill
     There's [F]soda pop and the [C]dancin's free
     So if you [D7]wanna have fun come a[G7]long with me
{eoc}

Hey [C]Hey Good Lookin', whatcha got cooking
[D7]How's about cooking [G7]somethin' up with [C]me [G7]

{c:INSTRUMENTAL/KAZOO }
Hey [C]Hey Good Lookin',  whatcha got cookin'
[D7]How's about cooking [G7]somethin' up with [C]me 
Hey sweet baby, don't you think maybe
[D7]We could find us a [G7]brand new reci[C]pe [C7]
 
{soc}
     I got a [F]hot rod Ford and a [C]two dollar bill
     And [F]I know a spot right [C]over the hill
     There's [F]soda pop and the [C]dancin's free
     So if you [D7]wanna have fun come a[G7]long with me
{eoc}

Hey [C]Hey Good Lookin', whatcha got cooking
[D7]How's about cooking [G7]somethin' up with [C]me [G7]

{c:SING}
I'm [C]free and ready so we can go steady
[D7]How's about saving [G7]all your time for [C]me
No more lookin' I know I've been tooken
[D7]How's about keepin' [G7]steady [C]company [C7] 
 
{soc}
     I'm gonna [F]throw my date book [C]over the fence
     And [F]buy me one for [C]five or ten cents 
     I'll [F]keep it 'til it's [C]covered with age
     'Cause I'm [D7]writin' your name down on [G7]every page
{eoc}
 
Hey [C]Hey Good Lookin', whatcha got cooking
[D7]How's about cooking [G7]somethin' up 
[D7]How's about cooking [G7]somethin' up 
[D7]How's about cooking [G7]somethin' up with 
[C]Me  [G7/]   [C/]

________________________________________








{define: D7 0 2 0 2 0}







