{title:CLOSE TO YOU}
{subtitle:(The Carpenters)}
{time:  3:00}
{metronome: 92 }





[Cadd9]/ / / /      [C]/ / / /    
[Cadd9]/ / / /      [C]/ / 
 
Why do bir[C]ds suddenly ap[B7]pear 
every[Bm]time you are [Em]near?
[C]Just like [Cadd9]me      
t[C]hey long to [Cadd9]be           [G]close to you
 
Why do st[C]ars fall down from the s[B7]ky 
everyt[Bm]ime you walk [Em]by?
[C]Just like [Cadd9]me       
t[C]hey long to [Cadd9]be           [G]close to you
 

[C6]On the day that y[C]ou were born 
the a[C6]ngels got tog[C]ether
And de[Bm]cided to create a dream come t[E7]rue
So they sprin[C]kled moon dust [C6]in your hair 
and go[Am]lden starlight [C6]in your eyes of b[D]lue
 
That is w[C]hy all the girls in t[B7]own 
follow [Bm]you all a[Em]round
[C]Just like [Cadd9]me 
t[C]hey long to [Cadd9]be         [G]close to you
  
[C6]On the day that y[C]ou were born 
the a[C6]ngels got tog[C]ether
And de[Bm]cided to create a dream come t[E7]rue
So they sprin[C]kled moon dust [C6]in your hair 
and go[Am]lden starlight [C6]in your eyes of b[D]lue
 
That is w[C]hy all the girls in t[B7]own, 
follow [Bm]you all a[Em]round
[C]Just like [Cadd9]me      
t[C]hey long to [Cadd9]be          [G]close to you 
  
[C]Ah.... ah ah ah ah... [G]close to you    
[C]Ah.... ah ah ah ah... [G]close to you  [G/]
{define: Cadd9 0 0 2 0 3}   