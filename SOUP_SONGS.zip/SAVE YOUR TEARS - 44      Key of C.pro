{title:SAVE YOUR TEARS}
{subtitle:4/4      Key of C}
{subtitle: The Weeknd}
{time:3:40}
{metronome:122}

[C]/ / / /   / / / /

{c:(}[C]{c:12)} I saw you d[Am]ancing in a crowded room
{c:(}[Em]{c:12)} You look so h[G]appy when I'm not with you
{c:(}[C]{c:12)} But then you [Am]saw me, caught you by surprise
{c:(}[Em]{c:12)} A single te[G]ardrop falling from your eyes
 
{c:(}[C]{c:123)} I don't know [Am]why {c:(23)} I [Em]run away 
([G]Ah-ah-ah-ah-)

[C](Ah...)  I'll make you [Am]cry when {c:(beat)} I [Em]run away 
[G/] {c:(234)}
  
{c:(}[C]{c:12)} You could've a[Am]sked me why I broke your heart
{c:(}[Em]{c:12)} You could've t[G]old me that you fell apart
{c:(}[C]{c:12)} But you walked [Am]past me like I wasn't there
{c:(}[Em]{c:12)} And ju...st pret[G]e...nded like you didn't [C]care

I don't know [Am]why {c:(23)} I [Em]run away 
([G]Ah-ah-ah-ah-)

[C](Ah...) I'll make you [Am]cry when {c:(beat)} I [Em]run away 
([G]Ah-ah-ah-ah-)

[Dm](ah...) Take me [Am]back 'cause I wanna sta-a[F]y
Save your t[G]ears for another
 
[C/]Save your [Am/]tears for another day [Em]         ([G]Ah-ah-ah-ah)
[C/]Save your [Am/]tears for another day [Em]         [G]
 
{c:(}[C]{c:12)} I made you [Am]think that I would always stay
{c:(}[Em]{c:12)}  I said some th[G]ings that I should never say
{c:(}[C]{c:12)} Yeah, I broke your [Am]heart like someone did to mine
[Em] And now you won't l[G]ove me for a second [C]ti-ime
 
I don't know [Am]why {c:(23)} I [Em]run away 
([G]Ah-ah-ah...)  Oo girl

[C](Ah...) I'll make you [Am]cry when {c:(beat)} I [Em]run awa-ay 
([G]Ah-ah-ah-ah)

[Dm](Ah...) Girl, take me [Am]back 'cause I wanna sta-[F]ay
Save your te[G]ars for another
{c:(}[Dm]{c:12)} I reali[Am]ze that I'm much too la-[F]ate
And you des[G]erve someone better

[C/]Save your [Am/]tears for another day [Em]        ([G]Ah-ah-ah-ah)
[C/]Save your [Am/]tears for another day [Em]          [G]

{c:(}[C]{c:123)} I don't know [Am]why {c:(23)} I [Em]run away  [G]
{c:(}[C]{c:123)}  I'll make you [Am]cry  when {c:(beat)} I [Em]run away  [G]   


[C]Save your                    [Am]tears for another day  {c:(}[Em]{c:1234)}  [G]
             {c:(I don't know why (23)                I   run away)}

[C]Save      your                 [Am]tears for another day  [Em]       [G]
{c:              (I'll make you cry   when   I              run away)}

[C]Save your                    [Am]tears for another day  [Em]        [G]
             {c:(I don't know why (23)                I   run away)}

[C]Save      your                 [Am]tears for another day    [Em]       [G]         [C/]
{c:              (I'll make you cry     when               I run away)}









