

{t:109  I WALK THE LINE   }
{subtitle:(4/4   Key of A)}
{subtitle: (Johnny Cash)}
{time:2:45}
{metronome: 188}





[A]/ / / /    [E7]/ / / /    [A]/ / / /    /  {c:(stop)}         

I keep a [E7]close watch on this heart of [A]mine   
I keep my [E7]eyes wide open all the [A]time [A7]
I keep the [D]ends out for the tie that [A]binds
Because you’re [E7]mine, I walk the [A]line    [A/]

I find it [E7]very, very easy to be [A]true
I find my[E7]self alone 
When each day is [A]through [A7]
Yes, I'll ad[D]mit that  I'm a fool for [A]you
Because you're [E7]mine, I walk the [A]line    [A/]

As sure as [E7]night is dark and day is [A]light
I keep you [E7]on my mind 
Both day and [A]night [A7]
And happi[D]ness I've known 
Proves that it's [A]right
Because you're [E7]mine, I walk the [A]line    [A/]

You've got a [E7]way to keep me on your [A]side
You give me [E7]cause for love 
That I can't [A]hide [A7]
For you I [D]know I'd even try to turn the [A]tide
Because you're [E7]mine, I walk the [A]line    [A/]

I keep a [E7]close watch on this heart of [A]mine   
I keep my [E7]eyes wide open all the [A]time [A7]
I keep the [D]ends out for the tie that [A]binds
Because you’re [E7]mine, I walk the [A]line    [A/]
Because you’re [E7]mine, I walk the [A]line    [A/]
Because you’re [E7]mine, I walk the [A]line    [A/]

____________________________________











