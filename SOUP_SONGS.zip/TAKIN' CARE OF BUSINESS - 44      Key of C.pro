{title:TAKIN' CARE OF BUSINESS}
{subtitle:4/4      Key of C}
{subtitle: Randy Bachman (Bachman-Turner Overdrive)}
{time:  3:30}
{metronome: }
 
[C]/ / / /    [Bb]/ / / /    [F]/ / / /    [C]/ / / / 
[C]/ / / /    [Bb]/ / / /    [F]/ / / /    [C]/ / / /

{c:Alternate INTRO:}
{sot}
  C        Bb       F       C
A|3-3-3-3--1-1-1-1--0-0-0-0--3-3-3-3
E|0-0-0-0--1-1-3-1--1-1-1-1--0-0-0-0
C|0-0-0-0--2-2-2-2--0-0-2-0--0-0-0-0
G|0-0-2-0--3-3-3-3--2-2-2-2--0-0-2-0
{eot}
 
You [C]get up every morning
From your [Bb]'larm clock's warning
Take the [F]8:15 into the [C]city
There's a [C]whistle up above
People [Bb]pushin', people shovin'
And the [F]girls who try to look [C]pretty
And if your [C]train's on time
You can [Bb]get to work by nine
And [F]start your slaving job to get your [C]pay
If you [C]ever get annoyed
Look at [Bb]me, I'm self-employed
I [F]love to work at nothin' all [C]day
And I'll be
 
{soc}
 [C]Takin' care of business [Bb]    (every day)
 [F]Takin' care of business [C]   (every way)
 I've been [C]takin' care of business[Bb]     (it's all mine)
 [F]Takin' care of business and [C]workin' overtime 
 (work out)
{eoc} 
 
[C]/ / / /    [Bb]/ / / /    [F]/ / / /    [C]/ / / / 
[C]/ / / /    [Bb]/ / / /    [F]/ / / /    [C]/ / /  

If it were [C]easy as fishin'
You could [Bb]be a musician
If [F]you could make sounds loud or [C]mellow
Get a [C]second-hand guitar
Chances [Bb]are you'll go far
And [F]get in with the right bunch of fel[C]lows

Get [C]yourself a ukulele
Play your [Bb]favourite songs daily
You will [F]get in with the right bunch of fel[C]lows

People [C]see you having fun
Just a-[Bb]lying in the sun
[F]Tell them that you like it this [C]way
It's the [C]work that we avoid
And we're [Bb]all self-employed
We [F]love to work at nothin' all [C]day
And we be
 
{soc}
[C]Takin' care of business [Bb]    (every day)
[F]Takin' care of business [C]   (every way)
We be [C]takin' care of business [Bb]    (it's all mine)
[F]Takin' care of business and [C]workin' overtime
{eoc} 
 
[C]/ / / /    [Bb]/ / / /    [F]/ / / /    [C]/ / / / 
[C]/ / / /    [Bb]/ / / /    [F]/ / / /    [C]/ / / /  

{soc} 
  [Z]Takin' care of business

  Takin' care of business 
  [C]Takin' care of business [Bb]    (every day)
  [F]Takin' care of business [C]   (every way)
  I've been [C]takin' care of business [Bb]    (it's all mine)
  [F]Takin' care of business and [C]workin' overtime
  [C]Takin' care of business [Bb] 
  [F]Takin' care of business [C]
  [C]Takin' care of business [Bb]
  We be [F]takin' care of business [C]
  We be [C]takin' care of business [Bb]
  [F]Takin' care of business [C/]
{eoc}


________________________________________








 
