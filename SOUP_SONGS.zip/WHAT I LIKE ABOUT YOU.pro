{title:WHAT I LIKE ABOUT YOU}
{subtitle:}
 
[D]  [G]  [C]  [G]
[D]  [G]  [C]  [G]

[D]   [G]   [C]   [G]   Hey
[D]  [G]  [C]  [G]   uh huh 
[D]huh  [G]   [C]    [G]   Hey 
[D]  [G]  [C]  [G]   uh huh 
[D]huh [G]    [C]    
What I [G]like about [D]you  [G]     [C]    you [G]hold me [D]tight [G] [C] [G]
 [D]Tell me I'm the [G]only one, [C]wanna come [G]over ton[D]ight, [G]      [C]yeah [G]
 [D]Keep on [G]whispering [C]in my [G]ear
[D]Tell me all the [G]things that [C]I wanna to [G]hear, 'cause that's [D]true [G]
[C] That's what I [G]like about [D]you [G]
[C] What I [G]like about [D]you, [G]     [C] you really [G]know how to [D]dance [G] [C]
 [G]When you go [D]up, down, [G]jump around, [C]think about [G]true ro[D]mance,[G]     [C]yeah [G]
 [D]You're [G]whispering [C]in my [G]ear
 [D]Tell me all the [G]things that [C]I wanna to [G]hear, 'cause that's [D]true
[C] That's what I [G]like about [D]you [G]
[C] That's what I [G]like about [D]you [G]
[C] That's what I [G]like about [D]you [G]
[C] Wahh! [G] [D] [G]
[C] Hey! [G] [D] [G]
[C] What I [G]like about [D]you,  [G]     [C] you keep me [G]warm at [D]night [G] [C] [G]
 [D]Never wanna' [G]let you go, [C]know you make me [G]feel alr[D]ight,[G]     [C]yeah [G]
 [D]You're [G]whispering [C]in my [G]ear
 [D]Tell me all the [G]things that [C]I wanna to [G]hear, 'cause that's [D]true
[C] That's what I [G]like about [D]you [G]
[C] That's what I [G]like about [D]you [G]
[C] That's what I [G]like about [D]you [G]
[C] That's what I [G]like about [D]you (whis[G]pered)
[C] That's what I [G]like about [D]you (whis[G]pered)
[C] That's what I [G]like about [D]you (whis[G]pered)
[C] That's what I [G]like about [D]you (whis[G]pered)
[C] Hey, uh huh hu[G]h, hey hey [D]hey [G]
[C] Hey, uh huh hu[G]h, brrr [D] [G]
[C] Hey, uh huh hu[G]h, hey  [D] [G] [C] [G] [D]
