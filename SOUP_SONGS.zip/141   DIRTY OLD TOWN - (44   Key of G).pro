

{title:141   DIRTY OLD TOWN  }
{subtitle:(4/4   Key of G)}  
{subtitle: (Ewan MacColl)}
{time:5:00}
{metronome: 118}

{c:Count-in: 1234, 12…}





 
[G]/ /      [D]/ / / /    / / / /      
[Em7]/ / / /    / {c:(stop)}

I met my [G]love by the gas works wall
Dreamed a [C]dream by the old ca[G]nal 
I kissed my girl by the factory wall
Dirty old [D]town dirty old [Em7]town {c:(234)}[Em7/]

Clouds are [G]drifting across the moon
Cats are [C]prowling on their [G]beats
Springs a girl on the streets at night 
Dirty old [D]town dirty old [Em7]town {c:(234)} 
[Em7/]    {c:(234)}
 
{c:(with kazoo)}
[C]/ / / /    / / / /,   / / / /    / / / /    
[F]/ / / /    / / / /      [C]/ / / /   / / / /
[C]/ / / /    / / / /,   / / / /    / / / /    
[G]/ / / /   / / / /     [Am]/ / / /    / {c:(stop)} 

Heard a [G]siren from the dock 
Saw a [C]train cut the night on [G]fire
Smelled the breeze on the smokey wind
Dirty old [D]town dirty old [Em7]town {c:(234)} [Em7/]
 
I'm going to [G]make me a big sharp ax
Shining [C]steel tempered in the [G]fire
I'll chop you down like an old dead tree
Dirty old [D]town dirty old [Em7]town {c:(234)} [Em7/]
 
I met my [G]love by the gas works wall
Dreamed a [C]dream by the old ca[G]nal
I kissed my girl, by the factory wall

Dirty old [Am/]town {c:(234,12)}  
Dirty old [Em7/]town {c:(234,12)}
Dirty old [D]town, dirty old [Em7/]town    

_________________________________________
















