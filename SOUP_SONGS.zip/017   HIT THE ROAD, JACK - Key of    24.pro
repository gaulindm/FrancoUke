

{title:017   HIT THE ROAD, JACK      }
{subtitle:    Key of    2/4}              
{subtitle:Percy Mayfield }
{time:2:32}
{metronome: 168   }





{c:BASS ONLY:}                [Am]/ /   [G]/ /   [F]/ /   [E7]/ /
                                    [Am]/ /   [G]/ /   [F]/ /   [E7]/ /

{c:EVERYONE:}   
                                   [Am]/ /   [G]/ /   [F]/ /   [E7]/ /
                                   [Am]/ /   [G]/ /   [F]/ /   [E7]/ /

{soc}
{c:(women)} 
Hit the [Am]road [G]Jack and [F]don't you come [E7]back 
No [Am]more no [G]more no [F]more no [E7]more
Hit the [Am]road [G]Jack and [F]don't you come [E7]back 
No [Am]more   [G]          ([F]what you [E7]say?!)

Hit the [Am]road [G]Jack and [F]don't you come [E7]back no
[Am]More no [G]more no [F]more no [E7]more
Hit the [Am]road [G]Jack and [F]don't you come [E7]back 
No [Am]more    [G]/ /      [F]/ /      [E7]/ /
{eoc}

{c:(men)}    Whoa [Am]woman oh [G]woman don't
 [F]treat me so [E7]mean
You're the [Am]meanest old [G]woman 
that I've [F]ever [E7]seen
I [Am]guess if [G]you say [F]so      [E7]
I'll have to [Am]pack my [G]things and [F]go 
{c:(women)} (That's [E7]right!)

{soc{
Hit the [Am]road [G]Jack and [F]don't you come [E7]back 
No [Am]more no [G]more no [F]more no [E7]more
Hit the [Am]road [G]Jack and [F]don't you come [E7]back 
No [Am]more  [G]      ([F]what you [E7]say?)

Hit the [Am]road [G]Jack and [F]don't you come [E7]back 
No [Am]more no [G]more no [F]more no [E7]more
Hit the [Am]road [G]Jack and [F]don't you come [E7]back 
No [Am]more   [G]/ /     [F]/ /     [E7]/ /
{eoc}

{c:(men)}  Now [Am]baby listen [G]baby 
don't [F]treat me this [E7]way
For [Am]I'll be [G]back on my [F]feet some [E7]day

{c:(women)}   Don't [Am]care if you [G]do 
cause it's [F]under[E7]stood
You ain't [Am]got no [G]money you just [F]ain't no [E7]good

{c:(men)}   Well I [Am]guess if [G]you say [F]so     [E7]
I'll have to [Am]pack my [G]things and [F]go 
{c:(women)}  (That's [E7]right!)

Hit the [Am]road [G]Jack and [F]don't you come [E7]back 
No [Am]more no [G]more no [F]more no [E7]more
Hit the [Am]road [G]Jack and [F]don't you come [E7]back 
No [Am]more    [G]       ([F]what you [E7]say?!)

Hit the [Am]road [G]Jack and [F]don't you come [E7]back 
No [Am]more no [G]more no [F]more no [E7]more
Hit the [Am]road [G]Jack and [F]don't you come [E7]back 
No [Am]more    [G]

[F]Don't you come [E7]back no [Am]more   [G]   
[F]Don't you come [E7]back no [Am]more   [G]
[F]Don't you come [E7]back no [Am/]more 


__________________________________












