

{title:028 DON'T STOP BELIEVING }
{subtitle:   4/4    Key of C  }
{subtitle:Steve Perry}
{metronome:  132 }
{time:4:18}



{c:INTRO #1: }
[C]//  {c:(23)}   Just a [G]small town girl, {c:(4,}[Am]{c:12)}   
Livin' in a [F]lonely world
{c:(}[C]{c:123)}  She took the [G]midnight train going 
[Em]a...ny whe...[F]ere {c:(234)}


{c:INTRO #2:  Opening 8 bar RIFF}
[C]//  {c:(23)}  Just a [G/]small town girl, {c:(4,}[Am/]{c:12)}   
Livin' in a [F/]lonely world
{c:(}[C/]{c:123)}  She took the [G/]midnight train going 
[Em]a...ny whe...[F]ere {c:(234)}


{c:CONTINUE HERE...}

{c:(}[C]{c:123)}  Just a [G]city boy, {c:(4,}[Am]{c:12)}   
Born and raised in [F]South Detroit
{c:(}[C]{c:123)}  He took the [G]midnight train going 
[Em]a...ny whe...[F]ere {c:(234)}
 
[C]/ / / /    [G]/ / / /    [Am]/ / / /    [F]/ / / / 


[C]/ / / /    [G]/ / / /    [Em]/ / / /    [F]/ / / / 

{c:(}[C]{c:12)}  A singer in a s[G]moky room, {c:(4,}[Am]{c:12)}   
The smell-of-wine and [F]cheap perfume
[C] For a smile they can [G]share the night 
It goes [Em]on and on and [F]on and on

{c:CHORUS}
{soc} 
   [F]Strangers, waitin'  
   [C]     Up and down the boulevard, their
   [F]Shadows searchin' in the [C]ni-i-ight {c:(4,1234)}

   [F]Streetlights, people 
   [C]     Livin' just to ↑find emotion
   [F]Hidin', somewhere in the [G]ni..{c:(hold for 8)}..ight
{eoc}

[C]/ / / /    [G]/ / / /    
[Am]/ / / /    [F]/ / / /  
 
[C] Workin' ha-ard to [G]get my fill, {c:(4,}[Am]{c:12)}   
Everybody [F]wants a thrill
[C] Payin' anything to [G]roll the dice 
Just [Em]one more ti...[F]ime {c:(234)}
[C] Some'll win, [G]    some will lose, {c:(4,}[Am]{c:12)}    
Some-are-born to [F]sing the blues
[C] Oh, the ↑movie [G]never ends 
It goes [Em]on and on and [F]on and on  


{soc} 
   [F]Strangers, waitin'  
   [C]     Up and down the boulevard, their
   [F]Shadows searchin' in the [C]ni-i-ight {c:(4,1234)}
     
   [F]Streetlights, people
   [C]    Livin' just to ↑find ↑emotion
   [F]Hidin', somewhere in the [G]ni..{c:(hold for 8)}..ight
{eoc}

 
[C]Don't stop be[G]lievin' {c:(4,}[Am]{c:12)}  
Hold on to that [F]fee..li-in' 
[C]Streetlights, [G]people, oh-oh-[Am]o...     [F]oh...
[C]Don't stop be[G]lievin', {c:(4,}[Am]{c:12)}     ho...ld [F]o...o...on 
[C]Streetlights, [G]people, oh-oh-[Am]o...     [F]oh...
[C]Don't stop be[G]lievin', {c:(4,}[Am]{c:12)}       
Hold on to that [F]fee...li-in'
[C]Streetlights, [G]people, oh-oh-[Am]o...     [F]oh...  {c:(234){}   [C/]


_________________________________________








{c:20/03/2024}