{title:DOWN IN THE VALLEY    }
{subtitle: tab    3/4     Key of C}
{subtitle:(Lead Belly)}
{metronome: 146}
{time: 1:45}

{c:INTRO: C / / /   G7 / / /    C / / /}

Down in the [C]valley valley so [G7]low
Hang your head over hear the wind [C]blow

Hear the wind blow love, hear the wind [G7]blow
Hang your head over hear the wind [C]blow

Roses love sunshine violets love [G7]dew
Angels in heaven know I love [C]you

Know I love you dear know I love [G7]you    
Angels in heaven know I love [C]you   

Down in the valley valley so [G7]low
Hang your head over hear the wind [C]blow
      
 
