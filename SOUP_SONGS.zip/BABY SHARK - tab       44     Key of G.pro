{title:BABY SHARK    }
{subtitle: tab       4/4     Key of G}
{metronome: 190}
{time: 1:30 }






{c:(One person will need to lead the hand movements)}

{c:(joined fingers and thumb open and close)}
Ba…by [G]shark do do, do-do do-do
Baby [C]shark do do, do-do
Baby [Em]shark do do, do-do do-do, baby [D/]shark

{c:(wrists together, stretched fingers open and close)}
Mom…my [G]shark do do, do-do do-do 
Mommy [C]shark do do do-do
Mommy [Em]shark do do do-do do-do, Mommy [D/]shark

{c:whole, straight arms open and close)}
Dad…dy [G]shark do do, do-do do-do
Daddy [C]shark do do do-do
Daddy [Em]shark do do do-do do-do, Daddy [D/]shark

{c:(wrists together, fingers curled, false teeth)}
Gram…ma [G]shark do do, do-do do-do
Gramma [C]shark do do do-do
Gramma [Em]shark do do do-do do-do, Gramma [D/]shark

{c:(elbows together, fingers curled)}
Gram…pa [G]shark do do, do-do do-do
Grampa [C]shark do do do-do
Grampa [Em]shark do do do-do do-do, Grampa [D/]shark

{c:(other ideas) }  
1.Let’s all swim…G C Em D/           
2.Bigger shark… G C Em D/      
3.Swim away…   G C Em D/         
4. Safely home…    G C Em D/ 
5. Let’s all dance… G C Em D/         
6. That’s the end…  (ending) [D/]That’s  [D/]the [G/]end!         


