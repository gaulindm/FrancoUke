

{title:151  WITH A LITTLE HELP }
{title:FROM MY FRIENDS}
{subtitle:(4/4    Key of G)}    
{subtitle:(Paul McCartney & John Lennon) }
{time:2:50}
{metronome: 124}       

{c:(Get ready for the unusual chord at the end)}
{c:B = BOYS, G = GIRLS)} 




[F]/ /     [C]/ /     [G]/ / / /    
[F]/ /     [C]/ /     [G]/ / / /    

(B)  [G]What would you [D]think if I [Am]sang out of tune
Would you [D]stand up and [D7]walk out on [G]me 
(G)  Lend me your [D]ears and I'll [Am]sing you a song 
And I'll [D]try not to [D7]sing out of [G]key 
Oh I get [F]by with a little [C]help from my [G]friends 
Mm I get [F]high with a little [C]help from my [G]friends 
Mm gonna [F]try with a little [C]help from my [G]friends 

(B)  [G]What do I [D]do when my [Am]love is away 
(G)  Does it [D]worry you to [D7]be a[G]lone 
(B)  [G]How do I [D]feel by the [Am]end of the day 
(G)  Are you [D]sad because you're [D7]on your [G]own
No, I get [F]by with a little [C]help from my [G]friends 
Mm I get [F]high with a little [C]help from my [G]friends 
Mm gonna [F]try with a little [C]help from my [G]friends 

Do you [Em]need any[A]body
I [G]need some[F]body to [C]love 
Could it [Em]be any[A]body
I [G]want some[F]body to [C]love 

(G)  [G]Would you be[D]lieve in a [Am]love at first sight
(B)  Yes I'm [D]certain that it [D7]happens all the [G]time 
(G)  What do you [D]see when you [Am]turn out the light 
(B)  I can't [D]tell you but I [D7]know it’s [G]mine 
Oh I get [F]by with a little [C]help from my [G]friends 
Mm I get [F]high with a little [C]help from my [G]friends 
Mm I’m gonna [F]try with a little [C]help from my [G]friends 

Do you [Em]need any[A]body 
I [G]need some[F]body to [C]love 
Could it [Em]be any[A]body 
I [G]want some[F]body to [C]love 
Oh I get [F]by with a little [C]help from my [G]friends 
Mm gonna [F]try with a little [C]help from my [G]friends 
Yes I get [F]by with a little [C]help from my 
[G]friends with a little help from my 
[D#]fri....ends {c:(hold for 8)} [G/]


______________________________


{define: D7 0 2 0 2 0}











