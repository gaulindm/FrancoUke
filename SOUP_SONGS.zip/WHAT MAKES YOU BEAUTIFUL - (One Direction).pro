{title:WHAT MAKES YOU BEAUTIFUL}
{subtitle:(One Direction)}

 
You're insecur[A]e,   [D]    don't know what [E7]for; you're turning [A]heads when you [D]walk through the [E7]do-o-or
Don't need make[A]up, [D] to cover u[E7]p; being the [A]way that you [D]are is en[E7]ou-u-ugh 
[A]Everyone e[D]lse in the [F#m]room can [E7]see it, [A]everyone [D]else but [E7]you-ou 
 
{c:CHORUS}
{soc} 
Baby you [A]light up my [D]world like no[E7]body else
The way that [A]you flip your [D]hair gets me [E7]overwhelmed
But when you [A]smile at the [D]ground it ain’t [E7]hard to tell
You don't [A]know, oh [F#m]oh, [E7]you don't know you're beauti[A]ful
 
 
[Verse]
 
So c-come [A]on,      you got it [D]wrong
To prove I'm[F#m] right I put it in a son[E7]g
I don't know [A]why,      you're being [D]shy
And turn [F#m]away when I look into your [E7]eyes
[A]Everyone [D]else in the ro[F#m]om can [E7]see it
[A]Everyone [D]else but [E7]you
 
 
Baby you [A]light up my [D]world like no[E7]body else
The way that [A]you flip your [D]hair gets me [E7]overwhelmed
But when you [A]smile at the [D]ground it ain’t [E7]hard to tell
You don't [A]know, oh [F#m]oh, [E7]you don't know you're beauti[A]ful
 
[A]If only [D]you saw what [F#m]I can se[E]e,
You'll under[A]stand why I [D]want you so [F#m]desperat[E]ely,
Right now I'm [A]looking at [D]you and I [F#m]can't belie[E]ve,
You don't [A]know, Oh oh,
[A]You don't know you're [D]beautiful, [A]
 
Oh oh
[A]That what makes you [D]beautiful [A]
