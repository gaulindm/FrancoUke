

{title:119  MAMMA MIA  }
{subtitle: 4/4      Key of C                  }
{subtitle:Benny Andersson, Björn Ulvaeus and Stig Anderson   }
{subtitle: (ABBA)}
{metronome: 134 }
{time:3:50}


 




[C]/ / / /    [Caug]/ / / /    
[C]/ / / /    [Caug]/ / / /}

[C]I've been [G]cheated by [C]you since I [G]don't know [F]when
{c:(Ba ba ba-da-ba-ba,  ba ba ba-da-ba-ba)}

[C]So  I [G]made up my [C]mind, it must [G]come to an [F]end
{c:(Ba ba ba-da-ba-ba,  ba ba ba-da-ba }

[C]Look at me now,         [Caug]           will I ever learn?    
{c:(ba..          look at me now… )}
[C]I don't know how, [Caug]         but I suddenly [F]lose control
    {c:(I don’t know ho…                      …↓ow)}

There's a fire with[G]in my soul   [G/]    {soh}huh!{eoh}   
[F/]Just [C/]one [G]look and I can hear a bell ring
[F/]One [C/]more [G]look and I forget everything
W-o-o-o-oh

{soc}   
[C]    Mamma mia, here I go again  
[F]    My my [G]how can I resist you?
[C]    Mamma mia, does it show again? 
[F]    My my,  [G]just how much I've missed you
[C]    Yes, I've been [G]brokenhearted 
[Am]        Blue since the [Em]day we parted
[Bb]     Why, [F]why [Dm]did I ever [G]let you go? 
[C]    Mamma mia, [Am]      now I really know  
[Bb]     My [F]my, [Dm]I could never [G]let you go   
{eoc}

[C]/ / / /    [Caug]/ / / /     
[C]/ / / /    [Caug]/ / / /
{eoc}

[C]I've been [G]angry and [C]sad ‘bout the [G]things that you 
[F]do {c:('bout the things that you do)}
    {c:(‘bout the things that you do)}

[C]I can't [G]count all the [C]times 
That I've [G]told you we're th[F]rough
{c:(times I’ve told you we’re through)}
{c:(times I’ve told you we're...)}

[C]And when you go           
{c:(through, and when you)}

[Caug]   When you slam the door
{c:(go...)}

[C]I think you know [Caug]              
{c:       (I think you kno...)}                              
That you won't be aw[F]ay too long
{c:                            (…↓ow…)}

You know that I'm [G]not that strong  [G/]     huh!   
[F/]Just [C/]one [G]look and I can hear a bell ring
[F/]One [C/]more [G]look and I forget everything
W-o-o-o-oh

{soc}
[C]    Mamma mia, here I go again  
[F]    My my [G]how can I resist you?
[C]    Mamma mia, does it show again?  
[F]    My my, [G]just how much I've missed you
[C]    Yes, I've been [G]brokenhearted 
[Am]       Blue since the [Em]day we parted
[Bb]     Why, [F]why [Dm]did I ever [G]let you go? 
[C]     Mamma mia, [Am]      now I really know  
[Bb]     My [F]my, [Dm]I could never [G]let you go

[C] Yes, I've been [G]brokenhearted 
[Am]  Blue since the [Em]day we parted
[Bb] Why, [F]why [Dm]did I ever [G]let you go?  
[C]    Mamma mia, [Am]       now I really know   
[Bb] My [F]my, [Dm]I could never [G]let you go
{eoc}

[C]/ / / /    [Caug]/ / / /        
[C]/ / / /    [Caug]/ / / /        
[C]/ / / /    [Caug]/ / / /         [C]/


______________________________________

{define: Caug 0 1 0 0 3}







