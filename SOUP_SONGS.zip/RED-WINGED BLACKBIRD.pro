{title:RED-WINGED BLACKBIRD}
{subtitle:4/4      Key of C}
{subtitle:(David Francey)}
{metronome:180}
{time:3:30}
 
[C]/ / / /    [F]/ /    [C]/ /    
[F]/ /    [C]/ / / /    [G]/ /
[C]/ / / /    [F]/ /    [C]/ /    
[F]/ /    [C]/ /    [G]/ /    [C]/ / / /   / / / /

{soc}
  [C]Thought I heard a [F]red-winged [C]blackbird
  [F]Red-winged [C]blackbird down my [G]road
  [C]Thought I heard a [F]red-winged [C]blackbird
  [F]Red-winged [C]blackbird [G]down my [C]road {c:(234,1234)}
{eoc}

[C]He'll be there beside the river
When winter finally breaks its [G]bones
[C]He'll be king [F]among the [Am]rushes
[F]He'll be [C]master [G]of his [C]home
 
{soc}
[C]Thought I heard a [F]red-winged [C]blackbird
[F]Red-winged [C]blackbird down my [G]road
[C]Thought I heard a [F]red-winged [C]blackbird
[F]Red-winged [C]blackbird [G]down my [C]road {c:(234,1234)}
{eoc} 
 
[C]Safe as Moses in the rushes
Builds his home on the river [G]wide
[C]Every time I [F]hear him [Am]singing
[F]Makes me [C]feel like [G]spring in[C]side
 
{soc}
[C]Thought I heard a [F]red-winged [C]blackbird
[F]Red-winged [C]blackbird down my [G]road
[C]Thought I heard a [F]red-winged [C]blackbird
[F]Red-winged [C]blackbird [G]down my [C]road {c:(234,1234)}
{eoc} 

[C]/ / / /    [F]/ /    [C]/ /    
[F]/ /    [C]/ / / /    [G]/ /
[C]/ / / /    [F]/ /    [C]/ /    
[F]/ /    [C]/ /    [G]/ /    [C]/ / / /   / / / /

[C]He'll be in there singing his heart out
He'll be telling me stories [G]too
Of [C]where he went to [F]winter [Am]last year
Of [F]how he's [C]going [G]back there [C]too
  
{soc}
[C]Thought I heard a [F]red-winged [C]blackbird
[F]Red-winged [C]blackbird down my [G]road
[C]Thought I heard a [F]red-winged [C]blackbird
[F]Red-winged [C]blackbird [G]down my [C]road

[C]Thought I heard a [F]red-winged [C]blackbird
[F]Red-winged [C]blackbird down my [G]road
[C]Thought I heard a [F]red-winged [C]blackbird
[F]Red-winged [C]blackbird [G]down my [C]road
{eoc}

[C]/ / / /    [F]/ /    [C]/ /    
[F]/ /    [C]/ / / /   [G]/ /     
[C]/ / / /    [F]/ /    [C]/ /    
[F]/ /     [C]/ /    [G]/ /    [C]/
______________________________






















