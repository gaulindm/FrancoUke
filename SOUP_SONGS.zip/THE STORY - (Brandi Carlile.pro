{title:THE STORY}
{subtitle:(Brandi Carlile}







All of these [C]lines across my face             
Tell you the [G]story of who I am
So many [Am]stories of where I've been
And how I [F]got to where I am          
But these [C]stories don't mean [G]anything
When you've [Am]got no one to [F]tell them to
It's [C]true [G]I was made for [C]you
I climbed across the mountain tops
Swam all a[G]cross the ocean blue
I crossed all the [Am]lines and I broke all the rules
But baby I [F]broke them all for you
Because [C]even when I [G]was flat broke
You [Am]made me feel like a [F]million bucks
You [C]do [G]I was made for [C]you
You see the [C]smile that's on my mouth
It's hiding the [G]words that don't come out
And all of my [Am]friends who think that I’m blessed
They don't [F]know my head is a mess
No [C]they don’t know who I [G]really am
And [Am]they don't know what
[F]I’ve been through like you [C]do
And [G]I was made for [C]you
All of these lines across my face
Tell you the [G]story of who I am
So many [Am]stories of where I've been
And how I [F]got to where I am         
But these [C]stories don't mean [G]anything    
When you've [Am]got no one to [F]tell them to
It's [C]true [G]I was made for [C]you

 
