{title:YELLOW SUBMARINE}
{subtitle:(Lennon/McCartney)}
{subtitle: 4/4   Key of D}
{metronome:  112}
{time:  3:30}


{c:"1234,123..."

{c:(Start note is B)}

[G]In the [D]town where [C]I was [G]born
[Em]Lived a [Am]man who [C]sailed to [D]sea
[G]And he [D]told us [C]of his [G]life
[Em]In the [Am]land of [C]subma[D]rines
[G]So we [D]sailed up [C]to the [G]sun
[Em]Till we [Am]found the [C]sea of [D]green
[G]And we [D]lived be[C]neath the [G]waves
[Em]In our [Am]yellow [C]subma[D]rine

{soc}
[G]We all live in a [D]yellow submarine
[D]Yellow submarine, [G]yellow submarine
[G]We all live in a ye[D]llow submarine 
[D]Yellow submarine, ye[G]llow submarine
{eoc}

[G]And our [D]friends are [C]all on [G]board
[Em]Many [Am]more of them [C]live next [D]door
[G]And the [D]band be[C]gins to [G]play  {c:(3,4)}

{c:kazoo}
[G]{c:(1234,1234)}

{soc}
[G]We all live in a [D]yellow submarine
[D]Yellow submarine, [G]yellow submarine
[G]We all live in a [D]yellow submarine 
[D]Yellow submarine, [G]yellow submarine
{eoc}
 
[G/] [D/]  {c:(3,4)} [C/]   [G/]  {c:(3,4)}
[Em/]  [Am/]  {c:(3,4)} [C/]  [D/] {c:(3,4)}
[G/] [D/]  {c:(3,4)} [C/]   [G/]  {c:(3,4)}
[Em/]  [Am/]  {c:(3,4)} [C/]  [D/] {c:(3,4)}


[G]As we [D]live a [C]life of [G]ease
[Em]Every[Am]one of us has [C]all we [D]need
[G]Sky of [D]blue and [C]sea of [G]green
[Em]In our [Am]yellow [C]subma[D]rine
 
[G]We all live in a [D]yellow submarine
[D]Yellow submarine, [G]yellow submarine
[G]We all live in a ye[D]llow submarine 
[D]Yellow submarine, ye[G]llow submarine
[G]We all live in a [D]yellow submarine
[D]Yellow submarine, [G]yellow submarine
[G]We all live in a ye[D]llow submarine 
[D]Yellow submarine, ye[G]llow submarine
