{title:HUSH LITTLE BABY   }
{subtitle:tab    4/4      Key of C}
{subtitle:(Graeme Revell)}
{metronome: 116}
{time: 2:00}

{c:INTRO: Very softly}
[C]/ / / /   / / / /

[C]Hush, little baby, [G7]don't say a word
Papa's gonna buy you a [C]mockingbird

[C]And if that mocking[G7]bird won't sing
Papa's gonna buy you a [C]diamond ring

[C]And if that diamond [G7]ring turns brass
Papa's gonna buy you a [C]looking glass

[C]And if that looking [G7]glass gets broke
Papa's gonna buy you a [C]billy goat

[C]And if that billy [G7]goat won't pull
Papa's gonna buy you a [C]cart and bull

[C]And if that cart and [G7]bull fall down,
You'll still be the sweetest little [C]baby in town
