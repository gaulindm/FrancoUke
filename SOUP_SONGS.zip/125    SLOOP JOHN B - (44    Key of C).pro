

{t:125 SLOOP JOHN B  }
{subtitle:(4/4    Key of C)}       
{subtitle:(Brian Wilson)}
{time:4:26}
{metronome: 136}





[C]/ / / /     [G7]/ / / /     
[C]/ / / /    / / / /

We [C]come on the sloop [F/]John [C]B
My grandfather [F/]and [C]me 
Around Nassau town we did [G7]roam 
Drinking all [C]night   [C7]        
Got into a [F]fight (yeah, yeah)
Well I [C]feel so broke up [G7]         
I want to go [C]home 

{c:CHORUS}
{soc} 
     So [C]hoist up the John [F/]B’s [C]sail
     See how the main [F/]sail [C]sets 
     Call for the captain ashore 
     Let me go [G7]home 
     Let me go [C]home [C7]
     I wanna go [F]home, (yeah yeah) 
     Well I [C]feel so broke up [G7]       
     I wanna go [C]home 
{eoc}

The [C]first mate he [F/]got [C]drunk
And broke in the cap[F/]tain’s [C]trunk 
The constable had to come and take him a[G7]way 
Sheriff John [C]Stone [C7]      
Why don’t you leave me a[F]lone, (yeah yeah) 
Well I [C]feel so broke up [G7]      
I wanna go [C]home   

{soc} 
     So [C]hoist up the John [F/]B’s [C]sail
     See how the main [F/]sail [C]sets 
     Call for the captain ashore 
     Let me go [G7]home 
     Let me go [C]home [C7]
     I wanna go [F]home, (yeah yeah) 
     Well I [C]feel so broke up [G7]      
     I wanna go [C]home 
{eoc}

The [C]poor cook he caught [F/]the [C]fits
And threw away all [F/]my [C]grits 
And then he took and he ate up all of my [G7]corn 
Let me go [C]home [C7]    
Why don’t they let me go [F]home, (yeah yeah) 
This [C]is the worst trip [G7]      
I’ve ever been [C]on    

{soc} 
     So [C]hoist up the John [F/]B’s [C]sail
     See how the main [F/]sail [C]sets 
     Call for the captain ashore
     Let me go [G7]home 
     Let me go [C]home [C7]
     I wanna go [F]home, (yeah yeah) 
     Well I [C]feel so broke up [G7]      
     I wanna go [C]home 

     So [C]hoist up the John [F/]B’s [C]sail
     See how the main [F/]sail [C]sets 
     Call for the captain ashore 
     Let me go [G7]home 
     Let me go [C]home [C7] 
     I wanna go [F]home, (yeah yeah) 
     Well I [C]feel so broke up 
     [G7]      I wanna go [C]home  
     Well I [C]feel so broke up 
     [G7]      I wanna go [C]home  
     {c:(234,1)} [G7/]  [C/]
{eoc}

________________________________________










