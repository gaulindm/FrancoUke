

{title:115  RAINBOW CONNECTION}
{subtitle:(3/4  Key of C)}
{subtitle:(Paul Williams & Kenny Ascher)}
{time:3:54}
{metronome: 114}

 




[C]/ / /    [F]/ /   {c:(rest)}  [C]/ / /    [F]/ /   {c:(rest)}

[C]Why are there [Am]so many 
[Dm]Songs about [G7]rainbows
And [C]what’s on the [Am]other [Dm]side  [G7]
[C]Rainbows are [Am]visions, but [Dm]only il[G7]lusions
And [C]rainbows have [Am]nothing to [F]hide  
So we’ve been told and some 
Choose to believe it
[Em7]I know they’re wrong, wait and [E7]see

{soc}
  [Dm]Some day we’ll [G7]find it
  The [Em7]rainbow co[A7]nnection
  The [Dm]lovers, the [G7]dreamers and 
  [C///]me  {c:F  / /   (rest)   C  / / /    F  / /   (rest)}
{eoc}

[C]Who said that [Am]every wish 
Would [Dm]be heard and [G7]answered
When [C]wished on the [Am]morning [F]star  [G7]
[C]Somebody [Am]thought of that 
And [Dm]someone be[G7]lieved it
[C]Look what it’s [Am]done so [F]far
What’s so amazing that 
Keeps us stargazing
And [Em7]what do we think we might [E7]see

{soc}
  [Dm]Some day we’ll [G7]find it 
  The [Em7]rainbow co[A7]nnection
  The [Dm]lovers, the [G7]dreamers and [C]me {c:(2,3)}

  [G]All of us [Am]under its [C]spell
  We [F]know that it’s [C]probably [Dm]ma…[Gaug]gic..
{eob}

[C]Have you been [Am]half asleep 
And [Dm]have you heard [G7]voices
[C]I’ve heard them [Am]calling my [Dm]name  [G7]
[C]Is this the [Am]sweet sound 
That [Dm]calls the young [G7]sailors
The [C]voice might be [Am]one and the [F]same  
I’ve heard it too many times to ignore it
It’s [Em7]something that I’m s’posed to [E7]be

{soc}
     [Dm]Someday we’ll [G7]find it 
     The [Em7]rainbow co[A7]nnection
     The [Dm]lovers, the [G7]dreamers and [C]me      

     [G]Laa da-da [Am]dee da-da [C]doo
     La [F]daa da-da [G]da dee da [C/gliss]doo
{eoc}

{define: Gaug 0 0 3 3 2 }
________________________________








