
{title:CHATTAHOOCHEE }
{subtitle:(4/4    Key of F)}   
{subtitle: (Alan Jackson and Jim McBride)}
{time: 2:00}
{metronome:180}


[F]/ / / /     [C]/ / / /      
[F]/ / / /      [C]/ / / 

Well [F]way down yonder on the Chattahoochee
It gets hotter than a [C]hoochee-[F]koochee
We laid rubber on the Georgia asphalt
We got a little crazy but we [C]never got [F]caught
   
[Bb]Down by the river on a Friday night
A [F]pyramid of cans in the [C]pale moon[F]light
[Bb]Talkin' 'bout cars and dreamin' 'bout women
[G]Never had a plan, just a[C]livin' for the minute

{soc} 
 Yeah [F]way down yonder on the 
 Chattahoochee
 Never knew how much that muddy water 
 [C]Meant to [F]me
 But I learned how to swim 
 And I learned who I was
 A lot 'bout living and a [C]little 'bout [F]love
{eoc}

[Bb]/ / / /    / / / /     
[F]/ / / /     [C]/ /      [F]/ /     
[Bb]/ / / /    / / / /     
[G]/ / / /    [C]/ / / /    / / /

Well we [F]fogged up the window in my ole Chevy
I was willin' but [C]she wasn't [F]ready
So I settled for a burger and a grape snow cone 
I dropped her off early but I [C]didn't go [F]home
 
[Bb]Down by the river on a Friday night
A [F]pyramid of cans in the [C]pale moon[F]light
[Bb]Talkin' 'bout cars and dreamin' 'bout women
[G]Never had a plan, just a[C]livin' for the minute

{soc} 
 Yeah [F]way down yonder on the 
 Chattahoochee
 Never knew how much that muddy water 
 [C]Meant to [F]me
 But I learned how to swim 
 And I learned who I was
 A lot 'bout living and a [C]little 'bout [F]love
{eoc}

{c:OUTRO (slower) }
A lot 'bout living and a [C]little 'bout [F/]love

________________________________________
















