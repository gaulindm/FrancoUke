{title:FUNNEL OF LOVE}
{subtitle:4/4      Key of Gm}
{subtitle: (Wanda Jackson))
{time: 3:40 }
{metronome:  }

[Gm]/ / / /    [Bb]/ / / /
[D7]/ / / /   [Gm]↑Ooo ↓ooo ↓ooo {c:(234)}  

[Gm]Here I go, falling [Bb]down, down, down
My [Gm]mind is a blank
My [C]head is spinning a[Bb]round and around
As I go [D7]deep into the funnel of [Gm]love {c:(234,1234)}
{c:                                                  (↑Ooo ↓ooo ↓ooo)}

[Gm]It's such a crazy, [Bb]crazy feeling
I get [Gm]weak in the knees
My [C]poor old head is a [Bb]reelin'
As I go [D7]deep into the funnel of [Gm]love {c:(234,1234)}
{c:                                                  (↑Ooo ↓ooo ↓ooo)}

{soc}
  I [Gm]tried and I tried, to [Bb]run and hide
  I [Gm]even tried to ru-u-un a[Bb]wa-a-ay
  Ya [Gm]just can't run from the [Bb]funnel of love
  [D7/]      It's gonna get ya some[Gm]day {c:(ah-oo, ah-oo)}
{eoc}

[Gm]It's such a crazy, [Bb]crazy feeling
I get [Gm]weak in the knees
My [C]poor old head is a [Bb]reelin'
As I go [D7]deep into the funnel of [Gm]love {c:(234,1234)}
{c:                                                  (↑Ooo ↓ooo ↓ooo)}

{soc}
  I [Gm]tried and I tried, to [Bb]run and hide
  I [Gm]even tried to ru-u-un a[Bb]wa-a-ay
  Ya [Gm]just can't run from the [Bb]funnel of love
  [D7/]       It's bound to get you some[Gm]day  {c:(ah-oo, ah-oo)}
{eoc}
 
[Gm]Here I go, going [Bb]down, down, down
My [Gm]mind is a blank
My [C]head is spinning a[Bb]round and around
As I go [D7]deep into the funnel of [Gm]love {c:(234,1234)}
{c:                                                  (↑Ooo ↓ooo ↓ooo)}
[D7]Deep into the funnel of [Gm]love {c:(234,1234)}
{c:                                     (↑Ooo ↓ooo ↓ooo)}
[D7]Deep into the funnel of [Gm/]love