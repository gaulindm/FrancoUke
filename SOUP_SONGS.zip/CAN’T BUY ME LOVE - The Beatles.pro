{title:CAN’T BUY ME LOVE}
{subtitle:The Beatles}
{metronome:  174}
{time:2:00}
 






{c:Lynda counts} 
{c:”1234,1 (first note is C) }

Can't buy me [Em]love, [Am]oh 
[Em]Love, [Am]oh, can't buy me [Dm]love [G7]oh 
I'll [C7]buy you a diamond ring my friend 
If it makes you feel alright 
I'll [F]get you anything my friend
If it [C7]makes you feel alright
Cause [G7]I don't care too [F/]    much for money 
[G]Money can't buy me [C]love 

I'll [C7]give you all I've got to give 
If you say you love me too 
I [F]may not have a lot to give 
But what I [C7]got I'll give to you  
[G7]I don't care too [F/]   much for money 
[G]Money can't buy me [C]love 

Can't buy me [Em]love, [Am]oh
[C7]Everybody tells me so 
Can't buy me [Em]love, [Am]oh
[Dm]No, no, no, [G7]no
 
[C7]Say you don't need no diamond rings 
And I'll be satisfied  
[F]Tell me that you want the kind of things 
That [C7]money just can't buy  
[G7]I don't care too [F/]   much for money 
[G]Money can't buy me [C]love 

Can't buy me [Em]love [Am]oh 
[C7]Everybody tells me so 
Can't buy me [Em]love [Am]oh
[Dm]No, no, no, [G7]no 

[C7]Say you don't need no diamond rings 
And I'll be satisfied  
[F]Tell me that you want the kind of things 
That [C7]money just can't buy  
[G7]I don't care too [F/]   much for money 
[G]Money can't buy me [C]love 

Can't buy me [Em]love, [Am]oh [Em]love [Am]oh 
Can't buy me [Dm]love, [G7]oh [C/gliss]oh… 