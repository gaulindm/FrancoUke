{t:GOODNIGHT SWEETHEART }
{subtitle:(4/4    Key of G)}
{subtitle:(Calvin Carter and James “pookie” Hudson)}
{time: 3:10}
{metronome: 90}






{c:Intro: }   
[G]/ /     [D7]/ /     [G]/ / / /  

{c:CHORUS}
{soc}
[G]Goodnight, sweet[Em7]heart, well it's [Am7]time to [D7]go
[G]Goodnight, sweet[Em7]heart, well it's [Am7]time to [D7]go
[G]    I hate to [G7]leave you, I [C]really must [Cm7]say
Good[G]night, sweet[D7]heart, good[G]night
{eoc}

{soc}
[G]Goodnight, sweet[Em7]heart, well it's [Am7]time to [D7]go
[G]Goodnight, sweet[Em7]heart, well it's [Am7]time to [D7]go
[G]    I hate to [G7]leave you, I [C]really must [Cm7]say
Good[G]night, sweet[D7]heart, good[G]night
{eoc}

Well, it's [C]    three o'[Cm]clock in the [G]morning, [G7]
And [C]baby, I just [Cm]can't get [G]right, [G7]
Well, I [C]hate to leave you, [Cm]baby
I [G]don't mean [E7]maybe, be[A7]cause I love you [D7]so

{soc}
[G]Goodnight, sweet[Em7]heart, well it's [Am7]time to [D7]go
[G]Goodnight, sweet[Em7]heart, well it's [Am7]time to [D7]go
[G]    I hate to [G7]leave you, I [C]really must [Cm7]say
Good[G]night, sweet[D7]heart, good[G]night
{eoc}

Well your [C]mother [Cm]and your [G]father [G7]
They won't [C]like it if I [Cm]stay here too [G]long [G7]
Well, I [C]hate to leave you, [Cm]baby
I [G]don't mean [E7]maybe, you [A7]know I hate to [D7]go

{soc}
[G]Goodnight, sweet[Em7]heart, well it's [Am7]time to [D7]go
[G]Goodnight, sweet[Em7]heart, well it's [Am7]time to [D7]go
[G]    I hate to [G7]leave you, I [C]really must [Cm7]say
Good[G]night, sweet[D7]heart, good[G]night
Good[G]night, sweet[D7]heart, good[G]night
{eoc}

{c:Slowly..}
    Good[G]night, sweet[D7]heart… good[G]ni…ght
{eoc}

{define: D7 0 2 0 2 0}
