{title:ON WE GO }
{subtitle: 4/4      Key of Am}
{subtitle:(Nancy McCallion of The Mollys)}
{time:3:04}
{metronome: 188}







{c:INTRO:}


[Am]/ /    [G]/ /   [Am]/ / / /  
[Am]/ /    [G]/ /   [Am]/ / / /  

There [Am]was an older [G]woman and there 
[Am]was an old [G]man
They [Am]lived u[G]pon the [C]high [G]road
[Am]He once [G]sat as a [Am]jockey for his [G]pay
And [Am]she was her [G]mother's [Am]darlin', oh

{c:CHORUS}
And [Am]on we go, and on we [G]go
[Am]Can you recall the day we married, oh?
On we go, and on we [G]go
[Am]Wouldn't you be [G]frightened to [Am]die alone?
Come a little [G]closer to me, [Am]darlin', oh

[Am]/ /    [G]/ /   [Am]/ / / /  
[Am]/ /    [G]/ /   [Am]/ / / /

[Am]’Come with [G]me, ye [Am]silly old [G]man
[Am]’Cozy [G]as a [C]codfish, [G]oh
'I [Am]never seen [G]anyone [Am]sour as [G]you
'At [Am]least not [G]after [Am]breakfast, oh'

She [Am]grabbed the [G]old man [Am]by the [G]hand
She [Am]led him [G]'cross a [C]moonlit [G]night
She [Am]took him [G]to the [Am]public [G]house
And [Am]filled him [G]full a'[Am]whisky, oh

{soc}
And [Am]on we go, and on we [G]go
[Am]Can you recall the day we married, oh?
On we go, and on we [G]go
[Am]Wouldn't you be [G]frightened to [Am]die alone?
Come a little [G]closer to me, [Am]darlin', oh
{eoc}

[Am]/ /    [G]/ /   [Am]/ / / /  
[Am]/ /    [G]/ /   [Am]/ / / /

And [Am]on the [G]way back [Am]home from [G]town
[Am]Oh, [G]oh, my [C]darlin', [G]oh
She [Am]pushed him in the [G]water 
And she [Am]held him [G]down
[Am]Can you re[G]call the day we [Am]married, oh?

{soc}
And [Am]on we go, and [C]on we [G]go
[Am]Can you recall the day we married, oh?
On we go, and on we [G]go
[Am]Wouldn't you be [G]frightened to [Am]die alone?
Come a little [G]closer to me, [Am]darlin', oh
{eoc}

[Am]/ /    [G]/ /   [Am]/ / / /  
[Am]/ /    [G]/ /   [Am]/ / / /

There [Am]was an older [G]woman and there 
[Am]was an old [G]man
They [Am]lived u[G]pon the [C]high [G]road… {c:(pause)}

{c:(slow)}[Am]He once [G]sat as a 
[Am]Jockey for his [G]pay

And {c:(Speed back up)}
[Am]she was her [G]mother's [Am]darlin', oh

{soc}
And [Am]on we go, and on we [G]go
[Am]Can you recall the day we married, oh?
On we go, and on we [G]go
[Am]Wouldn't you be [G]frightened to [Am]die alone?
Come a little [G]closer to me, [Am]darlin', oh

[Am]Come a little [G]closer to me, [Am]darlin', oh
[Am]Come a little [G]closer to me, [Am]darlin', oh
{c:(no ukes)}Come a little closer to me, darlin', oh
{eoc}