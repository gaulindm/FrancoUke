{title:WICKED GAME}
{subtitle:(Chris Issac)}
{time:4:44}
{metronome: 112}








[Am]/ / / /   [G]/ / / /       
[D]/ / / /   / / / /     

[Am]/ / / /   [G]/ / / /       
[D]/ / / /   / / / / 

[Am]/ / / /   [G]/ / / /       
[D]/ / / /   / / / / 

[Am]/ / / /   [G]/ / / /       
[D]/ / / /   / / / / 


The [Am]world was on fire and 
[G]no one could save me but [D]you 
It's [Am]strange what desire will
 [G]make foolish lovers [D]do 


[Am]I never dreamed that 
I[G]'d meet somebody like y[D]ou
[Am]I never dreamed that
 I[G]'d love somebody like y[D]ou 
 
{soc}
No [Am]I~   [G]  don't want to fall in [D]love 
This world is only gonna break your heart

No [Am]I~   [G]  don't want to fall in [D]love 
This world is only gonna break your heart

With y[Am]ou    [G]      [D]   {c:(234,1234)}   


With y[Am]ou    [G]      [D]   {c:(234,1234)}
{eoc}


[Am] What a wicked [G]game to play 
[D]   To make me feel this way
[Am] What a wicked [G]thing to do  
[D]   To make me dream of you

[Am] What a wicked [G]thing to say 
[D]   You never felt this way
[Am] What a wicked [G]thing to do  
[D]   To make me dream of you and
 
[Am]I~     [G]    don't want to fall in [D]love 
This world is only gonna break your heart

No [Am]I~     [G]    don't want to fall in [D]love 
This world is only gonna break your heart

With y[Am]ou    [G]       [D] {c:(234,1234)}

[Am]   [G]       [D]  {c:(234,1234)}

[Am]/ / / /   [G]/ / / /       
[D]/ / / /   / / / /     

 
The [Am]world was on fire and 
[G]No one could save me but [D]you 
It's [Am]strange what desire will 
[G]make foolish lovers [D]do

[Am]I never dreamed that 
I[G]'d love somebody like y[D]ou 
[Am]I never dreamed that 
I[G]'d lose somebody like y[D]ou 
 
No [Am]I~     [G]    don't want to fall in [D]love 
This world is only gonna break your heart
No [Am]I~     [G]    don't want to fall in [D]love 
This world is only gonna break your heart
With y[Am]ou    [G]     {c:(234)} 

[D]  This world is only gonna break your heart
With y[Am]ou    [G] 
[D]  This world is only gonna break your heart
No [Am]Iiii...      [G]   {c:(234)}
[D]  This world is only gonna break your heart
[Am] {c:(234)}   [G]   {c:(234)}
[D]  This world is only gonna break your heart
 
[Am/]Nobody       loves no o[D/]ne
