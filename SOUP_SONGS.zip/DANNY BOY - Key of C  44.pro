{title:DANNY BOY}
{subtitle:Key of C  4/4}


[C/]

Oh Danny [C]boy,    the [C7]pipes
The pipes are [F]calling
From glen to [C]glen and d[Am]own 
The mountain [D7]side [G]
The summer's [C]gone and 
[C7]All the roses [F]falling [Fm]
'Tis you, 'tis [C]you    
Must [Dm]go and [G]I must [C]bide
 
[G]But [Am]come [G]ye   [C]back 
When [F]summer's in the [C]meadow
[G]Or [Am]when [G]the v[Am]alley's [F]hushed 
And [C]white with [D7]snow [G]
And I'll be [C]here in [F]sunshine 
Or in s[C]ha-[Am]dow [Fm]
Oh Danny [C]boy, oh Danny [Dm]boy 
I [G]love you [C]so [G7]
 
But if he [C]come and 
[C7]All the flowers [F]dying
And I am [C]dead, as [Am]dead 
I well may [D7]be [G]
You'll come and [C]find 
The [C7]place where I am [F]lying [Fm]
And kneel and [C]say   
An [Dm]Avé [G]there for [C]me 
 
[G]And[Am] I [G]shall [C]feel
Though [F]soft you tread a[C]bove me
[G]And [Am]then [G]my [Am]grave will [F]warmer
[C]Sweeter [D7]be [G]
For you will [C]bend and [F]tell me 
That you [C]lo- [Am]ve    [Fm/]me

And I shall [C]sleep in peace 
U[Dm]ntil you [G]come to [C/]me
{c:Singers hold the last note}