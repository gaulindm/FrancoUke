

{title:077  HOUSE OF GOLD    }
{subtitle:(Twenty-One Pilots)}
{subtitle:  4/4      Key of C}
{metronome:210}
{time:3:40}


{c:No bass or percussion to start}
{c:Tambourine later}

{c:Count in is “1...2...123”}

She [Z]asked me, “Son, when I grow old
Will you buy me a house of gold?
And when your father turns to stone 
Will you take care of me?”
   
{soc}
   She [C]asked me, “Son, when [F]I grow old
   Will [Am]you buy me a [G]house of gold?
   And [C]when your father [F]turns to stone  
   Will [C]you take [G]care of [C]me?” {c:(234,1234)}
{eoc} 


{sob}
   [F]I will [A7]make you 
   [Dm]Queen of [Bbm]everything you [F]see
   I’ll put you on the [C]map 
   I’ll cure you of di[F]sease   
   {c:(234,1234, }[C]{c:1234,123)}
{eob}
 
{c:(Add bass, and simple drum to beats 1 and 3)}
Let’s [C]say we up and [F]left this town
And [Am]turned our future [G]upside down
We’ll [C]make pretend that [F]you and me
Lived [C]ever [G]after [C]happily {c:(234,1234,123)}


{c:(add *tambourine on beat 2)}
{soc}
   She [C]asked*  me, “Son,*  when [F]I*  grow old*
   Will [Am]you*  buy me*  a [G]house*  of gold?*
   And [C]when*  your fa* ther [F]turns*  to stone*
   Will [C]you*  take [G]care*  
   Of [C]me?” {c:(}[*]{c:234,1}[*]{c:234)}

{c:(tambourine on beats 2 and 4)}
   [F]I will [A7]make you 
   [Dm]queen of [Bbm]everything you [F]see
   I’ll put you on the [C]map 
   I’ll cure you of di[F]sease  {c:(234,1234)}
   [C]Oh…
{eoc}

{c:(percussion ramps up)}
And [C]since we know that [F]dreams are dead  
And [Am]life turns plans up [G]on their head  
[C]I will plan to [F]be a bum  
So [C]I just [G]might  
Be[C]{soh}come someone{eoh} {c:(234,1234,123)}  
 
{soc}
   She [C]asked me, “Son, when [F]I grow old
   Will [Am]you buy me a [G]house of gold?
   And [C]when your father [F]turns to stone  
   Will {soh}[C]you take [G]care of 
   [C]Me?”{eoh} {c:(234,1234)}
{eoc}

{c:(Stop all percussion)}
[F/]I will [A7/]make you 
[Dm/]Queen of [Bbm/]everything you [F/]see
I’ll put you on the [C/]map 
I’ll cure you of di[F/]sease
 

__________________________________













     
