{title:YOU’RE MY BEST FRIEND}
{subtitle:     4/4     Key of F }
{subtitle:  John Deacon  (Queen)}
{metronome: 130 }
{time:2:42}

{c:turn your tablet HORIZONTAL}

{c:TABS and OUTRO start at *}


{c:INTRO: TABS only for INTRO}

{sot}
(1st time no chords)     
A|- 3 - - - - 3 - - - -
E|- - - - - - - - - - -
C|- - 0 0 0 0 - 0 0 0 0


(add) Dm/  Dm/C/
A|- 3 - - - - 3 - - - -
E|- - - - - - - - - - - 
C|- - 0 0 0 0 - 0 0 0 0
{eot}
    
[Dm]Oooh you make me [C]live
What[Dm]ever this world can [C]give to me 
It's [Dm]you you're all I [C]see  

[Dm]Oooh you make me [C]live now honey 
[Dm]Oooh you make me [*C//]live    [G//]     [Am]      

{sot}
A|- 3 3 2 3 2 0 -
{eot}

Aw you're the [D]best friend 
That [F]I ever [G]had 
I’ve [C]been with [G]you such a [Am]long time

You're my [D]sunshine 
And I [F]want you to [G]know 
That my [E7]feelings are [Am]true 
I [G]really lo-[F]ove you… [Fm/]Oooh… 
Aw, you're my [*C]best friend {c:(34,1234)}

{sot}
A|- 3 - - - - 3 - - - - 
E|- - - - - - - - - - -
C|- - 0 0 0 0 - 0 0 0 0
{eot}

[Dm]Ooo you make me [C]live, ooo [G]I’ve been [Am]wa…ndering 
{c:(Ooo you make me li...      i…          ive..     round)} 
   
[F]Still come back to [Fm]you
{c:(Ooo…              still come back to)}

In [G]rain or [E7]shine you've [Am]stood by me [D7]girl
{c:  (you…   ooo...          ooo…         girl)}

I’m [G6]haa..ppy at [G]home, you're my [*C]best friend {c:(34,1234)}
{c:(I’m }[G6]{c:hap↑py… ↓}[G]{c:hap-py -at -ho-}[*C]{c:ome  (234,1234))}              

{sot}
A|- 3 - - - - 3 - - - - 
E|- - - - - - - - - - -
C|- - 0 0 0 0 - 0 0 0 0
{eot}

[Dm]Oooh you make me [C]live 
When[Dm]ever this world is [C]cruel to me     
I got [Dm]you to help me for[C]give {c:(Oo oo ↑oo)} 

[Dm]Ooo you make me [C]live now honey 
[Dm]oooh you make me [*C//]live    [G//]      [Am]      

{sot}
A|- 3 3 2 3 2 0 -
{eot}

Aw, you're the [D]first one
When [F]things turn out [G]bad   
You [C]know I'll [G]never be [Am]lonely 
You’re my [D]only one and I [F]love the [G]things
I really ↑[Am]love the [G]things that [F]you do 
[Fm/]Oooo, aw, you're my [*C]best friend {c:(34,1234)}

{sot}
A|- 3 - - - - 3 - - - - 
E|- - - - - - - - - - -
C|- - 0 0 0 0 - 0 0 0 0
{eot}

[Dm]Ooo you make me [C]live  [G]/ /   [Am]/ / / /   

[F]/ / / /    [Fm]/ / / /    [G]/ /   

 [E7]/ /    [Am]/ /    [D7]/ /

I'm  [G6]haa..ppy at [G]home, you're my [C]best friend  {c:(34,1234)}
{c:(I’m }[G6]{c:hap↑py… ↓}[G]{c:hap-py  -at  -ho-}[C]{c:ome  (234,1234)}

{c:(}[Dm/]{c:1,2)}  Aw… {c:C / / / /}
{c:(}[Dm]{c:1,2)} Aw, you’re my [C]best friend  
[Dm]Oooh, you make me [C]live {c:(Oo oo ↑oo)}
[Dm]Oooh, you’re {soh}my{eoh} best {soh}[*C]friend{eoh}    

{c:OUTRO: (on the Cmaj7, do a fast up-down)} 
[C]/ / /    [Cmaj7]/    [C]/ / /    [Cmaj7]/ 
[C]/ / /    [Cmaj7]/    [C]/

{define: D7 0 2 0 2 0 }
