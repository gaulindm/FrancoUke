

{title:003 JAMBALAYA    }
{subtitle:(4/4     Key of C)}
{subtitle:(Hank Williams)}
{time:3:41}
{metronome: 178}
 
 
{c:KAZOO SONG!}



{c:INTRO:}   
[C]/ / / /      [G7]/ / / /      
[C]/ / / /    / /

Goodbye [C]Joe, me gotta go, me oh [G7]my oh
Me gotta go pole the pirogue down the [C]bayou  
My Yvonne, the sweetest one, me oh [G7]my oh
Son of a gun, we'll have big fun on the [C]bayou    

{soc}
Jamba[C]laya and a crawfish pie and fillet [G7]gumbo
'Cause tonight I'm gonna see my ma chere a[C]mie-o
Pick guitar, fill fruit jar and be [G7]gay-o
Son of a gun, we'll have big fun on the [C]bayou
{eoc}

Thibo[C]daux, Fontaineaux, the place is [G7]buzzin'  
Kinfolk come to see Yvonne by the [C]dozen
Dress in style, go hog wild, me oh [G7]my oh
Son of a gun, we'll have big fun on the [C]bayou
   
{soc}
Jamba[C]laya and a crawfish pie and fillet [G7]gumbo
'Cause tonight I'm gonna see my ma chere a[C]mie-o
Pick guitar, fill fruit jar and be [G7]gay-o
Son of a gun, we'll have big fun on the [C]bayou
{eoc}

{c:INSTRUMENTAL: KAZOO}
Thibo[C]daux, Fontaineaux, the place is [G7]buzzin'  
Kinfolk come to see Yvonne by the [C]dozen
Dress in style, go hog wild, me oh [G7]my oh
Son of a gun, we'll have big fun on the [C]bayou

{c:SING}
{soc}
Jamba[C]laya and a crawfish pie and fillet [G7]gumbo
'Cause tonight I'm gonna see my ma chere a[C]mie-o
Pick guitar, fill fruit jar and be [G7]gay-o
Son of a gun, we'll have big fun on the [C]bayou
{eoc}

Son of a [G7]gun, we'll have big 
Fun on the [C]bayou
Son of a [G7]gun, we'll have big 
Fun on the [C]bayou [G7/][C/]

__________________________________









