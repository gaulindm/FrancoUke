

{title:C18: SOUP CHRISTMAS MEDLEY          }
{time:5:15}
{metronome:146}



[C]/ / / /   / / /   (Christmas bells only) }

Oh, the [C]weather outside is frightful
But the [G]fire is so de[G7]lightful 
And [Dm]since we've no [A7]place to [Dm]go 
Let it [G]snow, let it [G7]snow, let it [C]snow

Oh, it [C]doesn’t show signs of stopping
And I’ve [G]brought some corn for [G7]popping 
The [Dm]lights are turned [A7]way down [Dm]low 
Let it [G]snow, let it [G7]snow, let it [C]snow

When we [G]finally kiss good night
How I [D7]hate going out in the [G]storm 
But if you really hold me tight 
[A7]All the way [D7]home I'll be [G]warm [G7]

Oh, the [C]fire is slowly dying
And my [G]dear we’re still good[G7]bye-ing 
But as [Dm]long as you [A7]love me [Dm]so
Let it [G]snow, let it [G7]snow
let it [C]snow {c:(234,}[G]{c:1234) a bit faster}


You [G]better watch out, you [C]better not cry 
You [G]better not pout, I'm [C]telling you why 
[G]Santa Claus is [D7]coming to [G]town {c:(234,123)}

He's [G]making a list, he's [C]checking it twice
He’s [G]gonna find out who's [C]naughty or nice 
[G]Santa Claus is [D7]coming to [G]town {c:(234,}[G7]{c:123)}

He [C]sees you when you're sleeping 
He knows when you're awake 
He [A7]knows if you've been [D7]bad or good
So be [A7]good for goodness [D7/]sake    [D7/]Oh

You [G]better watch out, you [C]better not cry
You [G]better not pout, I'm [C]telling you why
[G]Santa Claus is [D7]coming to [G]town {c:(234,1234)}


{c:(Speed up, Voice goes down a bit}
[G]Jingle bells, jingle bells, jingle all the way 
[C]Oh, what fun it [G]is to ride 
in a [A]one-horse open [D/]sleigh, [D7/]hey!
[G]Jingle bells, jingle bells, jingle all the way
[C]Oh, what fun it [G]is to ride 
in a [D7]one-horse open [G]sleigh {c:(234)(slow down)}  



[G]I’m dreaming of a [Am]white [D7]Christmas 


[C]   Just like the [D7]ones I used to [G]know 


Where the tree tops [G7]glisten and [C]children [Cm]listen 


To [G]hear [Em]sleigh bells in the [Am]snow [D7]




[G]I’m dreaming of a [Am]white [D7]Christmas 


[C]   With every [D7]Christmas card I [G]write 


May your days be [G7]merry and [C]bright [Cm] 


And may [G]all your [Am]Christmases be [G]white {c:(234,1234)  speed up}


[G]Rocking around the Christmas tree 
at the [D7]Christmas party hop 
Mistletoe hung where you can see 
every couple tries to [G]stop


Rocking around the Christmas tree
let the [D7]Christmas spirit ring
Later we'll have some pumpkin pie 
and we'll do some carol[G]ling 


[C]You will get a sentimental 
[Bm7]feeling when you hear 
[Em]Voices singing, "Let's be jolly 
[A7/]Deck the halls with [D7/]boughs of holly"

[G]Frosty the Snow Man was a [C]jolly happy [G]soul  With a [C]corn-cob pipe and a [G]button nose 
and two [C]eyes made [D7]out of [G]coal

[G]Frosty the Snow Man is a [C]fairy tale they [G]say  He was [C]made of snow but the [G]children know 
how he [C]came to [D7]life one [G]day

There [C]must have been some [Bm7]magic in 
that [Am]old silk [D7]hat they [G]found 
 For [D]when they placed it on his [Bm7]head 
he be[A]gan to dance a[D7/]round

Fe[G/]liz Navi[C]dad    [D]      
Feliz Navi[G]dad  Feliz Navi[C]dad 
próspero [D]ano y felici[G]dad  [G/]

Feliz Navi[C]dad   [D]     
Feliz Navi[G]dad   Feliz Navi[C]dad 
próspero [D]ano y felici[G]dad  [G/]

We wanna wish you a [C]Merry Christmas  
[D]  we wanna wish you a [G]Merry Christmas   [Em]
We wanna wish you a [C]Merry Christmas 
From the [D]bottom of our [G]hearts  [G/]  

We wanna wish you a [C]Merry Christmas  
[D]  we wanna wish you a [G]Merry Christmas   [Em]
We wanna wish you a [C]Merry Christmas 
{c:(slow down)} from the [D]bottom of our [G]hearts  [G/]  














