{title: IKO IKO     }
{subtitle:(4/4   Key of F)}
{subtitle:(James Crawford, Barbara Hawkins)}
{subtitle:(Rosa Hawkins & Joan Johnson)}
{time: 2:10}
{metronome: 180}







{c:INTRO:}   
[C7]/ / / /      [F]/ / / /      
[C7]/ / / /      [F]/ / / /

[F]My grandma and your grandma
Sitting by the [C]fire
My grandma says to your grandma 
"I'm gonna [C7]set your flag on [F]fire"

{c:CHORUS}
{soc}
     Talkin' 'bout [F]hey now (hey now) 
     Hey now (hey now), iko iko wan [C]dey
     Jockomo feena ah nah ney
     [C7]Jockomo feena [F]ney
{eoc}

[F]Look at my king all dressed in red
Iko iko wan [C]dey
I bet you five dollars he'll kill you dead 
[C7]Jockomo feena [F]ney

{soc}
     Talkin' 'bout [F]hey now (hey now) 
     Hey now (hey now), iko iko wan [C]dey
     Jockomo feena ah nah ney
     [C7]Jockomo feena [F]ney
{eoc}

[F]My flag boy and your flag boy
Sitting by the [C]fire
My flag boy says to your flag boy
"I'm gonna [C7]set your flag on [F]fire"

{soc}
     Talkin' 'bout [F]hey now (hey now) 
     Hey now (hey now), iko iko wan [C]dey
     Jockomo feena ah nah ney
     [C7]Jockomo feena [F]ney
{eoc}

[F]See that guy all dressed in green 
Iko iko wan [C]dey
He's not a man, he's a loving machine 
[C7]Jockomo feena [F]ney

{soc}
     Talkin' 'bout [F]hey now (hey now) 
     Hey now (hey now), iko iko wan [C]dey
     Jockomo feena ah nah ney
     [C7]Jockomo feena [F]ney

     Talkin' 'bout [F]hey now (hey now) 
     Hey now (hey now), iko iko wan [C]dey
     Jockomo feena ah nah ney
     [C7]Jockomo feena [F]ney
     [C7]Jockomo feena [F]ney
     [C7]Jockomo feena [F/]ney  [C7/]  [F/]
{eoc}

