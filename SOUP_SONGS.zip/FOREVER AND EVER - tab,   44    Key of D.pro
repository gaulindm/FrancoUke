{title:FOREVER AND EVER }
{subtitle: tab,   4/4    Key of D}
{subtitle:(Royal Wood) }
{metronome: 200}
{time:3:00 }





{c:INTRO}
[D]/ / / /   / / / /   
[D7]/ / / /   / / / / 
[G]/ / / /   / / / /   
[G]/ / / /   / / / /

[D]  These two rivers [D7]meet, they run together
[G]  I will be with you, for worse or better
[D]  We'll keep travel[D7]ling, long as the sun lasts
[G]  'Cause my future met and married your past
[Em]When [D]the [A]stars, [D]fade to [G]black, 
[Em]I  [D]will [A/]say {c:(3 taps)}

{soc}
     [D]  Hey Hey Hey, [G]  I wanna [A]run with [D]you
     Hey Hey Hey, [G]  so let them [A]call us [Bm]fools
     Hey Hey Hey, [G]  I sing this [A]song to [D]prove
     For[G]ever and [A]ever and ever [D]          
     For[G]ever and [A]ever and ever [D]  
{eoc}

[D] Been quiet for so [D7]long, I didn't notice
[G]  Was lonely for someone I didn't know yet
[D]  But now I chase the [D7]moon to the horizon
[G]  And you are still the one  I've got my eyes on
[Em]When [D]the [A]stars, [D]fade to [G]black, 
[Em]I  [D]will [A/]say  {c:(3 taps}

{soc}
     [D]  Hey Hey Hey, [G]  I wanna [A]run with [D]you
     Hey Hey Hey, [G]  so let them [A]call us [Bm]fools
     Hey Hey Hey, [G]  I sing this [A]song to [D]prove
     For[G]ever and [A]ever and ever [D]          
     For[G]ever and [A]ever and ever [D]  
{eoc}

[Bm]How was I to [G]know? How was [D]I... How was [A]I
[Bm]Where this life would [G]go?  [A]Now forever

{soc}   
     [D]  Hey Hey Hey, [G]  I wanna [A]run with [D]you
     Hey Hey Hey, [G]  so let them [A]call us [Bm]fools
     Hey Hey Hey, [G]  I sing this [A]song to [D]prove
     For[G]ever and [A]ever and ever [D]         
     For[G]ever and [A]ever and ever [D]
     For[G]ever and [A]ever and ever [D/]
{eoc}



{tag: Shared by Lynda}