{title:THE MIDDLE}
{subtitle:}
 

[D]Hey, don't write yourself off y[A]et
It's only in your head you f[G]eel left out or looked down [D]on
Just try your b[D]est, try everything you c[A]an
And don't you worry what they t[G]ell themselves       
When you're a[D]way {c:(234)}  [D/]  [D/]  [D/]
 
{soc}                                          
  It just [D]takes some time
  Little girl you're in the middle [A]of the ride
  Everything, everything will [G]be just fine
  Everything, everything will [D]be alright (alright) {c:(234)}
 
[D]Hey, you know they're all the s[A]ame
You know you're doing better [G]on your own
So don't buy [D]in
Live right n[D]ow {c:(234,1)}   Yeah, just be yours[A]elf
It doesn't matter if it's go[G]od enough 
For someone [D]else  {c:(234)}  [D/] [D/] [D/]
                                         
It just takes some time, little girl you're in the middle [A]of the ride, everything,
Everything will [G]be just fine, everything, everything will [D]be alright (alright)
        N.C.  D                                           A
It just takes some time, little girl you're in the middle of the ride, everything,
Everything will [G]be just fine, everything, everything will [D]be alright (alright)
 
[Solo]
A    D
A    D
[G]A [D]
 
[Verse]
[D]Hey, don't write yourself off y[A]et.
It's only in your head you f[G]eel left out      or looked dow[D]n on.
Just do your b[D]est, do everything you c[A]an.
And don't you worry what the b[G]itter hearts     are gonna[D] say.
 

                                              
It just takes some time, little girl you're in the middle of the ride, everything,
Everything will [G]be just fine, everything, everything will [D]be alright (alright)
                                       
It just takes some time, little girl you're in the middle of   the ride, 
everything,
                                                    
Everything will be   just fine, everything, everything will be alright
X