{title:DREAM BABY  }
{subtitle:(4/4  Key of C)}
{subtitle:(Cindy Walker)}
{time: 2:45}
{metronome: 158}





{c:In brackets are background }
{c:harmonies on the E string}

{c:INTRO: }
[C7]/ / / /    / / / /

[C7]Sweet dream baby…
Sweet dream baby 
[F]Sweet dream baby 
[C7]How long must I [F]dream

{c:(ooh’s)}  
[C7] Dream baby got me dreamin' sweet dreams
The whole day through 
Dream baby got me dreamin' sweet dreams
Night time too 

{c:(ahh's)}   
[F] I love you and I'm dreaming of you
But that won't do 

{c:(ooh’s)}  
[C7]  Dream baby make me stop my dreamin' 
You can make my dreams come 
[F]True  {c:(234,1234)}

{c:(Sha la-la la)}     
[C7]Sweet dream baby…  
Sweet dream baby 
[F]Sweet dream baby 
[C7]How long must I {c:(ooh)} [F]dream

{c:(dream baby)}   
[C7] Dream baby got me dreamin' sweet dreams
The whole day through 
Dream baby got me dreamin' sweet dreams
Night time too 
[F] I love you and I'm dreaming of you 
But that won't do 
[C7] Dream baby make me stop my dreamin' 
You can make my dreams come 
[F]True  {c:(234,12)}

{c:OUTRO :}
{c:(ah’s)}       
Aww… [C7]sweet dream baby {c:(dream baby ah-huh-huh)} 
Sweet dream baby {c:(dream baby ah-huh-huh)} 
[F]Sweet dream baby {c:(dream baby ah-huh-huh) }
{c:(ooh)}       
[C7]How long must I [F]dream  
{c:(ah’s)}       
Aww… [C7]sweet dream baby {c:(dream baby ah-huh-huh)} 
Sweet dream baby {c:(dream baby ah-huh-huh)} 
[F]Sweet dream baby {c:(dream baby ah-huh-huh) }
{c:(ooh)}       
[C7]How long must I [F]dream  {c:(234)} [(F/)]
 
