

{title:C24: IT'S THE MOST WONDERFUL TIME OF THE YEAR}
{time:  3:00}


[G]/ [Em7]/ [Am7]/ [D7]/ 
It’s the [G] most [Em7] wonderful [Am7] time [D7] Of the [G] year [Em7] / [Am7] / [D7] With the [Am7] kids jingle-[D7]belling And [G] everyone [G7] telling you 
[C] Be of good [C] cheer [C#dim] / [C#dim] It’s the [G] most [Em7] wonderful [Am7] time [D7] 
Of the [Bb] year [Bb] / [Am7] / [D7]↓ 
It’s the [G] hap-[Em7]happiest [Am7] sea-[D7]son of [G] All [Em7] / [Am7] / [D7] With those [Am7] holiday [D7] greetings And [G] gay happy [G7] meetings 
or 
When [C] friends come to [C] call [C#dim] / [C#dim] It’s the [G] hap-[Em7]happiest [Am7] sea-[D7]son of [Dm7] all [G7] / [Dm] / [G7]↓ 
BRIDGE: There’ll be [C] parties for [C#dim] hosting Marsh-[G]mallows for [Em7] toasting And [Am7] caroling [D7] out in the [G] snow [G7] There’ll be [Cm7] scary ghost [F7] stories And [Bbmaj7] tales of the [Gm7] glories 
Of [Cm7] Christmases [Cm7] long, long a-[Am7]go [D7] / [Am7] / [D7]↓ 
It’s the [G] most [Em7] wonderful [Am7] time [D7] Of the [G] year [Em7] / [Am7] / [D7] There’ll be [Am7] much mistle-[D7]toeing And [G] hearts will be [G7] glowing 
When [C] loved ones are [C] near [C#dim] / [C#dim] It’s the [G] most [Em7] wonderful [Am7] time [D7] Yes, the [G] most [Em7] wonderful [Am7] time [D7] Oh, the [G] most [Em7] wonderful [Am7] time [D7] 
Of the [G] year [Em7] / [Am7] / [D7] / [G]/














 
