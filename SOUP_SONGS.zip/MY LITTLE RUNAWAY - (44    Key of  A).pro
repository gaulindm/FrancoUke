{t:RUNAWAY   }
{subtitle:(4/4    Key of  A)}      
{subtitle:(Del Shannon)}
{time: 3:05}
{metronome: 148}






{c:INTRO:}
[Am]/ / / /    / / / /     [G]/ / / /    / / / /      
[F]/ / / /    / / / /      [E7]/ / / /    / / / /

[Am] As I walk along, I [G]wonder what went wrong
With [F]our love, a love that was so [E7]strong 
[Am]  And as I still walk on
I [G]think of the things we've done 
To[F]gether, a-while our hearts were [E7]young

{c:CHORUS}
{soc}
  [A]   I'm a-walkin' in the rain 
  [F#m]       Tears are fallin' and I feel a pain      
  [A]   Wishin' you were here by me
  [F#m]       To end this misery 
  And I [A]wonder...I wah-wah-wah-wah-[F#m]wonder
  [A]Why... why-why-why-why [F#m]why, she ran away    
  And I [D]wonder, where she will [E7]stay-ay   [E7/]
  My little [A]runaway  
  [D]Run, run, run, run, [A]runaway  
{eoc}

{c:INSTRUMENTAL}
[Am]/ / / /    / / / /     [G]/ / / /    / / / /      
[F]/ / / /    / / / /      [E7]/ / / /    / / / /

[Am]/ / / /    / / / /     [G]/ / / /    / / / /      
[F]/ / / /    / / / /      [E7]/ / / /    / / / /

{c:CHORUS}
{soc}
  [A]   I'm a-walkin' in the rain 
  [F#m]       Tears are fallin' and I feel a pain      
  [A]   Wishin' you were here by me
  [F#m]       To end this misery 
  And I [A]wonder...I wah-wah-wah-wah-[F#m]wonder
  [A]Why... why-why-why-why [F#m]why, she ran away    
  And I [D]wonder, where she will [E7]stay-ay   [E7/]
  My little [A]runaway  
  [D]Run, run, run, run, [A]runaway  
{eoc}

[D]Run, run, run, run, [A]runaway
[D]Run, run, run, run, [A/]runaway 

