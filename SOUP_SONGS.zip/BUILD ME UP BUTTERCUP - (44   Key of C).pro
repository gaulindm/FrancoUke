{title:BUILD ME UP BUTTERCUP }
{subtitle:(4/4   Key of C)}
{subtitle:(Mike d'Abo & Tony Macaulay)}
{time: 3:20}
{metronome: 128}







{c:INTRO:}  
[C]/ / / /     [E7]/ / / /      
[F]/ / / /      [G7]/   {c:(stop)}

{c:CHORUS}
{soc}
Why do you [C]build me up (build me up)  
[E7]Buttercup, baby, just to [F]let me down 
(Let me down) 
And [G7]mess me around and then [C]worst of all 
(Worst of all) 
You [E7]never call, baby when you [F]say you will 
(Say you will) 
But [G7]I love you still 
I need [C]you (I need you) 
More than [C7]anyone, Darlin'
You [F/]know [F/]that [F/]I [F/]have [F/]from [F/]the  
[Fm]Start... so [C]build me up (build me up) 
[G]Buttercup don't break my [F]heart  [C]   
{eoc}

{c:Verse 1}
I'll be [C]over at [G]ten 
You told me [F]time and again
But you're [C]late, I wait a[F]round and then 
I [C]went to the [G]door, I can't [F]take any more
It's not [C]you, you let me [F]down again

{c:BRIDGE}
{soc}     
     Hey, hey, [Dm]hey, Baby, Baby
     Try to find; hey, hey [Em]hey 
     A little time and [A7]I'll make you mine 
     [F]I'll be home, I'll be be[D]side the phone 
     Waiting for [G]you
     Ooo-oo-ooo, Ooo-oo-ooo 

Why do you [C]build me up (build me up)  
[E7]Buttercup, baby, just to [F]let me down 
(Let me down) 
And [G7]mess me around and then [C]worst of all 
(Worst of all) 
You [E7]never call, baby when you [F]say you will 
(Say you will) 
But [G7]I love you still 
I need [C]you (I need you) 
More than [C7]anyone, Darlin'
You [F/]know [F/]that [F/]I [F/]have [F/]from [F/]the  
[Fm]Start... so [C]build me up (build me up) 
[G]Buttercup don't break my [F]heart  [C]   
{eoc}
         
{c:Verse 2}
To [C]you I'm a [G]toy but I [F]could be the boy 
You a[C]dore if you'd just [F]let me know 
Al[C]though you're un[G]true 
I'm at[F]tracted to you all the [C]more
Why do I [F]need you so? 

{soc}     
     Hey, hey, [Dm]hey, Baby, Baby
     Try to find; hey, hey [Em]hey 
     A little time and [A7]I'll make you mine 
     [F]I'll be home, I'll be be[D]side the phone 
     Waiting for [G]you
     Ooo-oo-ooo, Ooo-oo-ooo 
{soc}
Why do you [C]build me up (build me up)  
[E7]Buttercup, baby, just to [F]let me down 
(Let me down) 
And [G7]mess me around and then [C]worst of all 
(Worst of all) 
You [E7]never call, baby when you [F]say you will 
(Say you will) 
But [G7]I love you still 
I need [C]you (I need you) 
More than [C7]anyone, Darlin'
You [F/]know [F/]that [F/]I [F/]have [F/]from [F/]the  
[Fm]Start... so [C]build me up (build me up) 
[G]Buttercup don't break my [F]heart  [C]   
{eoc}
           
{c:OUTRO: (a bit slower!)}  
I...I...need [C]you...ooo, more than [C7]anyone Darlin'
You [F]know [F/]that [F/]I [F/]have [F/]from [F/]the [Fm]start
So [C]build me up [G]Buttercup, don't break my 
[F/]Heart  [F/]   [F/]    [F/]   [C/]         
