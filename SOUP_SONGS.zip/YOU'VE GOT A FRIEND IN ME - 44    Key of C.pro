{t:YOU'VE GOT A FRIEND IN ME}
{subtitle:4/4    Key of C }
{subtitle: (Randy Newman)}
{Metronome: 116}
{time:3:00 }






{c:INTRO}
[C]/ /    [C7]/ /    [F]/ /    [F#dim7]/ /  
[C]/ /    [G7]/ /    [C]/ / / /

[C]You've got a [G7]friend in [C]me  [C7]         
[F] You've got a [F#dim7]friend  in [C]me  [C7]
[F] When the [C]road looks [E7]  rough a[Am]head
And you're [F]miles and [C]miles from your [E7]nice warm [Am]bed
[F] You just re[C]member what your [E7]old pal [Am]said
Boy, [D7]you've got a [G]friend in [C]me     [A7]
Yeah [D7]you've got a [G]friend in [C]me

[C7]/ /    [F]/ /    [F#dim7]/ /  
[C]/ /    [G7]/ /    [C]/ / / /

[C] You've got a [G]friend in [C]me   [C7]         
[F] You've got a [F#dim7]friend                         in [C]me  [C7]
[F] You've got your tr[C]oubles, [E7] and I got them [Am]too
[F] There isn't [C]anything I wo[E7]uldn't [Am]do for you 
[F] We stick to[C]gether, we can [E7]see it [Am]through
'Cause [D7]you've got a [G]friend in [C]me  [A7]         
[D7] You've got a fr[G]iend in [C]me

[F] Some other folks might be a li[B]ttle bit smarter than I am
[C] Bigger and st[B]ronger t[C]oo, maybe
[B] But none of th[C]em will ev[D]er lo[B]ve you
The [Em]way I [A]do; it's m[Dm]e and yo[G]u, boy

[C] And as the ye[G]ars go b[C]y  [C7]           
Our [F]friendship will [F#dim7]never             [C]die  [C7]
[F] You're gonna [F#dim7]see it's our 
De[C]s---ti[Em]----n[Am]y

[D7]You've got a fr[G]iend in m[C]e    [A7]       
[D7]You've got a fr[G]iend in [C]me    [A7]       
[D7]You've got a f[G]riend in [C/]me   [G7/]   [C/]
