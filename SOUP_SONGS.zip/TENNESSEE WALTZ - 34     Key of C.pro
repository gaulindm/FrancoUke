{t:TENNESSEE WALTZ  }
{subtitle:   3/4     Key of G   }
{subtitle:(Red Stewart & Pee Wee King)}
{time: 4:15}
{metronome: 102}








{c: INTRO:} 
[C]/ / /    [G]/ / /    
[D7]/ / /    [G]/ /

I was [G]dancin' with my darlin 
To the [G7]Tennessee [C]Waltz
When an [G]old friend 
I [Em]happened to [A7]see [D7]
I intro[G]duced him to my darlin' 
And [G7]while they were [C]dancin'
my [G]friend stole my [C]sweet[G]heart 
[D7]From [G]me

{c: CHORUS 1}
{soc}
     I [G]remember the [G7]night 
     And the [C]Tennessee [G]Waltz
     'Cause I know just how [Em]much 
     I have [A7]lost [D7]
     Yes I [G]lost my little darlin' 
     The [G7]night they were [C]playin'
     That [G]beautiful [C]Tenn[G]ess[D7]ee [G]Waltz
{eoc}
          
Now I [G]wonder how a dance like 
The [G7]Tennessee [C]Waltz
Could have [G]broken my 
[Em]Heart so com[A7]plete [D7]
Well I [G]couldn't blame my darlin'
And [G7]who could help [C]fallin'
In [G]love with my [C]dar[G]lin' [D7]so [G]sweet

{c: CHORUS 2}
{soc}
     Well it [G]must be the [G7]fault 
     Of the [C]Tennessee [G]Waltz
     Wish I'd known just how [Em]much 
     It would [A7]cost [D7]
     But I [G]didn't see it comin', 
     It's all [G7]over but the [C]cryin'
     Blame it [G]all on the 
     [C]Tenn[G]ess[D7]ee [G]Waltz
{eoc}
         
{c: CHORUS 1}
{soc}
     I [G]remember the [G7]night 
     And the [C]Tennessee [G]Waltz
     'Cause I know just how [Em]much 
     I have [A7]lost [D7]
     Yes I [G]lost my little darlin' 
     The [G7]night they were [C]playin'
     That [G]beautiful [C]Tenn[G]ess[D7]ee [G]Waltz
     [C]That [G]beautiful 
     [C]Tenn[G]ess[D7]ee [G]Waltz[G/]
{eoc}


{define: D7 0 2 0 2 0}