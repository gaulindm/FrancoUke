{title: BLUE MOON  }
{subtitle:(4/4     Key of A)}
{subtitle:(Richard Rodgers & Lorenz Hart)}
{time: 2:15}
{metronome: 96}






{c: INTRO:}
[A]/ /    [F#m]/ /    [Bm7]/ /    [E7]/ /    
[A]/ /    [F#m]/ /    [Bm7]/ /    [E7]/ /    

Blue [A]moon  [F#m]    [Bm7]  
You saw me [E7]standing a[A]lone  [F#m]    [Bm7]  
Without a [E7]dream in my [A]heart  [F#m]    [Bm7]  
Without a [E7]love of my [A]own  [F#m]    [Bm7]    [E7]

Blue [A]moon  [F#m]    [Bm7]   
You knew just [E7]what I was [A]there for  [F#m]    [Bm7]   
You heard me [E7]saying a [A]prayer for  [F#m]    [Bm7]   
Someone I [E7]really could [A]care for  [Dm//]    [A///]

{c:BRIDGE}
{soc}
And then there [Bm7]suddenly a[E7]ppeared be[A]fore me
The only [Bm7]one my arms could [E7]ever [A]hold
I heard some[F]body whisper [G7]Please a[C]dore me
And when I [E7]looked, the moon had [B7]turned to [E7]gold
{eoc}
               
Blue [A]moon  [F#m]    [Bm7]   
Now I'm no [E7]longer a[A]lone  [F#m]    [Bm7]   
Without a [E7]dream in my [A]heart  [F#m]    [Bm7]   
Without a [E7]love of my [A]own  [Dm//]    [A///]


  
