

{title:059    DOWNTOWN        }
{subtitle: 4/4      Keys of C/D  }
{subtitle: Tony Hatch (Recorded by Petula Clark)}
{metronome: 128   }
{time:3:28}





[C]/ / / /    [F]/ /    [G]/ /    
[C]/ / / /    [F]/ /    [G7]/ /

[C]When you’re a[Em]lone and life is 
[F]Making you [G7]lonely you can [C]always [Em]go...   
[F]   Down[G7]town
[C]When you’ve got [Em]worries all the 
[F]Noise and the [G7]hurry seems to [C]help I [Em]know   
[F]   Down[G7]town
Just [C]listen to the music of the 
[Am]Traffic in the city
[C]Linger on the sidewalk where the 
[Am]Neon signs are pretty, [G]how can you lose

{soc}     
   [F]   The lights are much brighter there 
   You can for[D7]get all your troubles
   Forget all your cares and go 
   [C]Down[Em]town, [F]things'll be [G7]great when you're 
   [C]Down[Em]town, [F]no finer [G7]place for sure 
   [C]Down[Em]town, [F]everything's [G7]waiting for 
   [C]You    [G]             [C]           [G]        
   {c:(downtown...) }
   [C]         [G]              [C]           [G] 
   {c:(downtown...)}      
{eoc}

[C]Don’t hang a[Em]round and let your 
[F]Problems sur[G7]round you 
There are [C]movie [Em]sho...ws   
[F]  Down[G7]town
[C]Maybe you [Em]know some little 
[F]Places to [G7]go to 
Where they [C]never [Em]clo...se    
[F]  Down[G7]town
Just [C]listen to the rhythm of a 
[Am]Gentle bossa nova
[C]You’ll be dancing with him too 
Be[Am]fore the night is over, [G]happy again
{soc}     
   [F]   The lights are much brighter there 
   You can for[D7]get all your troubles
   Forget all your cares so go 
   [C]Down[Em]town, [F]where all the [G7]lights are bright 
   [C]Down[Em]town, [F]waiting for [G7]you tonight 
   [C]Down[Em]town, [F]you’re gonna [G7]be alright 
   [C]Now   [G]           [C]          [G]        
   {c:(downtown...) }
   [D]         [A7]                [D]        [A7] 
   {c:(downtown...   downtown)}      
{eoc}

[D]/ /    [F#m]/ /      [G]/ /    [A7]/ / 
[D]/ /    [F#m]/ /      [G]/    down[A7/]town...         

[D]/ /    [F#m]/ /      [G]/ /    [A7]/ / 
[D]/ /    [F#m]/ /      [G]/    down[A7/]town...

And [D]you may find somebody kind to 
[Bm]Help and understand you
[D]Someone who is just like you and 
[Bm]Needs a gentle hand to [A]guide them along

{soc}
   [G]     So maybe I'll see you there 
   We can for[E7]get all our troubles
   Forget all our cares so go 
   [D]Down[F#m]town, [G]things'll be [A7]great when you're
   [D]Down[F#m]town, [G]don't wait a [A7]minute more
   [D]Down[F#m]town, [G]everything's [A7]waiting for 
   [D]You   [A7]              [D]         [A7]
 {c: (downtown...    downtown)}
   [D]Down[A7]town...    [D]         [A7]             
 {c:                         (downtown...)  }

   [D]Down[A7]town...    [D]        [A7]               [D/]  
{c:                            (downtown...)}
{eoc}

______________________________________














{define: D7 0 2 0 2 0}
