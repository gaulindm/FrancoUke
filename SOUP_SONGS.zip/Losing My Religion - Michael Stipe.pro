{title: Losing My Religion}
{subtitle: Michael Stipe}

{c:INTRO: Em / / / /  / / / /  Am / / / /  / / / /  Em  / / / /  / / / /  Am / / / /}

       [G]    Oh, li[Am]fe it's bigger
       [Em]   It's bigger than you and you are [Am]  not me
       The lengths that I will [Em]go to
       The distance in your e[Am]yes
       [Em]   Oh no I've said too [Dm]much
       I've said it a[G]ll
       That's me in the c[Am]orner
       That's me in the s[Em]potlight
       Losing my r[Am]eligion
       Trying to k[Em]eep up with you
       And I [Am]don't know if I can do it
       [Em]    Oh no I've said too [Dm]much
       I haven't said en[G]ough
       
       I thought that I heard you [F]laughing
       I thought that I [G]heard you [Am]sing  [Am/C]
       I [F]think I thought I [Dm]saw [G]you [Am]try
       
       
       [Am]    Every whisper of every waking [Em]hour
       I'm choosing my con[Am]fessions
       Trying to [Em]keep an eye on you
       Like a [Am]hurt lost and blinded fool, fool
       [Em]    Oh no I've said too [Dm]much, I said e[G]nough

       Consider [Am]this, consider this
       [Em]Hint of the century
       Consider [Am]this, the slip, that [Em]brought me to my knees, failed
       [Am]What if all these fantasies come [Em]  flaming aground
       Now I've [Dm]said too [G]much
       I thought that I heard you la[F]ughing
       I thought that I [G]heard you [Am]sing
       I [F]think I thought I [Dm]saw [G]you [Am]try   [G]

       {c:Riff}
       
       But [Am]That was just a dream
       That was just a dream
      
       That's me in the corner,
       That's me in the [Em]spotlight
       Losing my reli[Am]gion
       Trying to [Em]keep up with you
       And I don't[Am] know if I can do it
       [Em]    Oh no I've said too [Dm]much
       I haven't said eno[G]ugh

       I thought that I heard you lau[F]ghing
       I thought that I [G]heard you [Am]sing
       I [F]think I thought I [Dm]saw [G]you [Am]try

       But [F]that was just a dream [G]
       [Am]Try, [Am]cry, why try
       [F]That was just a dream
       [G]Just a [Am]dream
       Just a [G]dream, dream

       {c:Riff}
            