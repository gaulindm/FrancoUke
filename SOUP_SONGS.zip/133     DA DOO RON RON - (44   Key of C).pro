

{title:133 DA DOO RON RON   }
{subtitle:(4/4   Key of C)}         
{subtitle:(Jeff Barry, Ellie Greenwich)}
{subtitle:(& Phil Spector)}
{time:2:33}
{metronome: 148}





[C]/ / / /      [F]/ / / /     
[G]/ / / /     [C]/ / / /

I [C]met her on a Monday and my 
[F]Heart stood still
Da [G]doo ron ron ron, da [C]doo ron ron
Somebody told me that her [F]name was Jill
Da [G]doo ron ron ron, da [C]doo ron ron {c:(4,1)}

{soc}
     [C]    Yes, my [F]heart stood still
     [C]    Yes, her [G]name was Jill
     [C]    And when I [F]walked her home
     Da [G]doo ron ron ron, da [C]doo ron ron 
     {c:(4,1234)}
{eoc}

I knew what she was thinkin' when she 
[F]Caught my eye
Da [G]doo ron ron ron, da [C]doo ron ron
She looked so quiet but [F]my oh my
Da [G]doo ron ron ron, da [C]doo ron ron  

{soc}
     [C]    Yes, she [F]caught my eye
     [C]    Yes, but [G]my oh my
     [C]    And, when I [F]walked her home
     Da [G]doo ron ron ron, da [C]doo ron ron
     {c:(4,1234)}
{eoc}




{c:INSTRUMENTAL:}
[C]/ / / /      [F]/ / / /     [G]/ / / /     [C]/ / / /
[C]/ / / /      [F]/ / / /     [G]/ / / /     [C]/ / / 



  
Well I [C]picked her up at seven and she 
[F]Looked so fine
Da [G]doo ron ron ron, da [C]doo ron ron
Someday soon I'm gonna [F]make her mine
Da [G]doo ron ron ron, da [C]doo ron ron     

{soc}
     [C]    Yes, she [F]looked so fine
     [C]    Yes, I'll [G]make her mine
     [C]    And, when I [F]walked her home
     Da [G]doo ron ron ron, da [C]doo ron ron
     {c:(4,1234)}
{eoc}

Da [C]doo ron ron ron, da [F]doo ron ron
Da [G]doo ron ron ron, da [C]doo ron ron

Da [C]doo ron ron ron, da [F]doo ron ron
Da [G]doo ron ron ron, da [C]doo ron [C/]ron

_________________________________













