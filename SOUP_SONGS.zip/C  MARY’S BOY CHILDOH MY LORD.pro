

{title:C12:  MARY’S BOY CHILD/OH MY LORD}
{subtitle: (Jestor Hairston, Bony M)}
{time:3:29}
{metronome:130 }



[G]/ / / /     [C]/ /     [Am]/ /    
[G]/ /    [D7]/ /     [G]/ / / /

[G]Long time ago in [C]Bethle[Am]hem
So the [D]holy Bible [G]say
Mary’s Boy Child [C]   Jesus [Am]Christ 
Was [G]born on [D7]Christmas [G]day  {c:(234)}

{c:CHORUS}
{soc}
[G]Hark now [C]hear the [D7]angels [G]sing
A [Em]King was [A]born to[D7]day
And [G]we shall live for  [C]   ever[Am]more
Be[G]cause of [D7]Christmas [G]Day  {c:(234)}
{eoc}

While [G]shepherds watch their 
[C]Flocks by [Am]night
They see a [D7]bright new shining [G]star
They hear a choir of [C]angels sing
Music [G]seems to [D7]come from a[G]far  {c:(234)}

{soc}
[G]Hark now [C]hear the [D7]angels [G]sing
A [Em]King was [A]born to[D7]day
And [G]we shall live for  [C]   ever[Am]more
Be[G]cause of [D7]Christmas [G]Day  {c:(234)}
{eoc}

Now [G]Joseph and his [C]wife Mary 
came to [D7]Bethlehem that [G]night
They find no place to [C]bear her child
Not a [G]single [D7]room was in [G]sight  {c:(234)}

By and by they found a [C]little nook
In a [D7]stable all for[G]lorn
In a manger [C]cold and dark
Mary's [G]little [D7]boy child was [G]born  {c:(234)}

{soc}
[G]Trumpets [C]sound and [D7]angels [G]sing
[Em]Listen to [A]what they [D7]say
That [G]man will live for [C]   ever more 
Be[G]cause of [D7]Christmas [G]day  {c:(234)}
{eoc}

[G]Oh my Lord, you sent your son to save us
Oh my Lord, your very self you gave us
[D]Oh my Lord, that sin will not enslave us
[G]And love will reign once more

[G]Oh my Lord, when in the crib they found Him
Oh my Lord, a golden halo crowned Him
[D]Oh my Lord, they gathered all around Him
[G]To see Him and adore

[G]Oh my Lord, they had begun to doubt you
Oh my Lord, what did they know about you
[D]Oh my Lord, but they were lost without you
[G]They needed you so bad

[G]Oh my Lord, you sent your son to save us
Oh my Lord, your very self you gave us
[D]Oh my Lord, that sin will not enslave us
[G]And love will reign once [G/]more
















