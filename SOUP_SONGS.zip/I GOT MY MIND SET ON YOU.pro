{title:I GOT MY MIND SET ON YOU}
{subtitle:}
Chorus:
I got my mind [Am7] set [Em7]  on [Am7]  you,  I got my min[C]d s[G]et o[F]n you.
 
I got my mind [Am7] set [Em7]  on [Am7]  you,  I got my min[C]d s[G]et o[F]n you.
 
 
Verse:
But it's gonna' take money [C]   [F]   [G]   A whole lotta' s[C]pending mo[F]ney [G]
 
It's gonna' take p[C]lenty of money[F]   [G]   To do it right chil[C]d [F] [G]
 
It's gonna' take ti[C]me  [F]   [G]   a whole lotta pr[C]ecious t[F]ime [G]
 
It's gonna' take pa[C]tients and t[F]ime  [G]    mmm...
 
    C         F         C         F         C         F     C        C**
to do it, to do it, to do it, to do it, to do it, to do it right child. 
 
 
Chorus:
I got my mind [Am7] set [Em7]  on [Am7]  you,  I got my min[C]d s[G]et o[F]n you.
 
I got my mind [Am7] set [Em7]  on [Am7]  you,  I got my min[C]d s[G]et o[F]n you.
 
 
Bridge:
 
[C]This time I know it's r[F]eal. The f[C]eeling that I f[F]eel.
 
I k[C]now if I put my mind to [F]it. I k[C]now that I really could [G]do it.  
 
 
Chorus:
I got my mind [Am7] set [Em7]  on [Am7]  you.        [C] (s[G]et o[F]n you).
 
I got my mind [Am7] set [Em7]  on [Am7]  you.        [C] (s[G]et o[F]n you).
 
 
Verse:
But it's gonna' take money [C]   [F]   [G]   A whole lotta' s[C]pending mo[F]ney [G]
 
It's gonna' take p[C]lenty of money[F]   [G]   To do it right chil[C]d [F] [G]
 
It's gonna' take ti[C]me  [F]   [G]   a whole lotta pr[C]ecious t[F]ime [G]
 
It's gonna' take pa[C]tients and t[F]ime  [G]    mmm...
 
    C         F         C         F         C         F     C**
to do it, to do it, to do it, to do it, to do it, to do it right. 
 
 
Solo:
 
Am7  Em7  Am7           C  G   F
Am7  Em7  Am7           C  G   F
 
 
Chorus:
I got my mind [Am7] set [Em7]  on [Am7]  you,  I got my min[C]d s[G]et o[F]n you.
 
I got my mind [Am7] set [Em7]  on [Am7]  you,  I got my min[C]d s[G]et o[F]n you.
 
 
Bridge:
 
[C]This time I know it's r[F]eal. The f[C]eeling that I f[F]eel.
 
I k[C]now if I put my mind to [F]it. I k[C]now that I really could [G]do it.  
 
 
Verse:
But it's gonna' take money [C]   [F]   [G]   A whole lotta' s[C]pending mo[F]ney [G]
 
It's gonna' take p[C]lenty of money[F]   [G]   To do it right chil[C]d [F] [G]
 
It's gonna' take ti[C]me  [F]   [G]   a whole lotta pr[C]ecious t[F]ime [G]
 
It's gonna' take pa[C]tients and t[F]ime  [G]    mmm...
 
    C         F         C         F         C         F     C**
to do it, to do it, to do it, to do it, to do it, to do it right. 
 
 
[Am7](Set [Em7]  on [Am7]   you)          [C] (s[G]et o[F]n you)   -----REPEATS FADES OUT
