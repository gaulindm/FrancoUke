{title:TUBTHUMPING & END OF THE WORLD (MEDLEY)}
{subtitle:(Chumbawamba & R.E.M.)}
{time:2:35}








[G/] We'll be [C/]singing 
[G/] When we're [C/]winning
[G/] We'll be [D/]singing   {c:(tap, tap, tap, tap, tap)}

I get knocked [G]down, but I get [C]up again

You're [G]never going to keep me [C]down

I get knocked [G]down, but I get [C]up again

You're [D]never going to keep me down


[Am]/ / / /   [C]Strumming the [Em]night aw[D]ay


[Am]/ / / /   [C]Strumming the [Em]night aw[D]ay


[G]Oh [C]Danny [G]Boy, 


[C]Danny [G]Boy


[C]Danny [D]Boy  {c:(234)}  [D/]     {c:(tap)}


[G] That's great it starts with an [C]earthquake
Birds and snakes an a[G]eroplane - 
Lenny Bruce is [C]not afraid


[G]Eye of a hurricane listen to yourself churn
[C]World serves its own needs 
don't misserve your own needs


[G]Feed it up an aux speed, 
grunt no strength no
The [C]ladder starts to clatter 
with fear fight down height


[Bb]Wire in a fire representing seven games
In a [Am]government for hire and a combat 


It's the [G]end of the [D]world as we [Am]know it

It's the [G]end of the [D]world as we [Am]know it

It's the [G]end of the [D]world as we [Am]know it 

And I feel [C]fi...ne {c:(234,1234,1234)}  [C/]


He drinks a [G]whisky drink, he drinks a [C]vodka drink
{c:(                  oh,                                   Danny)}

He drinks a [G]lager drink, he drinks a [C]cider drink
{c:(                   boy,                             Danny)}

He sings the [G]songs that remind him of the [C]good times  
{c:(                     boy,                                    Danny) }

He sings the [D]songs that remind him of  [D/]
{c:(                  boy)}

I get knocked [G]down, but I get[C] up again
You're [G]never going to keep me [C]down
I get knocked [G]down, but I get[C] up again
You're [D]never going to keep me down

It's the [G]end of the [D]world as we [C]know it
It's the [G]end of the [D]world as we [C]know it

I get knocked [G]down, but I get [D]up again
{c:         It's   the   end     of     the    world  as  we}
You're [C]never going to keep me down
{c:             know it                             }

I get knocked [G]down, but I get [D]up again
{c:         It's   the   end     of     the    world  as  we}
You're [C]never going to keep me down
{c:             know it                             }

I get knocked [G]down, but I get [D]up again
{c:         It's   the   end     of     the    world  as  we}
You're [C]never going to keep me down
{c:             know it                             }

I get knocked [G]down, but I get [D]up again
{c:         It's   the   end     of     the    world  as  we}
You're [C]never going to keep me down
{c:             know it                             }

I get knocked [G]down, but I get [D]up again
{c:         It's   the   end     of     the    world  as  we}
You're [C]never going to keep me down
{c:             know it                             }

And I feel [G/]fine

