{title:BIG BLACK HORSE}
{title:AND A CHERRY TREE}
{subtitle:K.T. Tunstall}
{subtitle: 4/4    Key of Dm}
{time: 3:30}


{c:”two, three, four!}

woo-[Dm]hoo,  woo-[A7]hoo   
woo-[Dm]hoo,  woo-[A7]hoo    

Well my [Z]heart knows me better than I know myself
So I'm gonna let it do all the talking 
Woo-[Dm]hoo, woo-[A7]hoo  

I [Z]came across a place in the middle of nowhere
With a big black horse and a cherry tree
Woo-[Dm]hoo, woo-[A7]hoo  

I [Z]felt a little fear upon my back
He said "Don't look back, just keep on walkin’
Woo-[Dm]hoo, woo-[A7]hoo  

When the [Z]big black horse said, "Look this way"
Said, "Hey, lady, will you marry me?"
Woo-[Dm]hoo, woo-[A7]hoo  

But I said [Dm]no,   [C]no, [Am]nooo… [Bb]no-no-no
I said [Dm]no,  [C]no, [Bb]you're not the one for [Dm]me 
  
[Dm]No,  [C]no, [Am]nooo… [Bb]no-no-no
I said [Dm]no,[C]no
[Bb/]You're not the one for [Dm]me {c:(234,123)}
Woo-[A7]hoo  

And my [Z]heart hit a problem in the early hours
So I stopped it dead for a beat or two
Woo-[Dm]hoo, woo-[A7]hoo  

But I [Z]cut some cord, and I shouldn't have done it
And it won't forgive me after {soh}all these years{eoh}
Woo-[Dm]hoo, woo-[A7]hoo

So I [Z]sent it to a place in the middle of nowhere
With a big black horse and a cherry tree
Woo-[Dm]hoo, woo-[A7]hoo 

Now it [Z]won't come back, 'cause it's oh so happy
And now I've got a hole for the {soh}world to see{eoh}
Woo-[Dm]hoo, woo-[A7]hoo 

And it said [Dm]no,  [C]no, [Am]nooo… [Bb]no-no-no
It said [Dm]no,  [C]no
[Bb]You're not the one for [Dm]me 
  
[Dm]No,[C]no, [Am]nooo… [Bb]no-no-no
It said [Dm]no,  [C]no
[Bb/]You're not the one for [Dm]me {c:(234,123)}

Woo-[A7]hoo   
Woo-[Dm]hoo, Woo-[A7]hoo 

Said [Z]  NO NO NO NO, No, no-o-o
No,no-o-o you're not the one for me 
  
NO NO NO NO, No, no-o-o
No,no-o-o you're not the one for me 

[Dm] Big black [C]horse [Bb]    and a cherry [Dm]tree 
[Dm] I can't quite [C]get there 
‘Cause my [Bb]heart's forsaken [Dm]me 
[Dm] Big black [C]horse [Bb]    and a cherry [Dm]tree 
[Dm] I can't quite [C]get there 'cause my 
[Bb/]heart's forsaken me

