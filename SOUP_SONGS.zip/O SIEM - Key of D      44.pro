{title:O SIEM  }
{subtitle:      Key of D      4/4  }
{subtitle: (Susan Aglukark)  }
{time:4:36}
{metronome: 78 }


{c:Drum for 8 beats }


{soc}
     [D/]O Siem, we are all [Bm/]family
     [D/]O Siem, we're all the [A/]same
     [G/]O Siem, the fires of [D/]freedom
     [G/]Da...[Bm/]ance in the [A/]burning 
     [C]Flame {c:(234,1234,1234,1234)}
{eoc}



[C]Siem o siyeya, all [Bb]people rich and [F]poor
[C]Siem o siyeya, those who [G]do and do not know
[C]Siem o siyeya, take the [Bb]hand of one close [F]by
[C]Siem o siyeya, of those who [Dm]kno...w  
Bec[F]...ause they [G]try
And watch the [Bb]wa...lls come [F]tu...mbling 
[G]Do...wn {c:(234,1234)}

{soc}
     [D]O Siem, we are all [Bm]family
     [D]O Siem, we're all the [A]same
     [G]O Siem, the fires of [D]freedom
     [G]Da...[Bm]ance in the [A]burning 
     [C]Flame {c:(234,1234,1234,1234)}
{eoc}



[C]Siem o siyeya, all [Bb]people of the [F]world
[C]Siem o siyeya, it's [G]time to make the turn
[C]Siem o siyeya, a [Bb]chance to share your [F]heart
[C]Siem o siyeya, to [Dm]ma...ke a 
[F]Bra...nd new [G]sta...rt
And watch the [Bb]wa...lls come [F]tu...mbling 
[G]Do...wn {c:(234,1234)}

{soc}
     [D]O Siem, we are all [Bm]family
     [D]O Siem, we're all the [A]same
     [G]O Siem, the fires of [D]freedom
     [G]Da...[Bm]ance in the [A]burning 
     [D]Flame {c:(234,1234)}
{eoc}

{c:BRIDGE:}
{c:(}[G]{c:12)}   Fires bu...rn in [D]silence    
{c:(}[G]{c:12)}   Hearts in anger ble[D]...ed 
{c:(}[G]{c:12)}   Wheel of cha...nge is [D]turning 
For the [G]o...nes who [D]tru...ly [A]nee...d
To see the [C]wa...lls come [G]tu...mbling 
[A]Do...wn {c:(234,1234)}

{soc}
     [D]O Siem, we are all [Bm]family
     [D]O Siem, we're all the [A]same
     [G]O Siem, the fires of [D]freedom
     [G]Da...[Bm]ance in the [A]burning 
     [D]Flame {c:(234,1234)}
     [D]O Siem, we are all [Bm]family
     [D]O Siem, we're all the [A]same
     [G]O Siem, the fires of [D]freedom
     [G]Da...[Bm]ance in the [A]burning 
     [D]Flame  {c:(234,1234)}
     [G]Da...[Bm]ance in the [A]burning 
     [C]flame {c:(234,1234)}    [D/] 
{eoc}

____________________________________


















