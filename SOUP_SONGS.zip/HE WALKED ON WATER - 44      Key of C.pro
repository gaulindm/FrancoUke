{title:HE WALKED ON WATER}
{subtitle:   4/4      Key of C}
{subtitle: (Allen Shamblin)}
{metronome: 105  }
{time: 3:00 }He wore [C/]starched white shirts 
[F/]buttoned at the neckAnd he'd [C/]sit in the shade and watch the 
[G/]chickens peckAnd his [C/]teeth were gone, but [F/]what the heck[C]I thought... that [G]he walked... 
on [C]water {c:(234,12)} [F/]   [G/]He [C]said he was a cowboy [F]when he was youngHe could [C]handle a rope and he was [G]good with a gunAnd [C]my mama's daddy was his [F]oldest sonAnd [C]I thought... that he [G]walked... 
on [C]water {c:(234,12)}   [F/]    [G/]{c:CHORUS}
{soc}  If the story's [F]to...ld, only heaven [C]kno...ws   But his hat seemed to [G]me... 
  like an old ha[C]lo-o-o  And though his [F]wi...ngs, they were never [C]seen  [C]I thought... that [G]he walked... 
  on [C]water {c:(234,12)}  [Am/]    [G/]  {eoc}
Then [C]he tied a cord to the [F]end of a mopAnd said, "[C]Son, here's a pony 
[G7]keep her at a trot."And [C]I'd ride in circles while he [F]laughed a lotThen [C]I'd flop [G]down be[C]side him
And he was [Am]seventy-three years old in [G]sixty-threeAnd [F]I loved him and [G]he loved meAnd [A]Lord, I cried the [G]day he died'Cause [C]I thought... that [G]he walked... 
on [C]water {c:(234,1)}  {soc}   If the story's [F]told, only heaven [C]knows  But his hat seemed to [G]me 
  like an old ha-[C]lo-o-o  And although his [F]wings, they were never [C]seen  [C]I thought... that [G]he walked... 
  on [C]water...  {c:(234,12)}  [F/]   [G/]
  [C]I thought... that [G]he walked... 
  on [C/]water... 
{eoc}