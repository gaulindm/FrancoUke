{title:LOST IN MY MIND}
{subtitle:tab     4/4    Key of G}
{subtitle:(The Head and The Heart)}
{metronome:184 }
{time: 3:00}








[G]  Put your dreams away for now 
I wont see you for some [C]time
I am lost in my mind, I get lost in my [G]mind
Mama once told me 
You’re already home when you feel [C]loved
I am lost in my mind 
I get lost in my [G]mind {c:(4 bars)}


Ooh [C]Ooh ↓Ooh ↓Ooh…   
Ooh [G]Ooh…    
Ooh [C]Ooh ↓ooh ↓ooh…


[G]Oh my brother, your wisdom is 
[C]All that I need
[G]Oh my brother, dont you worry about [C]me
Don’t you [D]worry, don’t you [C]worry
Don’t worry bout [G]me {c:(4 bars)}


Ooh [C]Ooh ↓Ooh ↓Ooh    
Ooh [G]Ooh…   
Ooh [C]Ooh ↓ooh ↓ooh


How’s that [G]brick layin coming 
How’s your engine runnin
Is that [C]bridge getting built 
Are your hands getting filled
Won’t you [G]tell me my brother… 
Cause there are [C] stars… up a[G]bo…ve 
We can [C]  start… moving 
[G]For…[C]ward {c:(4 bars)}

Ooh [G]Ooh…   
Ooh [C]Ooh ↓Ooh ↓Ooh…    
Ooh [G]Ooh…  
Ooh [C]Ooh ↓Ooh ↓Ooh…

How’s that [G]brick layin’ coming 
How’s your engine runnin
Is that [C]bridge getting built 
Are your hands getting filled
Won’t you [G]tell me my brother… 
Cause there are [C] stars… up a[G]bo…ve 
We can [C]  start… moving 
[G]For… [C]ward {c:(4 bars)}

[G]Lost in my mind, lost in my mind, oh I get 
[C]Lost in my mind
Lost, I get lost, I get 
[G]Lost in my mind, lost in my mind 
I get [C]lost in my mind 
Lost I get lost I get [G]lo… [C]o…st…
Oh I get [G]lo…[C]o…st… Oh I get [G/] 
