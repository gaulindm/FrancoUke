

{t:134   RING OF FIRE   }
{subtitle:(4/4  Key of G)}         
{subtitle:(Johnny Cash)}
{time:3:41}
{metronome:176}

{c:(Kazoos or voice ("do do's") for INTRO}
{c:and instrumental section)}






{c:(kazoos)}  
[G]/ / / /    [C]/ /     [G]/ / / /    / / / /    
[G]/ / / /    [D7]/ /    [G]/ / / /    / / / /

[G]Lo...ve is a [C]burning [G]thing
{c:(do-do  do-do} [C]{c:do do} [G]{c:dooo (234,123)}
And it ma....kes a [D7]fiery [G]ring 
{c:(do-do  do-do} [D7]{c:do do} [G]{c:dooo (234,1234)}      
Bou...nd by [C]wild de[G]sire                            
{c:(do-do  do-do} [C]{c:do do}  [G]{c:dooo (234,1234)}
I fell into a [D7]ring of [G]fire 

{c:CHORUS}
{soc}
  [D]I fell into a [C]burning ring of [G]fire
  I went [D]down, down, down, and the 
  [C]Flames went [G]higher
  And it [G]burns, burns, burns
  The [C]ring of [G]fire
  The [D7]ring of [G]fire {c:(234,1234)}
{eoc}

{c:Instrumental: (kazoos)}
[G]/ / / /    [C]/ /     [G]/ / / /    / / / /    
[G]/ / / /    [D7]/ /    [G]/ / / /    / / / /

[G]/ / / /    [C]/ /     [G]/ / / /    / / / /    
[G]/ / / /    [D7]/ /    [G]/ / / /    / / / /

{soc}
  [D]I fell in to a [C]burning ring of [G]fire
  I went [D]down, down, down and the
  [C]Flames went [G]higher
  And it [G]burns, burns, burns 
  The [C]ring of [G]fire
  The [D7]ring of [G]fire  {c:(234,123)}
{eoc}

The [G]ta...ste of [C]love is [G]sweet  
{c:(do-do  do-do} [C]{c:do do}  [G]{c:dooo (234,123)}
When hea...rts like [D7]ours [G]meet
{c:(do-do  do-do} [D7]{c:do do}  [G]{c:dooo (234,1234)}
I fell for you... [C]like a [G]child 
{c:(do-do  do-do} [C]{c:do do}  [G]{c:dooo (234,1234)}                         
Oh... but the [D7]fire went [G]wild 

{c:CHORUS}
{soc}
  [D]I fell into a [C]burning ring of [G]fire
  I went [D]down, down, down, and the 
  [C]Flames went [G]higher
  And it [G]burns, burns, burns 
  The [C]ring of [G]fire, the [D7]ring of [G]fire

  [D]I fell into a [C]burning ring of [G]fire
  I went [D]down, down, down, and the 
  [C]Flames went [G]higher
  And it [G]burns, burns, burns 
  The [C]ring of [G]fire, the [D7]ring of [G]fire
{eoc}

And it [G]burns, burns, burns 
The [C]ring of [G]fire, the [D7]ring of [G]fire
The [D7]ring of [G]fire, the [D7]ring of [G]fire {c:(234,1234)}    
{c:(}[G/]{c:Do, do-do, do-do, do do dooooo…)} 

_______________________________________

{define: D7 0 2 0 2 0}











