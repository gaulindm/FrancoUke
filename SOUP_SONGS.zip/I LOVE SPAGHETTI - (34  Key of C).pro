{t:I LOVE SPAGHETTI    }
{subtitle:(3/4  Key of C)}            
{subtitle:(Mark Anderson)}
{time: 3:20}
{metronome: 174}







{c:INTRO:}
[C]/ / /   / / /   / / /    [G7]/ / /    
[C]/ / /   / / /   / / /   / / /   

[C]I love spaghetti I hope you love spaghetti [Am]too
If [C]you love spaghetti I'll order a big bowl for [A7]two
[F/]I [F/]love [F/]the [F/]sauce
[G7/]I [G7/]love [G7/]the [G7/]cheese
If [F/]you [F/]love [F/]spa[F/]ghetti then [G7/]just [G7/]say  
"YES PLEASE!"
And [C]we'll have spaghetti and maybe some 
[G7]Gelato [C]too

[C]I love spaghetti I hope you love spaghetti [Am]too
If [C]you love spaghetti I'll order a big bowl for [A7]two
[F/]I [F/]love [F/]spa[F/]ghetti for 
[G7/]Break[G7/]fast [G7/]and [G7/]lunch
[F/]Spa[F/]ghe[F/]tti [F/]dinners I [G7/]love [G7/]a   
Whole bunch!
So [C]let's have spaghetti and maybe some 
[G7]Gelato [C]too

{c:INSTRUMENTAL only here}
[C]I love spaghetti I hope you love spaghetti [Am]too
If [C]you love spaghetti I'll order a big bowl for [A7]two
[F/]I [F/]love [F/]the [F/]sauce
[G7/]I [G7/]love [G7/]the [G7/]cheese
If [F/]you [F/]love [F/]spa[F/]ghetti then [G7/]just [G7/]say 
"YES PLEASE!"
And [C]we'll have spaghetti and maybe some 
[G7]Gelato [C]too

{c:(sing again)}
[C]I love spaghetti I hope you love spaghetti [Am]too
If [C]you love spaghetti I'll order a big bowl for [A7]two
[F/]I [F/]love [F/]the [F/]sauce 
[G7/]I [G7/]love [G7/]the [G7/]cheese
If [F/]you [F/]love [F/]spa[F/]ghetti then [G7/]just [G7/]say  
"YES PLEASE!"
And [C]we'll have spaghetti and maybe some 
[G7]gelato [C]too

Or some [G7]pasta fa[C]zoo
Or may[G7]be gaba[C]goo  {c:(23,123,12)}  [G7/]  [C/]