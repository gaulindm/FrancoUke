{title:KEEP HAULING}
{subtitle:}


[G]When love just seems so [C]far a[G]way,
Dkeep hEmauling, kCeep hDauling.
GThe tide will flood your Cheart some Gday,
Ckeep Dhauling Gboys.
Verse 2 
GWhen your guiding star's in a Ccloudy Gsky,
Dkeep Emhauling, Ckeep hDauling.
GYou'll find your way to the Cbright sunGrise,
Ckeep Dhauling Gboys.
Cborus 
CKeep hauling ho,
Grouse and Emraise your Dvoice.
EmHold your cCourse and Gdon't let go,
Ckeep Dhauling Gboys.
Verse 3 
GIf you gave your best and your Cheart stayed Gtrue,
Dkeep Emhauling, Ckeep Dhauling.
GThere's only one thing Cleft to Gdo,
Ckeep Dhauling Gboys.
