{title:THIS LITTLE LIGHT OF MINE   }
{subtitle:(4/4     Key of C)}
{subtitle:(Avis Burgeson Christiansen)}
{subtitle:(& Harry Dixon Loes)}
{c:(closing) }
{time: 3:25}
{metronome: 166} 
{c:(turn your tablet HORIZONTAL)}




{c:INTRO:}
[D7]/ / / /    [G7]/ / / /    
[C]/ / / /    / / / /

{soc}
     [C]This little light of mine,                  I’m gonna let it [C7]shine
                           {c:(this little light of mine,                let it)}
     [F]This little light of mine,                I’m gonna let it [C]shine
    {c:(shine…               this little light, I’m gonna let it shine)}
     This little light of mine,                 [E7]I’m gonna let it [Am]shine
                           {c:(this little light, I’m gonna let it shine)}
     Let it [D7]shine, let it [G7]shine, let it [C]shine 
{eoc}

[C]Some say the time's not right, we’re gonna let it [C7]shine
[F]Some say the time's not right, we’re gonna let it [C]shine
If there’s a darkness in our land, [E7]we’re gonna let it [Am]shine
Let it [D7]shine, let it [G7]shine, let it [C]shine

{soc}
     [C]This little light of mine,                  I’m gonna let it [C7]shine
                           {c:(this little light of mine,                let it)}
     [F]This little light of mine,                I’m gonna let it [C]shine
    {c:(shine…               this little light, I’m gonna let it shine)}
     This little light of mine,                 [E7]I’m gonna let it [Am]shine
                           {c:(this little light, I’m gonna let it shine)}
     Let it [D7]shine, let it [G7]shine, let it [C]shine 
{eoc}

[C]Won’t let anyone put it out, we’re gonna let it [C7]shine
[F]Won’t let anyone put it out, we’re gonna let it [C]shine
Won’t let anyone put it out, [E7]we’re gonna let it [Am]shine
Let it [D7]shine, let it [G7]shine, let it [C]shine

{soc}
     [C]This little light of mine,                  I’m gonna let it [C7]shine
                           {c:(this little light of mine,                let it)}
     [F]This little light of mine,                I’m gonna let it [C]shine
    {c:(shine…               this little light, I’m gonna let it shine)}
     This little light of mine,                 [E7]I’m gonna let it [Am]shine
                           {c:(this little light, I’m gonna let it shine)}
     Let it [D7]shine, let it [G7]shine, let it [C]shine 
{eoc}

Gonna [C]take this little light round the world
We’re gonna let it [C7]shine
Gonna [F]take this little light round the world
We’re gonna let it [C]shine
Gonna take this little light round the world 
[E7]We’re gonna let it [Am]shine
Let it [D7]shine, let it [G7]shine, let it [C]shine

{soc}
     [C]This little light of mine,                  I’m gonna let it [C7]shine
                           {c:(this little light of mine,                let it)}
     [F]This little light of mine,                I’m gonna let it [C]shine
    {c:(shine…               this little light, I’m gonna let it shine)}
     This little light of mine,                 [E7]I’m gonna let it [Am]shine
                           {c:(this little light, I’m gonna let it shine)}
     Let it [D7]shine, let it [G7]shine, let it [C]shine 

     Let it [D7]shi…ne, let it [G7]shi…ne, let it 

     [C]sh[////]i…[////]i…[////]   [C/]ine  [G7/]  [C/] 
{eoc}

{define: D7 0 2 0 2 0}