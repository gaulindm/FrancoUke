

{title:128  TAKE IT EASY  }
{subtitle:(4/4  Key of G)}
{subtitle:(Jackson Browne and Glenn Frey) }
{time:3:35}
{metronome: 142}
         




[G]/ / / /   / / / /    
[C]/ / / /    [Am7]/ / / / 
[G]/ / / /   / / / /    
[C]/ / / /    [Am7]/ / / /    
[G]/ / / /   / / /

Well I'm a [G]runnin' down the road try'n to 
Loosen my load
I've got seven women [D]on my [C]mind
[G]Four that wanna own me 
[D]Two that wanna stone me
[C]One says she's a friend of [G]mine 

Take it [Em]ea....sy, take it [C]ea...[G]sy
Don't let the [Am]sound of your own 
[C]Wheels drive you [Em]crazy {c:(4,123)}
Lighten [C]up while you still [G]can
Don't even [C]try to under[G]stand 
Just find a [Am]place to make your [C]stand
And take it [G]ea...sy

Well, I'm a [G]standin' on a corner in 
Winslow, Arizona
Such a fine [D]sight to [C]see
It's a [G]girl my lord in a [D]flat-bed Ford
Slowin' [C]down to take a look at [G]me 

Come on, [Em]ba...by, don't say [C]may...[G]be
I gotta [Am]know if your sweet [C]love is gonna 
[Em]Save me {c:(4,123)}
We may [C]lose and we may [G]win
Though we may [C]never be here a[G]gain
So open [Am]up I'm climbin' [C]in
So take it [G]ea...sy {c:(234)}


[G]/ / / /   / / / /   / /    [D]/ /    [C]/ / / /    
[G]/ / / /    [D]/ / / /    [C]/ / / /    [G]/ / /


Well, I'm a [G]runnin' down the road 
Tryin' to loosen my load
Got a world of trouble [D]on my [C]mind
[G]Lookin' for a lover who [D]won't blow my cover
She's [C]so hard to [G]find 
Take it [Em]ea...sy,  take it [C]ea...[G]sy
Don't let the [Am]sound of your own [C]wheels 
Make you [Em]crazy
Come on [C]ba...[G]by, don't say [C]may...[G]be
I gotta [Am]know if your sweet [C]love is gonna 
[G/]Save [G/]me {c:(234)}

[C]Ooo..oo-oo, Ooo..oo-oo
[G]Ooo..oo-oo, Ooo..oo-oo 
[C]Ooo..oo-oo, Ooo..oo-oo 
[G]Ooo..oo-oo, Ooo..oo-oo 

[C]Ooo..oo-oo, Ooo..oo  
Oh, we got it [G]ea…[F]…[C]sy
We oughtta take it [G]ea…[F]…[C]sy 
{c:(34,1234)} [Em/]  

_____________________________________








