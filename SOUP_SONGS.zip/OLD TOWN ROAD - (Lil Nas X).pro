{title:  OLD TOWN ROAD}
{subtitle:(Lil Nas X)}
{subtitle: 4/4      Key of A}
{metronome:128}
{time:3:01}







{c:(slow strums)}

[A]/ /    [C]/ /

[G]/ /    [D]/ /

[A]/ /    [C]/ /

[G]/ /    [D]/

[D/]Yeah, I'm gonna [A/]take my [A/]horse 
To the [C/]old town [C/]road
I'm gonna [G/]    ride   [G/]   ’til I [D/]can't no [D/]more
I'm gonna [A/]take my [A/]horse 
to the [C/]old town [C/]road
I'm gonna  [G/]     ride [G/]   ’til I [D/]can't no [D/]more
            
I got the [A]horses in the back
[C]Horse tack is attached [G]Hat is matte black
Got the [D]boots that's black to ma-a-atch
[A]Ridin' on a horse, ha [C]You can whip your Porsche
[G]I been in the valley
You ain't [D]been up off that po-orch, now

[A]Can't nobody tell me [C]nothin'
[G]   You can't tell me [D]nothin'
[A]Can't nobody tell me [C]nothin'
[G]   You can't tell me [D]nothin'

[A]Ridin' on a tractor, [C]lean all in my bladder
[G]Cheated on my baby, [D]You can go and ask her
[A]My life is a movie, [C]bull ridin' and buddies
[G]Cowboy hat from Gucci, [D]wrangler on my booty

[A]Can't nobody tell me [C]nothin'
[G]   You can't tell me [D]nothin'
[A]Can't nobody tell me [C]nothin'
[G]   You can't tell me [D]nothin'

Yeah, I'm gonna [A]take my horse 
to the [C]old town road
I'm gonna [G]      ride 
'til I [D]can't no more
I'm gonna [A]take my horse to the [C]old town road
I'm gonna  [G]     ride 
'til I [D]can't no more

[A/]Hat down, cross town   [C/]livin like a rock star
[G/]Spent a lot of money on my   [D/]brand new uke y'all
[A/]Baby's got a habit
diamond [C/]rings and fancy sports bras
[G/]Ridin' down Rodeo in my   [D/]Masarati sports car
[A]Got no stress I've been [C]through all that
I'm like a [G]Marlboro man so I [D]kick on back
Wish I could [A]roll on back 
to that [C]Old Town Road
I wanna [G]    ride till I [D]can't no more

I'm gonna [A]take my horse to the [C]old town road
I'm gonna [G]    ride 'til I [D]can't no more
I'm gonna [A]take my horse to the [C]old town road
I'm gonna  [G]     ride 'til I [D]can't no more

[A//] [C//] [G//] [D//]
[A//] [C//] [G//] [D/]


 