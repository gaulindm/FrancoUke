{title: ORDINARY DAY}
{subtitle:   4/4   Key of G}
{subtitle:  Alan Doyle, Sean McCann (Great Big Sea)}
{metronome: 130}
{time:  3:40}

{c:tambourine in barred sections}

[G]/ / / /    [C]/ / / /    [G]/ / / /    [C]/ / /
 
I've got a [G]smile on my face 
And I've got [C]four walls around me  [G]/ / / /    [C]/ / /
I've got the [G]sun in the sky
And all the [C]waters surround me [G]   oh, you [D]know
Yeah, I [G]win now but sometimes I [C]   lose
I've been [G]battered but I never [C]bruise
It's not so [Am7]ba...d   [D/]     and I say

{soc}
  [G]Way, hey hey it's just an [C]ordinary [D]day
  And it's [G]all your [C]state of [D]mind
  At the [G]end of the day
  You [C]just got to [D]say it's al[G]...right {c:(34)}
{eoc}  
   
 [C]/ / / /    [G]/ / / /    [C]/ / / 

Janey [G]sings on the corner
What [C]keeps her from dying ([G]oooo...[C]ooo)
Let 'em {soh}[G]say what they want{eoh}
[C]She won't stop trying [G]   oh, you [D]know
She might [G]stumble if they push her [C]  'round
She might [G]fall but she'll never lie [C]down
It's not so [Am7]ba...d  [D/]     and I say

{soc}
  [G]Way hey hey it's just an [C]ordinary [D]day
  And it's [G]all your [C]state of [D]mind
  At the [G]end of the day
  You [C]just got to [D]say it's al[G]...right {c:(34)}
{eoc}
  {c:(}[C]{c:123)}  It's al[G]right it's al[C]ri-ight  {c:(beat)}
  [C/]It's   [C/]all   [C/]right!

{soc}
  [G]/ / / /    [C]/ /    [D]/ /
  [G]/ /    [C]/ /    [D]/ / / /
  [G]/ / / /    [C]/ /    [D]/ /
  [G]/ / / /    [C]/ / /
{eoc}

In this [G]beautiful life
There's [C]always some sorrow ([G]oooo...[C]ooo)
And it's a {soh}[G]double-edged knife{eoh}
But there's [C]always tomorrow [G]    oh, you [D]know
It's up to {soh}[G]you now if you sink or [C]swim{eoh} 
{soh}Just keep the [G]faith{eoh} that your ship will come [C]in
It's not so [Am7]ba...d  [D/]    and I say

{soc}
  [G]Way hey hey it's just an [C]ordinary [D]day
  And it's [G]all your [C]state of [D]mind
  At the [G]end of the day, you [C]just got to [D]say
  I say [G]way hey hey it's just an [C]ordinary [D]day
  And it's [G]all your [C]state of [D]mind
  At the [G]end of the day
  You [C]just got to [D]say it's al[G]...right  {c:(34)}
  {c:(}[C]{c:123)}  It's al[G]right it's alri-ight {c:(123)}
{eoc}

Cause I've got a [G/]smile on my face 
{c:(slower)} And I've got [C/]four walls around me [G/gliss]

