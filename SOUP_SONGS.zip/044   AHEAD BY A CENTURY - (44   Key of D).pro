

{title:044   AHEAD BY A CENTURY   }
{subtitle:(4/4   Key of D)}    
{subtitle:(Rob Baker, Gordon Downie)}
{subtitle:(Johnny Fay, Paul Langlois, Gord Sinclair)}
{metronome:136}
{time:4:25}

{c:BEGINNERS, you can stay on a D }
       {c:(ignore the sus chord and strum lightly)}

{c:"open A" means pluck the open A string only}


[D]/ /   [Dsus2]/           {c:open A}    [D]/ / / /   
[D]/ /   [Dsus2]/           {c:open A}    [D]/ / / /  
[D]/ /   [Dsus2]/           {c:open A}    [D]/ / / /   
[D]/ /   [Dsus2]/           {c:open A}    [D]/ / / /   

{c:(}[D]{c:1,2)}     First thing we'd climb a tree     
{c:(4,12)}   And maybe then we'd talk
{c:(4,12)}   Or sit silently     
{c:(4,12)}   And listen to our thoughts

{c:(}[Cadd9]{c:12)}   With illusions of someday  
{c:(}[D]{c:12)}   Casting a golden light
{c:(}[C]{c:12)}   No dress rehearsal… 
{c:(}[D]{c:12)}   This is our life   

[D]/ /   [Dsus2]/           {c:open A}    [D]/ / / /   
[D]/ /   [Dsus2]/           {c:open A}    [D]/ / / /   

{c:(}[D]{c:12)} Then that's where the hornet stung me 
{c:                                        {c:(}[Cadd9]{c:123)}     And I had a feverish [D]     dream 
With revenge and [Cadd9]doubt
Tonight, we smoke them [D]ou-ou-ou-out {c:(4,1234)}



{c:(}[A]{c:12)}  You are ahead by a cent’ry  
{c:(}[G]{c:12)}  You are ahead by a cent’ry  
{c:(}[A]{c:12)}  You are ahead by a cen-tu-ry 
   
{c:G/   G/   G/    (234)}

[D]/ /   [Dsus2]/           {c:open A}    [D]/ / / /   
[D]/ /   [Dsus2]/           {c:open A}    [D]/ / / / 
[D]/ /   [Dsus2]/           {c:open A}    [D]/ / / /   
[D]/ /   [Dsus2]/           {c:open A}    [D]/ / / / 

{c:(}[D]{c:1,2)}     Stare in the morning shroud
{c:(4,12)}   And then the day began
{c:(4,12)}   I tilted your cloud
{c:(4,12)}   You tilted my hand

{c:(}[Cadd9]{c:12)}      Rain falls in real time  
[D]  And rain fell through the night
{c:(}[C]{c:12)}    No dress rehearsal 
[D/]  This is our life!!!    

[D]/ /   [Dsus2]/           {c:open A}    [D]/ / / /   
[D]/ /   [Dsus2]/           {c:open A}    [D]/ / / / 

[D] Then that's where the hornet stung me 
{c:(}[Cadd9]{c:123)}    And I had a serious [D]    dream 
With revenge and [Cadd9]doubt
Tonight, we smoke them [D]ou-ou-ou-out {c:(4,1234)}


{c:(}[A]{c:12)}  You are ahead by a cent’ry  
{c:(}[G]{c:12)}  You are ahead by a cent’ry  
{c:(}[A]{c:12)}  You are ahead by a cen-tu-ry 
{c:(}[G]{c:1234,1234)} 
 
{c:(}[A]{c:12)}  You are ahead by a cent’ry  
{c:(}[G]{c:12)}  You are ahead by a cent’ry  
{c:(}[A]{c:12)}  You are ahead by a cen-tu-ry 
 
{c:G/   G/   G/}

And disappointing you's [D]getting me down {c:(4,1234)}    

[D]/ /   [Dsus2]/           {c:open A}    [D]/ / / /   
[D]/ /   [Dsus2]/           {c:open A}    [D]/ / / / 
[D]/ /   [Dsus2]/           {c:open A}    [D]/ / / /  
[D]/ /   [Dsus2]/           {c:open A}    [D]/ / / /
[D]/ /   [Dsus2]/           {c:open A}    [D]/ / / /    /

_________________________________




{define: Cadd9 0 0 2 0 3}
{define: Dsus4 0 2 2 3 0}






