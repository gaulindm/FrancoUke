

{title:095  DRIFT AWAY }
{subtitle:  4/4  Key of D    }
{subtitle:(Mentor Williams)}
{subtitle: (Dobie Gray/Uncle Kracker)}
{metronome:154}
{time:4:28}

{c:(soft ukes on verses)}




[A]/ / / /   / / / /

[D]  Day after day I'm more conf[A]u-u-sed   
[D]   Yet I look for the light through the pouring [A]ra-ai-ain 
[D]  You know that's a game that I hate to [A]lo-oo-ose 
[Bm] And I'm feelin' the strain {c:(34)}  [D]     ain't it a shame?

Oh, [A]give me the beat boys and free my soul
I [E]want to get lost in your rock'n'roll and [D]drift away 
Oh, [A]give me the beat boys and free my soul 
I [E]want to get lost in your rock'n'roll and [D]drift away 
{c:(4,1234)}   {c: A  / / / /   / / / /}


[D]  Beginning to think that I'm wasting [A]ti-i-ime
[D]   I don't understand the things I [A]do-oo-oo 
[D]  The world outside looks so un[A]ki-i-ind  
[Bm] Now I'm a-countin' on you {c:(34)}  
[D]   To carry me through

Oh, [A]give me the beat boys and free my soul
I [E]want to get lost in your rock'n'roll and [D]drift away 
Oh, [A]give me the beat boys and free my soul
I [E]want to get lost in your rock'n'roll and [D]drift away 
{c:(4,1234)}   {c:A  / / / /   / / / /} 


[Bm]  And when my mind is free
[D]   You know a melody can [A]move me {c:(4,1234)} 
[Bm]  And when I'm feeling blue  
[D]   The guitars comin' through to [E]soothe me {c:(34,1234)}
[D]   Thanks for the joy that you've given [A]me-ee-ee {c:(4,1234)}
[D]    I want you to know, I believe in your [A]so-on-ong {c:(1234)} 
[D]    Rhythm and rhyme and harmo[A]ny-y-y {c:(4,1234)} 
[Bm]  You've helped me along {c:(34)}   
[D]    Making me strong 

{c:(No Ukes, add hand claps )}
Oh, give me the beat boys and free my soul
I want to get lost in your rock'n'roll and drift away 
{c:(4,1234)}
Give me the beat boys and free my soul
I want to get lost in your rock'n'roll and drift away 
{c:(4,123)} 

{c:(Add ukes)  }
Oh, [A]give me the beat boys and free my soul
I [E]want to get lost in your rock'n'roll and [D]drift away 
{c:(4,1234,1234,123)}
Oh, [A]give me the beat boys and free my soul
I [E]want to get lost in your rock'n'roll and [D]drift away 
{c:(4,1234)}  [A/] 



_________________________________




{define:  E  0 4 4 4 7} 




                          