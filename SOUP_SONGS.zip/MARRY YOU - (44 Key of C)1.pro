{title: MARRY YOU }
{subtitle:(4/4 Key of C)} 
{subtitle: (Bruno Mars, Philip Lawrence)}
{subtitle:(& Ari Levine)}
{time: 3:40}
{metronome: 160}







{c:INTRO:}  
[C]/ / / /     / / / /    
[Dm]/ / / /    / / / /
[F]/ / / /   / / / /
[C]/ / / /   / / / /  

{soc}
Its a [C]beautiful night 
We're looking for something [Dm]dumb to do
Hey [F]Baby, I think I wanna marry you    [C]
Is it the look in your eyes 
Or is it this [Dm]dancing juice
Who [F]cares Baby, I think I wanna marry you   [C]   
{eoc}

Well I [C]know this little chapel 
On the boulevard we can 
[Dm]Go-o-o-o-o, no one will [F]kno-o-o-o-ow  
Oh come [C]on, girl
Who cares if we're trashed
Got a pocket full of cash we can 
[Dm]Blo-o-o-o-ow
Shots of pa[F]tro-o-o-o-on, and its [C]on, girl
Don't say no, no, no, no-no 
Just say  [Dm]ya, ya, ya-ya-ya
and we'll [F]go, go, go-go-go, if you're [C]ready
Like I'm ready, 'cause 

{soc}
Its a [C]beautiful night 
We're looking for something [Dm]dumb to do
Hey [F]Baby, I think I wanna marry you    [C]
Is it the look in your eyes 
Or is it this [Dm]dancing juice
Who [F]cares Baby, I think I wanna marry you   [C]   
{eoc}

[C]I'll go get a ring, let the choir bells sing like 
[Dm]Oo-oo-oo-oo-oo, so watcha wanna 
[F]Do-oo-oo-oo-oo, let's just [C]run, girl
If we wake up and you wanna break up that's 
[Dm]Co-oo-oo-oo-ool, no, I won't blame 
[F]Yo-oo-oo-oo-ou, it was [C]fun, girl
Don't say no, no, no, no-no
Just say [Dm]ya, ya, ya-ya-ya
and we'll [F]go, go, go-go-go, if you're [C]ready
Like I'm ready, 'cause   

{soc}
Its a [C]beautiful night 
We're looking for something [Dm]dumb to do
Hey [F]Baby, I think I wanna marry you    [C]
Is it the look in your eyes 
Or is it this [Dm]dancing juice
Who [F]cares Baby, I think I wanna marry you   [C]   
{eoc}

{sob}
  Just say I [C]do-oo-oo-[Dm]oo  
  Tell me right [F]now baby 
  Tell me right [C]now baby, baby 
  Just say I [C]do-oo-oo-[Dm]oo  
  Tell me right [F]now baby
  Tell me right [C]now baby, baby, ‘cause 
{eob}

{soc}
Its a [C]beautiful night 
We're looking for something [Dm]dumb to do
Hey [F]Baby, I think I wanna marry you    [C]
Is it the look in your eyes 
Or is it this [Dm]dancing juice
Who [F]cares Baby, I think I wanna marry you   [C]   

Yeah who [F]cares Baby 
I think I wanna marry you   [C/]
{eoc}


