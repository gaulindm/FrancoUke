

{title:144    END OF THE LINE }
{subtitle:(4/4  Key of C)}      
{subtitle:  (Travelling Wilburys)}
{time:4:19}
{metronome: 168}





[F]/ / / /    /    [C]/ /   {c:(rest)}   
[F]/ / / /    /     [G7]/     [C]/   {c:(rest)}   
[F]/ / / /    /     [G7]/      [C]/     [G7]/      [C]/ / / /     / / / 

Well it’s [C]all right
Riding a[G7]round in the [F]breeze
Well it's [C]all right 
If you live the [G7]life you [C]please {c:(1,2)}
Well it’s all right, doing the [G7]best you [F]can
Well it's [C]all right, as long as you [G7]lend a [C]hand 
{c:(234,1234)}

[F]  You can sit around and wait 
For the [C]phone to ring (at the end of the line)
[F]{c:(1,2)} Waiting for someone to tell you 
[C]Everything (at the end of the line)
[F]  Sit around and wonder what 
To[C]morrow brings (at the end of the line)
Maybe a [G7]diamond ring {c:(1234)}

Well it’s [C]all right
Even if they [G7]say you're [F]wrong
Well it's [C]all right 
Sometimes you [G7]gotta be [C]strong {c:(1,2)}
Well it’s all right
As long as you got [G7]somewhere to 
[F]Lay, well it's [C]all right 
Every day is [G7]judgment [C]day  {c:(234,1234)}

[F]{c:(1,2)} Maybe somewhere down the 
[C]Road a ways (at the end of the line)
[F] You'll think of me wonder where I 
[C]Am these days (at the end of the line)
[F]  Maybe somewhere down the road 
When some[C]body plays (at the end of the line)
[G7]Purple haze {c:(1234)}

Well it’s [C]all right
Even when [G7]push comes to [F]shove
Well it's [C]all right
If you got [G7]someone to [C]love {c:(1,2)}
Well it’s all right, everything'll [G7]work out [F]fine
Well it's [C]all right 
We're going to the [G7]end of the [C]line  
{c:(234,1234)}

[F]  Don't have to be ashamed of the 
[C]Car I drive (at the end of the line)
[F]  I'm just glad to be here happy to 
[C]Be alive (at the end of the line)
[F]{c:(1,2)}  And it don't matter if you're [C]by my side 
        (at the end of the line)
I'm [G7]satisfied  {c:(1234)}

Well it’s [C]all right, even if you're [G7]old ‘n [F]gray
Well it's [C]all right, you still got [G7]something to [C]say 
Well it’s all right, remember to [G7]live and let [F]live
Well it's [C]all right, the best you can [G7]do is for[C]give 
Well it’s all right, riding a[G7]round in the [F]breeze
Well it's [C]all right, if you live the [G7]life you [C]please 
Well it’s all right, even if the [G7]sun don't [F]shine
Well it's [C]all right, we're going to the [G7]end of the [C]line 
{c:(234,1234)}

[F]/ / / /    /    [C]/ /   {c:(rest)}   
[F]/ / / /    /     [G7]/     [C]/   {c:(rest)}   
[F]/ / / /    /     [G7]/      [C]/     [G7]/      [C]/ 


_________________________________








