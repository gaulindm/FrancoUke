{title:VALERIE}
{subtitle:4/4      Key of D}
{subtitle: D. McCabe, R. Pritchard, S Payne, A. Harding}
{subtitle: (The Zutons)}
{time:  }
{metronome:  }

[D]/ / / /   / / 
 
Well some[D]times I go out by myself
And I look across the [Em]water
And I [D]think of all the things, what you're doing
And in my head I paint a [Em]picture
 
[G]Since I've come on home
Well my [F#m]body's been a mess
And I've [G]missed your ginger hair
And the [F#m]way you like to dress
[G] Won't you come on over
[Em] Stop making a fool out of [A]me
[A/]Why don't you come on over Va-a[D]lerie
Valer[Em]ie
V[D]alerie
Valer[Em]ie
 
Did you [D]have to go to jail
Put your house on up for sale
Did you get a good [Em]lawyer-↑er-↑er
I hope you [D]didn't catch a tan
I hope you find the right man 
Who'll fix it [Em]for ya
Are you [D]shoppin' anywhere
Changed the color of your hair 
Are you [Em]busy
And did you [D]have to pay that fine
That you were dodging all the time 
Are you still [Em]dizzy
 
[G]Since I've come on home
Well my [F#m]body's been a mess
And I [G]miss your ginger hair
And the [F#m]way you like to dress
[G] Won't you come on over
[Em] Stop making a fool out of [A]me
[A/]Why don't you come on over Va[D]lerie?
Valer[Em]ie
V[D]alerie
Valer[Em]ie
 
Well somet[D]imes I go out by myself
And I look across the [Em]water
And I [D]think of all the things what you're doing
And in my head I paint a [Em]picture
 
[G]Since I've come on home
Well my [F#m]body's been a mess
And I [G]miss your ginger hair
And the [F#m]way you like to dress
[G] Won't you come on over
[Em] Stop making a fool out of [A]me
[A/]Why don't you come on over V[D]alerie
Valer[Em]ie
V[D]alerie
Valer[Em]ie
V[D]alerie
Valer[Em]ie
V[D]alerie
Val[Em]erie
Why don't you come on over Valer[D/]ie

__________________________________








