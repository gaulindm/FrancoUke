
{title:UKULELE LADY}
{subtitle: 4/4       Key of C}
{subtitle: (Richard Whiting and Gus Kahn)}
{time: 4:40}
{metronome: 130}


{c:INTRO (walkdown):  }
[C]/ /   [Cmaj7]/ /   [C6]/ /   [Cmaj7]/ /
[C]/ /   [Cmaj7]/ /   [C6]/ /   [Cmaj7]/ /

[C]  I saw the splendor of the moonlight 
On Hono[Ab7]lu…   [G7]lu…   [C]Bay
There's something tender in the moonlight 
On Hono[Ab7]lu...     [G7]lu...    [C]Bay
[Am]  And all the beaches are filled with peaches 
[Em]  Who bring their ukes along
[C]  And in the glimmer of the moonlight
they love to [F7]sing ↑this [G7/]song  {c:(ahhh…)}

{soc}
If [C]you [Cmaj7]like a [C6]Ukulele [Cmaj7]Lady
[C]Ukulele [Cmaj7]Lady like a [C6]you  [Cmaj7]
If [F]you [G7]like to [F]linger where it's [G7]shady 
[F]Ukulele [G7]Lady linger [C]too  [Cmaj7]/ /  [C6]/ /  [Cmaj7]/ /
[C]/ /  [Cmaj7]/ /  [C6]/ /  [Cmaj7]/ /

If [C]you [Cmaj7]kiss a [C6]Ukulele [Cmaj7]Lady 
[C]while you promise [Cmaj7]ever to be [C6]true  [Cmaj7]
And [F]she [G7]sees an[F]other uku[G7]lele 
[F]lady fool a[G7]round with [C]you {c:(234)}  [C7]   {c:(234)}

[F]Maybe she'll sigh 
[C]Maybe she'll cry 
[D7]        Maybe she'll find somebody else 
[G7/]        By and [G7/]by

To [C]sing [Cmaj7]to [C6]when it's cool and [Cmaj7]shady 
[C]where the tricky [Cmaj7]wicky wackies [C6]woo   [Cmaj7]
If [F]you [G7]like a [F]Ukulele [G7]Lady  
[F]Ukulele [G7]Lady like a 
[C//]You   [Cmaj7]/ /   [C6]/ /   [Cmaj7]/ /
[C]/ /   [Cmaj7]/ /   [C6]/ /   [Cmaj7]/ / 
{eoc}

[C] She used to sing to me by moonlight 
on Hono[Ab7]lu...    [G7]lu...      [C]Bay
[C] Fond mem'ries cling to me by moonlight
although I'm [Ab7]far    [G7]a…[C]way
[Am] Someday I'm goin’, where eyes are glowin' 
[Em] And lips were made to kiss
[C]  To see somebody in the moonlight 
and hear the [F7]song ↑I [G7/]miss  {c:(Ah…)}


If [C]you [Cmaj7]like a [C6]Ukulele [Cmaj7]Lady
[C]Ukulele [Cmaj7]Lady like a [C6]you  [Cmaj7]
If [F]you [G7]like to [F]linger where it's [G7]shady 
[F]Ukulele [G7]Lady linger 

[C//]Too   [Cmaj7]/ /   [C6]/ /   [Cmaj7]/ /
[C]/ /   [Cmaj7]/ /   [C6]/ /   [Cmaj7]/ / 

If [C]you [Cmaj7]kiss a [C6]Ukulele [Cmaj7]Lady 
[C]while you promise [Cmaj7]ever to be [C6]true  [Cmaj7]
And [F]she [G7]sees an[F]other uku[G7]lele 
[F]lady fool a[G7]round with [C]you {c:(234)}  [C7]   {c:(234)}

[F]Maybe she'll sigh (an awful lot) 
[C]Maybe she'll cry (or maybe not)
[D7]    Maybe she'll find somebody else 
[G7/]   By and [G7/]by

To [C]sing [Cmaj7]to [C6]when it's cool and [Cmaj7]shady 
[C]where the tricky [Cmaj7]wicky wackies [C6]woo   [Cmaj7]
If [F]you [G7]like a [F]Ukulele [G7]Lady 

{c:OUTRO:}
[F]Ukulele [G7]Lady like-a-[C]you, like-a-[F]me, 
like [C]I like-a-[F]you
And [C]we like-a-[F]both the [C]same {c:(234)}  
[G7]I'd like to say, this very day
Oo-koo-lay-lee-La-dy-like-a [C]you... ↑[F]ooo ↑[C/]ooo  [G7]/  [C]/

{define: Ab7 0 x 3 2 3}

_______________________________________








