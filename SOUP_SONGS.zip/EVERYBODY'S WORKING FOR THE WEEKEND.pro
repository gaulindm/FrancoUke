{title:EVERYBODY'S WORKING FOR THE WEEKEND}
{subtitle:4/4      Key of A}
{subtitle: Paul Dean/Mike Reno/Matt Frennette (Loverboy)



Cowbell - Cowbell - Cowbell - SNARE!
  [Asus]  [A]

(Vamp above)  
 
[A] Everyone's watching to [F]see what you will do 
[A] Everyone's looking at [F#m]you...   [D]Oh
 
[A] Everyone's wondering will [F]you come out tonight? [A]
[A] Everyone's trying to get it [F#m]right, get it ri[D]ght
 
 
[C] Everybody's working for the [F]weekend
[C] Everybody wants a new ro[F]mance
[C] Everybody's going off the [F]deep end
[C] Everybody needs a second [F]chance, Whoa oh
 
 
You wanna piece of my [Asus]heart? [A]
You better start from the [Asus]start [A]
You wannna be in the [Asus]show? [A]
Come on baby, let's [F]go!
 
[F](ri[C]ff) [F] [C] [F] [C] [A]
 
[A] Everyone's looking to [F]see if it was you 
[A] Everyone wants you to come [F#m]through [D]
 
[A] Everyone's hoping [F]it'll all work out 
[A] Everyone's waiting, they're holding [F#m]out! [D]
 
 
[C] Everybody's working for the [F]weekend
[C] Everybody wants a new ro[F]mance, hey yeah, hey-hey
[C] Everybody's going off the [F]deep end
[C] Everybody needs a second [F]chance, No-oh
 
 
You wanna piece of my [Asus]heart? [A]
You better start from the [Asus]start [A]
You wannna be in the [Asus]show? [A]
Come on baby, let's [F]go! [Am] [F] [Am]
 
Hey!([F]rif[C]f) [F] [C] [F] [C] [A]
 
You wanna piece of my [Asus]heart? [A]
You better start from the [Asus]start [A]
You wanna be in the s[Asus]how? [A]
Come on baby, let's [F]go
 
You wanna piece of my [Asus]heart? [A]
You better start from the [Asus]start [A]
You wannna be in the [Asus]show? [A]
Come on baby, let's [F]go!
 
F  C  F  C  F  C  A
(riff)           END

{define: Asus  0 2 2 0 0}