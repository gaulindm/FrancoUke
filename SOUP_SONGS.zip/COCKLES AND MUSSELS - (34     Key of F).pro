{title:COCKLES AND MUSSELS }   
{subtitle:(3/4     Key of F)}    
{subtitle:(James Yorkston & Edmund Foreman)}
{time: 2:45}
{metronome:142}








{c:INTRO:}  
[F]/ / /    / / /     [C7]/ / /     [F]/ /  

In [F]Dublin’s Fair City 
Where [C7]girls are so pretty 
I [F]first set my eyes on sweet [C7]Molly Malone
As she [F]wheeled her wheel barrow, through 
[C7]Streets broad and narrow 
Crying [F]Cockles and Mussels 
A[C7]live, alive [F]oh 

{soc}
     A[F]live, alive oh, a[C7]live, alive oh, crying
     [F]Cockles and Mussels a[C7]live, alive [F]oh
{eoc}

Well she [F]was a fishmonger 
And [C7]sure ‘twas no wonder 
For [F]so were her father and [C7]mother before 
And they [F]both wheeled their barrows, through 
[C7]Streets broad and narrow 
Crying [F]Cockles and Mussels 
A[C7]live, alive [F]oh 
 
{soc}
     A[F]live, alive oh, a[C7]live, alive oh, crying
     [F]Cockles and Mussels a[C7]live, alive [F]oh
{eoc}

She [F]died of a fever
Which [C7]no one could save her
And [F]that was the end of sweet [C7]Molly Malone
Now her [F]ghost wheels her barrow, through 
[C7]Streets broad and narrow 
Crying [F]Cockles and Mussels a[C7]live, alive [F]oh 

{soc}
     A[F]live, alive oh, a[C7]live, alive oh, crying
     [F]Cockles and Mussels a[C7]live, alive [F/]oh
{eoc}
