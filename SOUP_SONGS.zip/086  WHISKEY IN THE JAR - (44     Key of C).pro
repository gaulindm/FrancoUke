

{title:086  WHISKEY IN THE JAR }
{subtitle:(4/4     Key of C)}       
{subtitle:(Unknown: Traditional Irish Song)}
{time:4:24}
{metronome: 190}






[F]/ / / /    / / / /      
[C]/ /     [G]/ /     [C]/ / / 

As [C]I was going over 
The [Am]Cork and Kerry mountains  
I [F]met with captain Farrell 
And his [C]money he was counting
I first produced my pistol 
And [Am]then produced my rapier
Saying "[F]Stand and deliver 
For you [C]are my bold deceiver.”

{soc}
Musha [G]ring dumm-a do dumm-a da  
{c:(tap, tap, tap)}
[C]    Whack fol the daddy ol!
[F]    Whack fol the daddy ol!  
There’s [C]whiskey [G]in the [C]jar  
{eoc}

He [C]counted out his money 
And it [Am]made a pretty penny
I [F]put it in my pocket 
And I [C]took it home to Jenny
She sighed and she swore 
That she [Am]never would deceive me
But the [F]devil take the women 
For they [C]never can be easy         

{soc}
Musha [G]ring dumm-a do dumm-a da  
{c:(tap, tap, tap)}
[C]    Whack fol the daddy ol!
[F]    Whack fol the daddy ol!  
There’s [C]whiskey [G]in the [C]jar  
{eoc}

I [C]went into my chamber 
All [Am]for to take a slumber
I [F]dreamt of gold and jewels 
And for [C]sure it was no wonder
But Jenny drew my charges 
And then [Am]filled them up with water
And she [F]sent for Captain Farrell 
To be [C]ready for the slaughter    

{soc}
Musha [G]ring dumm-a do dumm-a da  
{c:(tap, tap, tap)}
[C]    Whack fol the daddy ol!
[F]    Whack fol the daddy ol!  
There’s [C]whiskey [G]in the [C]jar  
{eoc}

’Twas [C]early in the morning 
Be[Am]fore I rose to travel
Up [F]crept a band of footmen 
And sure [C]with them Captain Farrell
I then produced my pistol 
For she [Am]stole away my rapier
But I [F]couldn’t shoot the water 
So a [C]prisoner I was taken           

{soc}
Musha [G]ring dumm-a do dumm-a da  
{c:(tap, tap, tap)}
[C]    Whack fol the daddy ol!
[F]    Whack fol the daddy ol!  
There’s [C]whiskey [G]in the [C]jar  
{eoc}

If [C]anyone can help me 
It’s my [Am]brother in the army
If [F]I could learn his station 
Be it [C]Cork or in Killarney
And if he’d come and save me 
We’d go [Am]roving in Kilkenney
I [F]know he’d treat me fairer 
Than me [C]darling sporting Jenny        

{soc}
Musha [G]ring dumm-a do dumm-a da  
{c:(tap, tap, tap)}
[C]    Whack fol the daddy ol!
[F]    Whack fol the daddy ol!  
There’s [C]whiskey [G]in the [C]jar  
{eoc}

There’s [C]some take delight 
In the [Am]drinking and roving
And [F]others take delight 
In the [C]gambling and the smoking
But I take delight 
In the [Am]juice of the barley
And [F]courting pretty maids 
In the [C]morning, bright and early         
 
{soc}
Musha [G]ring dumm-a do dumm-a da  
{c:(tap, tap, tap)}
[C]    Whack fol the daddy ol!
[F]    Whack fol the daddy ol!  
There’s [C]whiskey [G]in the [C]jar  

Musha [G]ring dumm-a do dumm-a da  
{c:(tap, tap, tap)}
[C]    Whack fol the daddy ol!
[F]    Whack fol the daddy ol!  
There’s [C]whiskey [G]in the [C/]jar  [G/]  [C/]
{eoc}

_______________________











