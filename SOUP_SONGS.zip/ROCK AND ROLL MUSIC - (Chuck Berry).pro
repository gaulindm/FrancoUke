{title:ROCK AND ROLL MUSIC}
{subtitle:(Chuck Berry)}
{subtitle:    4/4    Key of A}
{metronome:174}
{time:2:40}



{c:ELLEN shaker}

{c:(first note is F#)}

{c:LYNDA says  ”One two three four!”} 
 
[E7/] Just let me hear some of that...
 
{soc}
[A]Rock and roll music
Any old way you choose it        
It's got a [D]back beat, you can't lose it
[A]Any old time you use it
It's [E7]gotta be rock and roll music
If you wanna dance with me [A]  
[E7]If you wanna dance with me [A/]
{eoc}

I have no kick against [E7]modern jazz  
Unless you try to play it [A]too darn fast
I lose the beauty of a [D]melody 
until it sounds just like a [E7]symphony  [E7/]
That's why I go for that

{soc}
[A]Rock and roll music
Any old way you choose it        
It's got a [D]back beat, you can't lose it
[A]Any old time you use it
It's [E7]gotta be rock and roll music
If you wanna dance with me [A]  
[E7]If you wanna dance with me [A/]
{eoc}

I took my love on over [E7]’cross the tracks  
So she could hear a man a-[A]wailin' sax
I must admit they had a [D]rockin' band   
Man they were blowin' like a [E7]hurricane  [E7/]
That's why I go for that

{soc}
[A]Rock and roll music
Any old way you choose it        
It's got a [D]back beat, you can't lose it  
[A]Any old time you use it
It's [E7]gotta be rock and roll music
If you wanna dance with me [A]  
[E7]If you wanna dance with me [A/]
{eoc}

Way down south they had a [E7]jubilee  
The jokey folks, they had a [A]jamboree
They're drinkin' beer from a [D]wooden cup   
The folks that danced got [E7]all shook up  [E7/]
And started playin' that

{soc}
[A]Rock and roll music 
Any old way you choose it        
It's got a [D]back beat, you can't lose it
[A]Any old time you use it
It's [E7]gotta be rock and roll music
If you wanna dance with me [A]  
[E7]If you wanna dance with me [A/]
{eoc}

{c:(with fan strum)}
Don't care to hear 'em play a [E7]tango 
I'm in no mood to hear a [A]mambo
It's way too early for a [D]congo   
So keep on rockin' that [E7]piano  [E7/] 
That's why I go for that

{soc}
[A]Rock and roll music
Any old time you use it        
It's got a [D]back beat, you can't lose it   
[A]any old time you use it
It's [E7]gotta be rock and roll music
If you wanna dance with me [A]  
[E7]If you wanna dance with me [A/] [A///]
{eoc}
