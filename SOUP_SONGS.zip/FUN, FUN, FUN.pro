{title:FUN, FUN, FUN  }
{subtitle: 4/4   Key of C  (Brian Wilson, Mike Love)}
{metronome:  }
{time: 2:20 }





{c:INTRO: solo riff }




[F]/ / / /   / / / /    [C]/ / / /   / / / /  

  
[G7]/ / / /    [F]/ / / /    [C]/ / / /     [G7]/ / / 
   
 									    	
Well she [C]got her daddy's car and she cruised through the hamburger [F]stand now


Seems she for[C]got all about the library like she told her old [G7]man now 


And with the [C]radio blasting goes cruising just as fast as she [F]can now


And she'll have [C]fun fun  [G]fun till her  [F]daddy takes the  [G7]T-bird
{c:                  (}[C]{c:Fun, fun, }[G]{c:fun till her }[F]{c:daddy takes the }[G7]{c:T-bird) }
 
a[C]way-ay-ay…[F]            [C]                   [G]     Well the [C]girls can't stand her ‘cause she 
{c:(}[C]{c:Fun   fun   }[F]{c:fun till her }[C]{c:daddy takes the }[G]{c:T-bird        a}[C]{c:wa…) } 

Walks looks and drives like an [F]ace now
{c:(…a…                  …ay, you  }[F]{c:walk like an ace now, you walk like an ace)}

She makes the [C]Indy 500 look like a Roman chariot [G7]race now  
{c:                 (}[C]{c:Oooh…                             You }[G7]{c:look like an ace now, you look like an ace)}

A lotta [C]guys try to catch her but she leads them on a wild goose [F]chase now
{c:        (}[C]{c:Oooh...                                                         You }[F]{c:drive like an ace now)}

        And she'll have [C]fun fun [G]fun  till her [F]daddy takes the  [G7]T-bird 
{c:(You drive like an ace, }[C]{c:fun fun} [G]{c:fun till her }[F]{c:daddy takes the }[G7]{c:T-bird)} 

a[C]way-ay-ay…[F]            [C]                     [G]  
{c:(}[C]{c:Fun   fun   }[F]{c:fun till her }[C]{c:daddy takes the }[G]{c:T-bird a}

   
{c:G7 (way) / / / /   / / / /    C / / / /   / / / / }


{c:G7 / / / /   / / / /    D / / / /    G7 / / / }  Well you

		  
   
[C]Knew all along that your dad was gettin' wise to [F]you now,                and since he 
[C]{c:(Ooh…                                              You }[F]{c:shouldn't ‘a lied now, you shouldn't ‘a lied) }                  
                   
[C]Took your set of keys you've been thinking that your fun is all [G7]through now...     but you can
{c:(}[C]{c:Ooh...                                                             You }[G7]{c:shouldn't ‘a lied now you shouldn't ‘a lied)}
                                                                            
[C]Come along with me ‘cause we gotta a lot of things to [F]do now             and we'll have
{c:(}[C]{c:Ooh…                                                     You }[F]{c:shouldn't ‘a lied now you shouldn't ‘a lied)}
     
[C]Fun fun  [G]fun now that [F]daddy took the [G7]T-bird 
[C]{c:(Fun fun }[G]{c:fun now that }[F]{c:daddy took the }[G7]{c:T-bird)} 

a[C]way-ay-ay…[F]                [C]              and [G]we'll have      
{c:(}[C]{c:Fun   fun   }[F]{c:fun now that }[C]{c:daddy took the }[G]{c:T-bird}
          
[C]Fun fun   [G]fun now that [F]daddy took the [G7]T-bird 
[C]{c:(Fun fun }[G]{c:fun now that }[F]{c:daddy took the }[G7]{c:T-bird)} 
      
a[C]way-ay-ay…[F]             [C]                    [D]  
{c:(}[C]{c:Fun   fun   }[F]{c:fun now that }[C]{c:daddy took the }[D]{c:T-bird}

{c:(Oo-oh)} A[G]way, fun, fun now that Daddy took the T-bird 
{c:(Oooh)} A[C]way, fun, fun now that [F]Daddy took the T-bird
{c:(Oo-oh)} A[G]way, fun, fun now that Daddy took the T-bird 
{c:(Oooh)} A[C]way, fun, fun now that [F]Daddy took the T-bird 
{c:(Oo-oh)} A[G]way, fun, fun now that Daddy took the T-bird 
{c:(Oooh)} A[C]way, fun, fun now that 
[F]Daddy took the T-bird a[C//]way  [F]//   [C]////