{title:PURPLE PEOPLE EATER}
{subtitle: (Sheb Wooley)}
{metronome: 162}
{time: 2:45 }





{c:INTRO: C / / / /   / / /}

Well I [C]saw the thing comin’ out of the sky 
It had [G7]one long horn, [C]one big eye 
I commenced to shakin’ and I [F]said “ooh-eee! 
It [G7/]looks like a purple people eater to me.”

It was a [C]one-eyed, one-horned
Flyin’ purple people eater 
([G7]One eyed, one horned flyin’ purple people eater)
[C]One-eyed, one horned, flyin’ purple people eater 
[G7]Sure looked strange to [C]me (one eye?){c:(234,123)}

Well he [C]came down to earth and he lit in a tree 
I said [G7]“Mr. Purple People Eater, [C]don’t eat me” 
I heard him say in a [F]voice so gruff 
“I [G7/]wouldn’t eat you ‘cause you’re so tough”

It was a [C]one-eyed, one-horned
Flyin’ purple people eater 
([G7]One eyed, one horned flyin’ purple people eater)
A [C]one-eyed, one horned, flyin’ purple people eater 
[G7]Sure looked strange to [C]me (one horn?) {c:(234,123)}

I said “[C]Mr Purple People eater, what’s your line?” 
He said “[G7]Eatin' purple people and it [C]sure is fine 
But that's not the reason that I [F]came to land 
I [G7/]wanna get a job in a rock and roll band”

Well, [C]bless my soul, rock and roll 
Flyin' purple people eater
[G7]Pigeon-toed, under-growed
Flyin' purple people eater, ([C]we wear short shorts) 
Friendly little people eater
[G7] What a sight to [C]see (oh!) {c:(234,123)}

And then he [C]swung from the tree and he 
Lit on the ground, and he [G7]started to rock 
Really [C]rockin' around
It was a crazy little ditty with a [F]swingin' tune 
(sing a [G7/]lop-bop-a-lupa-lop, a lop bam boom)

Well [C]bless my soul, rock and roll 
Flyin' purple people eater
[G7]Pigeon-toed, under-growed
Flyin' purple people eater
([C]I like short shorts) flying purple people eater  
[G7] What a sight to [C]see (purple people!)  {c:(234,123)}

Well he [C]went on his way and 
What do you know I [G7]saw him last night 
On a [C]TV show
He was blowin' it out really [F]knockin' ‘em dead 
Playing [G7/]rock and roll music through the 
Horn in his head 

{c:KAZOOS}
{c:F/ / / /   / / / /    C / / / /  }
{c:C / / / /    F / / / /   / / / / }
{c:G7 / / / /   / / / /     C /}  Tequila!