{title:QUE SERA SERA    }
{subtitle:tab    3/4    Key of G}
{subtitle:(Jay Livingston & Ray Evans)}
{metronome: 150}
{time:2:30 }





{c:INTRO: }
{c:G / / /   / / /   /   (stop)  “sweetly”}

When I was [G]just a [Gmaj7]little  [G6]girl 
I asked my mother what will I [D7]be
Will I be pretty, [C]will I be [D7]rich
Here’s what she said to [G]me   

{soc} 
   Que se[C]ra, sera
   Whatever will [G]be, will be
   The future’s not [D7]ours to see 
   Que sera, se[G]ra    [D7]
   What will [Am]be, will [G]be  
{eoc}
 
When I grew [G]up and [Gmaj7]fell     in [G6]love 
I asked my sweetheart, what lies a[D7]head
Will we have rainbows, [C]day after [D7]day?  
Here’s what my sweetheart [G]said 
 
{soc} 
   Que se[C]ra, sera
   Whatever will [G]be, will be
   The future’s not [D7]ours to see 
   Que sera, se[G]ra    [D7]
   What will [Am]be, will [G]be  
{eoc}
 
Now I have [G]children [Gmaj7]of     my [G6]own 
They ask their mother, what will I [D7]be
Will I be handsome, [C]will I be [D7]rich?  
I tell them tende[G]rly  
 
{soc} 
   Que se[C]ra, sera
   Whatever will [G]be, will be
   The future’s not [D7]ours to see 
   Que sera, se[G]ra    [D7]
   What will [Am]be, will [G]be  [G/]
{eoc}