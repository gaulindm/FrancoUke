{title:MY LIFE}
{subtitle:Billy Joel}

[D7]  [C7]  [F7]  [Bb]
[D7]  [C7]  [F7]  [Bb]

[D] Got a call from an old friend, we used to be [G]real close
[A] Said he couldn't go on the American [D]way [G] [G]
[D] Closed the shop, sold the house, bought a ticket to the [G]West Coast
[A] Now he gives them a stand-up routine in L.[D] A. [D] [C7] [F7] [Bb]

 

[D7]  [C7]  [F7]  [Bb]

[D] I don't need you to worry for me cause I'm al-[G]right
[A] I don't want you to tell me it's time to come [D] home [G] [D] [G] [Em7]
[D] I don't care what you say anymore, this is [G] my life [G] [D] [Em7] [D]
[A] Go ahead with your own life, and leave me a-[Bm]lone

 

I never said you had to offer me a [F#7] second chance
[D7] I never said I was a victim of [E7] circumstance
[G] I still be-[D] long, [F#7] don't get me [Bm] wrong
[E7sus4] And you can [E7] speak your mind
But [G] not [A] on [G] my [A] time

 

[D] They will tell you you can't sleep alone in a [G] strange place [G] [D] [Em7] [D]
[A] Then they'll tell you you can't sleep with somebody [D] else [G] [D] [G] [D]
[D] But sooner or later you sleep in your [G] own space
[A] Either way it's okay you wake up with your[D] self [D] [C7] [F7] [Bb]

 

[D7] [C7] [F7] [Bb]

[D] I don't need you to worry for me cause I'm al-[G]right
[A] I don't want you to tell me it's time to come [D] home
[D] I don't care what you say anymore, this is [G] my life [G] [D] [Em7] [D]
[A] Go ahead with your own life, and leave me a-[Bm]lone

 

I never said you had to offer me a [F#7] second chance
[D7] I never said I was a victim of [E7] circumstance
[G] I still be-[D]long, [F#7] don't get me [Bm] wrong
[E7sus4] And you can [E7] speak your mind
But [G] not [A] on [G] my [A] time

 

[D]  [G]  [A]  [D]

[D] I don't care what you say anymore, this is [G] my life [G] [D] [Em7] [D]
[A] Go ahead with your own life, and leave me a-[D]lo-[D]ne [C7] [F7] [Bb]

repeat fading
[D7]  [C7]  [F7]  [Bb]


