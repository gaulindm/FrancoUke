

{title:039  ME AND JULIO }
{t:DOWN BY THE SCHOOLYARD      }
{subtitle:(4/4      Key of G)}
{subtitle: (Paul Simon)}
{metronome: 196 }
{time:3:16}





[G]/ /    [C]/ /    [G]/ /    [D7]/ /
[G]/ /    [C]/ /    [G]/ /    [D7]/ /
[G]/ /    [C]/ /    [G]/ /    [D7]/ /
[G]/ /    [C]/ /    [G]/ /    [D7]/ /

The [G]mama pajama rolled out of bed
And she ran to the police [C]station {c:(34,123)}
When the [D7]papa found out he began to shout
And he started the investi[G]gation {c:(34)} [G/]

It's against the [D7]law. It was against the [G]law
What the mama [D]saw 
It was against the [G]law {c:(234,123)}

Oooh, the [G]mama looked down 
And spit on the ground
Ev'ry time my name gets [C]mentioned {c:(34,1234)}
The [D7]papa say “Oy, if I get that boy
I'm gonna stick him in the house of de[G]tention” {c:(34)}  [G/]

{soc}
  Well I'm on my [C]way
  I don't know [G]where I'm goin' 
  I'm on my [C]way
  I'm takin' my [G]time but I [A7]don't know [D]where
  Goodbye to [C]Rosie, the Queen of Co[G]rona 
  Seein' [G]me and [F]Julio 
  [C]Down by the [D]school[G]yard [C//] [G//] [D7//]
  Seein' [G]me and [F]Julio 
  [C]Down by the [D]school[G]yard [C//] [G//] [D7//]
{eoc}

{c:Whistle over chords}
[C]/ / / /   / / / /    [G]/ / / /   / / / /
[C]/ / / /   / / / /    [G]/ /    [A7]/ /    [D]/ / / / 
[C]/ / / /   / / / /    [G]/ / / /   / / / /
[G]/ /    [F]/ /    [C]/ /    [D]/ /    
[G]/ /    [C]/ /    [G]/ /    [D7]/ /
[G]/ /    [F]/ /    [C]/ /    [D]/ /    
[G]/ /    [C]/ /    [G]/ /    [D7]/ /
[D7]/ / / /    [D7]/

Whoa-oh, in a [G]couple of days
They come and take me away
But the press let the story [C]leak {c:(234,123)}
And when the [D7]radical priest 
Come to get me released
We was all on the cover of [G]Newsweek {c:(34)} [G/]

{soc}     
  And I'm on my [C]way
  I don't know [G]where I'm goin' 
  I'm on my [C]way
  I'm takin' my [G]time but I [A7]don't know [D]where
  Goodbye to [C]Rosie
  The Queen of Co[G]rona  {c:(34,123)}
  Seein' [G]me and [F]Julio 
  [C]Down by the 
  [D]school[G]yard [C//] [G//] [D7//]
  Seein' [G]me and [F]Julio 
  [C]Down by the 
  [D]school[G]yard [C//] [G//] [D7//]
  Seein' [G]me and [F]Julio 
  [C]Down by the 
  [D]school[G]yard [C//] [G//] [D7//] [G/]
{eoc}



_____________________________________













