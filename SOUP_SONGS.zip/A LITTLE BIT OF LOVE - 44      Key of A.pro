

{title:A LITTLE BIT OF LOVE  }
{subtitle:   4/4      Key of A}
{subtitle: Rivers Cuomo, Dave Gibson Jax, Wayne Wilkins}
{subtitle:  (Weezer) }
{time:3:57}
{metronome:174}


[A]/ / / /    [F#m]/ / / /    
[Dsus2]/ / / /      [A]/ / / /
[A]/ / / /    [F#m]/ / / /    
[Dsus2]/ / / /      [A]/ / / /

{soc}
   [A]   A little bit, a little [F#m]bit of lo...[Dsus2]           ...ove 
   Goes a [A]pretty long way
   [A]   Take a look at where you [F#m]started fro...[Dsus2]         ...om 
   And where you [A]are today
   [A]   You climbed mountains [F#m]         you swam oceans 
   [Dsus2]          You got knocked down [A]    and kept goin'
   [A]    In the end you know you [F#m]got to say 
   A [Dsus2]little bit of love goes a [A]pretty long way
{eoc} 

[A]/ / / /    [F#m]/ / / /

 
[A]All your [F#m]wounds are [Dsus2]healing [A]fine
[A]I'm so [F#m]glad I got you [Dsus2]in my [A]life

[A]Now the [F#m]winter [Dsus2]frost is g[A]one
[A]Now is our ch[F#m]ance to live the [Dsus2]life we w[A]ant


{soc} 
   [A]    A little bit, a little [F#m]bit of lo... [Dsus2]           ...ove 
   Goes a [A]pretty long way
   [A]    Everybody, evеry[F#m]body's lo... [Dsus2]          ...ost
   And [A]that's okay
   [A]    Some show it [F#m]        some hide it            
   [Dsus2]           But thеre's a battle [A]    we're all fighting
   [A]    So if you're looking for the [F#m]words to say 
   A [Dsus2]little bit of love goes a [A]pretty long way
{eoc}
 
[A]/ / / /   [F#m]/ / / /

 
[A]Holding [F#m]onto the [Dsus2]rabbit's [A]feet
[A]Walking [F#m]down the sunny [Dsus2]side of the [A]street

[A]Shadows [F#m]creeping [Dsus2]at your [A]back
[A]You can forget '[F#m]em like an am[Dsus2]ne...sia[A]c 


 
{soc} 
   [A]    A little bit, a little [F#m]bit of lo... [Dsus2]          ...ove 
   Goes a [A]pretty long way
   Love is really like a [F#m]wonder dru... [Dsus2]          ...ug 
   Let's [A]medicate
   [A]     And say {soh}goodbye{eoh} [F#m]        to the drama 
   [Dsus2]           It's a beeline  [A]    to nirvana
   If you're looking for the [F#m]words to say 
   A [Dsus2]little bit of love goes a [A]pretty long way
{eoc} 
 
H[A]e-e-ey  H[F#m]o-oh-oh  
H[Dsus2]e-e-ey hoh-oh-oh -[A]oh-oh-oh 
He-e-ey  H[F#m]o-oh-oh  
H[Dsus2]e-e-ey hoh-oh-oh -[A]oh-oh-oh 

{soc} 
   [A]    A little bit, a little [F#m]bit of lo...[Dsus2]         ...ove 
   Goes a [A]pretty long way
   [A]    Take a look at where you [F#m]started fro...[Dsus2]          ...om  
   And where you [A]are today
   [A]    You climbed mountains, [F#m]             swam oceans 
   [Dsus2]           You got knocked down [A]    and kept goin'
   [A]    In the end you know you [F#m]got to say 
   A [Dsus2]little bit of love goes a [A]pretty long way
{eoc}
 
H[A]e-e-ey  H[F#m]o-oh-oh  
H[Dsus2]e-e-ey hoh-oh-oh -[A]oh-oh-oh 
H[A]e-e-ey  H[F#m]o-oh-oh  
     
A [Dsus2/]little bit of love goes a [A/]pretty long way
 

______________________________

















