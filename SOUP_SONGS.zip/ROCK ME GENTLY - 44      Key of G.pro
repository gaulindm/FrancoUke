{title:ROCK ME GENTLY   }
{subtitle:   4/4      Key of G}
{subtitle:(Andy Kim)}
{time:3:30}
{metronome:121}

[G]/ / / /   / / / /
  
[G] Ain't it good   [C]    ain't it right 
[G] That you are with me  [C]     here tonight
[G] The music playing, [C]   our bodies swayin' in [G]time 
(In time, in t[C]ime, in time)
 
[G] Touching you  [C]    so warm and tender 
[G] Lord I feel such a  [C]    sweet surrender
[G] Beautiful is the [C]dream that makes you m[G]ine  O[C]oh

{soc} 
[G]Rock me gently, [C]Rock me slowly
[G]Take it easy,   [C]don't you know
That [G]I have never been lo[C]ved like this bef[G]ore
[C]Baby, [D]baby,    [G]Rock me gently, [C]Rock me slowly
[G]Take it easy, [C]don't you know
That [G]I have never been lo[C]ved like this bef[G]ore
{eoc}
 

[G] Oh my darling   [C]    oh my baby
[G] You got the moves that [C]    drive me crazy
[G] And on your face  [C]    I see a trace of lov[G]e
(Of love, of l[C]ove, of love)
[G] Come hold me close [C]    don't let me go
[G] I need you, honey  [C]    I love you so
[G] You were made for [C]me by the stars ab[G]ove   [C]Ohh

{soc} 
[G]Rock me gently, [C]Rock me slowly
[G]Take it easy,   [C]don't you know
That [G]I have never been lo[C]ved like this bef[G]ore
[C]Baby, [D]baby,    [G]Rock me gently, [C]Rock me slowly
[G]Take it easy, [C]don't you know
That [G]I have never been lo[C]ved like this bef[G]ore


[C]Baby, [D]baby, [G]rock me gently, [C]    rock me slowly
[G]Take it easy, [C]don't you know
That [G]I have never been lo[C]ved like this bef[G/]ore 
{soc}

_____________________________________






















