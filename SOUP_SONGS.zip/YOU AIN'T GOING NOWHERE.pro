{title:YOU AIN'T GOING NOWHERE}
{subtitle:}
 
[G]Clouds so swift   [Am]rain won't lift
[C]Gate won't close   [G]railings froze
[G]Get your mind off [Am]wintertime  [C]you ain't goin' now[G]here
 
[G]Whoo-ee! [Am]Ride me high   [C]tomorrow's the day
My [G]bride's gonna come     oh, oh, are [Am]we gonna fly
[C]Down in the easy [G]chair
 
[G]I don't care how many [Am]letters they sent
The [C]morning came and [G]morning went
[G]Pack up your money  [Am]and pick up your tent
[C]You ain't goin' n[G]owhere
 
[G]Whoo-ee! [Am]Ride me high  [C]tomorrow's the day
My [G]bride's gonna come    
oh, oh, are [Am]we gonna fly
[C]Down in the easy [G]chair!

chords 2X
 
[G]Buy me a flute and a [Am]gun that shoots
[C]Tailgates 2,3  and [G]substitutes
Strap yourself to the [Am]tree with roots
[C]You ain't goin' now[G]here
 
[G]Whoo-ee! [Am]Ride me high t[C]omorrow's the day
My [G]bride's gonna come     
oh, oh, are [Am]we gonna fly
[C]Down in the easy [G]chair!
 
[G]Genghis Khan  he [Am] could not keep  
[C]all his kings supp[G]lied with sleep
We'll [G]climb that hill  no [Am]matter how steep
[C]When we get up to [G]it
 
[G]Whoo-ee! [Am]Ride me high t[C]omorrow's the day
My [G]bride's gonna come     oh, oh, are [Am]we gonna fly
[C]Down in the easy [G]chair!

[G]Whoo-ee! [Am]Ride me high t[C]omorrow's the day
My [G]bride's gonna come     oh, oh, are [Am]we gonna fly
[C]Down in the easy [G]chair!

chords 2X