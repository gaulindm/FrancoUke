

{title:108    MY GIRL   }
{subtitle:(4/4   Key of C)}      
{subtitle:(Smokey Robinson & Ronald White)}
{time:2:11}
{metronome: 100}


{c:Riff can be played through the verses}
{c:but not the chorus}

{c:RIFF}
A - - - - - - - - - - - 0 - 3 -        
E - - - - - - - 0 - 3 - - - - -         
C - 0 - - - 2 - - - - - - - - - 
G - - - - - - - - - - - - - - - 

{c:INTRO (with riff twice):}
[C]/ / / /    / / /    

I've got [C]sunshi...i-ine     {c:(}[F]{c:12)}     
On a cloudy [C]day  {c:(234,}[F]{c:1234)} 
When it's [C]co...ld outsi-i-ide   {c:(}[F]{c:12)}     
I've got the month of [C]May     [F]

{soc}
     [C]I    [Dm]guess [F]you’d [G7]say 
     [C]What can [Dm]make me [F]feel this [G7]way 
     [C]My girl (my girl, my girl)..[C]talkin' 'bout 
     [Dm]       My gi-i-irl…  [G7/]my girl  {c:(beat)}
{eoc}

I've got [C]so... much honey       {c:(}[F]{c:12)}     
The bees envy [C]me    {c:(234,}[F]{c:123)} 
I've got a [C]swee...ter song     {c:(}[F]{c:12)}     
Than the birds in the [C]trees     [F] 

{soc}
     [C]I       [Dm]guess [F] you'd [G7]say 
     [C]What can [Dm]make me [F]feel this [G7]way 
     [C]My girl, (my girl, my girl)…[C]talkin' 'bout 
     [Dm]       My girl…  [G7/]my girl  {c:(beat)}
{eoc}

I don't [C]nee...d no money     {c:(}[F]{c:12)}     
Fortune or [C]fame   {c:(234,}[F]{c:123)} 
I've got [C]a...ll the riches baby    {c:(}[F]{c:12)}     
One man can [C]claim    [F] 

{soc}
     [C]I    [Dm]guess [F]you'd [G7]say 
     [C]What can [Dm]make me [F]feel this [G7]way 
     [C] My girl, (my girl, my girl)…[C]talkin' 'bout 
     [Dm]      My girl… [G7]my girl
     Talking ‘bout [Cmaj7/gliss]my girl
{eoc}

___________________________________________
{define: Cmaj7/gliss  0 0 0 0 2}







