{title:I SAW THE LIGHT    }
{subtitle: 4/4     Key of C    }
{subtitle:(Hank Williams)}
{time:3:15}
{metronome: 184}







{c:INTRO:}    
[C]/ / / /     [G7]/ / / /     
[C]/ / / /    / / /
 
I [C]wandered so aimless life filled with [C7]sin
[F]I wouldn't let my dear Saviour [C]in
Then He came like a stranger in the night
[C/]Praise the Lord [G7]I saw the [C]light

{c:CHORUS}
{soc}
     [C]I saw the light I saw the [C7]light
     [F]No more darkness no more [C]night
     Now I'm so happy no sorrow in sight
     [C/]Praise the Lord [G7]I saw the [C]light
{eoc}

[C]Just like a blind man, I wandered a[C7]lone
[F]Worries and fears I claimed for my [C]own
Then like a blind man that God gave back his sight
[C/]Praise the Lord, [G7]I saw the [C]light

{soc}
     [C]I saw the light I saw the [C7]light
     [F]No more darkness no more [C]night
     Now I'm so happy no sorrow in sight
     [C/]Praise the Lord [G7]I saw the [C]light
{eoc}

[C]I was a fool to wander and [C7]stray
[F]Straight is the gate and narrow the [C]way
Now, I have traded the wrong for the right
[C/]Praise the Lord, [G7]I saw the [C]light

{soc}
     [C]I saw the light I saw the [C7]light
     [F]No more darkness no more [C]night
     Now I'm so happy no sorrow in sight
     [C/]Praise the Lord [G7]I saw the [C]light
{c:(slow down and get wild)}
     [C/]Praise the Lord [G7]I saw… the [C]light…
{eoc}

