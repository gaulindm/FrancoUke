{title: THE IRISH ROVER}
{subtitle:(4/4 Key of G)}
{subtitle:(The Dubliners)}
{time: 4:05}

{c:G / / / /    D / / / /    G / / / /   / / }

On the [G]fourth of July, eighteen hundred and [C]six 
We set [G]sail from the sweet cove of [D]Cork
We were [G]sailing away with a cargo of [C]bricks
For the [G]Grand City [D]Hall in New [G]York
'Twas a wonderful craft,she was [D]rigged fore and aft
And [G]oh, how the wild wind [D]dro-ove her
She [G]stood several blasts she had [Em]twenty-seven [C]masts
And they [G]called her The [D]Irish [G]Ro-over

We had [G]one million bags of the best Sligo [C]rags
We had [G]two million barrels of [D]stone
We had [G]three million sides of old blind horses [C]hides
We had [G]four million [D]barrels of [G]bones
We had five million hogs, [D]six million dogs
And [G]seven million barrels of [D]porter
We had [G]eight million bales of old [Em]nanny goats' [C]tails
In the [G]hold of The [D]Irish Ro[G]ver

There was [G]awl Mickey Coote who played hard on his [C]flute
And the [G]ladies lined up for a [D]set
He would [G]tootle with skill for each sparkling qua[C]drille
Though the [G]dancers were flu[D]ther'd and [G]fet
With his smart witty talk he was [D]cock of the walk
As he [G]rolled the dames under and [D]o-over
They all [G]knew at a glance when he [Em]took up his [C]stance
That he [G]sailed in The [D]Irish [G]Rover

There was [G]Barney McGee from the banks of the [C]Lee
There was [G]Hogan from County Ty-[D]rone
There was [G]Johnny McGurk who was scared stiff of [C]work
And a [G]man from West[D]meath called Ma[G]lone
There was Slugger O'Toole who was [D]drunk as a rule
And [G]fighting Bill Treacy from [D]Dover
And your [G]man, Mick MacCann from the [Em]banks of the [C]Bann
Was the [G]skipper on The [D]Irish [G]Rover

For the [G]sailor it's always a bother in [C]life
It's so [G]lonesome by night and by [D]day
That he [G]longs for the shore and a charming young [C]whore
Who will [G]melt all his [D]troubles [G]away
Oh, the [G]noise and the rout swillin' poitin and [C]stout
For him [G]soon the torment's [D]o-over
Of the [G]love of a maid, he is [Em]never a [C]fraid
That old [G]salt from The [D]Irish [G]Rover

We had [G]sailed seven years when the measles broke [C]out
And the [G]ship lost its way in the [D]fog
And that [G]whale of a crew was reduced down to [C]two
Just my[G]self and the [D]Captain's old [G]dog
Then the ship struck a rock Oh [D]Lord, what a shock
The [G]bulkhead was turned right [D]o-over[stop playing]
Turned nine times around
And the poor old dog was drowned [1-2-3] 
And the [G]last of The [D]Irish [G]Rover

