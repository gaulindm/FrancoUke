{title: IN SPITE OF OURSELVES}
{subtitle: John Prine}
{metronome: 152}
{time: 3:10}





{c:INTRO:  }
[C]/ / / /    [F]/ /    [G]/ /
[C]/ / / /   / / / /


{c:HIS VERSE:}
[C]She don't like her eggs all runny
[C]She thinks crossin' her legs is funny
[F]She looks down her nose at money
She [C]gets it on like the Easter Bunny
[G]She's my baby, I'm her honey
I'm never gonna let her [C]go  {c:(23)}  [G/]      {c:(}[C]{c:123)} 

{c:HER VERSE:}
Well he [C]ain't got laid in a month of Sundays
I [C]caught him once and he was sniffin' my undies
He [F]ain't too sharp but he gets things done
[C]Drinks his beer like it's oxygen
But [G]he's my baby, and I'm his honey
I'm never gonna let him [C]go {c:(23)}  [G/]   [C/]

{soc}
{c:CHORUS:}
     In spite of our[F]selves
     We'll end up a'sittin' on a [C]rainbow
     Against all [G]odds
     Honey, we're the big door [C]prize {c:(23)} [G/]     {c:(}[C]{c:12)} 
     We're gonna [F]spite our noses
     Right off of our [C]faces  {c:(4,12)}
     There won't be nothin' but big old [G]hearts
     Dancin' in our [C]eyes {c:(23)}  [G/]       {c:(}[C]{c:1234)} 
{eoc}



{c:HIS VERSE:}
[C]She thinks all my jokes are corny
[C]Convict movies make her horny
[F]She likes ketchup on her scrambled eggs
[C]Swears like a sailor when she shaves her legs
She [G]don't need fixin' and she keeps on tickin'
I'm never gonna let her [C]go {c:(23)}  [G/]      {c:(}[C]{c:1234)} 

{c:HER VERSE:}
He's [C]got more balls than a big brass monkey
He's a [C]whacked out weirdo and a lovebug junkie
He's [F]sly as a fox and crazy as a loon
When [C]payday comes, he's howlin' at the moon
But [G]he's my baby.  I don't mean maybe
I'm never gonna let him [C]go {c:(23)} [G/]  [C/]

{soc}
{c:CHORUS:}
     In spite of our[F]selves
     We'll end up a'sittin' on a [C]rainbow
     Against all [G]odds
     Honey, we're the big door [C]prize {c:(23)}  [G/]      {c:(}[C]{c:12)}               
     We're gonna [F]spite our noses
     Right off of our [C]faces
     There won't be nothin' but big old [G]hearts
     Dancin' in our [C]eyes {c:(23)}  [G/]       [C/]

     In spite of our[F]selves
     We'll end up a'sittin' on a [C]rainbow
     Against all [G]odds
     Honey, we're the big door [C]prize {c:(23)}  [G/]      {c:(}[C]{c:12)}     
     We're gonna [F]spite our noses
     Right off of our [C]faces
     There won't be nothin' but big old [G]hearts
     Dancin' in our [C]eyes  {c:(23)}  [G/]       [C/]
{eoc}

There won't be [C]nothin' but big old [G]hearts
Dancin' in our [C]eyes  {c:(234,1)}  [F/]      [C/]
            