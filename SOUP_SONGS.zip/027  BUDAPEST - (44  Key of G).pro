

{title:027  BUDAPEST  }
{subtitle:(4/4  Key of G)}
{subtitle:(George Ezra) }
{time:4:05}
{metronome: 130}





[G]/ / / /   / / / /  

[G]  My house in Budapest, my 
[G]  My hidden treasure chest
[G]  Golden grand piano [G]    my beautiful Castillo 
[C]You...whooo, you...whoo 
I'd leave it [G]all  {c:(234,123)}  
Oh for [C]you... whoo, you... whoo 
I'd leave it [G]all

[G]  My acres of a land   [G]      I have achieved
[G]  It may be hard for you to 
[G]  Stop and believe but for  
[C]You...whoo, you...whoo 
I'd leave it [G]all   {c:(234,123)}  
Oh for [C]you... whoo, you... whoo 
I'd leave it [G]all

{soc}             
     [D]Give me one good reason why 
     [C]I should never make a [G]change
     And [D]baby if you hold me then 
     [C]All of this will go a[G]way
{eoc}

[G]   My many artifacts [G]     the list goes on
[G]   If you just say the words I'll 
[G]   I'll up and run, oh to 
[C]You...whoo, you...whoo 
I'd leave it [G]all  {c:(234,1234)}   
Oh for [C]you... whoo, you.. whoo 
I'd leave it [G]all

{soc}             
     [D]Give me one good reason why 
     [C]I should never make a [G]change
     And [D]baby if you hold me then 
     [C]All of this will go a[G]way

     [D]Give me one good reason why 
     [C]I should never make a [G]change
     And [D]baby if you hold me then 
     [C]All of this will go a[G]way
{eoc}
        
[G]  My friends and family they [G]   don't understand
[G]  They fear they'd lose so much if 
[G]  You take my hand but for 
[C]You... whoo [C]you... whoo
I'd lose it [G]all   {c:(234,1234)}  
Oh for [C]you... whoo [C]you... whoo   
I'd lose it [G]all
 
{soc}             
     [D]Give me one good reason why 
     [C]I should never make a [G]change
     And [D]baby if you hold me then 
     [C]All of this will go a[G]way

     [D]Give me one good reason why 
     [C]I should never make a [G]change
     And [D]baby if you hold me then 
     [C]All of this will go a[G]way
{eoc}

[G]  My house in Budapest, my   
[G]  My hidden treasure chest
[G]  Golden grand piano [G]     my beautiful castillo  
[C]You... whoo [C]you... whoo
I'd leave it [G]all {c:(234,123)}  
Oh for [C]you... whoo [C]you... whoo   
I'd leave it [G/]all


________________________________________










