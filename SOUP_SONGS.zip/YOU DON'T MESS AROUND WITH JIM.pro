{title:YOU DON'T MESS AROUND WITH JIM}
{subtitle:}

[E]Uptown [E7]got it's [E]hustlers
The bowery [E7]got it's [E]bums
42nd Street got [E7]Big Jim [E]Walker
He's a pool-shooting [E7]son of a [E]gun
Yeah he b[A]ig and dumb as a man can come
But he [E]stronger than a [E7]country [E]hoss
And when the [B7]bad folks all get tog[A]ether at night
You know they [A7]all call big Jim B[E]oss just because
And they [E7]say
 
You don't [A]tug on [A7]Superman's [E]cape
You don't [A]spit [A7]into the [E]wind
You don't [A]pull the mask off that [A7]old Lone Ranger
And you [B7]don't mess a[A7]round with [E]Jim
 
Well outta [E]south Ala[E7]bama came a [E]country boy
He say I'm looking for a [E7]man named [E]Jim
I am a [E7]pool-shooting [E]boy
My name [E7]Willie Mc[E]Coy
But down home they [E7]call me [E]Slim
Yeah I'm [A]looking for the king of nd Street
He driving a [E7]drop top Cadil[E]lac
Last week he [B7]took all my money
And it [A]may sound funny
But I [A7]come to get my [A]money [E]back
And everybody [E7]say Jack don't you know
 
You don't [A]tug on [A7]Superman's [E]cape
You don't [A]spit [A7]into the [E]wind
You don't [A]pull the mask off that [A7]old Lone Ranger
And you [B7]don't mess a[A7]round with [E]Jim
 
Well a [E]hush fell [E7]over the [E]pool room
Jimmy come bopping in [E7]off the [E]street
And when the [E7]cutting were [E]done
The only [E7]part that wasn't [E]bloody
Was the [E7]soles of the big man's [E]feet
Yeah he were [A]cut in bout a hundred places
And he were [E]shot in a couple [E7]more
And you [B7]better believe
They sung a [A]different kind of [A7]story
When big [A]Jim hit the [E]floor now they sa[E7]y
 
You don't [A]tug on [A7]Superman's [E]cape
You don't [A]spit [A7]into the [E]wind
You don't [A]pull the mask off that [A7]old Lone Ranger
And you [B7]don't mess a[A7]round with [E]Slim
 
Yeah, big Jim got his hat
 
Find out where it's at
 
And it's not hustling people strange to you
 
Even if you do got a two-piece custom-made pool cue
 
You don't [A]tug on [A7]Superman's [E]cape
You don't [A]spit [A7]into the [E]wind
You don't [A]pull the mask off that [A7]old Lone Ranger
And you [B7]don't mess a[A7]round with [E]Slim [E7] [B7] [E]
X