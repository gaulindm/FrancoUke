{t: TIPSY}
{subtitle: 4/4      Key of  F#m}

[F#m]/ / / /    [A]/ / / /    
[D]/ / / /    [A]/ /    [E7]/ /
 
My [F#m]baby want a [A]Birkin
She's been [D]tellin' me all night [A]long  [E7]/ /
[F#m]Gasoline and [A]groceries 
The [D]list goes on and [A]on  [E7]/ /
This [F#m]9 to 5 ain't [A]workin'
Why the [D]hell do I work so [A]hard   [E7]/ /
I can't [F#m]worry 'bout my [A]problems 
I can't [D]take 'em when I'm [A]gone [E7]/ /
 
[F#m]One, here comes the [A]two, to the three, to the [D]four
Tell 'em "Bring a[A]nother round", [E7]we need plenty [F#m]more
Two steppin' on the [A]table, she don't need a dance [D/]floor
Oh my, [A]    good Lord
 
 
[F#m] Someone pour me up a [A]double shot of whiskey
[D] They know me and Jack [A]Daniels got a [E7]history
[F#m] Therе's a party down[A]town, near 5th Street
[D]Everybody at the [A]bar gеttin' [E7]tipsy 
[F#m]/ / / /    [A]/ / / /
[D]Everybody at the [A]bar gettin' [E7]tipsy [F#m] [A]
[D/A]Everybody at the [A]bar gettin' [E7]tipsy
 
[F#m]I been Boozey since I [A]left, I ain't changin' for a [D]check
Tell my ma, I ain't for[A]get (Oh, Lord, uh)
[F#m]Woke up drunk at 10 a.[A]m., we gon' do this shit a[D]gain
Tell your girl to bring a [A]friend ([E7]Oh, Lord)
 
[F#m]One, here comes the [A]two, to the three, to the [D]four
Tell 'em "Bring a[A]nother round", [E7]we need plenty [F#m]more
Two steppin' on the [A]table, she don't need a dance [D]floor
Oh my,[A] good Lord
 
[F#m] Someone pour me up a [A]double shot of whiskey (A double shot of whiskey)
[D/] They know me and Jack [A]Daniels got a [E7]history (We go way back)
[F#m] Therе's a party down[A]town, near 5th Street
[D] Everybody at the [A]bar gеttin' [E7]tipsy [F#m](Woo[A])
[D] Everybody at the [A]bar gettin' [E7]tipsy 
[F#m](At [A]the bar gettin' tipsy)
[D] Everybody at the [A]bar gettin' [E7]tipsy
 
[F#m]One, here comes the [A]two, to the three, to the [D]four
When it's last [A]call and they [E7]kick us out the [F#m]door
It's gettin' kind of [A]late but the ladies want some [D]more
N.C.
Oh my, good Lord (Tell 'em drink some more)
 
[F#m/] Someone pour me up a [A/]double shot of whiskey (A double shot of whiskey)
[D/] They know me and Jack [A/]Daniels got a history (Way back)
[F#m] There's a party down[A/]town, near 5th Street (Come on)
[D/] Everybody at the [A/]bar gettin' tipsy (Woo)

[F#m] Someone pour me up a [A]double shot of whiskey (A double shot of whiskey)
[D] They know me and Jack [A]Daniels got a [E7]history (History)
[F#m] At the bottom of a [A]bottle gon' miss me (Bet you gon' miss me)
[D] Everybody at the [A]bar gettin' [E7]tipsy (At the bar gettin' tipsy) [F#m] [A]
[D] Everybody at the [A]bar gettin' [E7]tipsy [F#m] [A]

[D/] Everybody at the [A/]bar gettin' tipsy
 
