

{title:156  THAT’S HOW I GOT TO }
{title:MEMPHIS  }
{subtitle:(4/4   Key of G  )}
{subtitle:(Tom T. Hall)}
{time:3:37}
{metronome: 114}





 
[Am]/ / / /     [C]/ / / /      
[G]/ / / /    / / / /

If you [G]love somebody e[C]nough 
You [G]follow wherever they [Em]go
That's how I got to [Am]Memphis  
[C]   That's how I got to [G]Memphis
If you love somebody e[C]nough
You’ll [G]go where your heart wants to [Em]go
That's how I got to [Am]Memphis  
[C]   That's how I got to [G]Memphis 

{sob}
   I [D]know if you've seen her you'd 
   [C]tell me cause you are my [G]friend
   [D]I've got to find her, and 
   [C]find out the trouble she's [G]in   [D7]
{eob}

And if you [G]tell me that she’s not [C]here 
I’ll [G]follow the trail of her [Em]tears
That's how I got to [Am]Memphis 
[C]    That's how I got to [G]Memphis
She would [G]get mad and she used to [C]say… 
She’d come [G]back to Memphis some[Em]day
That's how I got to [Am]Memphis 
[C]   That's how I got to [G]Memphis

Well [G]I haven’t eaten a [C]bite
I haven’t [G]slept for three days or [Em]nights
That’s how I got to [Am]Memphis 
[C]   That’s how I got to [G]Memphis {c:(34,1234)}

{c:INSTRUMENTAL:} 
[G]/ / / /     [C]/ / / /     
[G]/ / / /     [Em]/ / / /     
[Am]/ / / /    [C]/ / / /     
[G]/ / / /    / / / /

{sob}
     [D]I've got to find her and 
     [C]tell her that  I love her [G]so
     [D]I'll never rest till I 
     [C]find out why she had to [G]go [D7]
{eob}

[G]Thank you for your precious [C]time
For[G]give me if I start to [Em]crying
That's how I got to [Am]Memphis 
[C]   That's how I got to [G]Memphis
That's how I got to [Am]Memphis  
[C]  {c:(slow down)} that's how I got to… 
[G/]Memphis


__________________________________

{define: D7 0 2 0 2 0}












