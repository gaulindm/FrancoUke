{t:WAGON WHEEL}
{subtitle:(4/4     Key of C)}             
{subtitle:(Bob Dylan & Ketch Secor)}
{time: 4:30}
{metronome:140}
 







{c:INTRO: (gently, so pickers can be heard)}
[C]/ / / /     [G]/ / / /     
[Am]/ / / /     [F]/ / / /
[C]/ / / /     [G]/ / / /     
[F]/ / / /    / / / /       

[C]Headed down south to the [G]land of the pines
I'm [Am]thumbin' my way into [F]North Caroline
[C]Starin' up the road and 
[G]Pray to God I see [F]headlights
I [C]made it down the coast in [G]seventeen hours
[Am]Pickin' me a bouquet of [F]dogwood flowers 
And I'm a [C]hopin' for Raleigh, I can 
[G]See my baby to[F]night

{c:CHORUS}
{soc}             
  So [C]rock me mama like a [G]wagon wheel
  [Am]Rock me mama any [F]way you feel 
  [C]Hey- [G]ey mama [F]rock me
  [C]Rock me mama like the [G]wind and the rain
  [Am]Rock me mama like a [F]south-bound train
  [C]Hey- [G]ey mama [F]rock me

 {c:(gently)}  
 [C]/ / / /     [G]/ / / /     
 [Am]/ / / /     [F]/ / / /
 [C]/ / / /     [G]/ / / /     
 [F]/ / / /    / / / /  
{eoc}

[C]Runnin from the cold up in [G]New England
I was [Am]born to be a fiddler 
In an [F]old-time stringband
My [C]baby plays the guitar 
[G]  I pick a banjo [F]now
Oh the [C]North country winters keep a [G]gettin' me now 
Lost my [Am]money playin poker 
So I [F]had to up and leave
But I [C]ain't a turnin' back 
To [G]livin' that old life [F]no more

{soc}             
  So [C]rock me mama like a [G]wagon wheel
  [Am]Rock me mama any [F]way you feel 
  [C]Hey- [G]ey mama [F]rock me
  [C]Rock me mama like the [G]wind and the rain
  [Am]Rock me mama like a [F]south-bound train
  [C]Hey- [G]ey mama [F]rock me
     
 {c:(gently)}  
 [C]/ / / /     [G]/ / / /     
 [Am]/ / / /     [F]/ / / /
 [C]/ / / /     [G]/ / / /     
 [F]/ / / /    / / / /  
{eoc}

[C/]Walkin to the south [G/]out of Roanoke
I caught a [Am/]trucker out of Philly 
Had a [F/]nice long toke
But [C/]he's a headed west from the 
[G/]Cumberland gap 
To [F/]Johnson City, [F/]Tennessee
And I [C]gotta get a move on be[G]fore the sun 
I hear my [Am]baby callin’ my name and I 
[F]know that she's the only one
And [C]if I die in Raleigh at [G]least I will die [F]free    

{soc}             
  So [C]rock me mama like a [G]wagon wheel
  [Am]Rock me mama any [F]way you feel 
  [C]Hey- [G]ey mama [F]rock me
  [C]Rock me mama like the [G]wind and the rain
  [Am]Rock me mama like a [F]south-bound train
  [C]Hey- [G]ey mama [F]rock me
    
  {c:ACAPELLA  (no ukes until you see a chord)}
  So rock me mama like a wagon wheel
  Rock me mama any way you feel 
  Hey- ey mama rock me
  Rock me mama like the wind and the rain
  Rock me mama like a south-bound train
  Hey- ey mama [F]rock me    {c:(34,1234)}
  [C]Hey- [G]ey mama [F]rock me  
  [C]Hey- [G]ey mama [F]rock me {c:(34,1234)} [C/]
{eoc}

