{title:THE ADDAMS FAMILY}
{time:1:24}
{metronome: 112}

 






{c:Kazoo Intro: }
da da da dum (snap, snap) 
da da da dum (snap, snap) 
da da da dum, da da da dum, 
da da da dum (snap, snap)

da da da dum (snap, snap) 
da da da dum (snap, snap) 
da da da dum, da da da dum, 
da da da dum (snap, snap)

They're [C]creepy and they're [F]kooky
My[G7]sterious and [C]spooky
They're [C]altogether [F]ooky
The [G7]Addams fami[C]ly

Their house is a [F]museum
When [G7]people come to [C]see 'em
They really are a [F]scre-am
The [G7]Addams fami[C]ly

{c:Kazoo}
da da da dum (snap, snap) 
da da da dum (snap, snap) 
da da da dum, da da da dum, 
da da da dum (snap, snap)

So [C]get a witch's [F]shawl on
A [G7]broomstick you can [C]crawl on
We're gonna pay a [F]call on
The [G7]Addams fami[C]ly

They're [C]creepy and they're [F]kooky
My[G7]sterious and [C]spooky
They're [C]altogether [F]ooky
The [G7]Ad.........dams......  fam.......i......[C/]ly 


