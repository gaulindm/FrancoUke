

{title:BROWN-EYED GIRL  }
{subtitle:(4/4   Key of G)}                 
{subtitle:(Van Morisson)}
{time: 3:45}
{metronome:147}

{c:(Turn tablet horizontal)}


{c:INTRO:(choose either RIFF, ADVANCED RIFF,}
{c:or INTRO CHORDS )}

{c:RIFF (TWICE)}
{sot}
A|2-3-5-3-2---7-8-10-8-7---2-3-5-3-2--0-----0
E|- - - - - - - - - - - - - - - - - - - 2-3 - -
C|- - - - - - - - - - - - - - - - - - - - - - -
G|- - - - - - - - - - - - - - - - - - - - - - -
{eot}

{c:FULL/ADVANCED RIFF (TWICE)}
{sot}
A|2-3-5-3-2---7-8--10-8--7---2-3-5-3-2--0-----0
E|3-5-7-5-3---8-10-12-10-8---3-5-7-5-3----2-3 - 
C|- - - - - - - - - - - - - - - - - - - - - - -
G|- - - - - - - - - - - - - - - - - - - - - - -
{eot}

{c:INTRO CHORDS (once):}
{c:G / / / /    C / / / /    G / / / /    D / / / /}
{c:G  / / / /   C / / / /    G / / / /    D / / / /}

[G]  Hey where did we [C]go 
[G]  Days when the [D]rains came 
[G]  Down in the [C]hollow 
[G]  Playin' a [D]new game 
[G]  Laughing and a [C]running hey hey  
[G]  Skipping and a [D]jumping 
[G]  In the misty [C]morning fog with 
[G]  Ah {c:(3,4)} our [D]hearts a thumping and 
[C]You    [D]     My brown-eyed [G]girl     [Em]         
[C]  You, my-[D]y brown-eyed [G]girl    [D7]/ / / / 

[G]  Whatever ha[C]ppened 
[G]  To Tuesday and [D]so slow 
[G]  Going down to the [C]old mine with a 
[G]  Transistor [D]radio 
[G]  Standing in the [C]sunlight laughing 
[G]  Hide behind a [D]rainbow's wall 
[G]  Slipping and a-[C]sliding    
[G]   All along the [D]waterfall with 
[C]You,    [D]     My brown-eyed [G]girl     [Em]         
[C]   You my-[D]y brown-eyed [G]girl {c:(234)}

{soc}
   [D7]       Do you remember whe…n, we used to 
   [G]Sing, sha la la [C]la la la la [G]la la la-laa dee 
   [D7]Da (just like that)
   [G]     Sha la la [C]la la la la [G]la la la laa dee  
   [D7]Da,    la dee [G]da  {c:(hold for 16 beats)}
{eoc}

[G]  So hard to [C]find my way
[G]  Now that I'm all [D]on my own 
[G]  I saw you just the [C]other day 
[G]  My how [D]you have grown 
[G]  Cast my memory [C]back there Lord 
[G]  Sometimes I'm [D]overcome thinking 'bout 
[G]  Making love in the [C]green grass 
[G]  Behind the [D]stadium with 
[C]You    [D]      My brown-eyed [G]girl     [Em]        
[C]   You my-[D]y brown-eyed [G]girl {c:(234)}

{soc} 
     [D7]      Do you remember whe…n, we used to 
     [G]Sing, sha la la    [C]la la la la    
     [G]la la la-laa   dee  [D7]da  
     [G]    Sha la la    [C]la la la la    
     [G]la la la-laa   dee [D7]da
     La dee [G/]da 
{eoc}


___________________________________________




{define: D7 0 2 0 2 0}











