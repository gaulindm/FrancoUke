{title:C'EST LA VIE    }
{subtitle:  4/4      Key of D}
{subtitle:(Chuck Berry)}
 

 
It was a [C]teen-aged wedding 
and the old folks wished them well
You could see that Pierre did truly 
love the mademois[G]elle
And now the young Monsieur and Madame 
have rung the chapel bell
C'est La Vie say the old folks
it goes to show you never can [C]tell  {c:(234,123)}
 

They furnished [C]off an apartment 
with a two room Roebuck sale
The coolerator was crammed with 
TV dinners and Ginger [G]Ale
But when Pierre found work 
the little money comin' worked out well
C'est La Vie say the old folks
it goes to show you never can [C]tell  {c:(234,123)}
 
 
They had a [C]hi-fi phono
Boy, did they let it blast
Seven hundred little records
all rock, rhythm and [G]jazz
But when the sun went down 
the rapid tempo of the music fell 
C'est La Vie say the old folks, 
it goes to show you never can [C]tell {c:(234,123)}
 
They bought a [C]souped up jitney 
'twas a cherry red fifty-three
Drove it down to New Orleans 
to celebrate their anniversa[G]ry
It was there where Pierre was wedded 
to the lovely mademoiselle
C'est La Vie say the old folks
it goes to show you never can [C]tell  {c:(234,1234)}
 
[C]/ / / /   / / / /   
/ / / /   / / / /
/ / / /   / / / /    
[G]/ / / /   / / / /
/ / / /   / / / /   
/ / / /   / / / / 
[G]/ / / /   / / / /    
[C]/ / / /   / / /   
 
They had a [C]teen-aged wedding
And the old folks wished them well
You could see that Pierre did
Truly love the mademois[G]elle
And now the young Monsieur and Madame
Have rung the chapel bell
C'est La Vie say the old folks
It goes to show you never can [C/]tell
