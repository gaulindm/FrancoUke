

{title:088   SPIRITS    }
{subtitle:(4/4      Key of F)}  
{subtitle:(The Strumbellas) }
{time:4:20}
{metronome: 160}

{c:* percussion pattern for chorus}





{c:INTRO: (Softly)}
[F]/ / / /    [C]/ / / /    
[Am]/ / / /    [G]/  {c:(stop 2,3)}

{soc}
  I got [F]guns in my head and they [C]won't go
  [Am]Spirits in my head and they [G]won't go 
  I got [F]guns in my head and they [C]won't go
  [Am]Spirits in my head and they [G/]won't- {c:(shhh)}
{eoc}

{c:(Firmly)}
[F]/ / / /    [C]/ / / /    [Am]/ / / /    [G]/ / / /    

[F]/ / / /    [C]/ / / /    [Am]/ / / /    [G]/ / / /  

{c:(}[C]{c:123)}   I been [G]looking at the stars 
To[F]night  {c:(34,1)} and I think [C]oh
How I [G]miss that bright sun {c:(}[F]{c:1234,1234)}
{c:(}[C]{c:123)}   I’ll be a [G]dreamer till the 
Day I [F]die  {c:(34,1)} but they say [C]oh 
How the [G]good die young {c:(}[F]{c:1234,12)}
But we’re all [Em]strange {c:(234)} 
And maybe we don't want to 
Change {c:(}[G]{c:1234,1234,1234)}  [G/]     {c:(2,3)}

{soc}
  I got [F]guns in my *head and they [C]won't go, *   
  [Am]Spirits in my *head and they [G]won't go  *
  I got [F]guns in my *head and they [C]won't go  *
  [Am]Spirits in my *head and they [G]won't go *
  But the [F]gun still *rattles  
  The [C]gun still *rattles woh-o-[G]woh    *     * 
  I got [F]guns in my *head and they [C]won't go  *  
  [Am]Spirits in my *head and they [G]won't go {c:(*3,4)}
{eoc}

{c:(}[C]{c:123)} I spend a [G]lot of nights on the 
[F]Run {c:(34,1)}  and I think [C]oh, like I'm 
[G]Lost and can’t be found {c:(}[F]{c:1234,1234)} 
{c:(}[C]{c:123)} I'm just [G]waiting for my day to 
[F]Come   {c:(34,1)}  and I think [C]oh I don't 
[G]Want to let you down {c:(}[F]{c:1234)}
Cause something inside has [Em]changed  {c:(234)}
And maybe we don't want to stay the [G]same    [G/]    

{soc}
  I got [F]guns in my *head and they [C]won't go  *
  [Am]Spirits in my *head and they [G]won't go    *
  I got [F]guns in my *head and they [C]won't go   *
  [Am]Spirits in my *head and they [G]won't go   *
  But the [F]gun still *rattles 
  The [C]gun still *rattles woh-o-[G]woh  *    *
  But the [F]gun still *rattles 
  The [C]gun still *rattles woh-o-[G]woh {c:(2}[*]{c:34)} [C/]oh…
{eoc}

{c:(Gentle single strums, or use a picking pattern)}
And [F/]I don't [F/]want a [C/]never ending life 
[C/]   I just [G/]want to be alive, [G/]   
While I'm [Am/]here   [Am/]
And [F/]I don't [F/]want a [C/]never ending life 
[C/]    I just [G/]want to be alive, [G/]    
While I'm [Am/]here   [Am/]
And [F/]I don't [F/]want to [C/]see another night [C/]    
Lost in[G/]side a lonely life, [G/]    
While I’m [Am/]here  [Am/]

{soc}
  I got [F]guns in my head and they [C]won't go 
  [Am]Spirits in my head and they [G]won't go 
  I got [F]guns in my head and they [C]won't go 
  [Am]Spirits in my head and they [G]won't go 
  But the [F]gun still rattles 
  The [C]gun still rattles woh-o-[G]woh
  But the [F]gun still rattles 
  The [C]gun still rattles woh-o-[G/]woh… 
{eoc}

____________________________________________












