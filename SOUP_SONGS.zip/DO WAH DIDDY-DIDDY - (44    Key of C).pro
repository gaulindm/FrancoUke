{title:DO WAH DIDDY-DIDDY }
{subtitle:(4/4    Key of C)}      
{subtitle:(Jeff Barry & Ellie Greenwich)}
{time: 2:25}
{metronome: 136}









{c:INTRO:} 
[C]/ / / /      [F]/ /     [C]/  {c:(stop)} 

There she was just a walkin' down the street 
Singin' [C]doo wah diddy diddy [F]dum diddy [C]doo 
[C]Snappin' her fingers and [F]shufflin' her [C]feet 
Singin' [C]doo wah diddy diddy [F]dum diddy [C/]doo 
She looked [C/]good (looked good) 
She looked [C/]fine (looked fine) 
She looked [C/]good she looked [C/]fine 
And I [C/]nearly lost my [C/]mind 

Be[C]fore I knew it she was [F]walkin' next to [C]me 
Singin' [C]doo wah diddy diddy [F]dum diddy [C]doo 
[C]Holdin' my hand just as [F]natural as can [C]be 
Singin' [C]doo wah diddy diddy [F]dum diddy [C/]doo 
We walked [C/]on (walked on) 
To my [C/]door (my door) 
We walked [C/]on to my [C/]door 
Then we [C/]kissed a little [C/]more 
[C]{c:(1234)}  [C7]     Whoa-whoa
I [Am]knew we was falling in love 
[F]{c:(1234,1)} Yes I did and so I 
[G7]Told her all the things I'd been dreamin' of 

Now [C/]we're together nearly [F/]every single [C/]day 
Singin' [C]doo wah diddy diddy [F]dum diddy [C]doo 
Oh [C/]we're so happy and 
That’s [F/]how we're gonna [C/]stay 
Singin' [C]doo wah diddy diddy [F]dum diddy [C]doo 
I'm [C/]hers (I'm hers) she's [C/]mine (she's mine) 
I'm [C/]hers she's [C/]mine wedding 
[C/]bells are gonna [C/]chime
[C]{c:(1234)} [C7]     Whoa-whoa, 
I [Am]knew we was falling in love 
[F]{c:(1234,1)} Yes I did and so I 
[G7]Told her all the things I'd been dreamin' of 
  
[C]Doo wah diddy diddy [F]dum diddy [C]doo   
[C]Doo wah diddy diddy [F]dum diddy [C]doo 
[C]Doo wah diddy diddy [F]dum diddy [C]doo 
[C]Doo wah diddy diddy [F]dum diddy [C/]doo 
