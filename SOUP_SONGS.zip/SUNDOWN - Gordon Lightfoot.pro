{title:SUNDOWN    }
{subtitle: 4/4     Key of G  }
{subtitle:  (Gordon Lightfoot)}

   
[G]/ /    [C]/ /    [F]/ /    [G]/ / 

I can [G]see her lyin’ back in her satin dress 
In a [D]room where you do what you [G]don’t confess
Sundown, you [C]better take care 
If I [F]find you been creepin’ round [G]my back stairs
Sundown, you [C]better take care 
If I [F]find you been creeping round [G]my back stairs

She’s been [G]lookin’ like a queen in a sailor’s dream
And she [D]don’t always say what she [G]really means
Sometimes I [C]think it’s a shame 
When I [F]get feelin’ better when I’m [G]feelin’ no pain
Sometimes I [C]think it’s a shame
When I [F]get feelin’ better when I’m [G]feelin’ no pain

I can [G]picture ev’ry move that a man could make 
Getting’ [D]lost in her lovin’ is your [G]first mistake
Sundown, you [C]better take care 
If I [F]find you been creepin’ round [G]my back stairs
Sometimes I [C]think it’s a sin 
When I [F]feel like I’m winnin’ when I’m [G]losin’ again

I can [G]see her lookin’ fast in her faded jeans
She’s a [D]hard lovin’ woman got me [G]feelin’ mean
Sometimes I [C]think it’s a shame
When I [F]get feelin’ better when I’m [G]feelin’ no pain
Sundown, you [C]better take care 
If I [F]find you been creepin’ round [G]my back stairs

Sundown, you [C]better take care 
If I [F]find you been creepin’ round [G]my back stairs
Sometimes I [C]think it’s a sin
When I [F]feel like I’m winnin’ when I’m [G]losin’ again
Sometimes I [C]think it’s a sin
When I [F]feel like I’m winnin’ when I’m [G]losin’ again [G/]  