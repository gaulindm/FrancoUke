{title:HEART OF GOLD}
{subtitle:     4/4      Key of Em      }
{subtitle: (Neil Young)}
{time: }
{metronome: }



*[Em]/  //////    [D]/-/    [Em]/  
*[Em]/  //////    [D]/-/    [Em]/

(harmonica)
[Em]/ /    [C]/ /    [D]/ /    [G]/ / 
[Em]/ /    [C]/ /    [D]/ /    [G]/ /  
[Em]/ /    [C]/ /    [D]/ /    [G]/ / 
 
*[Em]/  //////    [D]/-/    [Em]/

[Em]  I want to [C]live [D]    I want to [G]give
[Em]  I've been a [C]miner for a [D]heart of [G]gold
[Em]  It's these ex[C]pressions [D]    I never [G]give
[Em]  That keep me searching for a [G]heart of gold
[C//][tap]And I'm [C/]getting old  A|-3-2-0-|[G/]

[Em]  Keep me searching for a [G]heart of gold
[C//][tap]And I'm [C/]getting old    A|-3-2-0-|[G/]

(harmonica)
[Em]/ /    [C]/ /    [D]/ /    [G]/ / 
[Em]/ /    [C]/ /    [D]/ /    [G]/ /  
[Em]/ /    [C]/ /    [D]/ /    [G]/ / 

*[Em]/  //////    [D]/-/    [Em]/ 

[Em]  I've been to [C]Hollywood [D]    I've been to [G]Redwood
[Em]  I've crossed the [C]ocean for a [D]heart of [G]gold
[Em]  I've been in [C]my mind [D]    It's such a [G]fine line
[Em]  That keeps me searching for a [G]heart of [G]gold
[C//][tap]And I'm [C/]getting old  A|-3-2-0-|[G/]

[Em]  Keeps me searching for a [G]heart of [G]gold
[C//][tap]And I'm [C/]getting old  A|-3-2-0-|[G/] 

*[Em/]   [Em/]Keep [Em/]me [Em/]sear[Em/]ching [Em/]for [Em/]a [D]heart of [Em]gold
*[Em]   You keep me searching, and I'm [D]growing [Em]old
*[Em]   Keep me searching for a [D]heart of [Em]gold
[Em]   I've been a miner for a [G]heart of gold
[C//tap]  [C/]       A|-3-2-0-|[G/]