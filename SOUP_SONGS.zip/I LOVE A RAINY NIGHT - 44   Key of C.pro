{t:I LOVE A RAINY NIGHT }
{subtitle:   4/4   Key of C}
{subtitle: (Eddie Rabbit, David Malloy)}
{metronome: }
{time: 4:00 }
{c:Suggested strum is uduD (or uDuchunk)}







{c:INTRO:   C / / / /   / / /}

{c:CHORUS}
{soc}
     Well I [C]love a rainy night, I love a rainy night  
     I love to hear the thunder 
     watch the lightning when it lights up the [F]sky
     You know it makes me [C]feel good
      Well, I love a rainy night, it's such a beautiful sight 
     I love to feel the rain on my face
     taste the rain on my [F]lips
     In the moonlight [C]shadows {eoc} 
[G/] Showers wash all my [Am/]        cares away
[F/]  I wake up to a [G]     sunny day ‘Cause I [C]love a rainy night  [F]    [G]    
Yeah, I [C]love a rainy night  [F]    [G] Well, I [C]love a rainy night   [F]    [G]    
Well, I [C]love a rainy night [F/]ooh,  [G/]ooh…{c:(stop)}

{soc}
     {c:(snap fingers on beats 1 and 3)}
     Well I *love a rainy *night, I *love a rainy *night  
     I *love to hear the *thunder, watch the *lightning 
     When it *lights up the *sky {c:(snap, snap)}
     You know it *makes me *feel good {c:(snap, snap, snap)}
     
     {c:(strum again)}      Well, I [C]love a rainy night
     It's such a beautiful sight 
     I love to feel the rain on my face
     Taste the rain on my [F]lips
     In the moonlight [C]shadows {eoc}

[G/] Puts a song in this 
[Am/]  Heart of mine
[F/]   Puts a smile on my [G]face every time ‘Cause I [C]love a rainy night    [F]      [G]      
Yeah, I [C]love a rainy night  [F]     [G] 
Ooh, I [C]love a rainy night    [F]     [G]     
Well, I [C]love a rainy night, [F]ooh, [G]ooh 
{c:Instrumental C / / / /   / / / /    }
{c:F / / / /   / / / /    C / / / /   / / / / }
 
[G/] Showers wash all my [Am/]       cares away
[F/] I wake up to a [G]     sunny day ‘Cause I [C]love a rainy night    [F]      [G]     
Yeah, I [C]love a rainy night   [F]     [G] Well, I [C]love a rainy night    [F]      [G]     
I [C]love a rainy night  [F]    [G]

{soc}
Well I [C]love a rainy night (you can [F]see it in my [G]eyes)
Yeah, I [C]love a rainy night (well it [F]makes me [G]high) Well, I [C]love a rainy night (you [F]know I [G]do)  
Well, I [C]love a rainy night   [F]   [G]
 
‘Cause I [C]love a rainy night (you can [F]see it in my [G]eyes)
Yeah, I [C]love a rainy night (well it [F]makes me [G]high) Well, I [C]love a rainy night (you [F]know I [G]do)  
Well, I [C]love a rainy night   [F]      [G]    [(C/)]
{eoc}


