{title:SOME DAYS YOU GOTTA DANCE}
{subtitle:4/4      Key of C}
{subtitle: The Dixie Chicks}
 
[A]Well it was about five to five on a Friday
we were all getting ready to go
And the boss-man started screamin’
and his veins begin to show
He said a [D]you and you come with me, 
'cos [A]you’re gonna have to stay
My he[E7]art was thumpin’, I was jumpin   [A//]
 
I had to get awaaaaaay
 
{soc}
[A]Some days you gotta dance 
Live it up when you get the chance
[D]Cause when the world doesn’t make no sense
[A]And your feelin just a little too tense
You gotta [E7]loosen up those [D]chains and da[A]nce
{eoc} 
[A]Well I was talkin’ with my baby
Over a small glass of tea
And he asked a load of questions
He said “How do you feel about me”
 
My mind was r[D]acing I was pacing
The wo[A]rds just a wouldn’t come
And there was [E7]only one thing left to do  [A//]
I feel it coming ooonnnnnn
 
{soc}
[A]Some days you gotta dance 
Live it up when you get the chance
[D]Cause when the world doesn’t make no sense
[A]And your feelin just a little too tense
You gotta lo[E7]osen up those c[D]hains and da[A]nce
{eoc}
 

{c:A  D  A  E7  A}
 
{soc}
[A]Some days you gotta dance 
Live it up when you get the chance
[D]Cause when the world doesn’t make no sense
[A]And your feelin just a little too tense
You gotta lo[E7]osen up those c[D]hains and da[A]nce
You gotta lo[E7]osen up those c[D]hains and da[A]nce
Come on, you gotta lo[E7]osen up those c[D]hains and da[A]nce{eoc}