{title:YOU COULD HAVE BEEN A LADY}
{subtitle:(April Wine)}
 
CHORUS:
[C]Could have been all right, could have been 
[F]here tonight.
Could have been [C]sweet as wine, you could have 
been a [C]lady.
[C]I could have been all right, I could have been 
[F]here tonight.
Could have been [C]sweet as wine, you could have 
been a [C]lady.
 
[.C]  [F] [C] [C..]
#1.
[C]They all need you, [F]to make love to..when you a[C]wake 
you find them on the bed lyin' be[C]side you.
[C]They all love you, you're a good [F]girl..and I ain't 
surprised when you [C]realize just where you're [C]goin' to.
 
CHORUS:
[C]Could have been all right, could have been 
[F]here tonight.
Could have been [C]sweet as wine, you could have 
been a [C]lady.
[C]I could have been all right, I could have been 
[F]here tonight.
Could have been [C]sweet as wine, you could have 
been a [C]lady.
 
[.C]  [F] [C] [C..]
#2.
[C]If I told you, where you're [F]goin' to..you'd 
laugh in my face, say I'm [C]out of place..mind 
your [C]business.
[C]And they all want you, to make [F]love to..it's a 
[C]shame, the fate of the game, the way it de[C]lights you.
 
CHORUS:
[C]Could have been all right, could have been 
[F]here tonight.
Could have been [C]sweet as wine, you could have 
been a [C]lady.
[C]I could have been all right, I could have been 
[F]here tonight.
Could have been [C]sweet as wine, you could have 
been a [C]lady.
 
BRIDGE:
[C]Na..na-na-na-na-na..[F]Na..na-na-na-na-na..
[C]Na..na-na-na-na-na..na-[C]na.
[C]Na..na-na-na-na-na..[F]Na..na-na-na-na-na..
[C]Na..na-na-na-na-na..na-[C]na.
 
CHORUS:
[C]All right, could have been [F]here tonight.
Could have been [C]sweet as wine, you could have 
been a [C]lady.
[C]I could have been all right, I could have been 
[F]here tonight.
Could have been [C]sweet as wine, you could have 
been a [C]lady.
 