{t:DREAM A LITTLE DREAM OF ME }
{subtitle:  4/4    Key of F}
{subtitle:(Fabian Andre, Wilbur Schwandt}
{subtitle: (& Gus Kahn)}
{metronome: 84}
{time:2:31}







{c:INTRO: }
[Bb]/ / / /     [Bbm6]/ / / /   
[F]/ /    [C#7]/ /    [C7]/ / / / 

[F] Stars [E7]shining bright a[C#7]bove [C7]you
[F] Night breezes seem to [D7]whisper 
"I love [D]you"
[Bb] Birds singing in a [Bbm6]sycamore tree
[F]Dream a little [C#7]dream of [C7]me

[F] Say "[E7]Nightie-night" and [C#7]kiss [C7]me
[F] Just hold me tight and 
[D7]Tell me you'll miss [D]me
[Bb] While I'm alone and [Bbm6]blue as can be
[F]Dream a little [C#7]dream [C7]of [F]me [A7]

[D] Stars [Bm7]fading but [Em7]I linger [A7]on dear
[D] Still [Bm7]craving your [Em7]kiss [A7]
[D] I'm [Bm7]longing to [Em7]linger till [A7]dawn dear
[D] Just saying [C#7]this [C7]

[F] Sweet [E7]dreams till sunbeams [C#7]find [C7]you
[F] Sweet dreams that leave all 
[D7]Worries behind [D]you
[Bb] But in your dreams what[Bbm6]ever they be
[F]Dream a little [C#7]dream [C7]of [F]me [F7]

[Bb] But in your dreams what[Bbm6]ever they be
[F]Dream a little [C#7]dream [C7]of [F/]me



{define: C#7 0 1 1 1 2}
{define: F7 0 2 3 1 0}
{define: D7 0 2 0 2 0}