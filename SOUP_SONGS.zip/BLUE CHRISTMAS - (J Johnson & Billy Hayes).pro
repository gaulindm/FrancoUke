{title: BLUE CHRISTMAS}
{subtitle: (J. Johnson & Billy Hayes)}

{c:INTRO:  G7 / / / /   / / / /   C / / / /  /stop}
                                           
I’ll have a [C]blue Christmas with[G7]out you                                              
I’ll be so [G7]blue just thinking a[C]bout you                                       
Decor[C7]ations of red on a [F]green Christmas tree                                              
[D7]  Won’t be the same dear, if [G7/]you’re not here with me
                     
And when those [C]blue snowflakes start [G7]falling
That’s when those [G7]blue memories start [C]calling
You’ll be [C7]doing alright, with your [F]Christmas of white                                        
But [G7]I’ll have a blue, blue [C]Christmas {c:(34) C/}

I’ll have a [C]blue Christmas with[G7]out you                                              
I’ll be so [G7]blue just thinking a[C]bout you                                       
Decor[C7]ations of red on a [F]green Christmas tree                                              
[D7]  Won’t be the same dear, if [G7/]you’re not here with me
                     
And when those [C]blue snowflakes start [G7]falling
That’s when those [G7]blue memories start [C]calling
You’ll be [C7]doing alright, with your [F]Christmas of white                                        
But [G7]I’ll have a blue, blue [C]Christmas {c:(34) C/}

You’ll be [C7]doing alright, with your [F]Christmas of [D7]white                                 
But [G7]I’ll have a blue, blue-blue-blue [C]Christmas {c:(34) C/}
