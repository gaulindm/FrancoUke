

{title:149  THREE LITTLE BIRDS   }
{subtitle:   4/4      Key of  A  }
{time:3:23}
{subtitle:(Bob Marley)}
{metronome:  148}
{time:  3:30}


{c:RIFFS: RIFF 1 is played through the INTRO}
{c:For the CHORUS, play RIFFS where indicated}

{sot}
RIFF 1             
A|- - - - 7 4 - -       
E|- 5 7 5 - - 7 5         

RIFF 2 
A|- 0 0 - 0 0 4 2 0
E|- - - 2 - - - - -
{eot}


[A]/ / / /   / / / /   / / / /   / / /

{c:CHORUS:}
{soc}
  Don't [A]wor↓ry [RIFF1]          about a thing  [RIFF1]
  Cause [D-RIFF2]every little thing is gonna be al[A]right  [RIFF1]
  Singin' don't [A]worry [RIFF1]           about a thing  [RIFF1]
  Cause [D-RIFF2]every little thing is gonna be al[A]right  {c:(2}[RIFF1]{c:34,12)}
{eoc}
 
Rise up this [A]mornin'
Smiled with the [E7]risin' sun
Three little [A]birds 
Pitched by my [D]doorstep
Singin' [A]sweet songs 
Of melodies [E7]pure and true, sayin' 
[D]  This is my message to you-[A]ou-ou {c:(34,12)}  
  

{soc}
  Singin' don't [A]worry [RIFF1]          about a thing  [RIFF1]
  Cause [D-RIFF2]every little thing is gonna be al[A]right  [RIFF1]
  Singin' don't [A]worry [RIFF1]           about a thing  [RIFF1]
  Cause [D-RIFF2]every little thing is gonna be al[A]right  {c:(2}[RIFF1]{c:34,12)}
{eoc}
 
Rise up this [A]mornin'
Smiled with the [E7]risin' sun
Three little [A]birds 
Pitched by my [D]doorstep
Singin' [A]sweet songs 
Of melodies [E7]pure and true, sayin' 
[D]  This is my message to you-[A]ou-ou {c:(34,12)}   


{soc}
  Singin' don't [A]worry [RIFF1]          about a thing  [RIFF1]
  Cause [D-RIFF2]every little thing is gonna be al[A]right  [RIFF1]
  Singin' don't [A]worry [RIFF1]           about a thing  [RIFF1]
  Cause [D-RIFF2]every little thing is gonna be al[A]right  {c:(2}[RIFF1]{c:34,12)}
  Singin' don't [A]worry [RIFF1]          about a thing  [RIFF1]
  Cause [D-RIFF2]every little thing is gonna be al[A/]right
{eoc}

___________________________________













