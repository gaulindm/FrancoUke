{title:ONE FINE DAY   }
{subtitle:(4/4  Key of C)}
{subtitle: (Gerry Goffin & Carole King)}
{time: 2:25}
{metronome: 166}



{c:Maybe turn the tablet horizontal)}
{c:First note for melody is G, harmonies start on C or E}



{c:INTRO:}
[C]  Shooby dooby dooby [Am]dooby do wah wah 
[F]  Shooby dooby dooby [G7]dooby do wah wah  
   
[C]  Shooby dooby dooby [Am]dooby do wah wah 
[F]  Shooby dooby dooby [G7]dooby do wah wah  


[C] One fine day   
   {c:(shooby dooby dooby dooby do wah wah)}
[G] You'll look at me 
    {c:(shooby dooby dooby dooby do wah wah)}
[Am] And you will know our love was  
      {c:(shooby dooby dooby dooby do wah wah)}
[F] Meant to be  
    {c:(shooby dooby dooby dooby do wah wah)}

[C] One fine [Am]day    [F]    you're gonna [G7]want me for your 
   {c:(One fine day…  ooh….                    ooh…)}
[C]Girl (234)              ([Am]1234)          
 {c:    (Shooby dooby dooby dooby do wah wah)} 
([F]1234)                          [G7/]               [G7/]
   {c:(shooby dooby dooby dooby do wah wah)}

   
[C] The arms I long for  
    {c:(shooby dooby dooby dooby do wah wah)}
[G] Will open wide  
    {c:(shooby dooby dooby dooby do wah wah)}
[Am] And you'll be proud to have me  
     {c:(shooby dooby dooby dooby do wah wah)}
[F] Right by your side
    {c:(shooby dooby dooby dooby do wah wah)}
[C]  One fine [Am]day   [F]   you're gonna [G7]want me for your 
     {c:(One fine day…  ooh….                ooh…)}
[C]Girl (234)                        ([F]1234)                        ([C]1234,1234) 
    {c:(Shooby dooby dooby, dooby dooby dooby do wah…)}


{c:(”ah’s” throughout)}
{soc}
     [Gm7]        Though I [C]know you're the 
     [Gm7]        Kind of  [C]boy
     [F]   Who only [Am]wants to run a[Dm]round   [F] 
     [Am7]         I'll keep [D7]waiting and 
     [Am7]       Someday [D7]darling
     [G/]You'll come to [F/]me when you 
     [G/]want to settle [F/]down, [G/]oh!
{eoc}

[C] One fine day 
   {c:(shooby dooby dooby dooby do wah wah)}
[G] We'll meet once more 
   {c:(shooby dooby dooby dooby do wah wah)}
[Am] And then you'll want the love you 
     {c:(shooby dooby dooby dooby do wah wah)}
[F] Threw away before
   {c:(shooby dooby dooby dooby do wah wah)}
[C]  One fine [Am]day   [F]   you're gonna [G7]want me for your 
    {c:(One fine day…  ooh….             ooh…)}
[C]girl (234)                       ([F]1234)                        ([C]1234,1234) 
    {c:(Shooby dooby dooby, dooby dooby dooby do wah…)}

{c:(Kazoos and "Ah...") } 
[C]/ / / /   / / / /   [G]/ / / /   / / / /      
[Am]/ / / /   / / / /    [F]/ / / /   / / / /  

[C] One fine [Am]day    [F]      you're gonna [G7]want me for your 
   {c:(One fine day... ooh…                 ooh…)   }                      

[C]Girl              ([Am]1234) ([F]1234)                         ([G7]1234)  
   {c:(One fine day,       you're gonna want me for your girl)} 
                     
[C] One fine [Am]day     [F]     you're gonna [G7]want me for your 
    {c:(One fine day,   ooh…                 ooh… )}

[C]Girl (234)                      ([F]1234)                              [C/]
    {c:(Shooby dooby doo, shooby dooby dooby do wah…)}


{define: D7 0 2 0 2 0}