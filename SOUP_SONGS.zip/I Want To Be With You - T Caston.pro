{title:I Want To Be With You}
{subtitle:T. Caston}
{subtitle: 4/4 Time}
{subtitle:Key of A}
{time:3:42}
{metronome: 116}




{c: Intro:  picking only}
[A/] {c:(234)}    [B7/]      {c:(234)}      
[D/] {c:(234)}   [A/]   {c:(234)} 

{c:(then add strumming}

[A/] {c:(234)}    [B7/]      {c:(234)}      
[D/] {c:(234)}   [A/]   {c:(234)} 

{soc}                                                              
[A]          [B7]      ummm   hmmmm  
[D]     I want to be with [A]you
[A]           [B7]     ummm   hmmmm  
[D]     I want to be with [A]you {c:(234,1234)}
{eoc}
                             
[A]We've been through [D]rough times
And bitter battles [A]fought {c:(234,1234)}
I [E]wouldn't change a single [D]thing
You really mean a l[A]ot {c:(234,1234)}
And for [A]what it's worth I [D]couldn't have loved
Anyone, any[A]more {c:(234,1234)}
So [E]here's to you and the 
[D]Things you do for [A]me 

{soc}
When the [A]sun goes down and the [B7]moon comes up
[D]     I want to be with [A]you
When the [A]moon goes down and [B7]sun comes up
[D]     I want to be with [A]you
When the [A]winter winds turn to [B7]summer breezes 
[D]     I want to be with [A]you
When the [A]youthful dreams turn to [B7]weathered creases  
[D]     I want to  be with [A]you {c:(234,1234)}
{eoc}
                                   
So if [A]you know what I'm [D]trying to say
I hope you'll be with [A]me {c:(234,1234)}
At [E]least if the future is un[D]certain
We'll have eterni[A]ty

{soc}
When the [A]sun goes down and the [B7]moon comes up
[D]     I want to be with [A]you
When the [A]moon goes down and [B7]sun comes up
[D]     I want to be with [A]you
When the [A]winter winds turn to [B7]summer breezes 
[D]     I want to be with [A]you
When the [A]youthful dreams turn to [B7]weathered creases
[D]     I want to  be with [A]you {c:(234)}
{eoc}
                                                           
[E]Look into my [D]eyes and tell me you don't 
[A]feel the same
[E]If we said good[D]bye, could either of us 
[A]take the pain {c:(4,123)}

{soc}
When the [A]sun goes down and the [B7]moon comes up
[D]     I want to be with [A]you
When the [A]moon goes down and [B7]sun comes up
[D]     I want to be with [A]you
When the [A]winter winds turn to [B7]summer breezes 
[D]     I want to be with [A]you
When the [A]youthful dreams turn to [B7]weathered creases
[D]     I want to  be with [A]you {c:(234)}
{eoc}

[A]////     [B7]////      [D]////      [A]////

[A/]      [B7/]          [D/]           [A/]



