{title:B-I-N-G-O   }
{subtitle:tab   4/4      Key of C}
{metronome:108 }
{time: 2:00 }





1.There… [C/]was a farmer [F/]had a [C/]dog 
And [Am/]BINGO was his [C/]name-o
[C]B - I - [F]N - G - O     
[G7]B - I - [C]N - G - O
[Am]B - I - [F]N - G - O
And [G7]BINGO was his [C]name-o

2.There [C/]was a farmer [F/]had a [C/]dog 
And [Am/]BINGO was his [C/]name-o
{c:(clap)} - I - [F]N - G - O  
{c:(clap)} - I - [C]N - G - O
{c:(clap)} - I - [F]N - G - O 
And [G7]BINGO was his [C]name-o

3.There [C/]was a farmer [F/]had a [C/]dog 
And [Am/]BINGO was his [C/]name-o
{c:(clap, clap)}  [F]N - G - O     
{c:(clap, clap)}  [C]N - G - O
{c:(clap, clap)}  [F]N - G - O 
And [G7]BINGO was his [C]name-o

4.There [C/]was a farmer [F/]had a [C/]dog 
And [Am/]BINGO was his [C/]name-o
{c:(X, X, X)}  - G - O   
{c:(X, X, X)}  - G - O
{c:(X, X, X)}  - G - O 
And [G7]BINGO was his [C]name-o

5. There [C/]was a farmer [F/]had a [C/]dog 
And [Am/]BINGO was his [C/]name-o
{c:(X, X, X-X)}  - O
{c:(X, X, X-X)}  - O
{c:(X, X, X-X)}  - O 
And [G7]BINGO was his [C]name-o

6.There [C/]was a farmer [F/]had a [C/]dog 
And [Am/]BINGO was his [C/]name-o
{c:X-X-XXX, X-X-XXX, X-X-XXX} 
And [G7]BINGO was his [C/]name-[C/]o


{tag: Children}