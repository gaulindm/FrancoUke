

{title:010  SPIRIT IN THE SKY }
{subtitle:     4/4      Key of A}
{subtitle: (Norman Greenbaum)}
{time:3:09}
{metronome: 136 }






[A]/ / / /   / /    [D]/    [C]/ 
[A]/ / / /   / /    [C]/    [D]/ 

[A]/ / / /   / /    [D]/    [C]/ 
[A]/ / / /   / /    [C]/    [D]/ 

[A] When I die and they lay me to rest
Gonna go to the [D]place that's the best 
When they lay me [A]down to die  
Going [E7]up to the spirit in the [A]sky {c:(234)}
 
{c:CHORUS}
{soc}
[A]    Going up to the spirit in the sky 
                                              {c:(spirit in the sky)}
That's where I'm gonna go [D]when I die {c:(when I die)}
When I die and they [A]lay me to rest 
I'm gonna [E7]go to the place that’s the [A]best {c:(234)}
{eoc}

[A]/ / / /   / /    [D]/    [C]/ }
[A]/ / / /   / /    [C]/    [D]/ }

[A]/ / / /   / /    [D]/    [C]/ }
[A]/ / / /   / /    [C]/    [D]/ }

[A] Prepare yourself, you know it's a must 
Gotta have a friend in [D]Jesus 
So you know that [A]when you die
He's [E7]gonna recommend you to the 
Spirit in the [A]sky                                                             
                 {c:(spirit in the sky)}

{soc} 
[A]Gonna recommend you to the 
Spirit in the sky 
                    {c:(spirit in the sky)}
That's where you're gonna go 
[D]When you die {c:(when you die)}
When you die and they [A]lay you to rest
You're gonna [E7]go to the place that’s the [A]best {c:(234)}
{eoc}

[A]/ / / /   / /    [D]/    [C]/ 
[A]/ / / /   / /    [C]/    [D]/ 

[A]/ / / /   / /    [D]/    [C]/ 
[A]/ / / /   / /    [C]/    [D]/ 

[A]Never been a sinner,[A]   I never sinned
I've got a friend in [D]Jesus
So you know that [A]when I die
He's [E7]gonna set me up with the spirit in the [A]sky

{soc} 
[A]Gonna set me up with the spirit in the sky 
                                                             {c:(spirit in the sky)}
That's where I'm gonna go [D]when I die {c:(when I die)}
When I die and they [A]lay me to rest
I'm gonna [E7]go to the place that's the [A]best
[E7]Go to the place that's the [A]best {c:(234)}
{eoc}

[A]/ / / /   / /    [D]/    [C]/ 
[A]/ / / /   / /    [C]/    [D]/ 

[A]/ / / /   / /    [D]/    [C]/ 
[A]/ / / /   / /    [C]/    [D]/    [A]/


_____________________________________












