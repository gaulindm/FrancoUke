{title:IRISH MEDLEY  }
{subtitle:   Keys of C, G,      4/4 and 3/4   }
{metronome: 140}
{time:3:00}





{c:INTRO:}
[C]/ / / /    [F]/ /    [C]/ / 
[D7]/ /    [G7]/ /    [C]/ / /
 
It's a [C]long way to Tippe[C7]rary 
It's a [F]long way to [C]go
It's a long way to Tipperary
To the [D]sweetest [D7]girl I [G7]know 
[C]Goodbye, Picca[C7]dilly  
[F]Farewell, Leicester [E7]Square!
It's a [C]long long way to Tippe[F]ra…[C]ry 
But [D7]my heart's [G7]      right [C/]there 

{c:(soft strums)}
Oh Danny [C]Boy, the [C7]pipes
The pipes are [F]calling   [F]
From glen to [C]glen and [Am]down 
The [D7]mountain[G7]side    [G7] 
The summer's [C/]gone and 
[C7]All the roses [F]falling    [F]
Tis you, tis [C]you 
Must [G7]go and I must [C]bide {c:(23,123)}
 
{c:(3/4 time now, key of G)} 
[G]/ / /   / /  
            
When [G]Irish [D7]eyes are [G]smiling [G7]  
Sure, 'tis [C]like a morn in [G]Spring [G7]
In the [C]lilt of Irish [G]laughter [E7]     
You can [A7]hear the angels [D]sing 
When [G]Irish [D7]hearts are [G]happy  [G7]      
All the [C]world seems bright and [G]gay [G7]
And when [C]Irish [A7]eyes are [G]smi[E7]ling 
Sure, they’ll [A7]steal your [D7]heart a-[G]way

My [G]wild [D7]Irish [G]Rose [G7]    
The [C]sweetest flower that [G]grows 
You may [D7]search every[G]where 
But [D7]none can com[G]pare 
With my [A7]wild Irish [D7]Rose 
[G]Too-ra-[C]loo-ra-[G]loorah [G7]       
[C]Too ra loo ra [A7]lie 
[G]Too ra [C]loo ra [G]loorah   [Em]         
[A7]Hush now don't you [D]cry [D7]
[G]Too-ra-[C]loo-ra-[G]loorah [G7]        
[C]Too ra loo ra [A7]lie 
[G]Too ra [C]loo ra [G]loorah   [Em]      
It's an [A7/]Irish… [D/]lu…lla[G/]by… 
