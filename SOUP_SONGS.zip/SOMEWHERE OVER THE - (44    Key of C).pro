
{title:SOMEWHERE OVER THE}
{title: RAINBOW &}
{title:WHAT A WONDERFUL WORLD  }
{subtitle:(4/4    Key of C)}
{subtitle:(Isreal Kamakawiwo’ole)}
{time:6:01}
{metronome: 165}

Ellen



{c:"Ooo"...  } 
[C]/ / / /   / / / /    [Em]/ / / /   / / / /    
[F]/ / / /   / / / /    [C]/ / / /   / / / /   
[F]/ / / /   / / / /    [E7]/ / / /   / / / /    
[Am]/ / / /   / / / /    [F]/ / / /   / / / /  

[C]Somewhere [Em]over the rainbow   
[F]   Way up [C]high   
[F]And the [C]dreams that you dream of 
[G]Once in a lulla[Am]ba-↑a-↑aye   [F]   ↑a-a-aye

Oh [C]some↓where [Em]over the ↑rainbow 
↑[F]Blue birds [C]fly  
[F]And the [C]dreams that you dream of
[G]Dreams really do come 
[Am]Tru-↑u-↑u    [F]   ↑u-u-ue

Some[C]day I'll wish upon a star
[G]Wake up where the clouds are far 
Be[Am]hind ↑[F]me-e-e
Where [C]trouble melts like lemon drops 
[G]High above the chimney top that's 
[Am]Where you'll ↑[F]fi-ind me
 
Oh, [C]some↑where [Em]over the ↑rainbow 
[F]   Blue birds [C]fly 
[F]And the [C]dreams that you dare to
Oh [G]why, oh why can't [Am]I-↑i-↑i   [F]    ↑i-i-i

Well I see [C]trees of [Em]green and  
[F]   Red roses [C]too   
[F]I'll watch them [C]bloom for [E7]     me and [Am]you 
And I   [F]     think to myself 
[G]    What a wonderful 
↑[Am]world {c:(234,1234)}   {c:(}[F]{c:1234,1)}

Well I see [C]skies of [Em]blue and I see 
[F]  Clouds of [C]white and the [F]brightness of [C]day 
[E7]  I like the [Am]dark and I [F]      think to myself  
[G]    What a wonderful ↓[C]world {c:(234)}    
{c:(}[F]{c:1234)}   {c:(}[C]{c:1234,123)}

The [G]colours of the rainbow so [C]pretty in the sky 
Are [G]also on the faces of [C]people passing by
I see [F]friends shaking [C]hands saying
[F]   How do you [C]do?
[F]  They're really [C]saying, [Dm7]I {c:(234,12)}  
I love [G]you  {c:(234,12)}

I hear [C]babies [Em]cry and I [F]    watch them [C]grow 
[F]They'll learn much [C]more [E7]     than we'll [Am]know 
And I [F]   think to myself, [G]   
What a wonderful ↓[Am]wor-↑or-↑old   
[F]  ↓wor -↑or-↑old

Some[C]day I'll wish upon a star 
[G]Wake up where the clouds are far 
Be[Am]hind   ↑[F]me-e-e
Where [C]trouble melts like lemon drops
[G]High above the chimney top that's 
[Am]Where you'll ↑[F]fi-ind me, oh

[C]Some↑where [Em]over the rainbow   
[F]   Way up [C]high
[F]And the [C]dreams that you dare to 
[G]Why, oh why can't   ↓[Am]I-↑i-↑i     [F]    ↓i -↑i-↑i

{c:OUTRO: ("Ooo")}
[C]/ / / /   / / / /    [Em]/ / / /   / / / /    
[F]/ / / /   / / / /    [C]/ / / /   / / / /  
[F]/ / / /   / / / /    [E7]/ / / /   / / / /    
[Am]/ / / /   / / / /    [F]/ / / /   / / / /
[C]/ 

_________________________________________









  





