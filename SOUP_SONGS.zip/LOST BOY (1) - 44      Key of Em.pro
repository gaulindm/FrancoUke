{title:LOST BOY }
{subtitle:    4/4      Key of Em}
{subtitle:}
{time: 4:00}





[Intro]


[Em] [G] [C] [G]


[Em]There was a time when [G]I was alone
[C]Nowhere to go and no [G]place to call home
[Em]My only friend was the [G]man in the moon
And [C]even sometimes he would [G]go away too 
[Em]Then one night as I [G]   closed my eyes
[C]I saw a shadow [G]flying high
[Em]He came to me with the [G]sweetest smile 
[C]Told me he wanted to [G]talk for a while
He said [Em] "Peter Pan [G]that's what they call me 
[C] I promise that you'll [G]never be lonely."
And [Em]ever since that [D]day


[Em] I am a lost boy [G]from Neverland
[C]Usually hangin' out with [G] Peter Pa-an
[Em]And when we're bored we [G]play in the woods
[C]Always on the run from [G]   Captain Hook
[Em]"Run, run, [G]lost boy" [C]   they say to [G]me
A[Em]way from [G]all of [C]   reali[G]ty
[Em]Neverland is home to [G]lost boys like me
And [C]lost boys like me are [G]free


He [Em]sprinkled me in pixie dust and 
[G]Told me to believe
Be[C]lieve in him, and be[G]lieve in me
To[Em]gether we will fly away [G]in a cloud of green
[C]To your beautiful [G]destiny
As we [Em]soared above the town that [G]never loved me
I [C]realized I finally had a [G]family
[Em]Soon enough we reached [G]Neverland
[C]Peacefully my feet [G]hit the sand
And [Em]ever since that [D]day


[Em] I am a lost boy [G]from Neverland
[C]Usually hangin' out with [G] Peter Pa-an
[Em]And when we're bored we [G]play in the woods
[C]Always on the run from [G]   Captain Hook
[Em]"Run, run, [G]lost boy" [C]    they say to [G]me
A[Em]way from [G]all of [C]reali[G]ty
[Em/]Neverland is home to [G/]lost boys like me
And [C/]lost boys like me are [G/]free
[Em/]Neverland is home to [G/]lost boys like me
And [C/]lost boys like me are [G/]free

[Em]Peter Pan, Tinkerbell, [G]Wendy Darling
[C]Even Captain Hook, you are my 
[G]Perfect storybook
[Em]Neverland I love you so 
[G]You are now my home sweet home
For[C]ever a lost boy at [G]last
And for [C]always I will [D]say


[Chorus]

[Em] I am a lost boy [G]   from Neverland
[C]Usually hangin' out with[G] Peter Pan
[Em]And when we're bored we [G]play in the woods
[C]Always on the run from [G]   Captain Hook
[Em]"Run, run, [G]lost boy" [C]   they say to [G]me
A[Em]way from [G]all of [C] reali[G]ty
[Em/]Neverland is home to [G/]lost boys like me
And [C/]lost boys like me are [G/]free
[Em/]Neverland is home to [G/]lost boys like me
And [C/]lost boys like me are [G/]free


