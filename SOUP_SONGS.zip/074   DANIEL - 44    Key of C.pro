

{title:074   DANIEL }{subtitle: 4/4    Key of C}{subtitle:(Elton John)}{metronome: 135}
{time:4:47}[C]/ / / /   / / / /    [F]/ / / /   / / / / 
   [G]/ / / /    [F]/ / / /    [C]/ / / /   / / / /{c:(}[C]{c:12)} Daniel is traveling tonight on a [Dm]plane {c:(234,1234)}[G] I can see the red tail li-ights 
[E7]Heading for Spa-a-[Am]ain, oh and 
{c:(}[F]{c:12)} I can see [G]Daniel waving good[Am]bye {c:(234,123)}God it [F]looks like Daniel {c:(1234)}  [G7] Must be the [F]clouds in my [C]eyes {c:(234)}[C]/ / / /    [G7]/ / / /   / / / /{c:(}[C]{c:12)} They {soh}say{eoh} Spain is pretty 
Though I've never [Dm]been {c:(234,1234)}[G]  Well {soh}Dan{eoh}iel says it's the best place 
[E7]That he's ever [Am]seen, oh and 
{c:(}[F]{c:12)} He should [G]know 
He's been there e[Am]nough {c:(234,123)}Lord [F]I miss Daniel {c:(1234)}
{c:(}[G7]{c:12)} Oh, I [F]miss him so [C]much {c:(234)}{soc}  [C]   O-o-oh, [F]   Daniel my brother, you are 
  [C]    Older than me, do you still [F]feel the pain {c:(4,123)} 
  Of the [C]scars that won't heal 
  Your eyes have [Am]died {c:(234)} 
  But you see more than [F]I {c:(234)}  [Fm/]Daniel you're a [C]star [A7]      
  In the face of the [Dm]sky-y-[G7]y  {c:(234)}{eoc}{sob}  [C]/ / / /   / / / /    [Dm]/ / / /   / / / /     [G]/ / / /   / / / /    [E7]/ / / /    [Am]/ /    [G]/ /  [F]/ / / /    [G]/ / / /    [Am]/ / / /   / / / /  [F]/ / / /   / / / /    [G]/ / / /   / / / /     [C]/ / / /   / {eob}{soc}  [C]   O-o-oh, [F]   Daniel my brother, you are 
  [C]    Older than me, do you still [F]feel the pain {c:(4,123)} 
  Of the [C]scars that won't heal 
  Your eyes have [Am]died {c:(234)} 
  But you see more than [F]I {c:(234)}  [Fm/]Daniel you're a [C]star [A7]      
  In the face of the [Dm]sky-y-[G7]y  {c:(234)}{eoc}

{c:(}[C]{c:12)} Daniel is traveling tonight on a [Dm]plane {c:(234,1234)}[G] I can see the red tail li-ights 
[E7]Heading for Spa-a-[Am]ain, oh and 
{c:(}[F]{c:12)}  I can see [G]Daniel waving good[Am]bye {c:(234,123)}God it [F]looks like Daniel {c:(1234)}[G7] Must be the [F]clouds in my [C]eyes {c:(234,1)}Oh God it [F]looks like Daniel {c:(1234)}[G7] Must be the [F]clouds in my [C]eyes {c:(234)}[C]/ / / /    [F]/ / / /   / / / /   
[G]/ / / /    [F]/ / / /    [C]/ / / /   /


______________________________________




{define: Fm/ 0 1 0 1 3}









