{t:AS TIME GOES BY   }                
{subtitle:(Herman Hupfeld)}
{metronome: 80}
{time: 3:00}








{c:INTRO: D7  / /    G7  / /   C  / / / /  }

You [Dm]must remember [G7]this 
A [Gm6]kiss is just a [G7]kiss 
A [C]sigh is just a [Dm]sigh [Gdim] [G7] 
The [D7]fundamental things ap[G7]ply 
As [Dm]time [G7]goes [C////]by    [Gdim////]  
 
And [Dm]when two lovers [G7]woo 
They [Gm6]still say I love [G7]you
On [C]that you can [Dm]rely [Gdim] [G7] 
No [D7]matter what the future [G7]brings 
As [Dm]time [G7]goes [C////]by    [C7////] 

{c:BRIDGE }
{sob} 
     [F]Moonlight and love songs [A7]never out of date 
     [Dm]Hearts full of passion, [D#m-5]jealousy and hate 
     [Am]Woman needs [Am/C]man 
     And man must have his [D7]mate 
     That [Dm]no one [Gdim]can de[G7////]ny 
{eob} 

It’s [Dm]still the same old [G7]story 
A [Gm6]fight for love and [G7]glory 
A [C]case of do or [Dm]die [Gdim][G7] 

The [D7]world will always welcome [G7]lovers 
as [Dm]time [G7]goes ↑[E7////]by   [A7////]
The [D7]world will always welcome [G7]lovers 
as [Dm/]time [G7/]goes [C//]by  [Fm//]  [C/]   

{define: D7 0 2 0 2 0}
{define: D#m-5 0 3 2 1 1}
