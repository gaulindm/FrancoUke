{title:HOME}
{subtitle: (Edward Sharpe and the Magnetic Zeros)}
{metronome: 210}
{time:4:20}


Lynda counts in

Ooos


[Am]/ / / /   / / / /    
[C]/ / / /   / / / /   
[C]/ / / /   / / / /    
[F]/ / / /   / / / /

[Am]/ / / /   / / / /    
[C]/ / / /   / / / /   
[C]/ / / /   / / / /    
[F]/ / / /   / / / /

{c:(Girls)}  [Am]Alabama, Arkansa 
         [C]I do love my Ma and Pa
        Not the way that I do love  [F]    you

{c:(Boys)}  Well [Am]Holy moley me oh my 
       [C]You’re the apple of my eye
       Girl I’ve never loved one like  [F]    you

{c:(Girls)}  [Am]Man oh man you’re my best friend 
       I [C]scream it to the nothingness {c:(beat)} 
       There ain’t nothing that I [F]need

{c:(Boys)}  Well [Am]hot and heavy pumpkin pie 
      [C]Chocolate candy Jesus Christ
      {c:(beat)} Ain’t nothing please me more than 
        [F]you    [F/]      {c:(tap)}



[Am]Home, let me come [C]home  
Home is whenever I’m with [F]you
Ahh [Am]home, let me come [C]ho-o-ome 
Home is wherever I’m with [F]you 



[Dm]/ / / /    [C]/ /     
[G]/ / /    [G/]hey!        
[Dm]/ / / /    
[C]/ /    [G]/ /    
[Dm]/ / /    [Dm/]hey!   
[C]/ /    [F]/ /    [F/]hey!   [F/]hey!    
   

[Am]La la   [G]la la  [Dm]take me  [F]    home 
[G/]Mother, I’m comin’ ho[Gsus/]me        {c:(234,1)}

{sot}
A| - - 0 2 - 
E| - 2 - - - 
{eot}

Ooos...         
[Am]/ / / /   / / / /    
[C]/ / / /   / / / /   
[C]/ / / /   / / / /    
[F]/ / / /   / / / /

[Am]/ / / /   / / / /    
[C]/ / / /   / / / /   
[C]/ / / /   / / / /    
[F]/ / / /   / / / /

{c:(Boys)} I'll [Am]follow you into the park 
 [C]Through the jungle through the dark
 Girl I never loved one like [F]   you

{c:(Girls)} [Am]Moats and boats and waterfalls 
 [C]Alleyways and payphone calls  {c:(beat)} 
 I've been everywhere with [F]you {c:(⚤That's true)}

{c:(Boys)} We [Am]laugh until we think {c:(⚤we’ll die)} 
 [C]Barefoot on a {c:(⚤summer night)  }
 {c:(beat)}  Nothing is sweeter than with [F]you

{c:(Girls)} And [Am]in the streets you run afree
 [C]Like it's only  {c:(⚤ You and me)}
      
{c:(⚤)}[C]{c:Geeze, you're something to} [F]{c:see  } [F/] {c:(tap)}


[Am]Home, let me come [C]home  
Home is whenever I’m with [F]you
Ahh [Am]home, let me come [C]ho-o-ome 
Home is wherever I’m with [F]you 


[Dm]/ / / /    [C]/ /     
[G]/ / /    [G/]hey!      
[Dm]/ / / /    
[C]/ /    [G]/ /   
[Dm]/ / /    [Dm/]hey!    
[C]/ /    [F]/ /    [F/]hey!   [F/]hey!    
        
[Am]La la [G]la la [Dm]take me  [F]    home 
[G/]Mother, I’m comin’ ho[Gsus/]me {c:(234,1)}


{sot}
A| - - 0 2 - - 
E| - 2 - - - - 
{eot}



[Am]Home, let me come [C]home  
Home is whenever I’m with [F]you

Ahh [Am]home, let me come [C]ho-o-ome 
Home is wherever I’m with [F]you 


{c:(quietly)}
   [Am/]Home, let me come [C/]home
   [C/]home is wherever I’m with [F/]you

   Ahh [Am/]home,yes I am [C/]ho-o-ome 
   [C/]home is wherever I’m with [F/]you 


{c:(Girls)} [Am]Alabama Arkan[C]sas... 
   I do love my Ma and [F]Pa 
   [Am]Moats and boats and water[C]falls 
     Alleyways and pay phone [F]calls
  

{c:(all)} [Am]Home, let me come [C]home
   Home is whenever I’m with [F]you
   Ahh [Am]home, let me come [C]ho-o-ome
   [C/]Home is when I’m alone with [F/]you 

{define: Gsus/ 0 0 2 3 3}