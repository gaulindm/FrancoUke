

{title:145   HOOKED ON A FEELING}
{subtitle: Key of G   4/4}
{subtitle:(Mark James)}
{metronome: 130}
{time:3:15}





[G]/ / / /    [D]/ / / /    
[G7]/ / / /    [C]/ / / /
[Cm]/ / / /    [G]/ / / /    
[D]/ / / /    [D7]/ / / / 
  
[G]I can't stop this [D]feeling 
[G7]Deep inside of [C]me 
[Cm]Girl you just don't [G]re…alize 
What you [D]do… to me [D7]
 
When you [G]hold me in your [Gaug]arms so tight 
You let me [Em]       know 
Every[G7]thing's alright 

{soc} 	
   [C]I-I…  [D//]      I’m hooked on a [G]feeling  
[D]    I’m high on be[C]lieving  
[D]    That you're in [G]love with me  [C]/ /   [D]/ /  
{eoc}
			
[G]Lips as sweet as [D]candy
The [G7]taste stays on my [C]mind 
[Cm]Girl, you keep me [G]thirsty for 
A[D]nother cup of [D7]wine 
I’ve [G]got it bad for [D]you, girl 
But [G7]I don't need no [C]cure 
[Cm]I'll just stay a[G]ddicted
And hope I [D]can endure  [D7]

All the [G]good love when we're [Gaug]all alone
Keep it [Em]up, girl, yeah you [G7]turn me on 

{soc} 	
   [C]I-I…  [D//]      I’m hooked on a [G]feeling  
[D]    I’m high on be[C]lieving  
[D]    That you're in [G]love with me  [C]/ /   [D]   
{eoc}

All the [G]good love, when we're [Gaug]all alone 
Keep it [Em]up, girl, yeah you [G7]turn me on 

{soc}  
[C]I-I…  [D//]      I’m hooked on a [G]feeling  
[D]    I’m high on be[C]lieving  
[D]    That you're in [G]love with me  [C]/ / 
{eoc}

{c:OUTRO:}   
I’m [D]hooked on a [G]feeling   
[D]  I'm high on be[C]lieving  
[D]  That you're in [G]love with me  
[C]  That [D]you're in [G]love with me  
[C]/ /    [D]/ /     [G]/


___________________________________
{define: Gaug 0 0 3 3 2}
{define: D7 0 2 0 2 0}









