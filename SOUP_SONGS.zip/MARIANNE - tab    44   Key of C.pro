{title:MARIANNE   }
{subtitle:tab    4/4   Key of C }
{subtitle:(Terry Gilkyson, Frank Miller)}
{subtitle: (& Richard Dehr)}
{metronome:180 }
{time:3:30 }
                                                               }     




{c:INTRO:}
{c:F / / / /    C / / / /    }
{c:G7 / / / /   C / / / / }

{soc}
  [C]All day, all night, [G7]Marianne
  Down by the seaside [C]siftin' sand
  Even little children love [G7]Marianne
  Down by the seaside [C]siftin' sand
{eoc}

[C]Marianne, oh Marianne oh [G7]won't you marry me?
We can have a bamboo hut with brandy in the [C]tea
Leave your fat old mama home she never will say [F]yes
If your mama don't [C]know now 
[G7/]  She can [C/]guess (my my yes!)     

{soc}
  [C]All day, all night, [G7]Marianne
  Down by the seaside [C]siftin' sand
  Even little children love [G7]Marianne
  Down by the seaside [C]siftin' sand
{eoc}

[C]When she walks along the shore [G7]People pause to greet
White birds fly around her, little fish come to her [C]feet
In her heart is love but I'm the only mortal [F]man
Who's allowed to [C]kiss my 
[G7/]  Mari[C/]anne  (Don't rush me!)     

{soc}
  [C]All day, all night, [G7]Marianne
  Down by the seaside [C]siftin' sand
  Even little children love [G7]Marianne
  Down by the seaside [C]siftin' sand
{eoc}

[C]When we marry we will have a [G7]time you never saw
I will be so happy I will kiss my mother-in-[C/]law (Phooey!)
[C]Children by the dozen in and out the bamboo [F]hut
One for every [C]palm tree 
[G7/]  And coc-y-[C/]nut  (Hurry up now!)    

{soc}
  [C]All day, all night, [G7]Marianne
  Down by the seaside [C]siftin' sand
  Even little children love [G7]Marianne
  Down by the seaside [C]siftin' sand
{eoc}


{c:OUTRO: F / / / /    C / / / / }
{c: G7 / / / /   C / }
