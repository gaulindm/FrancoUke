{title:HOME      }
{subtitle:  4/4      key of G}
{subtitle:(Michael Bublé)}
 
[G] Another summer day 
[D] Is come and gone away
[Em] In Paris and [D]Rome
But I wanna go [C]home {c:(234)} [Cadd9]
M[D]mmm  [G]      [D]
 
[G] Maybe surrounded by
[D] A million people I
[Em]   Still feel all alon[D]e
I just wanna go [C]home {c:(234)} [Cadd9]
Oh I [D]miss you, y[G]ou know 
 
And I've been [C]keeping all the letters 
That I [Em]wrote to you
Each one a [Asus4]line or two  [A]
"I'm fine baby, [C]    how are you?" [D]
Well I would [C]send them 
But I know that it's just [Em]not enough
My words were [F]cold and flat 
And you deserve [D]more than that  {c:(234)}
 
[G] Another aeroplane
[D] Another sunny place
[Em]   I'm lucky I kno[D]w
But I wanna go h[Cadd9]ome
Mmmm, I'v[D]e got to go h[G]ome [D]
 
Let me go [G]hoo[D]ooooo[Em]ome [Em7]
I'm just too [C]far from where you [Em]are
I wanna come [G]home [D]
 
And I [C]feel just like I'm living 
Someone [Em]else's life
It's like I just [Asus4]stepped outside [A]
When everything was [C]going right [D]
And I [C]know just why you could not 
Come [Em]along with me
But this was [F]not your dream
But you always be[D]lieved in me
 
[G] Another winter day has come 
[D] And gone away
[Em]   And even Paris and Rom[D]e
And I wanna go [C]home [Cadd9]
[D]Let me go [G]home [D]
 
[G] And I'm surrounded by
[D] A million people I
[F]    Still feel alone
Oh, let go [C]home [Cadd9]
Oh, I m[D]iss you, y[G]ou know [D]
 
Let me go[G] ho[D]ooooo[Em]oom[Em7]e
I've had my [C]run Baby, I'm [C]done
I [D]gotta go [G]home [D]
Let me go[G] ho[D]ooooo[Em]oom[Em7]e
It will alr[C]ight
I'll be home ton[D]ight
I'm coming back h[G]ome
