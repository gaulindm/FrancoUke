{title:  FIVE YEARS TIME}
{subtitle:(4/4   Key of G)}
{subtitle:(Noah and The Whales)}
{metronome: 130}
{time: 3:00}







{c:Chunking works well}
{c:See website tutorial}

[G]/ /    [C]/ /    
[D]/ /    [C]/ /  
[G]/ /    [C]/ /    
[D]/ /    [C]/  

Oh, well, in [G]five years [C]time 
We could be [D]walking round a [C]zoo
With the [G]sun shining [C]down 
Over [D]me and [C]you
And there’ll be [G]love in the [C]bodies 
Of the [D]elephants [C]too
I’ll put my [G]     hands over [C]your eyes
But [D]you'll peep [C]through

And there’ll be [G]sun, sun, [C]sun   
[D]  All over our [C]bodies
And [G]sun, sun, [C]sun   
[D]  All down our [C]necks
And there'll be [G]sun, sun, [C]sun
[D]  All over our [C]faces
And [G]sun, sun, [C]sun    
[D]  So what the [C]heck

Cause I’ll be [G]laughing at [C]all your 
[D]Silly little [C]jokes
And we’ll be [G]laughing about [C]how we 
[D]Used to [C]smoke
All those [G]stupid little [C]cigarettes 
And [D]drink stupid [C]wine
Now a [G]ukulele’s [C]all we need to 
[D]Have a good [C]time

And now it’s [G]fun, fun, [C]fun 
[D] When we are [C]strumming
Yeah it’s [G]fun, fun, [C]fun 
[D] And we’re not [C]drunk
And it is [G]fun, fun, [C]fun 
[D] Cause we are [C]laughing
It’s [G]fun, fun, [C]fun
[D]  Oh it’s [C]fun (whoo!)  

[G]/ /    [C]/ /    [D]/ /    [C]/ / 
[G]/ /    [C]/ /    [D]/ /    [C]/  

Oh, well, I [G]look at you and [C]say 
It’s the happiest [D]I’ve ever [C]been
And I’ll say [G]I no longer [C]feel 
I have to [D]be James [C]Dean
And she'll say [G]   “Yeah, well I [C]feel 
All [D]pretty happy [C]too
And I’m [G]always pretty [C]happy 
When I’m [D]kicking back with [C]you”

Let it be [G]love, love, [C]love 
[D] All through our [C]bodies
And [G]love, love, [C]love 
[D]  All through our [C]minds
Let it be [G]love, love, [C]love 
[D]  All over [C]your face
And [G]love, love, [C]love
[D]  All over [C]mine

Although [G]maybe all these [C]moments 
Are [D]just in my [C]head
I’ll be [G]thinking 'bout [C]them 
As I'm [D]lying in [C]bed
And [G]all that we be[C]lieve 
They might not [D]even come [C]true
But in my [G]mind I’m [C]having 
A pretty good [D]time with [C]you, oh

In [G]five years [C]time 
[D] I might not [C]know you
In [G]five years [C]time 
[D]  We might not [C]speak at all
In [G]five years [C]time 
[D] We might not [C]get along
In [G]five years [C]time 
[D]  You might just [C]prove me  

[G]Wrong  [C]/ /    [D]/ /    [C]/ / 
[G]/ /    [C]/ /    [D]/ /    [C]/ 

Oh, there’ll be [G/]love, love, [C/]love 
[D/] Wherever [C/]you go 
There’ll be [G]love, love, [C]love 
[D] Wherever [C]you go 
There’ll be [G]love, love, [C]love 
[D] Wherever [C]you go
There’ll be [G]love, love, [C]love
[D] Wherever [C]you go   
There’ll be [G/]love 