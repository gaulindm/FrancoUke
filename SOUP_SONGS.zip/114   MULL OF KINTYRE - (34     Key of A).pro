

{title:114   MULL OF KINTYRE    }
{subtitle:(3/4     Key of A)} 
{subtitle:(Paul McCartney & Denny Laine)}
{time:4:16}
{metronome:106}






[A]/ / /   / / /   / / /   / / /   
 
{soc}
[A]Mull of Kintyre, oh [D]mist rolling in from the 
[A]Sea, my desire is [D]always to be here
Oh [A]Mull of Kintyre {c:(23,123,123) }
{eoc}

[A]Far have I travelled and much have I [A7]seen 
[D]Dark distant mountains with [A]valleys of green
Past painted deserts, the sunsets on [A7]fire as he
[D]carries me home to the [E7]Mull of Kin[A]tyre 
{c:(23, 123)  } 

{soc}
[A]Mull of Kintyre, oh [D]mist rolling in from the 
[A]Sea, my desire is [D]always to be here
Oh [A]Mull of Kintyre {c:(23,123,123) }
{eoc}

[A]Sweep through the heather like deer in the [A7]glen 
[D]Carry me back to the [A]days I knew then 
Nights when we sang like a heavenly [A7]choir of the 
[D]life and the times of the [E7]Mull of Kin[A]tyre 
{c:(23,123)  }

{soc}
[A]Mull of Kintyre, oh [D]mist rolling in from the 
[A]Sea, my desire is [D]always to be here
Oh [A]Mull of Kintyre {c:(23,123,123) }
{eoc}

[A]Smiles in the sunshine and tears in the [A7]rain 
[D]Still take me back where my [A]memories remain 
Flickering embers grow higher and [A7]high’r as they 
[D]carry me back to the [E7]Mull of Kin[A]tyre 
{c:(23,123)}

{soc}
[A]Mull of Kintyre, oh [D]mist rolling in from the 
[A]Sea, my desire is [D]always to be here
Oh [A]Mull of Kintyre {c:(23,123,123) }
{eoc}

[A]Mull of Kintyre, [E7]Mull of Kintyre
[A]Mull of Kintyre, [E7]Mull of Kintyre [A/]

__________________________________












