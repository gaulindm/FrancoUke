{t:     YOU AND I  } 
{subtitle:(4/4      Key of  C)}         
{subtitle:(Ingrid Michaelson)}
{time: 3:20}
{metronome: 135}         






{c:(gentle strumming for verses)}

{c:INTRO:}  
[C]/ / / /    / / / /                               
       
{c:(Sue)}  
[C]Don't you worry, there my honey
[F]We might not have any money
[Am]But we've got our love to pay the [F]bills 

{c:(Gord)}  
[C]Maybe I think you're cute and funny
[F]Maybe I wanna do what bunnies 
[Am]do with you, if you know what I [F]mean

{c:CHORUS}
{soc}
Oh, {soh}[C]let’s{eoh} get {soh}rich{eoh} ’n 
[E7]Buy our parents [F]homes in the South of [C]France
Let's get rich and give every[E7]body nice 
Sweaters and [F]teach them how to [G]dance
Let's get [C]rich and build a [E7]house on a mountain
Making [F]everybody look like [D7]ants   
From way up [C]there, you and [F]I, [G]you and [C]I
{eoc}

{c:(Gord)}  Well [C]you might be a bit confused
{c:(Sue)}  And [F]you might be a little bit bruised
{c:(BOTH)}  But [Am]baby how we spoon like no one [F]else
{c:(Gord)} So [C]I will help you read those books
{c:(Sue)} If [F]you will soothe my worried looks
{c:(BOTH)} And [Am]we will put the lonesome on the [F]shelf

{soc}
Oh, {soh}[C]let’s{eoh} get {soh}rich{eoh} ’n 
[E7]buy our parents [F]homes in the South of [C]France
Let's get rich and give every[E7]body nice 
Sweaters and [F]teach them how to [G]dance
Let's get [C]rich and build a [E7]house on a mountain
Making [F]everybody look like [D7]ants   
From way up [C]there, you and [F]I, [G]you and [C]I
{eoc}

{soc}
Oh, [C/]let's get rich and buy our parents 
homes in the South of France
Let's get rich and give everybody nice 
Sweaters and teach them how to dance
Let's get rich and build a house on a mountain
Making everybody look like ants   
From way up there, you and I, you and I
{eoc}


{define: D7 0 2 0 2 0}
