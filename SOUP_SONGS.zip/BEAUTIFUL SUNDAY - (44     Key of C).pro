{title:  BEAUTIFUL SUNDAY }
{subtitle:(4/4     Key of C)}  
{subtitle:(Daniel Boone & Rod McQueen)}
{time: 3:30}
{metronome: 136}
 
{c:(note: chorus goes up one key at end of song) }


    


{c:INTRO:}   
[F]/ / / /    [G]/ / / /    
[C]/ / / /    / / / /         


[C]Sunday morning, up with the lark 
I think I'll take a walk in the park
[F]Hey, hey, [G]hey, it's a beautiful [C]day!

I've got someone waiting for me  
When I see her I know that she'll say
[F]Hey, hey, [G]hey, it's a beautiful [C]day!

{c:CHORUS 1}
{soc}
     [C]Hi, hi, hi, beautiful [F]Sunday 
     This is [G]my, my, my beautiful [C]day
     When you say, say, say, say that you [D7]love me
     Whoa, [F]my, my, [G]my, it's a beautiful [C]day!
{eoc}

[C]Birds are singing, you by my side
Let's take a car and go for a ride
[F]Hey, hey, [G]hey, it's a beautiful [C]day

We'll drive on and follow the sun
Makin' Sunday go on and on
[F]Hey, hey, [G]hey, it's a beautiful [C]day!

{c:CHORUS 1}
{soc}
     [C]Hi, hi, hi, beautiful [F]Sunday
     This is [G]my, my, my beautiful [C]day
     When you say, say, say, say that you [D7]love me
     Whoa, [F]my, my, [G]my
     It's a beautiful [C////]day!  {c:(up one key!)}  [D////]    
{eoc}

{c:CHORUS 2}
{soc}
     [D]Hi, hi, hi, beautiful [G]Sunday 
     This is [A]my, my, my, beautiful [D]day
     When you say, say, say, say that you [E7]love me
     Whoa, [G]my, my, [A]my it's a beautiful [D]day!    

     [D]Hi, hi, hi, beautiful [G]Sunday
     This is [A]my, my, my, beautiful [D]day
     When you say, say, say, say that you [E7]love me
     Whoa, [G]my, my, [A]my it's a beautiful [D]day!     
     
     Whoa, [G]my, my, [A]my it's a beautiful [D]day!    [A/]   [D/]
{eoc}

{define: D7 0 2 0 2 0}