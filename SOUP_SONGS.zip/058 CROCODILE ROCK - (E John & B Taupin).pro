

{title:058   CROCODILE ROCK}
{subtitle:(E. John & B. Taupin)}
{subtitle: 4/4 Key of G}
{time:4:28}
{metronome: 148}





[G]/ / / /   / / / /    
[Em]/ / / /   / / / /    
[C]/ / / /   / / / /    
[D]/ / / /   / / / 

I rem[G]ember when rock was young 
Me and [Bm]Susie had so much fun
Holding [C]hands and skimmin' stones
Had an [D]old gold Chevy and a place of my own
But the [G]biggest kick I ever got 
Was doin' a [Bm]thing called the Crocodile Rock
While the [C]other kids were rockin' 'round the clock 
We were [D]hoppin' and boppin' to the Crocodile Rock, well

{soc}
     [Em]     Crocodile Rockin' is something shockin' 
     When your [A7]feet just can't keep still
     [D7]     I never knew me a better time 
     And I [G]guess I never will
     [E7]Ow! Lawdy mamma those Friday nights 
     When [A7/]Susie wore her [A7/]dresses tight and
     [D7]     The Crocodile Rockin' was ou-ou-out of 
     [C/]Si- [C/]i- [C/]i- [C/]ight  [C//] 
     [G]Laaah la la la la [Em]laaaah
     La la la la [C]laaah, la la la la [D]laaah 
{eoc}

But the [G]years went by and rock just died 
[Bm]Susie went and left us for some foreign guy
[C]Long nights cryin' by the record machine 
[D]Dreamin' of my Chevy & my old blue jeans 
But they'll [G]never kill the thrills we've got 
Burnin' [Bm]up to the Crocodile Rock
Learning [C]fast as the weeks went past 
We really [D]thought the Crocodile Rock would last, well  

{soc}
     [Em]     Crocodile Rockin' is something shockin' 
     When your [A7]feet just can't keep still
     [D7]     I never knew me a better time 
     And I [G]guess I never will
     [E7]Ow! Lawdy mamma those Friday nights 
     When [A7/]Susie wore her [A7/]dresses tight and
     [D7]     The Crocodile Rockin' was ou-ou-out of 
     [C/]Si- [C/]i- [C/]i- [C/]ight  [C//]
 
     [G]Laaah la la la la [Em]laaaah
     La la la la [C]laaah, la la la la [D]laaah 
{eoc}

I rem[G]ember when rock was young 
Me and [Bm]Susie had so much fun
Holding [C]hands and skimmin' stones
Had an [D]old gold Chevy and a place of my own
But the [G]biggest kick I ever got
Was doin' a [Bm]thing called the Crocodile Rock
While the [C]other kids were rockin' 'round the clock
We were [D]hoppin' and boppin' to the Crocodile Rock, well

{soc}
     [Em]     Crocodile Rockin' is something shockin' 
     When your [A7]feet just can't keep still
     [D7]     I never knew me a better time 
     And I [G]guess I never will
     [E7]Ow! Lawdy mamma those Friday nights 
     When [A7/]Susie wore her [A7/]dresses tight and
     [D7]     The Crocodile Rockin' was ou-ou-out of 
     [C/]Si- [C/]i- [C/]i- [C/]ight  [C//]
 
     [G]Laaah la la la la [Em]laaaah
     La la la la [C]laaah, la la la la [D]laaah
 
     [G]Laaah la la la la [Em]laaaah
     La la la la [C]laaah, la la la la [D]laaah {c:(234,1234)} [G/]
{eoc}
 

_______________________________________







	     





