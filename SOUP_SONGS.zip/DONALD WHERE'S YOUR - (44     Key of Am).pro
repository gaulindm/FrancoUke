
{title:DONALD WHERE'S YOUR }
{title:TROOSERS }
{subtitle:(4/4     Key of Am)}
{subtitle:(Neil Grant & Andy Stewart)}
{time:2:29}
{metronome: 182}






{c:INTRO: (Four slow strums)}   

[Am]/     {c:(234)}   [Am]/     {c:(234)}  

[Am]/     {c:(234)}   [Am]/     {c:(234)}

I've [Am]just come down from the Isle of Skye
I’m [G]no very big but I’m awful shy
And the [Am]lassies shout as I walk by
“[G]Donald where’s your [Am]troosers?”

{soc}
Let the [Am]wind blow high, and the wind blow low
[G]Through the streets in my kilt I go
[Am]All the lassies shout “Hello!”
"[G]Donald where’s your [Am]troosers?”   
[Am]/  {c:(234}  [Am]/  {c:(234)} 
{eoc}

[Am]I went to a fancy ball
[G]It was slippery in the hall
[Am]I was afeard that I would fall ‘cause
[G]I had nae on ma [Am]troosers                          

{soc}
Let the [Am]wind blow high, and the wind blow low
[G]Through the streets in my kilt I go
[Am]All the lassies shout “Hello!”
"[G]Donald where’s your [Am]troosers?”   
[Am]/  {c:(234}  [Am]/   {c:(234}
{eoc}

[Am]I went down to London town
To [G]have a little fun in the underground
The [Am]ladies turned their heads around saying
“[G]Donald where’s your [Am]troosers?” 

{soc}
Let the [Am]wind blow high, and the wind blow low
[G]Through the streets in my kilt I go
[Am]All the lassies shout “Hello!”
"[G]Donald where’s your [Am]troosers?”   
[Am]/   {c:(234} [Am]/   {c:(234}
{eoc}

To [Am]wear the kilt is my delight
It [G]is not wrong, I know it's right
The [Am]Highlanders would get a fright
If they [G]saw me in the [Am]troosers             

{soc}
Let the [Am]wind blow high, and the wind blow low
[G]Through the streets in my kilt I go
[Am]All the lassies shout “Hello!”
"[G]Donald where’s your [Am]troosers?”   
[Am]/  {c:(234}  [Am]/  {c:(234}
{eoc}

The [Am]lassies love me, everyone
But [G]they must catch me if they can
You [Am]canna put the breeks on a Highland man 
Saying “[G]Donald where’s your [Am]troosers?”   
         
{c:CHORUS: slow down on last line}
{soc}
Let the [Am]wind blow high, and the wind blow low
[G]Through the streets in my kilt I go
[Am]All the lassies shout “Hello!”
{c:(slow down)}
“[G]Donald where’s your [Am/]troo…[Am/]sers?” 
{eoc}


***************************************









