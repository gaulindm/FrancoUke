

{t:135  SONG FOR THE MIRA  }
{subtitle:(3/4   Key of C)} 
{subtitle:(Allister MacGillivray)}
{time:4:11}
{metronome:130}




 
[C]/ / /    [G7]/ / /     [C]/ / /    / / / 
   
[C]Out on the [C7]Mira on [F]warm after[C]noons
[G7]Old men go [C]fishing with [G7]black line and spoons
And [C]if they catch [C7]nothing they [F]never com[C]plain 
I wish I was [G7]with them a[C]gain
 
As boys in their [C7]boats call to [F]girls on the [C]shore 
[G7]Teasing the [C]ones that they [G7]dearly adore
And [C]into the [C7]evening the [F]courting be[C]gins 
I wish I was [G7]with them a[C]gain [C7]

{c:CHORUS}
{soc}
     [F]Can you imagine a [C]piece of the universe 
     [G7]More fit for princes and [C]kings [C7]
     [F]I’ll trade you ten of your [C]cities 
     For [A7]Marion [D7]Bridge 
     And the pleasure it [G]brings [G7]
{eoc}

[C]Out on the [C7]Mira on [F]soft summer [C]nights 
[G7]Bonfires [C]blaze to the [G7]children’s delight
They [C]dance round the [C7]flames 
Singing [F]songs with their [C]friends 
I wish I was [G7]with them a[C]gain

And over the [C7]ashes the [F]stories are [C]told 
Of [G7]witches and [C]werewolves and [G7]Oak Island gold
[C]Stars on the [C7]river-face [F]sparkle and [C]spin
I wish I was [G7]with them a[C]gain  [C7]

{soc}
     [F]Can you imagine a [C]piece of the universe 
     [G7]More fit for princes and [C]kings [C7]
     [F]I’ll trade you ten of your [C]cities 
     For [A7]Marion [D7]Bridge 
     And the pleasure it [G]brings [G7]
{eoc}

[C]Out on the [C7]Mira the [F]people are [C]kind
They [G7]treat you to [C]home brew and [G7]help you unwind
And [C]if you come [C7]broken they’ll [F]see that you [C]mend 
I wish I was [G7]with them a[C]gain

[C]Now I’ll conc[C7]lude with a [F]wish “You go [C]well” 
[G7]Sweet be your [C]dreams and your [G7]happiness swell
[C]I’ll leave you [C7]here, for my [F]journey be[C]gins 
I’m going to be [G7]with them 

[C]Going to be [G7]with them, 
I’m [C]going to be [G7]with them a[C]gain [C/-(hold)] 

_____________________________________










{define: D7 0 2 0 2 0}