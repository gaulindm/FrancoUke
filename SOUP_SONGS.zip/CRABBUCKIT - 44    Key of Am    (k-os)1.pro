{title: CRABBUCKIT  }
{subtitle:4/4    Key of Am    (k-os)}
{metronome:  178}
{time:3:07}






{c:INTRO:}
[Am]/ /    [G]/ /    [F]/ /    [E7]/ /   
[Am]/ /    [G]/ /    [F]/ /    [E7]/ / 
[Am]/ /    [G]/ /    [F]/ /    [E7]/ / 
[Am]/ /    [G]/ /    [F]/ /    [E7]/ / 

[Am] Took a [G]trip on a [F]bus that I [E7]didn't know
[Am] Met a [G]girl sellin' [F]drinks at the [E7]disco
[Am] Said [G]truth comes [F]back when you [E7]let it go
[Am]Seems [G]complicated 'cause it's [F]really so [E7]simple
[Am] Walkin' [G]down Yonge [F]Street on a [E7]Friday
[Am] Can't [G]follow them [F]gotta do it [E7]my way
[Am] No fast [G]lane [F]still on the [E7]highway
[Am]Movin' in and [G]out, no [F]doubt there's a [E7]brighter way

No [Am]time to get [G]down cause I'm [F]moving [E7]up
No [Am]time to get [G]down cause I'm [F]moving [E7]up
No [Am]time to get [G]down cause I'm [F]moving [E7]up
Aaa[Am]ahhhh  [G]  check out the [F]crabs in the [E7]bucket

No [Am]time to get [G]down cause I'm [F]moving [E7]up
No [Am]time to get [G]down cause I'm [F]moving [E7]up
No [Am]time to get [G]down cause I'm [F]moving [E7]up
Aaa[Am]ahhhh  [G]  check out the [F]crabs in the [E7]bucket

[Am]//  [G]//  [F]//  [E7]//.       [Am]//   [G]//   [F]//   [E7]/

It's like [Am]flies on the [G]windscreen, [F]writing on [E7]walls
[Am]Square biz [G]clones claim they're [F]havin' a [E7]ball
[Am]Foolin' them[G]selves just [F]before last [E7]call
Ticka [Am]ticka toc [G]ticka ticka [F]toc [E7]clock strikes 
[Am]Twelve, [G]clock strikes [F]one [E7]
Smoking [Am]gun put these [G]fools on the [F]run [E7]
I [Am]know it's [G]not that [F]simple [E7] I
[Am]Know it's [G]not that [F]hard [E7]

No [Am]time to get [G]down cause I'm [F]moving [E7]up
No [Am]time to get [G]down cause I'm [F]moving [E7]up
No [Am]time to get [G]down cause I'm [F]moving [E7]up
Aaa[Am]ahhhh  [G]  check out the [F]crabs in the [E7]bucket

No [Am]time to get [G]down cause I'm [F]moving [E7]up
No [Am]time to get [G]down cause I'm [F]moving [E7]up
No [Am]time to get [G]down cause I'm [F]moving [E7]up
Aaa[Am]ahhhh  [G]  check out the [F]crabs in the [E7]bucket

[Am]//  [G]//  [F]//  [E7]//.        [Am]//   [G]//   [F]//   [E7]/

It's a [Am]conniption, [G]fit from the [F]microphone [E7]flit
I take it [Am]higher like a [G]bird on a [F]wire, retire [E7]the fire
I [Am]never [G]cause I'm just [F]moving on [E7]up
Choosin' to [Am]touch the [G]unseen, [F]craving the [E7]clutch
The most [Am]inevita[G]ble legi[F]ble pyro[E7]mania
[Am]Slayin' the devil [G] and sendin' him [F]back to Transyl[E7]vania
[Am]Strangely enough, [G]I evolved that [F]side of the [E7]ghetto
But my [Am]heavy metal [G]will settle the [F]puppets like Ge[E7]petto
[Am]Damn if [G]mirrors were [F]created by [E7]sand
Then I'm [Am]looking in the [G]water for re[F]flections of [E7]man
Under[Am]stand the [G]minds above [F]time when it's [E7]empty
[Am]Emcee, [G]Tragically [F]Hip Ahead by a [E7]Century

No [Am]time to get [G]down cause I'm [F]moving [E7]up
No [Am]time to get [G]down cause I'm [F]moving [E7]up
No [Am]time to get [G]down cause I'm [F]moving [E7]up
Aaa[Am]ahhhh  [G]  check out the [F]crabs in the [E7]bucket
No [Am]time to get [G]down cause I'm [F]moving [E7]up
No [Am]time to get [G]down cause I'm [F]moving [E7]up
No [Am]time to get [G]down cause I'm [F]moving [E7]up
Aaa[Am]ahhhh  [G]  check out the [F]crabs in the [E7]bucket

[Am]//  [G]//  [F]//  [E7]//
[Am]//   [G]//   [F]//   [E7]//
[Am]//  [G]//  [F]//  [E7]//
[Am]//   [G]//   [F]//   [E7]//   [Am]/
