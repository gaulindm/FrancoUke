{title:LET'S TALK DIRTY IN HAWAIIAN}
{subtitle:(John Prine)}
{metronome: 164}
{subtitle: (4/4      Key of F)}
{time: 3:20}








[Bb]/ / / /    [F]/ / / /    [C]/ / / /    [F]/  {c:(tap)}
 
Well [F]I packed a bag and bought myself a ticket
For the land of the tall palm [C7]tree
Aloha Old Milwaukee, Hello Waiki[F]ki
 
I just stepped down from the airplane
When I heard her [Bb]say
Waka waka nuka licka, [F]waka waka nuka licka
[C]Would you like a le[F/]i?  [C7/]eh?

{soc} 
  [F]Let's talk dirty in Hawaiian
  Whisper in my [C7]ear 
  Kicka pooka maka wa wahine
  Are the words I long to [F]hear

  Lay your coconuty on my tiki
  What the hecka mooka mooka [Bb]dear
  Let's talk dirty in Ha[F]waiia[D]n
  Say the [G]words I [C]long to [F]hear  {c:(234)}
 
  [Bb]////    [F]//    [D]//   
  [G]//   [C]//   [F]///   
 {eoc}

It's a [F]ukulele Honolulu sunset
Listen to the grass skirts [C7]sway 
Drinking rum from a pineapple
Out on Honolulu [F]Bay
 
The steel guitars all playing
While she's talking with her [Bb]hands
Gimme gimme oka doka [F]make a wish I wanna polka
[C]Words I under[F/]stand, [C7/]oh yeah
 
{soc} 
  [F]Let's talk dirty in Hawaiian
  Whisper in my [C7]ear 
  Kicka pooka maka wa wahine
  Are the words I long to [F]hear

  Lay your coconuty on my tiki
  What the hecka mooka mooka [Bb]dear
  Let's talk dirty in Ha[F]waiia[D]n
  Say the [G]words I [C]long to [F]hear  {c:(234)}
 
  [Bb]////    [F]//    [D]//   
  [G]//   [C]//   [F]////
{eoc}

I [F]boughta lota junka with my moola
And sent it to the folks back [C7]home
 
I never had the chance to dance the hula
I guess I should have [F]known
 
When you [F]start talking to the sweet wahine
Walking in the pale moon [Bb]light
Oka noka gotta a setta [F]knocka rocka sis boom bocas
[C]Hope I said it [F/]right, [C7/]Hey!
 
{soc}
  [F]Let's talk dirty in Hawaiian
  Whisper in my [C7]ear
  Kicka pooka maka wa wahine
  Are the words I long to [F]hear
  Lay your coconuty on my tiki
  What the hecka mooka mooka [Bb]dear
  Let's talk dirty in Ha[F]waiia[D]n
  Say the [G]words I [C]long to [F]hear {c:(234)} 

  [Bb]Let's talk dirty in Ha[F]waiia[D]n
  Say the [G]words I [C]long to [F]hear{c:(234)} 
  [Bb]////    [F]//    [D]//   
  [G]//   [C]//   [F]/   
{eoc}