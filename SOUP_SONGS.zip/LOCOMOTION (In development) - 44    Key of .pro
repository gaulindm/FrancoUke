{title:LOCOMOTION }
{subtitle:4/4    Key of ?}
{subtitle: (Gerry Goffin & Carole King)}
{metronome: 130 }
{time:3:30 }









[C]Everybody`s doing a [Am]brand new dance now
[C] Come on, baby, [Am]do the Loco-motion
I [C]know you`ll get to like it if you [Am]give it 
a chance now

[C] Come on, baby, [Am]do the Loco-motion
My [F]little baby sister can [Dm]do it with ease
It`s [F]easier than learning your [D7]A-B-C`s
So, [C]come on, come on, 
Do-[G7]oo the Loco-motion with [C]me

{c:CHORUS:}
{soc}
     [C]You gotta swing your hips, now
     [F]come on, baby.. jump [C]up, jump back..
     well now, I [G7]think you`ve got the knack
     ..whoa, whoa..

[C]Now that you can do it [Am]let`s make a chain now.
[C]Come on, baby, [Am]do the Loco-motion.
A [C]chug-a chug-a motion like a [Am]railroad train, now.
[C]Come on, baby, [Am]do the Loco-motion.
[F]Do it nice and easy now, [Dm]don`t lose control.
[F]A little bit of rhythm, and a [D7]lot of soul.
[C]Come on, come on, [G7]do the Loco-motion with [C]me

(INTERLUDE:)


[C]Yeah, yeah, yeah, yeah..[C]move around the floor 
in a [Am]Loco-motion.
[C]Come on, baby, [Am]do the Loco-motion.
[C]Do it holding hands, if [Am]you get the notion.
[C]Come on, baby, [Am]do the Loco-motion
There`s [F]never been a dance that`s so [Dm]easy to do.
It [F]even makes you happy when you`re [D7]feeling blue.
So, [C]come on, come on, [G7]do the Loco-motion with [C]me.

OUTRO:
[C]You gotta swing your hips, now, [F]come on, that's right..
you're doin' f[C]ine...
[C]Mmmmm, mmmmm, baby, jump [F]up, jump back..
you're lookin' [C]good.
[C]Mmmmm, mmmm, mmmm, jump [F]up, jump back...(Fade.

{define: D7 0 2 0 2 0} (check bytown)
