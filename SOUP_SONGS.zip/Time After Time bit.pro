{title:Time After Time bit}
{subtitle:}


If you [G]fall I will catch you I'll [Am]be waiting                                           {c:(I will be waiting)}