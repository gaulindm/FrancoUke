

{title:103 PRICE TAG     }
{subtitle:(4/4      Key of C)}
{subtitle:(Jessie J.)}
{time:4:14}
{metronome:164}

 



[C]/ / / /   / / / /    
[Em]/ / / /   / / / /    
[Am]/ / / /   / / / /   
[F]/ / / /   / / / /    [C]/ / 

Seems like everybody's got a [Em]price
I wonder how they sleep at [Am]night When the sale comes first and the 
[F]Truth comes second
Just stop for a minute and [C]    smile
Why is everybody so [Em]serious 
Acting so damn mys[Am]terious Got shades on your eyes and your 
[F]Heels so high that you 
Can't even have a good [C]    time 
{sob}
  Everybody look to the [Em]left
  Everybody look to the [Am]right    Can you feel that? (yeah)
  We're [F]playing with love tonight
{eob}

{soc}
  It's not about the [C]money, money, money
  We don't need your [Em]money, money, money   We just wanna make the [Am]world dance
  Forget about the [F]price tag
  Ain't about the [C]   (uh) cha-ching, cha-ching
  Ain't about the [Em]      (yeah) ba-bling, ba-bling   Wanna make the [Am]world dance 
  Forget about the [F]price tag 
{eoc}

[C]   We need to take it back in [Em]time
When music made us all u[Am]nite And it wasn't low blows and [F]video hoes
Am I the only one getting [C]   tired
Why is everybody so-[Em]o obsessed? 
Money can't buy us [Am]happiness Can we all slow down and [F]enjoy right now 
Guarantee we'll be feelin' all [C]   right

{sob}
  Everybody look to the [Em]left
  Everybody look to the [Am]right    Can you feel that? (yeah)
  We're [F]playing with love tonight
{eob}

{soc}
  It's not about the [C]money, money, money
  We don't need your [Em]money, money, money   We just wanna make the [Am]world dance
  Forget about the [F]price tag
  Ain't about the [C]   (uh) cha-ching, cha-ching
  Ain't about the [Em]      (yeah) ba-bling, ba-bling   Wanna make the [Am]world dance 
  Forget about the [F]price tag 
{eoc}

[C]La la la-la la-la-la hey!  
[Em]La la la-la la-la-la hey!   
[Am]La la la-la la-la-la hey!   
[F]Price tag  

[C]La la la-la la-la-la hey!  
[Em]La la la-la la-la-la hey!   
[Am]La la la-la la-la-la hey!   
[F]Price tag  

{soc}
  It's not about the [C]money, money, money
  We don't need your [Em]money, money, money   We just wanna make the [Am]world dance
  Forget about the [F]price tag
  Ain't about the [C]   (uh) cha-ching, cha-ching
  Ain't about the [Em]    (yeah) ba-bling, ba-bling   Wanna make the [Am]world dance 
  Forget about the [F]price tag 
{eoc}

[C]/ / / /   / / / /    
[Em]/ / / /   / / / /    
[Am]/ / / /   / / / /   
[F]/ / / /   / / / /    [C]/ 

________________________________

















 