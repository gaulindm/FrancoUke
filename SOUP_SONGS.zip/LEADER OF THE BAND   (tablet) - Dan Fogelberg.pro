{title:LEADER OF THE BAND   }
{subtitle:Dan Fogelberg}
{c:Intro:}

[D]  [G]      [D]  [G]      [D]  [G]      [D]  [G]

[D]  An only child, alone and wild 
a [F#m]cabinet maker's [G]son
His [Em]hands were meant for [Bm]different work 
and his [Em]heart was known to [G]no[A]ne
[D]  He left his home and went his lone 
and [F#m]solitary [G]way 
And he [Em]gave to me a [Bm]gift I know 
I [Em]never [A7]can re[D]pay[G]     
[D]  [G]      [D]  [G]      [D]  [G]

[D]  A quiet man of music 
den[F#m]ied a simpler [G]fate 
He [Em]tried to be a [Bm]soldier once 
but his [Em]music wouldn't [G]wa[A]it
[D]  He earned his love through discipline 
a [F#m]thundering, velvet [G]hand
His [Em]gentle means of [Bm]sculpting souls 
took me [Em]years to [A7]under[D]stand 

[G]  The leader of the [F#m]band is tired 
and his [G]eyes are growing [D]old
But his [Em]blood runs through my [Bm]instrument 
and his [Em]song is in my [C]so[A]ul 
[G]  My life has been a [F#m]poor attempt 
[G]   to imitate the [D]man
I'm [Em]just a living [Bm]legacy 
to the [Em]leader [G]of the [D]band[G]     
[D]    [G]    [D]  [G]    [D]  [G]

[D]  My brothers' lives were different 
for they [F#m]heard another [G]call
[Em]One went to Chi[Bm]cago 
and the [Em]other to St. [G]Pa[A]ul
[D]  And I'm in Colorado 
when I'm [F#m]not in some ho[G]tel
[Em] Living out this l[Bm]ife I've chose 
and [Em]come to [A7]know so [D]well[G]     
[D]  [G]     [D]  [G]    [D]  [G]


[D]  I thank you for the music 
and your [F#m]stories of the [G]road
I [Em]thank you for the [Bm]freedom 
when it [Em]came my time to [G]go [A]
[D]  I thank you for the kindness 
and the [F#m]times when you got [G]tough
And, [Em]Papa, I don't [Bm]think I said 
'I[Em] love you [A7]near e[D]nough

[G]  The leader of the [F#m]band is tired 
and his [G]eyes are growing [D]old
But his [Em]blood runs through my [Bm]instrument 
and his [Em]song is in my [C]so[A]ul 
[G]  My life has been a [F#m]poor attempt,  
[G]   to imitate the [D]man
I'm [Em]just a living [Bm]legacy 
to the [Em]leader [G]of the [D]band 
I [Em]am a living [Bm]legacy 
to the [Em]lea-[Em]der [G]o-[G]f the [D]band [G]        
[D]  [G]    [D]  [G]    [D]  
