{title:THE SHOW   (Lenka)   Key of G}
{time: 4:00}








{c:INTRO:  G  / / / /    D  / / / /   }
{: Em  / / / /    C  / / / /   G  / / / /   / / / /}

[G]I'm just a little bit caught in the middle
[D]Life is a maze and love is a riddle
[Em]I don't know where to go, can't do it a[C]lone                           
I've tried, and I don't know why... [G]{c:(8 plucks on E string)}
 
[G/]   Slow it [D/]down, make it [Em/]stop
Or else my [C/]heart is going to [G]pop
'Cause it's too [D]much, yeah it's a [Em]lot {c:(234)}
To [C]be something I'm [G]↑not, I'm a [D]fool out of [Em]love
'Cause I [C]just can't get e[D]nough... {c:(8)}
 
[G]I'm just a little bit caught in the middle
[D]Life is a maze and love is a riddle
[Em]I don't know where to go, can't do it a[C]lone                           
I've tried, and I don't know why.
[G]I'm just a little girl lost in the moment
[D]I'm so scared but I don't show it
[Em]I can't figure it out, it's bringing me [C]down
I know I've got to let it [D]go... {c:(234,1)}  
and just enjoy the [G]show
 
The sun is [D]hot in the [Em]sky, 
just like a [C]giant spotlight [G]
The people [D]follow the [Em]signs 
and [C]synchronise in [G]↑time 
It's a [D]joke, nobody [Em]knows, 
they've got a [C]ticket to the [D]show {c:(8)}
 
Yeah, [G]I'm just a little bit caught in the middle
[D]Life is a maze and love is a riddle
[Em]I don't know where to go, can't do it a[C]lone
I've tried, and I don't know why
[G]I'm just a little girl lost in the moment
[D]I'm so scared but I don't show it
[Em]I can't figure it out, it's bringing me [C]down
I know I've got to let it [D]↑go...
And just enjoy the [C]↑show-↓ow-↓ow-↓ow- [G]↑ow
And just enjoy the [C]↑show-↓ow-↓ow-↓ow- [G]ow  {c:(8)} 
 
[G]I'm just a little bit caught in the middle
[D]Life is a maze and love is a riddle
[Em]I don't know where to go, can't do it a[C]lone                          
I've tried, and I don't know why.
[G]I'm just a little girl lost in the moment
[D]I'm so scared but I don't show it
[Em]I can't figure it out, it's bringing me [C]down
I know i've got to let it [D]go...
and just enjoy the [G]show
dum dee [D]dum, dum dee [C]dum {c:(234)}  
[D]  and just enjoy the [G]show
Da dum dee [D]dum, dum dee [C]dum {c:(234)}  
[D]  just enjoy the [G]show
I want my money back  [D]  I want my money back
[Em]  I want my money back  [C]   Just enjoy the [G]show
I want my money back, [D]   I want my money back
[Em]   I want my money back, [C]  Just enjoy the [G/]show  
