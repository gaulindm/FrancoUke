{title:I WANNA GROW OLD WITH YOU (harder version)}
{subtitle:tab    4/4     Key of A}
{subtitle:(Adam Sandler)}
{metronome: 100}
{time: 2:30}





[E/]     [Bm/]            [A/]

I wanna [A]make you smile when[Bm]ever you're sad 
[C#m] Carry you around when your arth[Bm]ritis is bad, oh
[A]All I wanna do [E]      is grow [Bm]old with [A]you

I'll get your [A]   medicine when your [Bm]    tummy aches
[C#m] Build you a fire if the [Bm]furnace breaks
Oh [A]it could be so nice  [E]      growing [Bm]old with [A]you  [A7]

I'll [D]miss you kiss you [A]give you my coat when you are cold
[D]need you feed you, [E/]even let you hold the re[Bm/]mote [D/]control
    
So [A]let me do the dishes in our [Bm]       kitchen sink
[C#m] Put you to bed if you've had [Bm]too much to drink
oh [A]I could be the one [E]     who grows [Bm]old with [A]you

I [E/]wanna grow [Bm/]old with [A/]you


{define: C#m 0 6 4 4 4}
{define: E 0 4 4 4 7}

