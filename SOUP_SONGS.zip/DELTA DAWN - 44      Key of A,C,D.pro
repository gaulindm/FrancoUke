{t:DELTA DAWN}
{subtitle: 4/4      Key of C}
{subtitle:Helen Reddy}






[A]Delta Dawn, what`s that
[D]Flower you have [A]on
Could it be a faded rose from days gone [E7]by

And [A]did I hear you [A7]say 
He was [D]meeting you here to[A]day
To [A]take you to his [E7]mansion in the [D]sky.y.y.[A]y

She`s [A]forty-one and her [D]Daddy still calls her [A]Baby
[A]All the folks around [D]Brownsville say she`s [A]crazy
Cause she [D]walks downtown with her [E7]suitcase in her [A]hand
[A]Looking for a my[D]sterious dark haired [A]man

In her [A]younger days they [D]called her Delta [A]Dawn
[A]Prettiest woman [D]you ever laid eyes [A]on
Then a [D]man of low de[E7]gree stood by her [A]side
[A]Promised her he`d [D]take her for his [A]bride


[C]Delta Dawn, what`s that 
[F]Flower you have [C]on 
Could it be a faded rose from days gone [G]by
And [C]did I hear you [C7]say 
He was [F]meeting you here to[C]day
To [C]take you to his [G]mansion in the [F]sky.y.y.[C]y


[D]Delta Dawn, what`s that 
[G]Flower you have [D]on 
Could it be a faded rose from days gone [A]by
And [D]did I hear you [D7]say 
He was [G]meeting you here to[D]day
To [D]take you to his [A]mansion in the [G]sky.y.y.[D/]y


