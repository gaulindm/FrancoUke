{title: I WILL}
{subtitle: 4/4      Key of G}
{subtitle: Beatles}
{metronome:117 }
{time: 2:00}




{c:(very light strum, or pick)}

Who k[G]nows how [Em]long I've l[Am]oved you [D7]     
You k[G]now I l[Em]ove you s[Bm]till 
[G7]Will I [C]wait a [D7]lonely li[Em]fetime [G7]     
If you [C]want me [D7]to I [G//]will   [Em]/ /   [Am7]/ /   [D7]/ /

For [G]if I [Em]ever [Am]saw you  [D7]     
I [G]didn't [Em]catch your [Bm]name  
[G7]But it [C]never [D7]really [Em]mattered  [G7]     
I will [C]always [D7]feel the [G]same [G7]

{c: BRIDGE}
{soc}
[C]Love you for[Bm7]ever [Em]and forever
[Am7]Love you with [D7]all my [G]heart  [G7]
[C]Love you when[Bm7]ever [Em]we're together
[A7]Love you when we're a[D7]part
{eoc}

And [G]when at [Em]last I [Am]find you  [D7]     
Your [G]song will [Em]fill the [Bm]air  
[G7]Sing it [C]loud so [D7]I can [Em]hear you  [G7]     
Make it [C]easy [D7]to be [Em]near you  [G7]
For the [C]things you [D7]do en[Em]dear you [G7]to me
[C]Oh you {c:(full D7)} [D7]know I [D#7]will   {c:(234,123)}
I [G]will {c:(234,}[G7]{c:1234)}

[C]Do do do [D7]do do   [Em]Do do [Bm]do do 
[C]Da da da da  [D7]da da [G/gliss]da…

{define: D7 0 2 0 2 0}