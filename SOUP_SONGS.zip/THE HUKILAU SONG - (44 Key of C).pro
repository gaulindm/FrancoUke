{title: THE HUKILAU SONG}
{subtitle:(4/4 Key of C)}      
{subtitle:(Jack Owens)}
{time: 3:10}
{metronome: 128}








{c:INTRO: }
[C]/ / / /    [A7]/ / / /    
[G7]/ / / /    [C]/ / / 
 
Oh, we’re [C]going, to a hukilau  
A huki, huki, [D7]huki, huki, [G7]hukilau 
Everybody loves a hukilau 
Where the lau lau is the kau kau 
At the [D7]big lu[C]au 

We [A7]throw our nets out into the sea
And [D7]all the ama ama 
Come a-[Cdim]swimmin’ to me 
Oh, we’re [C]going to a [A7]hukilau  
A [G7]huki, huki, huki, huki[C]lau 
 
What a [C]beautiful day for fishing 
The old [D7]Hawaiian [G7]way 
The hukilau nets are swishing 
Down in old [D7]Laie [G7]Bay

{soc} 
Oh, we’re [C]going, to a hukilau  
A huki, huki, [D7]huki, huki, [G7]hukilau 
There’s romance ‘neath Hawaiian skies 
Where the lovely hula hula maidens 
[D7]Roll their [C]eyes
With a [A7]silvery moon shining above 
The [D7]kanes and wahines 
Sing a [Cdim]song about love 
Para[C]dise now at the [A7]hukilau 
A [G7]huki huki, huki huki[C]lau 
 {eoc}

{c:INSTRUMENTAL- NO SINGING}
{soc} 
Oh, we’re [C]going, to a hukilau  
A huki, huki, [D7]huki, huki, [G7]hukilau 
There’s romance ‘neath Hawaiian skies 
Where the lovely hula hula maidens 
[D7]Roll their [C]eyes
With a [A7]silvery moon shining above 
The [D7]kanes and wahines 
Sing a [Cdim]song about love 
Para[C]dise now at the [A7]hukilau 
A [G7]huki huki, huki huki[C]lau 
 {eoc}

{c:RESUME SINGING…}
Oh, we’re [C]going, to a hukilau  
A huki, huki, [D7]huki, huki, [G7]hukilau 
Everybody loves a hukilau
Where the lau lau is the kau kau 
At the [D7]big lu[C]au  

We [A7]throw our nets out into the sea 
And [D7]all the ama ama 
Come a-[Cdim]swimmin’ to me 
Oh, we’re [C]going to a [A7]hukilau  
A [G7]huki, huki, huki... 
[A7]huki, huki, huki...
A [G7]huki, huki, huki huki[C/]lau  [D7/] [C/]


Hukilau: a group fishing method                                 
Lau lau: a pork dish   
Kau kau:    slang for food                                               
Laie Bay: ("Lie-ee-ay Bay.")
Ama ama: ("ah-muh-ah-muh.") a fish  
Kanes: ("Kay-nays")Hawaiian Gods of forests and trees       
Wahines: ("wah-hee-nays")  female surfers

{define: D7 0 2 0 2 0}
{define: Cdim 0 2 3 2 3} 