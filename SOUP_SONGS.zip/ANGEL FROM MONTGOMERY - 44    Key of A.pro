{title:  ANGEL FROM MONTGOMERY}
{subtitle: 4/4    Key of A}
{subtitle: (John Prine)}
{time:3:30}
{metronome:128}



{c:the timing pattern in the INTRO}
{c:is repeated where you see **}


{c:INTRO:}
[A]/ / /     [D]/  {c:(beat)}  [D]/ / /    
[A]/ / /     [D]/  {c:(beat)}  [D]/ / /

[A]  I am an old [D]woman  
[A]  Named after my [D]mother
[A]  My old man is a[D]nother   
**[E7]Child that's grown [A/]old {c:(beat)} {c:(}[A]{c:234)}

[A]  If dreams were [D]thunder   
[A]  And lightening was de[D]sire
[A]  This old house would've [D]burnt down 
**A [E7]long time a[A/]go {c:(beat)} {c:(}[A]{c:234)}

{soc}
   [A]    Make me an [G]angel 
   That [D]flies from Mont[A]gomery
   [A]    Make me a [G]poster 
   Of an [D]old rodeo-o-[A]o

   [A]    Just give me [G]one thing 
   **That [D]I can hold [A/]o-on [A]to 
   [A]    To believe in this [G]living is just a
   **[D]Hard way to [A/]go {c:(beat)} {c:(}[A]{c:234)}
{eoc}

[A]/ / /     [D]/  {c:(beat)}  [D]/ / /    
[A]/ / /     [D]/  {c:(beat)}  [D]/ / /

[A]  When I was a [D]young girl  
[A]  I had me a [D]cowboy
[A]  Wasn't much to [D]look at, just a
**[E7]free ramblin' [A/]man {c:(beat)} {c:(}[A]{c:234)}

[A]  But that was a [D]long time   
[A]  And no matter how [D]I try
[A]  The years just [D]flow by like a
**[E7]Broken-down [A/]dam {c:(beat)} {c:(}[A]{c:234)}

{soc}
   [A]    Make me an [G]angel 
   That [D]flies from Mont[A]gomery
   [A]    Make me a [G]poster 
   Of an [D]old rodeo-o-[A]o

   [A]    Just give me [G]one thing 
   **That [D]I can hold [A/]o-on [A]to    
   [A]    To believe in this [G]living is just a
   **[D]Hard way to [A/]go {c:(beat)} {c:(}[A]{c:234)}
{eoc}

[A]/ / /     [D]/  {c:(beat)}  [D]/ / /    
[A]/ / /     [D]/  {c:(beat)}  [D]/ / /

[A]  There's flies in the [D]kitchen  
[A]  I can hear them a-[D]buzzin' 
[A]  And I ain't done [D]nothin' since I
**[E7]Woke up to[A/]day {c:(beat)} {c:(}[A]{c:234)}  

[A]  How the hell can a [D]person  
[A]   go to work in the [D]morning
[A]  Come home in the [D]evenin' and have
**[E7]Nothin' to [A/]say {c:(beat)} {c:(}[A]{c:234)}

{soc}
   [A]    Make me an [G]angel 
   That [D]flies from Mont[A]gomery
   [A]    Make me a [G]poster 
   Of an [D]old rodeo-o-[A]o

   [A]    Just give me [G]one thing 
   **That [D]I can hold [A/]o-on [A]to    
   [A]    To believe in this [G]living is just a
   **[D]Hard way to [A/]go {c:(beat)} {c:(}[A]{c:234)}
   [A]  To believe in this [G]living is just a
   **[D]Hard way to [A/]go 
{eoc} 
