

{title:PAPERBACK WRITER }
{subtitle:(4/4  Key of C)}
{subtitle:(Paul McCartney and John Lennon)}
{time: 2:30}
{metronome:164}

{c:(}[C/]{c:1234)} 

[C/]Paperback Writer… {c:(hold)}  
                           {c:(Paperback Writer…) }   
 
[G7]/ / / /   / / / /   
[G7]/ / / /   / / /   

Dear [G7]Sir or Madame will you read my book 
It took me years to write will you take a look
It’s based on a novel by a man named Lear 
And I need a job and I wanna be a 
Paperback [C]writer {c:(34,12)}   
Paperback [G7/]wri[G7/]ter… {c:(hold note for 34,123)}

It’s a [G7]dirty story of a dirty man 
And his clinging wife who doesn’t understand
His son is working for the Daily Mail 
It’s a steady job but he wants to be a 
Paperback [C]writer {c:(34,12)}   
Paperback [G7/]wri[G7/]ter… {c:(34,123)}

[C/]Paperback Writer… {c:(hold)}  
                            {c:(Paperback Writer…) } 
[G7]/ / / /   / / / /  
[G7]/ / / /   / / /   

{c:(Add “Frere Jacques”)}
It’s a [G7]thousand pages, give or take a few 
I’ll be writing more in a week or two
I can make it longer if you like the style 
I can change it ‘round and I want to be a 
Paperback [C]writer {c:(34,12)}   
Paperback [G7/]wri[G7/]ter… {c:(34,123)}

If you [G7]really like it you can have the rights 
It could make a million for you overnight
If you must return it you can send it here 
But I need a break and I wanna be a 
Paperback [C]writer  {c:(34,12)}   
Paperback [G7/]wri[G7/]ter… {c:(34,123)}

[C/]Paperback Writer… {c:(hold)}  
                         {c:(Paperback Writer…) }    

[G7]/ / / /   / / / /  
[G7]/ / / /   / / / / 

[G7]Pa…perback wri…ter
                               {c:paperback writer (34,1234)    }
[G7]Pa…perback wri…ter
                               {c:paperback writer (34,1234)    }
[G7]Pa…perback wri…ter
                               {c:paperback writer (34,1234)    }
[G7]Pa…perback wri…ter
                               {c:paperback writer (34,1234)  }
[C/]

_______________________________________









