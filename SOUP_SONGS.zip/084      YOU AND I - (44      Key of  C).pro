


{t:084 YOU AND I  } 
{subtitle:(4/4      Key of  C)}         
{subtitle:(Ingrid Michaelson)}
{time:3:07}
{metronome: 135}         





 
[C]/ / / /    / / / /                               
       
[C]Don't you worry, there my honey
[F]We might not have any money
[Am]But we've got our love to pay the [F]bills   
[C]Maybe I think you're cute and funny
[F]Maybe I wanna do what bunnies 
[Am]do with you, if you know what I [F]mean

{c:CHORUS}
{soc}
Oh, [C]let's get rich and [E7]buy our parents 
[F]homes in the South of [C]France
Let's get rich and give every[E7]body nice 
Sweaters and [F]teach them how to [G]dance
Let's get [C]rich and build a [E7]house on a mountain
Making [F]everybody look like [D7]ants   
From way up [C]there, you and [F]I, [G]you and [C]I
{eoc}

Well [C]you might be a bit confused
And [F]you might be a little bit bruised
But [Am]baby how we spoon like no one [F]else
So [C]I will help you read those books 
If [F]you will soothe my worried looks
And [Am]we will put the lonesome on the [F]shelf

{soc}
Oh, [C]let's get rich and [E7]buy our parents 
[F]homes in the South of [C]France
Let's get rich and give every[E7]body nice 
Sweaters and [F]teach them how to [G]dance
Let's get [C]rich and build a [E7]house on a mountain
Making [F]everybody look like [D7]ants   
From way up [C]there, you and [F]I, [G]you and [C]I

{c:(A capella; stomp, stomp clap)}
Oh, let's get rich and buy our parents 
Homes in the South of France
Let's get rich and give everybody nice 
Sweaters and teach them how to dance
Let's get rich and build a house on a mountain
Making everybody look like ants   
From way up there, you and I, you and I
{eoc}

______________________________________
{define: D7 0 2 0 2 0}
















