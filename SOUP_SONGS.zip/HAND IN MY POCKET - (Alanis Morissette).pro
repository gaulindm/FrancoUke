{title:HAND IN MY POCKET}
{subtitle: 4/4      Key of D}
{subtitle:(Alanis Morissette)}
{time:4:10}
{metronome:  180}

ddD-

[D]/ / / /   / / / /   / / / /   / / / /
 
I'm [D]broke but I'm happy I'm poor but I'm kind
I'm short but I'm healthy yea-eah
I'm high but I'm grounded 
I'm sane but I'm overwhelmed
I'm lost but I'm hopeful baby
 
[D]What it all comes [C]down to     [G]
Is that everything's gonna be [D]fine fine fine
Cause I've got o[C]ne hand in my pocket
And the [G]other one is giving [A]a high five     [D] 
 
I feel [D]drunk but I'm sober 
I'm young and I'm underpaid
I'm tired but I'm working yeah
I care but I'm restless 
I'm here but I'm really gone
I'm wrong and I'm sorry baby 
 
And [D]what it all comes [C]down to      [G]
Is that everything is going to be [D]quite alright
Cause I've got [C]one hand in my pocket
And the [G]other one is flicking [A]a cigarette  [D]   

[D]What it all comes [C]down to...    [G]
Is that I haven't got it all figured [D]out just yet
Cause I've got [C]one hand in my pocket
And the [G]other one is giving [A]a peace sign  [D] 
 
I'm [D]free but I'm focused 
I'm green but I'm wise
I'm hard but I'm friendly baby
I'm sad but I'm laughing 
I'm brave but I'm chickenshit
I'm sick but I'm pretty baby
 
And [D]what it all boils [C]down to    [G]
Is that no one's really got it figured [D]out just yet
But I've got [C]one hand in my pocket
And the [G]other one is playing [A]the piano [D]  
 
And [D]what it all comes [C]down to my friends   yeah   [G]
Is that everything is just  [D]fine fi...ne fi...ne
I've got [C]one hand in my pocket
And the [G]other one is hailing [A]a taxi cab   [D/]

_________________________________
















 
 
