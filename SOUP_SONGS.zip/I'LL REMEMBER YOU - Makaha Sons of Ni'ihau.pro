{title:I'LL REMEMBER YOU}
{subtitle: Makaha Sons of Ni'ihau}
{time:2:57}
{metronome:  }




[G]/ / / /   [G/]

I'll remember [Bm]you  {c:(234)}  
[C]Lo...ng after [D]this  {c:(2,3)}
Endless s[G]ummer is [E7]go...ne    
[Am] I'll be lonely  [Cm]       oh so lonely 
[Am] Living only [D]to remember 
[G]You   [Bm]         [C]     [D]     [G]

I'll remember [Bm]Yo...u {c:(234)}  
[C]Your voice as s[D]oft {c:(2,3)}  as the 
[G]Wa...rm summer [E7]bree...ze 
[Am] Your sweet laughter [Cm]  mornings after 
[Am] Ever after, [D]     I'll remember [G]you {c:(234)}
 
[G7] To your arms somed[C]a...y 
[A7] I'll return to [D]stay, till [D7]then
 
I will re[G]me...mber [Bm]too...  
[C]E...very bright s[D]tar 
We made w[G]ishes u[E7]pon 
[Am] Love me always [Cm]    promise always 
[Am] Oo-oo-oo-oo-[D]oo, you'll remember [G]too 
 
[G7] To your arms somed[C]a...y 
[A7] I'll return to s[D]tay, till [D7]then...
 
I... will... re...[G]member [Bm]too  
[C]Every bright [D]star 
We made [G]wishes u[E7]pon 
[Am] Love me always [Cm]   promise always 
[Am] Oo-oo-oo-oo-[D]oo, you'll remember [G]too 
[D] I'll remember [G]you 
[D] I'll remember [G]you... [Bm]  [C]  [D]  [G/]
