{title:A DAISY A DAY      3/4      G}
{subtitle:(Jud Strunk)}

 
[G]He remembers the first time he [G7]met her
He re-[C]members the first thing she [G]said
He re-[C]members the first time he [G]held her
And the [A7]night that she came to his [D]bed
He re-[G]members her sweet way of [G7]say-in'
[C]Honey has some-thin' gone [G]wrong
He re-[C]members the fun and the [G]teas-in'
And the reason he [D]wrote her this [G]song
 
 
Chorus
 
[G]I'll give you a daisy a [G7]day dear
I'll [C]give you A daisy A [G]day
I'll [C]love you until the [G]rivers run [Em]still
And the [G]four winds we [D]know blow A-[G]way
 
 
They would [G]walk down the street in the [G7]evenin'
And for [C]years I would see them go [G]by
And their [C]love that was more than the [G]clothes that they wore
Could be [A7]seen in the gleam of their [D]eye
As a [G]kid they would take me for [G7]candy
And I'D [C]love to go taggin' A-[G]long
We'd hold [C]hands while we walked to the [G]corner
And the old man would [D]sing her his [G]song
 
 
I'll [G]give you a daisy a [G7]day dear
I'll [C]give you A daisy A [G]day
I'll [C]love you until the [G]rivers run [Em]still
And the [G]four winds we [D]know blow A-[G]way
 
 
Now he [G]walks down the street in the [G7]evenin'
And he [C]stops by the old candy [G]store
And I [C]somehow believe he's be-[G]lievin'
He's [A7]hold-in' her hand like be-[D]fore
For he [G]feels all her love walkin' [G7]with him
And he [C]smiles at the things she might [G]say
Then the [C]old man walks up to the [G]hill-top
And he gives her A [D]daisy A [G]day
 
 
I'll [G]give you a daisy a [G7]day dear
I'll [C]give you A daisy A [G]day
I'll [C]love you until the [G]rivers run [Em]still
And the [G]four winds we [D]know blow A-[G]way    [G/]
