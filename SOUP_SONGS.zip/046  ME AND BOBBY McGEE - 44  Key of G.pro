

{title:046  ME AND BOBBY McGEE }
{subtitle:  4/4  Key of F   }
{subtitle: (Kris Kristofferson)}
{subtitle: (Janis Joplin version)}
{metronome: 176  }
{time:4:31}





[F]/ / / /   / / / /   / / / /   / / / /

[F] Busted flat in Baton Rouge, waitin' for a train 
I was feelin' near as faded as my [C]jeans {c:(234,1234)} 
[C] Bobby thumbed a diesel down, just before it rained
And rode us all the way to New Or[F]leans {c:(234,123)}

I {soh}pulled{eoh} my harpoon out of my dirty red bandana  I was playing soft while [F7]Bobby sang the [Bb]blues
 
Windshield wipers slappin' time 
I was [F]    holdin' Bobby's hand in mine 
[C]We sang every song that driver knew {c:(234,1234)}

{soc}
  [Bb]Freedom's just another word for 
  [F]    Nothin' left to lose 
  [C]Nothin'... ain't worth {soh}nothing{eoh} Honey 
  If it ain't [F]free {c:(34,123)}
  Yeah [Bb]feelin' good was easy Lord 
  [F]    When he sang the blues 
  [C]Feeling good was good enough for me 
  
  {c:(234,1234)}
  
  Good enough for me and my Bobby 
  Mc[F]Gee  {c:(234,1234)}
 {eoc}

{c:(Key Change)}   [G]/ / / /    / / / /
 
From the [G]Kentucky coal mines
To the California sun 
Bobby shared the secrets of my [D]soul 
{c:(234,1234)}

{soh}Through{eoh} all kinds of weather
Through {soh}every{eoh}thing we done  {c:(234)}
Yeah, Bobby baby, kept me from the [G]cold 
{c:(234,123)}

One day up near Salinas {soh}Lord{eoh}
I let him slip away 
He's lookin' for that [G7]home 
And I hope he [C]finds it {c:(34,123)} 
But I'd {soh}trade{eoh} all my tomorrows for one 
[G]Single yesterday 
To be [D]holdin' Bobby's body next to mine {c:(234,1234)} 

{soc} 
  [C]Freedom's just another word for 
  [G]    Nothin' left to lose
  [D]Nothin', and that's ↑all that Bobby le..ft [G]me, yeah 
  [C]Feelin' good was easy Lord
  [G]    When he sang the blues 
  [D]Feelin' good was good enough for me, mmm-hmm 
  Good enough for me and my Bobby Mc[G]Gee 
 
  {c:(234,123)}  
{eoc}

La-la-la {c:(23)} la-la-la-la {c:(beat)} 
La-la-laa  la-la-la-la {c:(234,1)}
La-la-la-la-la-la-la-la 
Bobby Mc[D]Gee {c:(234)} yeah {c:(234)} 
     
Laa  la-la-la-la-la {c:(34,1)} la-la-la-la-la {c:(234)}
Laa  la-la-la-la-la Bobby Mc[G]Gee {c:(234)} yeah {c:(23)}     

La-la-LA, LA-la-la LA-la-la LA-la-la,  {c:(12)}   

la-la-la la-la-la LA-la-LA {c:(12)}

Hey now Bobby now my Bobby Mc[D]Gee, yeah {c:(12)}

La-na-NA-na-na-NA-na-na, {c:(12)} 
 
Na-na-NA-na-na-NA-na-na-
NA-na-na-NA-na-na {c:(12)}
Hey now Bobby now my Bobby Mc[G]Gee, yeah {c:(123)}

{soc}
  Oh well I call him my lover, call him my man    I said I call him my lover 
  Did the best I can, come on
  {c:(beat)} Hey now Bobby now
  Hey now Bobby Mc[D]Gee, yeah
   Oh a Lord, a Lord, a Lord, a Lord
  A Lord, a Lord, a Lo...rd {c:(34)}
  Hey! hey! hey! Bobby Mc[G/]Gee-ee yeah... 
{eoc}
_____________________________________











{define:  F7 0 2 3 1 0 }

