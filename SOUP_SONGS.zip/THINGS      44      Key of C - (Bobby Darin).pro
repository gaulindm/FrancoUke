{title:THINGS }
{subtitle:     4/4      Key of C}
{subtitle:(Bobby Darin)}
{metronome:160 }
{time:3:00 }


Men sing melody, {c:women in italics}





{c:INTRO:}   [C]/ / / /   / / / /

[C]Every night I sit here by my window {c:(window)}
Starin' at the lonely aven[G]ue {c:(avenue)}
[C]Watchin' lovers holdin' hands and [F]laughin' 
{c:(Ooo...                                                       ...laughin'  )}
And [G]thinkin' 'bout the things we used to [C]do  [C/]
 
{soc}
{c:(Thinkin' of }[G7]{c:things)} like a walk in the park
{c:(}[C]{c:Things)} like a kiss in the dark 
{c:(}[G]{c:Things)} like a sailboat ride {c:(yeah,} [C/]{c:yeah)}

What about the night we cried
[F]Things, like a lovers vow [C]things, that we don't do now
{c:(things, ooo...                   things, ooo...                     )}
[G]Thinkin' 'bout the things we used to [C]do
{c:Ooo...                                                }
{eoc} 

[C]Memories are all I have to cling to {c:(cling to)}
And heartaches are the friends I'm talkin' [G]to {c:(talkin' to)}
When [C]I'm not thinkin' of just how much I [F]love you 
          {c:(Ooo...                                                           ...love you)}
Well, I'm [C]thinkin' 'bout the [G]things we used to [C]do  [C/]

{soc}
{c:(Thinkin' of }[G7]{c:things)} like a walk in the park
{c:(}[C]{c:Things)} like a kiss in the dark 
{c:(}[G]{c:Things)} like a sailboat ride {c:(yeah,} [C/]{c:yeah)}

What about the night we cried
[F]Things, like a lovers vow, [C]things that we don't do now
{c:(things, ooo...                   things, ooo...                     )}
[G]Thinkin' 'bout the things we used to [C]do
{c:Ooo...                                                }
{eoc} 

I [C]still can hear the jukebox softly playin' {c:(playin')}
And the {soh}face{eoh} I see each day belongs to [G]you {c:(belongs to you)}
Though there's [C]not a single sound
                           {c:Ooo...                  }
And there's no[F]body else around  {c:(23)}
                         {c:Ooo...                                      }
Well, it's a [G]just me thinkin' 'bout the things we used to [C]do    [C/]

{soc}
{c:(Thinkin' of }[G7]{c:things)} like a walk in the park
{c:(}[C]{c:Things)} like a kiss in the dark 
{c:(}[G]{c:Things)} like a sailboat ride {c:(yeah,} [C/]{c:yeah)}

What about the night we cried
[F]Things, like a lovers vow, [C]things that we don't do now
{c:(things, ooo...                  things, ooo...                     )}
[G]Thinkin' 'bout the things we used to [C]do
{c:Ooo...                                                }
{eoc} 

And the [G]heartaches are the friends I'm talkin' [C]to
               {c:Ooo...                        }
You got me [G]thinkin' 'bout the things we used to [C]do...{c:(}[C/]{c:things!)}
                     {c:Ooo...                           }
                                              