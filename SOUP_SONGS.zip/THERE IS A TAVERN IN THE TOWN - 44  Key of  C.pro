
{title:THERE IS A TAVERN IN THE TOWN  }
{subtitle: 4/4  Key of  C  }
{time:3:37}
{metronome: 200 }




[G7]/ / / /   / / / /    
[C]/ / / /   / / /         

There [C]is a tavern in the town 
(in the town)
And there my true love sits him [G7]down 
Sits him do-o-own
And [C]drinks his [C7]wine as [F]merry as can be
And [G7]never, never, thinks of [C]me

{soc}
  Fare thee [G7]well, for I must leave thee
  do not [C]let this parting grieve thee
  And re[G7]member that the best of friends 
  must [C/]part, [F/]must [C/]part
  A[C]dieu, adieu kind friends, adieu 
  (yes adieu) 
  I can no longer stay with [G7]you 
  stay with you-oo-oo
  l'll [C]hang my [C7]harp 
  on a [F]weeping willow tree
  And [G7]may the world go well with [C]thee 
{eoc}

He [C]left me for a damsel dark 
(damsel dark)
Each Friday night they used to [G7]spark 
Used to spa-a-ark
And [C]now my [C7]love who [F]once was true to me  
[G7]takes that dark damsel on his [C]knee                          

{soc}
  Fare thee [G7]well, for I must leave thee
  do not [C]let this parting grieve thee
  And re[G7]member that the best of friends 
  must [C/]part, [F/]must [C/]part
  A[C]dieu, adieu kind friends, adieu 
 (yes adieu) 
  I can no longer stay with [G7]you 
  stay with you-oo-oo
  l'll [C]hang my [C7]harp 
  on a [F]weeping willow tree
  And [G7]may the world go well with [C]thee 
{eoc}
  
And [C]now I see him never more 
(never more)
He never knocks upon my [G7]door 
on my do-o-or
Oh, [C]woe is [C7]me, he [F]penned a little note
And [G7]these were all the words he [C]wrote                      

{soc}
  Fare thee [G7]well, for I must leave thee
  do not [C]let this parting grieve thee
  And re[G7]member that the best of friends 
  must [C/]part, [F/]must [C/]part
  A[C]dieu, adieu kind friends, adieu 
  (yes adieu) 
  I can no longer stay with [G7]you 
  stay with you-oo-oo
  l'll [C]hang my [C7]harp 
  on a [F]weeping willow tree
  And [G7]may the world go well with [C]thee 
{eoc}

Oh [C]dig my grave both wide and deep 
(Wide and deep)
Put tombstones at my head and [G7]feet
Head and fe-e-et
And [C]on my [C7]breast please 
[F]carve a turtle dove
To [G7]signify l died for [C]love                                             
{soc}
  Fare thee [G7]well, for I must leave thee
  do not [C]let this parting grieve thee
  And re[G7]member that the best of friends 
  must [C/]part, [F/]must [C/]part
  A[C]dieu, adieu kind friends, adieu 
  (yes adieu) 
  I can no longer stay with [G7]you 
  stay with you-oo-oo
  l'll [C]hang my [C7]harp 
  on a [F]weeping willow tree
  And [G7]may the world go well with [C/]thee [G7/]         [C/]
{eoc}

