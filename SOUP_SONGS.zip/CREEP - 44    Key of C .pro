{title:CREEP}
{subtitle: 4/4    Key of C
{subtitle:Thom Yorke  (Radiohead)}
{time:4:00}
{metronome:86  }




[C] / / / /
[E7] / / / /
[F]/ / / /
[Fm]/    {c:(stop for 1 beat)}

When you were here before    [C]
Couldn't look you in the [E7]eyes
You're just like an an[F]gel 
Your skin makes me [Fm]cry

You float like a fea[C]ther   
in a beautiful wor[E7]ld
I wish I was [F]special
You're so very [Fm]special

{soc}
But I'm a creep [C]
I'm a wie[E7]rdo
What the hell am I doin' [F]here
I don't belo[Fm]ng here
{eoc}

I don't care if it hurts [C]
I wanna have con[E7]trol
I want a perfect [F]body 
I want a perfect [Fm]soul
I want you to no[C]tice  
When I'm not a[E7]round
So very [F]special
I wish I was [Fm]special

{soc}
But I'm a creep [C]
I'm a wie[E7]rdo  
What the hell am I doin' [F]here   
I don't be[Fm]long here
{eoc}

[C]Shes running out the 
[E7]door
[F]Shes running out she’s 
[Fm]run....run, run...

[C]Ooh
[E7]Ooh
[F]Run
[Fm]Run

Whatever makes you hap[C]py 
whatever you [E7]want
You're so very [F]special 
Wish I was [Fm]special

{soc}
But I'm a creep  [C]
I'm a wie[E7]rdo  
What the hell am I doin' [F]here  
I don't be[Fm]long here
No I dont be[C/]long here 
{eoc}

