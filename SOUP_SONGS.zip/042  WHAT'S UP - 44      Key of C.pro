{title:042  WHAT'S UP     }
{subtitle: 4/4      Key of C}
{subtitle:Linda Perry (4 Non Blondes)}
{time:4:49}
{metronome: 136 }
 





[C]/ / / /   / / / /    
[Dm]/ / / /   / / / /    
[F]/ / / /   / / / /   
[C]/ / / /   / / / /

[C] Twenty-five years and my life is still 
[Dm]trying to get up that great big hill
Of [F]hope  {c:(234,1)}  for a desti[C]nation {c:(34,1234)}
I [C]realized quickly when I knew I should 
that the [Dm]world was made up of this 
Brotherhood of [F]man, {c:(234,1)}  
For whatever that me[C]ans {c:(234,123)}
 
And so I [C]cry sometimes when I'm lying in bed
Just to [Dm]get it all out
What's in my head, and I
[F] I am feeling {c:(4,12)} a little pe[C]culiar {c:(34,123)}
And so I [C]wake up in the morning and I 
Step outside and I [Dm]take a deep breath 
And I get real high and I
[F]  scream from the top of my lungs 
"What's going [C]on?" {c:(234,1)}
 
{c:CHORUS}
{soc}
  And I said "[C]Hey yeah yeah ey-ey 
  [Dm]Hey yeah yeah"
  I said "[F]Hey, what's going [C]on?"  
  And I said "[C]Hey yeah yeah ey-ey 
  [Dm]Hey yeah yeah"
  I said "[F]Hey, what's going [C]on?" {c:(234,1234)}
{eoc}
 
{c:(With "Ooo's")}
[C]/ / / /   / / / /    
[Dm]/ / / /   / / / /    
[F]/ / / /   / / / /   
[C]/ / / /   / / / 

And I [C]try {c:(234)} oh my God do I [Dm]try {c:(234)}
I try all the [F]time {c:(234,1)} 
In this insti[C]tution {c:(34,123)}

And I [C]pray {c:(234)} oh my God do I [Dm]pray {c:(234)}
I PRAY EVERY SINGLE [F]DAY {c:(234,1)} 
FOR A REVO[C]LUTION {c:(4,123)}

And so I [C]cry sometimes when I'm lying in bed 
Just to [Dm]get it all out
What's in my head and I  
[F]  I am feeling {c:(234)} a little pe[C]culiar 
And so I [C]wake up in the morning 
And I step outside and I [Dm]take a deep breath 
And I get real high and I
[F]  Scream from the top of my lungs 
"WHAT'S GOING [C]O-ON?" {c:(34,1)}

{soc}
 And I said "[C]Hey yeah yeah ey-ey 
 [Dm]Hey yeah yeah"
 I said "[F]Hey, what's going [C]on?" {c:(234,1)}
 And I said "[C]Hey yeah yeah ey-ey 
 [Dm]Hey yeah yeah"
 I said "[F]Hey, WHAT'S GOING [C]ON?"  {c:(234,1)}
 
 And I said "[C]Hey yeah yeah ey-ey [Dm]Hey yeah yeah",    
{c:               (I wake up in the...         take a deep breath...)}         
 I said "[F]Hey,     what's going [C]on?" 
{c: And I  - - - - -    what's going on?... )}  
 And I said "[C]Hey yeah yeah ey-ey [Dm]Hey yeah yeah",    
{c:               (I wake up in the...        take a deep breath...)}          
 I said "[F]Hey,       what's going [C]on?"    {c:(234)} 
{c: And I   - - - -       what's going on?... )}

{c:(slowly)}  [C]/ / / /    
{eoc}

{c:(Slowly)} 
[C/]  Twenty-five years and my [C/]life is still 
[Dm/]Trying to get up that [Dm/]great big hill 
of [F/]hope {c:(234)}    [F/]      for a desti[C/]nation

_______________________________________________









