{title:  WITCH DOCTOR }
{subtitle:4/4   Key of C}
{subtitle: (Thomas Kerry)}
{metronome:200 }
{time:2:46}

{c:TAB #1}
{sot}
A| - 0 2 3 - 
E| - - - - - 
C| - - - - - 
G| 0 - - - - 
{eot}
{c:TAB #2}
{sot}
A| - 0 - 2 - 
E| - - - - - 
C| - - - - - 
G| 0 - 0 - - 
{eot}

{c:(Tab #1)} 
I told the witch doctor I was in love with you
{c:(Tab #1)}
I told the witch doctor I was in love with you
{c:(Tab #2)}
And then the witch doctor 
He [C/]told me what to do, he said that ....

{c:CHORUS:}
{soc}
[C]Ooo eee, [F]ooo ah ah 
[C]Ting tang [G]walla walla, bing bang
[C] Ooo eee, [F]ooo ah ah 
Ting [G]tang walla walla, bing [C]bang 
[C]Ooo eee, [F]ooo ah ah 
[C]Ting tang [G]walla walla, bing bang
[C] Ooo eee, [F]ooo ah ah 
Ting [G]tang walla walla, bing [C/]bang 
{eoc}

{c:(Tab #1)} 
I told the witch doctor you didn't love me true
{c:(Tab #1)}
I told the witch doctor you didn't love me nice
{c:(Tab #2)}
And then the witch doctor
He [C/]gave me this advice
He said that ....

{soc}
[C]Ooo eee, [F]ooo ah ah 
[C]Ting tang [G]walla walla, bing bang
[C] Ooo eee, [F]ooo ah ah 
Ting [G]tang walla walla, bing [C]bang 
[C]Ooo eee, [F]ooo ah ah 
[C]Ting tang [G]walla walla, bing bang
[C] Ooo eee, [F]ooo ah ah 
Ting [G]tang walla walla, bing [C/]bang 
{eoc}

Now [F]you've been keeping love from me
Just [C]like you were a miser
And [F]I’ll admit I wasn't very [C]smart
So [F]I went out and found myself
A [C]guy that's so much wiser                                                
And [D7]he taught me the way to win your [G]heart [G/]

{c:(Tab #1)} 
My friend the witch doctor he taught me what to say
{c:(Tab #1)}
My friend the witch doctor he taught me what to do
{c:(Tab #2)}
I know that you'll be mine when 
[C/]I say this to [C/]you, Oh Baby

{soc}
[C]Ooo eee, [F]ooo ah ah 
[C]Ting tang [G]walla walla, bing bang
[C] Ooo eee, [F]ooo ah ah 
Ting [G]tang walla walla, bing [C]bang 
[C]Ooo eee, [F]ooo ah ah 
[C]Ting tang [G]walla walla, bing bang
[C] Ooo eee, [F]ooo ah ah 
Ting [G]tang walla walla, bing [C/]bang [G/] [C/]
{eoc}

{define: D7 0 2 0 2 0}