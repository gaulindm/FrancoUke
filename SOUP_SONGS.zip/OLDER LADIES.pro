{t: OLDER LADIES   }
{subtitle:4/4     Key of C}
{subtitle: Donnalou Stevens}
{metronome:190}
{time:3:11}









{c:INTRO:}
[G7]/ / / /   / / / /    [D7]/ /    [G7]/ /    [C]/ / /  

Well I [C]ain't sixteen, not a beauty queen
And my [G]eyes are baggin' and my skin is saggin'           
And if [G7]that's the reason that you don't love me
Then [D7]maybe [G7]that's not [C]love  {c:(234,123)}

Well I [C]ain't twenty either And I don't care neither
And my [G]hair is gray and I like it that way                           
And if [G7]that's the reason that you don't love me
Then [D7]maybe [G7]that's not [C]love  {c:(234,123)}

{soc}
     If [F]you don't think I rock, 
     well [C]we ain't gonna roll
     If [D]you don't think I hung the moon,
     my [G/]hot just turned to cold  [G7//]
     If you [C]want a younger model, 
     I [F]wish you well sweet pea
     Cause if [G]you can't see what it is you have
     then [G7]you ain't havin’  [C]me  
     {c:(234,1234, 1234, 123)}
{eoc}
 
I got [C]cellulite and my butts not tight
And my [G]thighs kinda jiggle 
When I giggle and wiggle          
And if [G7]that's the reason that you don't love me
Then [D7]maybe [G7]that's not [C]love {c:(234,1234)}

My [C]tummy ain't tucked or lyposucked
[G]It's a little poochie 
But it's still hoochie koochie              
And if [G7]that's the reason that you don't love me 
Then [D7]maybe [G7]that's not [C]love {c:(234,123)}

{soc}
     See [F]I'm no longer desperate
     I'll [C]only have a man
     [D]If he has the smarts to see 
     how [G/]HOT that I still am!  [G7//]
     If you [C]want a younger model
     I [F]wish you well sweet pea
     Cause if [G]you can't see what it is you have
     then [G7]you ain't havin' [C]me {c:(234,12)}
{eoc}

{soc}
     Older ladies, older [F]ladies, 
     older [G]ladies are di[C]vi -i -i -i -ine 
     {c:(234,1234,123)}
{eoc}

I gotta a [C]chicken neck and I love it by heck
It [G]makes a double chin whenever I grin                       
And if [G7]that's the reason that you don't love me
Then [D7]maybe [G7]that's not [C]love {c:(234,1234)}

[C]Certain parts are now quite droopy
And [G]menopause has made me loopy                                
But if [G7]that's the reason that you don't love me
Then [D7]maybe [G7]that's not [C]love  {c:(234,123)}

If [F]you don't think I rock
well, [C]we ain't gonna roll
If [D]you don't think I hung the moon, 
my [G/]hot just turned to cold   [G7//]
If you [C]want a younger model
I [F]wish you well sweet pea
Cause if [G]you can't see what it is you got
[G7]you ain't gettin' [C]me {c:(234,12)}

Older ladies, older [F]ladies
older [G]ladies, are di[C]vi -i -i -i -ine!
Older ladies, older [F]ladies
older [G/]la[G/]dies, ("what are we ladies?")
...We're di[C]vi -i -i -i
-i -i -i -i,   -i -i -i -i -[C/]ine!

{define: D7 0 2 0 2 0}
