

{title: C27: DECK THE HALLS}
{subtitle:    Key of G       4/4}
{metronome{   }
{time:1:56}


{c:INTRO:}
[D7]/ / / /    / / / /     
[G]/ / / /    / / / /


[G]Deck the halls with boughs of holly  
[C]Fa-la-la-la-[G]la, la-[D7]la  la-[G]la 
[G]'Tis the season to be jolly 
[C]Fa-la-la-la-[G]la, la-[D7]la  la-[G]la 
[D]Don we now our [G]gay apparel  
Fa-la-la, [Em]la-la-la, [A7]la-la-[D7]la 
[G]Troll the ancient Yule-tide carol 
[C]Fa-la-la-la-[G]la, la-[D7]la  la-[G]la {c:(234, 1234)}


[G]See the blazing Yule before us 
[C]Fa-la-la-la-[G]la, la-[D7]la  la-[G]la 
[G]Strike the harp and join the chorus 
[C]Fa-la-la-la-[G]la, la-[D7]la  la-[G]la
[D]Follow me in [G]merry measure  
Fa-la-la, [Em]la-la-la, [A7]la-la-[D7]la 
[G]While I tell of Yule-tide treasure 
[C]Fa-la-la-la-[G]la, la-[D7]la  la-[G]la {c:(234,1234)}


[G]Fast away the old year passes 
[C]Fa-la-la-la-[G]la, la-[D7]la  la-[G]la 
[G]Hail the new year, lads and lasses 
[C]Fa-la-la-la-[G]la, la-[D7]la  la-[G]la
[D]Sing we joyous, [G]all together  
Fa-la-la, [Em]la-la-la, [A7]la-la-[D7]la 
[G]Heedless of the wind and weather  
{c:(slowly)} [C]Fa-la-la-la-[G]la, la-[D7]la   la-[G/]la 



















 
