{title:NEVER GIVE IT UP}
{subtitle:Privateers}
{subtitle:(4/4     Key of Am)}

[A]/ / / /    / / / / 

[Am]Went from Manit[F]oba, down to Otta[C]wa
[G]On my way to Moncton J’suis passé à Mont[Am]réal
I [Am]love Prince Edward [F]Island, where it all be[C]gan
[G]Iqaluit is calling I’ll be going back a[Am]gain
 
{soc}
  [Am]Oh Oh [F]Oh, Oh Oh [C]Oh, Oh Oh [G]Oh
  Oh Cana[Am]da!
 
  [Am]Oh Oh [F]Oh, Oh Oh [C]Oh, Oh Oh [G]Oh
  Oh Cana[Am]da!
 {eoc}

[Am]On to Nova Sc[F]otia
The true land of the [C]free
[G]In St. John's Newfoundland  
they’ve always been so good to[Am]me
[Am]I went out to Alb[F]erta 
through Saskatche[C]wan
[G]The land of living skies
can’t be bought by any[Am]one!!!
 
{soc}
  [Am]Oh Oh [F]Oh, Oh Oh [C]Oh, Oh Oh [G]Oh
  Oh Cana[Am]da!
 
  [Am]Oh Oh [F]Oh, Oh Oh [C]Oh, Oh Oh [G]Oh
  Oh Cana[Am]da!
{eoc}

[Am]Foothills of the [F]Yukon
beautiful B[C].C.
[G]Where mountains meet the ocean
with a thousand shades of [Am]green
[Am]Northwest Terri[F]tories
crown jewel way up [C]top
[G]We got what they’re looking for
but we’ll never give it [Am]up!!!!
 
{soc}
  [Am]Oh Oh [F]Oh, Oh Oh [C]Oh, Oh Oh [G]Oh
  Oh Cana[Am]da!
 
  [Am]Oh Oh [F]Oh, Oh Oh [C]Oh, Oh Oh [G]Oh
  Oh Cana[Am]da!
 
  [Am]Am [F]F [C]C [G]G [Am]Am
 
  [Am]Oh Oh O[F]h, Oh Oh [C]Oh, Oh Oh [G]Oh
  Oh Cana[Am]da!
 
  [Am]Oh Oh O[F]h, Oh Oh [C]Oh, Oh Oh [G]Oh
  Oh Cana[Am]da!
{eoc}

____________________________

















