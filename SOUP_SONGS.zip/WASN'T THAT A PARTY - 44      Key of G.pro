{t:WASN'T THAT A PARTY  }
{subtitle:    4/4      Key of G   }
{time: 3:00 }
{metronome: 168  }






[G]/ / / /   / /       

{soc}        
  Coulda been the [G]whiskey
  Mighta been the gin
  Coulda been the three or four six-packs
  I don’t know, but [G7]look at the mess I’m in 
  My head is  like a [C]football 
  I think I’m gonna [G]die
  Tell me, [D7]me, oh, me oh [D7/]my...  
  Wasn’t that a [G]party {c:(34,12)}
{eoc}

Someone took a [G]grapefruit
Wore it like a hat  
I saw someone under my kitchen table
[G7]Talking to my old tom cat 
They were talkin bout [C]hockey 
And the cat was talkin [G]back  
Long about [D7]then everything went [D7/]black...     
But wasn’t that a [G]party {c:(34)}

[G7]   Maybe just my [C]memory 
Playin tricks on [G]me 
But I [A]think I saw my buddy 
Cutting down my neighbour’s [D7/]tree

{soc}        
  Coulda been the [G]whiskey
  Mighta been the gin
  Coulda been the three or four six-packs
  I don’t know, but [G7]look at the mess I’m in 
  My head is  like a [C]football 
  I think I’m gonna [G]die
  Tell me, [D7]me, oh, me oh [D7/]my...  
  Wasn’t that a [G]party {c:(34)}
{eoc}

[G7]  Old Billy Joe and [C]Tommy
Well they went a little [G]far
They were [A]sitting in the back seat 
Blowin on the siren in 
Somebody’s police [D7/]car

So, you see, your [G]honour 
It was all in fun
That little bitty track meet down on main street 
Was just to [G7]see if the cops could run  
Well they run us in to [C]see you 
In an alcoholic [G]haze
I sure could [D7]use those forty days 
To recover from the [G////]party   [A/] 
{c:CHORUS- up one key}
{soc}        
  Coulda been the [A]whiskey 
  Mighta been the gin
  Coulda been the three or four six-packs 
  I don’t know but [A7]look at the mess I’m in 
  My head is  like a [D]football 
  I think I’m gonna [A]die
  Tell me, [E7]me, oh, me oh [E7/]my...    
  Wasn’t that a [A]party  {c:(34,12)}
{eoc}

[E7]Wasn't that a [A]party  {c:(34,12)} 
[E7]Wasn't that a [A]party  {c:(34,12)} 
[E7]Wasn't that a [A]party  {c:(34,12)}  
[E7]wasn't that a [A]party  {c:(34)}  [A/]      [E7/]   [A/]