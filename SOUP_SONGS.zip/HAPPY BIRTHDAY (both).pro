{title:HAPPY BIRTHDAY (both) }
{subtitle:tab    4/4    Key of C, G  }
{subtitle:(Patty & Mildred Hill)}
{metronome: 128}
{time:2:30}




Happy [C]Birthday to [G]you, happy Birthday to [C]you
Happy Birthday, Dear   [G]____  [F]_____   
Happy [C]Birthday [G/]to [C/]you!   And many [C7]more…..

{t:Happy Birthday #2}

{c:INTRO: D7 / / / /    G / / /}
We’ve got that [G]birthday fever birthday fever                     
                       {c:(birth… day    fe… ver)}
Down in our hearts {c:(where?)} 
[D7]Down in our hearts {c:(where?)}   [G]Down in our hearts

We’ve got that [G]birthday fever birthday fever 
                       {c:(birth…  day   fe…       ver)}
Down in our hearts {c:(where?)}
[D7]Down in our hearts to [G]stay 

‘Cause it’s your [C]birthday, yes it’s your [G]birthday
[D7]Age is just a number you are [G/]loo[C/]king [G/]good!
Oh it’s your [C]birthday, yes it’s your [G]birthday, we 
[D7]Sing happy birthday to [G/]you!  [C/]  [G/]

We’ve got that [G]birthday fever birthday fever 
                       {c:(birth…  day   fe… ver)}
Down in our hearts {c:(where?)} 
[D7]Down in our hearts {c:(where?)}   [G]Down in our hearts

We’ve got that [G]birthday fever birthday fever 
                       {c:(birth…  day   fe…       ver)}
Down in our hearts {c:(where?)}
[D7]Down in our hearts to [G/]stay [C/]   [G/]  