{title: A SUMMER SONG}
{subtitle: (4/4 Key of G)}
{subtitle: (Chad and Jeremy)}
{metronome: 124}
{time: 2:33}

[G]/ /   [Bm]/ /   [C]/ /   [D]/ / 
[G]/ /   [Bm]/ /   [C]/ /   [D]/ /


[G] Trees. .[Bm] .  [C]  [D]   swayin' in the [G]summer [Bm]breeze  [C]
[D] Showin' off their [G]silver [Bm]leaves,[C] as [D]we walked [G]by
[Bm] Soft. .[C] . [D]  kisses on a [G]summer's [Bm]day  [C]
[D] Laughing all our [G]cares a-[Bm]way[C], just [D]you and [G]I  [Bm]   [C]  [D]

[G] Sweet. .[Bm] .  [C]  [D]  sleepy warmth of [G]summer [Bm]nights [C]
[D] Gazing at the [G]distant [Bm]lights,[C] in the [D]starry [G]sky [Bb]   [C]  [G]


[C] They say that [D]all good things must [G]end some [Em]day
[Am] Autumn [D]leaves must [Em]fall
But [G]don't you know that it [B7]hurts me so, to [Em]say goodbye to [Bm]you? [Am]
[Em] Wish you didn't have to [D]go, [Em]no, no, no, [D]no


And when the [G]rain. .[Bm] .  [C]   [D]  beats against my [G]window [Bm]pane [C]
I'll [D]think of summer [G]days a-g[Bm]ain, [C]and [D]dream of you [(G)]


[G]/ /   [Bm]/ /   [C]/ /   [D]/ /
[G]/ /   [Bb]/ /   [C]/ /   [G]/ /


[C] They say that [D]all good things must [G]end some [Em]day
[Am] Autumn [D]leaves must [Em]fall
But [G]don't you know that it [B7]hurts me so, to [Em]say goodbye to [Bm]you?  [Am]
[Em] Wish you didn't have to [D]go, [Em]no, no, no, [D]no


And when the [G]rain..[Bm]  [C]  [D]   beats against my [G]window [Bm]pane [C]
I'll [D]think of summer [G]days a-[Bm]gain,[C] and [D]dream of [G]you [Bm]   [C]
And [D]dream of [G]you [Bm]  [C]  [D]  [E/]