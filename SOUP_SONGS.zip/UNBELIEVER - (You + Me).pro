{title:UNBELIEVER}
{subtitle:(You + Me) }
{subtitle:(Alecia Moore & Dallas Green)}
{subtitle: 4/4     Key of A}
{time:4:02}




[A]/ / / /   / /    [D]/ /
[A]/ / / /   / /    [D]/ /
[A]/ / / /   / /    [D]/ /
[A]/ / / /   / / /

I've been [A]wandering through this there [D]city
With the [E7]devil's voice inside my [A]head
And the [A]streets they're all, bereft of [D]fortune
And the [E7]sky is painted blood da[A]rk  red

But I [Bm]keep hanging o-[D]o-o-on
I [Bm]keep hanging [D]o-on
And [A]o-o-o-o-on   {c:(4,12)}     [D]  
[A]Oooohhhh  (ooo[D]o)  
[A]Oooohhhh  (ooo[D]o)

[A]/ / / /   / / /

Now I'm a [A]thousand miles away from [D]nowhere
And the [E7]night is turning, is turning [A]  bleak
[A]Fea-ea-ea-ea-ear comes u↑pon me [D]now
And I [E7]feel just like some ill-fated [A]    beast

But I [Bm]keep hanging o-[D]o-o-on
I [Bm]keep hanging [D]o-on
And [A]o-o-o-o-on   {c:(4,12)}  [D]
[A]Oooohhhh  (ooo[D]o)  
[A]Oooohhhh  (ooo[D]o)
[A]/ / / /   / / /

Now I [A]don't have much to [D]offer
[E7]I thought that was plain [A]to see
Cause [A]ba-a-a-a-abe, I'm ↑just an ↑unbe[D]liever
But [E7]I believe you can count o[A]n  me

If you [Bm]keep (I'll keep) hanging o-[D]o-o-on   
Just [Bm]keep (I'll keep) hanging [D]o-on

And [A]o-o-o-o-on  [D]   
[A]O-o-o-o-o-on [D]   
[A]O-o-o-o-on  [D]   
[A]O-o-o-o-o-on [D] 
[A]O-o-o-o-on  [D]

{c:(Higher... )}  
[A]O-o-o-o-o-on [D] 
[A]O-o-o-o-on  [D]   
[A]O-o-o-o-o-on [D] 
[A/]O-o-o-o-[A/]o...n