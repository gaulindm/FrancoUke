{title:DON'T STOP}
{subtitle: Key of D    4/4}
{subtitle:Christine McVie(Fleetwood Mac)}


[D]/ /    [C]/ /    [G]/ / / / 
[D]/ /    [C]/ /    [G]/ / / / 
[D]/ /    [C]/ /    [G]/ / / / 
[A7]/ / / /    / / / / 

[D]   If you [C]wake up and [G]don't want to smile
[D]   If it [C]takes just a [G]little-while
[D]   Open-your-[C]eyes and [G]look at the day
[A7]You'll see things in a different way
 

{soc}
[D]Don't  [C]stop,  [G]thinking about tomorrow
[D]Don't  [C]stop,  [G]It'll soon be here
[D]     It'll [C]be  here [G]better than before
[A7]Yesterday's gone, yesterday's gone
{eoc}

[D]/ /   [C]/ /    [G]/ / / /
[D]/ /   [C]/ /    [G]/ / / /
 
[D]   Why not [C]think about [G]times to come
[D]    And not a[C]bout the [G]things that you've done
[D]   If your [C]life was [G]bad to you
[A7]   Just think what tomorrow will do
 
{soc}
[D]Don't  [C]stop,  [G]thinking about tomorrow
[D]Don't  [C]stop,  [G]it'll soon be here
[D]    It'll [C]be here [G]better than before
[A7]Yesterday's gone, yesterday's gone
{eoc}

 [D]/ /   [C]/ /    [G]/ / / / 
[D]/ /    [C]/ /    [G]/ / / /


[D]   All I [C]want is to [G]see you smile
[D]   If it [C]takes just a [G]little-while
[D]   I know you [C]don't be[G]lieve that it's true
[A7] I never meant any harm to you


{soc}
[D]Don't [C]stop,  [G]thinking about tomorrow
[D]Don't  [C]stop,  [G/]It'll soon be here
[D]    It'll [C]be  here  [G]better than before
[A7]Yesterday's gone, yesterday's gone
{eoc} 


A-[D//]Oooo-[C//]oooo-[G]oooo   Don't you look [D//]back [C//]    [G]        {c:(234)}
A-[D//]Oooo-[C//]oooo-[G]oooo   Don't you look [D//]back [C//]    [G]        {c:(234)}
A-[D//]Oooo-[C//]oooo-[G]oooo   Don't you look [D//]back [C//]    [D/]  




