

{title:143 RIPTIDE   }
{subtitle:(4/4    Key of Am)}     
{subtitle: (Vance Joy)}
{time:4:18}
{metronome:190}




[Am]/ / / /    [G]/ / / /    [C]/ / / /   / / / /         
[Am]/ / / /    [G]/ / / /    [C]/ / / /   / / / /     

[Am]I was scared of [G]dentists and the [C]dark
[Am]I was scared of [G]pretty girls and 
[C]starting conversations
[Am]All my [G]friends are turning [C]green
You're the [Am]magician's as[G]sistant in their [C]dream  

A[Am]hoo, [G]ooh, [C]ooh  {c: (234,123)}
Ah [Am]oh oh [G]oh, and they [C/]come unstuck  {c: (beat)}


{soc}
     [Am]Lady [G]running down to the [C]riptide 
     Taken away to the [Am]dark side
     [G]I wanna be your [C]left hand man
     I [Am]love you [G]when you're singing that 
     [C]Song and I got a lump in my [Am]throat 'cause 
     [G]You're gonna sing the words [C]    wrong
{eoc}

[Am]There's this movie [G]that I think you'll [C]like
This [Am]guy decides to [G]quit his job and 
[C]Heads to New York City
This [Am]cowboy's [G]running from him[C]self
And [Am]she's been living [G]on the highest [C]shelf  

A[Am]hoo, [G]ooh, [C]ooh  {c: (234,123)}
Ah [Am]oh oh [G]oh, and they [C/]come unstuck  {c: (beat)}

{soc}
     [Am]Lady [G]running down to the [C]riptide 
     Taken away to the [Am]dark side
     [G]I wanna be your [C]left hand man
     I [Am]love you [G]when you're singing that 
     [C]Song and I got a lump in my [Am]throat 'cause 
     [G]You're gonna sing the words [C]     wrong
{eoc}

[Am]I just wanna, I just wanna know  [G]
[C]If you're gonna, if you're gonna st[F]ay  
[Am]I just gotta, I just gotta know  [G]
[C]I can't have it, I can't have it [F/]any other [F/]way

I [Am/]swear she is [G/]destined for the [C/]screen 
[Am/]Closest thing to [G/]Michelle Pfeiffer 
[C/]That you've ever seen, oh

{c: (softly)}
{soc}
     [Am]Lady [G]running down to the [C]riptide 
     Taken away to the [Am]dark side
     [G]I wanna be your [C]left hand man
     I [Am]love you [G]when you're singing that 
     [C]Song and I got a lump in my [Am]throat 'cause 
     [G]You're gonna sing the words [C]     wrong
{eoc}
{c: CHORUS}  {c: (louder)}
{soc}
     [Am]Lady [G]running down to the [C]riptide 
     Taken away to the [Am]dark side
     [G]I wanna be your [C]left hand man
     I [Am]love you [G]when you're singing that 
     [C]Song and I got a lump in my [Am]throat 'cause 
     [G]You're gonna sing the words [C]wrong yeah
     I get a lump in my [Am]throat ‘cause 
     [G]You’re gonna sing the words [C/]    Wrong
{eoc}

_________________________________











