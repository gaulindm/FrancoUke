

{title:087 HANDLE WITH CARE}
{subtitle:(4/4   Key of D)}
{subtitle:(Traveling Wilburys)}
{time:3:25}
{metronome: 124}







[D]/ /    [C]/ /    [G]/ / / /
[D]/ /    [C]/ /    [G]/ / / /     
          
[D]  Been beat [C]up and [G]battered around     
[D]  Been set [C]up and I've b[G]een shut down
[C]  You're the best thing that [G]I’ve ever [Em]found     
[C]  Handle [D]me with [G]care {c:(udud)} {c:(tap)}

[D]  Repu[C]tations [G]changable  
[D]  Situ[C]ations [G]tolerable
[C]  But baby you're a[G]dorable    [Em]         
[C]  Handle me with [D]care

{soc}
[G]I'm so [B7]tired of [C]being [D]lonely 
[G]I still [B7]have some [C]love to [D]give
[G]Won't you [B7]show me [C]that you [D]really 
[G]Care {c:(234)}   {c:(}[G7]{c:123)}
Every[C]body's got somebody {c:(23)}
To le- [G]ean on 
Put your [C]body next to mine {c:(23)}
And dre- [D]eam on
{eoc}

[D]I’ve been fobbed [C]off and [G]I've been fooled     
[D]  I've been [C]robbed and [G]ridiculed
[C]  In daycare centers [G]and night [Em]schools    
[C]  Handle [D]me with [G]care {c:(udud)} {c:(tap)}

[D]/ /    [C]/ /    [G]/ / / /
[D]/ /    [C]/ /    [G]/ / / /    

[D]  Been stuck in [C]airports [G]terrorized   
[D]  Sent to [C]meetings [G]hypnotized
[C]  Overexposed co[G]mmercialized  [Em]            
[C]  Handle me with [D]care

{soc}
[G]I'm so [B7]tired of [C]being [D]lonely 
[G]I still [B7]have some [C]love to [D]give
[G]Won't you [B7]show me [C]that you [D]really 
[G]Care {c:(234)}  {c:(}[G7]{c:123)}
Every[C]body's got somebody {c:(23)}
To le- [G]ean on  
Put your [C]body next to mine {c:(23)}
And dre- [D]eam on
{eoc}

I've [D]been up[C]tight and [G]made a mess  
But [D]I'm cleaning [C]up my[G]self I guess
[C] Oh the sweet [G]smell of suc[Em]cess       
[C]  Handle [D]me with [G]care {c:(udud)} {c:(tap)}

[D]/ /    [C]/ /    [G]/ / / /
[D]/ /    [C]/ /    [G]/ / / /  
[D]/ /    [C]/ /    [G]/ / / /
[D]/ /    [C]/ /    {c:(}[G]{c:dudu)}   

____________________________________









