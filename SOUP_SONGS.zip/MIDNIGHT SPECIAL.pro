{title:MIDNIGHT SPECIAL}
{subtitle:}
{time:3:00}



 
[D]Well, you wake up in the [G]mornin, you hear the work bell [D]ring,
And they march you to the [A7]table to see the same old [D]thing.
Ain t no food upon the [G]table, and no pork up in the [D]pan.
But you better not com[A7]plain, boy, you get in trouble with the [D]man.
 
Let the midnight [G]special shine a light on [D]me,
Let the midnight [A7]special shine a light on [D]me,
Let the midnight [G]special shine a light on [D]me,
Let the midnight [A7]special shine a everlovin light on [D]me.
 
[D]Yonder come Miss [G]Rosie, how in the world did you [D]know? 
By the way she wears her [A7]apron, and the clothes she [D]wore.
Umbrella on her [G]shoulder, piece of paper in her [D]hand;
She come to see the [A7]govnor, she wants to free her [D]man.
 
Let the midnight [G]special shine a light on [D]me,
Let the midnight [A7]special shine a light on [D]me,
Let the midnight [G]special shine a light on [D]me,
Let the midnight [A7]special shine a everlovin light on [D]me.
 
[D]If you re ever in [G]Houston, well, you better do the [D]right;
You better not [A7]gamble, there, you better not [D]fight, at all
Or the sheriff will [G]grab ya and the boys will bring you [D]down.
The next thing you [A7]know, boy, oh! You re prison [D]bound.
 
Let the midnight [G]special shine a light on [D]me,
Let the midnight [A7]special shine a light on [D]me,
Let the midnight [G]special shine a light on [D]me,
Let the midnight [A7]special shine a everlovin light on [D]me. 2x
 
* Alternate:
 
Capo II
 
D  = C
G  = F
A7 = G7
 
Set8
 
 