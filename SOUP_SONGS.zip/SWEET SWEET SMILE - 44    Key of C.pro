{title: SWEET SWEET SMILE  }
{subtitle:4/4    Key of C}
{subtitle:Juice Newton, Otha Young (The Carpenters)}
{metronome:164  }
{time:2:24}






{c:INTRO:}
[C]/ / / /   / / / /

[C] You're always in my heart
From [Am]early in the morning till it's dark
I gotta [F]see your sweet, sweet [G]smile every [C]day 
When I [C]wake up in the morning and I see you there
I [Am]always whisper a little prayer
I gotta [F]see your sweet sweet [G]smile every [C]day
 
I gotta [Am]know that you love me, and that you want me
And that you'll always be there
I gotta [F]know that you [G]care
And I gotta [Am]feel your arms around me
And that you need me, and you'll always be there
I gotta [F]know that you [G]care
 
[C]If my times are bringing me down
[Am]You're the only one that I want around
I gotta [F]see your sweet sweet [G]smile every [C]day
[C] And if I'm all strung out
[Am]You're the only one who can straighten me out
I gotta [F]see your sweet sweet [G]smile every [C]day
 
I gotta [Am]know that you love me, and that you want me
And that you'll always be there
I gotta [F]know that you [G]care
And I gotta [Am]feel your arms around me
And that you need me, and you'll always be there
I gotta [F]know that you [G]care
 
[C] You're always in my heart
From [Am]early in the morning till it's dark
I gotta [F]see your sweet sweet [G]smile every [C]day
I gotta [F]see your sweet sweet [G]smile every [C]day
I gotta [F]see your sweet sweet  [G]smile every [C]day    [G/]   [C/]