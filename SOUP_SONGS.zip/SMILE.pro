{title:SMILE   } 
{metronome: }
{time: 3:00}






                                        

{c:INTRO:}
{c:C / / / /   Am / / / /   }
{c:Dm / / / /   G / / / /}

[C]Smile, though your heart is aching
[Em]Smile, even though it's breaking
[Am] When there are [Cdim]clouds in the [Dm7]sky  
You'll get [A7]by
 
If you [Dm]smile through your fears and sorrow
[Fm]Smile, and maybe tomorrow
[C] You'll see the [Am]sun come shining 
[Dm]through, for [G]you

{soc}
[C]Light up your face with gladness
[Em]Hide every trace of sadness
[Am]     Although a [Cdim]tear may be 
[Dm7]Ever so [A7]near 
{eoc}

That's the [Dm]time you must keep on trying
[Fm]Smile, what's the use of crying
[C] You'll find that [Am]life is still 
worth[Dm7]while
If [G]you'll just [C]smile {c: (2 3 4)}

{c:Instrumental}
{soc}
[C]Light up your face with gladness
[Em]Hide every trace of sadness
[Am]     Although a [Cdim]tear may be 
[Dm7]Ever so [A7]near 
{eoc}

{c: OUTRO: resume singing}
That's the [Dm]time you must keep on trying
[Fm]Smile, what's the use of crying
[C] You'll find that [Am]life is still worth[Dm7]while
If [G]you'll just [C]smile {c: (2 3 4)} [C/] 


