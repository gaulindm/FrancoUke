{title:ROCK AROUND THE CLOCK }
{subtitle:(4/4   Key of A)} 
{subtitle:(Max C. Freedman & James E. Myers)}
{time:2:44}
{metronome: 174}







{c:*  means “ba dum" (quick up-down)}  
{c:(Count right into the song “1,2,3,4, 123)}

[*A/]One, two, three o’clock, four o’clock rock 
[*A/]five, six, seven o’clock, eight o’clock rock  
[*A/]Nine, ten eleven o’clock, twelve o’clock rock
We’re gonna rock  [E7/]        a-round  [E7/]        the 
Clock [E7/]tonight 
 
[E7/]Put your [A]glad rags on and join me, hon, we’ll 
Have some fun when the [A7]clock strikes one 
We’re gonna [D7]rock around the clock tonight
We’re gonna [A]rock, rock, rock, ‘til broad daylight
We’re gonna [E7]rock, gonna rock, a[D7]round the 
Clock to[A]night 
 
When the [A]clock strikes two, three and four 
If the band slows down, we’ll [A7]yell for more 
We’re gonna [D7]rock around the clock tonight 
We’re gonna [A]rock, rock, rock, ‘til broad daylight 
We’re gonna [E7]rock, gonna rock, a[D7]round the 
Clock to[A]night 
 
{c:INSTRUMENTAL:} 
[A]DDD Ddududu 
[A]DDD Ddududu 
[D7]DDD Ddududu 
[A]DDD Ddududu 
[E7]DDD Ddududu  
[A]/ - [A]/ - [A]/ - [A]/
 
When the [A]chimes ring five, six and seven
We’ll be right in [A7]seventh heaven 
We’re gonna [D7]rock around the clock tonight
We’re gonna [A]rock, rock, rock, ‘til broad daylight 
We’re gonna [E7]rock, gonna rock, a[D7]round the 
Clock to[A]night 
 
When it’s [A]eight, nine, ten, eleven too, I’ll be 
Goin’ strong and [A7]so will you 
We’re gonna [D7]rock around the clock tonight 
We’re gonna [A]rock, rock, rock ‘til broad daylight 
We’re gonna [E7]rock, gonna rock, a[D7]round the 
Clock to[A]night 

{c:INSTRUMENTAL:} 
[A]DDD Ddududu 
[A]DDD Ddududu 
[D7]DDD Ddududu 
[A]DDD Ddududu 
[E7]DDD Ddududu  
[A]/ - [A]/ - [A]/ - [A]/

When the [A]clock strikes twelve, we’ll cool off then, start 
A-rockin’ round the [A7]clock again 
We’re gonna [D7]rock around the clock tonight
We’re gonna [A]rock, rock, rock, ‘til broad daylight 
We’re gonna [E7]rock, gonna rock, a[D7]round the clock 
To[A//]night  [A7]/ /     [D]/ /     [D7]/ /     [E7]/  {c:(234)}  
[E7]/ /     [A/]  {c:(then flutter on A)}

{define: D7 0 2 0 2 0}



