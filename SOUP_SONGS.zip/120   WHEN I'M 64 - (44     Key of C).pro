

{t:120   WHEN I'M 64      }
{subtitle:(4/4     Key of C)}       
{subtitle:(Paul McCartney)}
{time:3:27}
{metronome: 138}






{c:INTRO (with kazoos):}
[C]/ / / /   / / / /    
[D7]/ /    [G7]/ /    [C]/ / / /   

[C]When I get older, losing my hair 
Many years from [G7]now 
Will you still be sending me a Valentine 
Birthday greetings, [C]bottle of wine 
If I'd been out to quarter to three 
[C7]Would you lock the [F]door 
Will you still need me, [C]will you still [A7]feed me 
[D7]When I'm [G7]sixty-[C]four 

{sob} 
     [Am]/ / / /   / / / /    
     [G]/ / / /   [Am]/ / / /
     [Am]You'll be older, [E7]too 
     [Am////]          And if you [Dm]say the word 
     [F]I could [G7]stay with [C/]you [C/-]  [G7////] 
{eob}

[C]I could be handy mending a fuse
When your lights have [G7]gone 
You can knit a sweater by the fireside 
Sunday mornings [C]go for a ride 
Doing the garden, digging the weeds
[C7]Who could ask for [F]more 
Will you still need me, [C]will you still [A7]feed me 
[D7]When I'm [G7]sixty-[C]four
 
{sob}
     [Am]Ev'ry summer we could rent a 
     Cottage in the Isle of 
     [G]Wight, if it's not too [Am]dear 
     [Am]We shall scrimp and [E7]save 
     [Am////]           Grandchildren [Dm]on your knee 
     [F]Vera, [G7]Chuck and [C/]Dave [C/-] [G7////] 
{eob}

[C]Send me a post-card, drop me a line 
Stating point of [G7]view 
Indicate precisely what you mean to say 
Yours sincerely [C]wasting away 
Give me your answer fill in a form 
[C7]Mine forever [F]more 
Will you still need me, [C]will you still [A7]feed me 
[D7]When I'm [G7]sixty-[C]four? 

[F]Will you still need me, [C]will you still [A7]feed me 
[D7]When I'm [G7]sixty-[C/]four? [G7/][C/]
  

____________________________________

{define: D7 0 2 0 2 0}














