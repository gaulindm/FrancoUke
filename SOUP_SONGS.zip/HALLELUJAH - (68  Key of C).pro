

{title:O!  HALLELUJAH (Orchestra) }
{subtitle:(6/8  Key of C)}
{subtitle:(Leonard Cohen)}
{time:4:15}
{metronome: 76}


{c:COUNT-IN in 4/4 time}

Lynda


[C]/ /    [Am]/ /      [C]/ /    [Am]/ / 

I've [C]heard there was a [Am]secret chord 
That [C]David played, and it [Am]pleased the Lord
But [F]you don't really [G]care for music, [C]do ya   [G]
It [C]goes like this the [F]fourth, the [G]fifth 
The [Am]minor fall, the [F]major lift
The [G]baffled king com[Em]posing Halle[Am]lujah
Halle[F]lujah, Halle[Am]lujah 
Halle[F]lujah, Halle[C]lu…[G]u…[C//]jah    
[Am]/ /     [C]/ /   [Am]/ /

[C]Baby I have been [Am]here before
I [C]know this room, I've [Am]walked this floor
I [F]used to live a[G]lone before I [C]knew ya   [G]
I've [C]seen your flag on the [F]marble [G]arch
[Am]Love is not a [F]victory march it's a 
[G]Cold and it's a [Em]broken Halle[Am]lujah
Halle[F]lujah, Halle[Am]lujah 
Halle[F]lujah, Halle[C]lu…[G]u…[C//]jah     
[Am]/ /     [C]/ /   [Am]/ /

You [C]say I took the [Am]name in vain
[C]I don't even [Am]know the name
But [F]if I did, well [G]really, what's it [C]to ya  [G]
There's a [C]blaze of light in [F]every [G]word
It [Am]doesn't matter [F]which you heard
The [G]holy or the [Em]broken Halle[Am]lujah
Halle[F]lujah Hallel[Am]ujah 
Hallelu[F]jah Halle[C]lu…[G]u…[C//]jah      
[Am]/ /     [C]/ /   [Am]/ /

I [C]did my best, it [Am]wasn't much
I [C]couldn't feel, so I [Am]tried to touch
I've [F]told the truth, I [G]didn't come to [C]fool ya  [G]
And [C]even though it [F]all went [G]wrong
I'll [Am]stand before the [F]Lord of Song
With [G]nothing on my [Em]tongue but Halle[Am]lujah

Halle[F]lujah Halle[Am]lujah 
Halle[F]lujah Halle[C]lu…[G]u…
Halle[F]lujah Halle[Am]lujah 
Halle[F]lujah Halle[C]lu…[G]u…[C/]jah

***********************************










