{title: ANYTIME  }
{subtitle:(4/4     Key of C)}
{subtitle:(Herbert Lawson)}
{time: 3:00}
{metronome: 118}







{c:INTRO:}
[A7]/ / / /     [D7]/ / / /     
[G7]/ / / /     [C]/ /  

Any[A7]time you're feeling [D7]lonely
Any[G7]time you're feeling [C]blue [C7]
Any[F]time you feel down-[C]hearted [A7]
That will [D7]prove your love for me is [G7]true

Any[A7]time you're thinking [D7]'bout me
That's the [G7]time I'll be thinking of [E7]you
So any[A7]time you say you 
[D7]Want me back again
That's the [G7]time I'll 
Come back home to [C]you (234, 1234)

{c:Instrumental:}
[A7]/ / / /     / / / /   
[D7]/ / / /    / / / /    
[G7]/ / / /    / / / /    
[C]/ / / /     / /
 
Any[A7]time your world gets [D7]lonely
And you [G7]find true friends are [C]few [C7]
Any[F]time you see a [C]rainbow [A7]
That will [D7]be a sign the storm is [G7]through
                            
Any[A7]time will be the [D7]right time
Any[G7]time at all will [E7]do
So any[A7]time you say you 
[D7]Want me back again
That's the [G7]time I'll 
Come back home to [C]you [A7]
That's the [G7]time I'll 
Come back home to [C]you   [Cgliss]

{define: D7 0 2 0 2 0}



