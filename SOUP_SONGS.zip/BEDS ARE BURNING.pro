{title:BEDS ARE BURNING}
{subtitle:}
 
[A] [C] [D]
 
[Am]Out where the river broke
The bloodwood and the desert oak
Holden wrecks and boilin' diesels
Steam in forty five degrees
 
The [A]time has come, to [G]say fair's fair
to [D]pay the rent, to [A]pay our share
The [A]time has come, a fact's a [G]fact
it be[D]longs to them, let's [B]give it back
 
[A]  [C]   [D]
 
[Am]How can we dance when our [F]earth is turning
[C]/ / / /   / / / /
[Am]How do we sleep while our [F]beds are burning
[G]/ / / /   / / / /
[Am]How can we dance when our [F]earth is turning
[C]/ / / /   / / / /
[Am]How do we sleep while our [F]beds are burning
[G]/ / / /   / / / /
 
The [A]time has come, to [F]say fairs fair
to [C]pay the rent, now to [G]pay our share
 
[A]Four wheels scare the cockatoos
From Kintore East to Yuendemu
The western desert lives and breathes
In forty five degrees
 
The [A]time has come, to [G]say fair's fair
to [D]pay the rent, to [A]pay our share
The [A]time has come, a [G]fact's a fact
it be[D]longs to them, let's [A]give it back
 
G A# C
 
[Am]How can we dance when our [F]earth is turning? [C]
[Am]How do we sleep while our [F]beds are burning? [G]
[Am]How can we dance when our [F]earth is turning? [C]
[Am]How do we sleep while our [F]beds are burning? [G]
The [A]time has come, to say fair's [G]fair;
to [D]pay the rent, to [A]pay our share
The [A]time has come, a fact's a [G]fact;
it be[D]longs to them, let's [A]give it back
 
[Am]How can we dance when our [F]earth is turning? [C]
[Am]How do we sleep while our [F]beds are burning? [G]
 
Gm D# A# Gm D# F
 
G A# C 2x
 