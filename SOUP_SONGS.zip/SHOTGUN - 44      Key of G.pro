
{title:SHOTGUN}
{subtitle:4/4      Key of G}
{subtitle: George Ezra}
{metronome:126}
{time:3:26}






[G/] {c:(234)}    [C/]     {c:(234)}    [Em/]          {c:(234)}    [D/]        {c:(234)}

[G]Home grown alligator, [C]see you later
Gotta hit the [Em]ro-o-oad, gotta hit the [D]road
[G]Something changed in the atmosphere
[C]Architecture unfamiliar
[Em/]  I could get used to this  [D]/ / / /
 
 
[G]Time flies by in the [C]yellow and green
stick a[Em]round and you’ll see what I [D]mean
There’s a [G]mountain top that  [C]I’m dreaming of
If you [Em]need me you know where I’ll be [D7/]      {c:(tap)}
 
 
{soc}
  I’ll be riding [G]shotgun underneath the [C]hot sun
  Feeling like a [Em]someone {c:(someone,} [D]{c:someone)}
  I’ll be riding [G]shotgun underneath the [C]hot sun
  Feeling like a [Em]someone   {c:(34,}[D]{c:1234)}
{eoc}
 
[G]South of the equator, [C]navigator
Gotta hit the [Em]ro-o-oad, gotta hit the [D]road
[G]Deep-sea diving round the clock
Bi[C]kini bottoms, lager tops
[Em/]   I could get used to this  {c:(}[D]{c:1234)}
 
[G]Time flies by in the [C]yellow and green
Stick arou[Em]nd and you’ll see what I [D]mean
There’s a [G]mountain top that [C]I’m dreaming of
If you [Em]need me, you know where I’ll be [D/]      {c:(tap)}
 
{soc}
  I’ll be riding [G]shotgun underneath the [C]hot sun
  Feeling like a [Em]someone {c:(someone,} [D]{c:someone)}
  I’ll be riding [G]shotgun underneath the [C]hot sun
  Feeling like a [Em]someone {c:(34,}[D]{c:123)}
{eoc}
 
We got [G]two in the front, [C]two in the back
[Em]Sailing along and we [D]don’t look ba-a-ack
 
[G]Ba-a-ack, ba-a-ack  [C]back-back-back-back  {c:(beat)} 
[Em]/ / / /    [D]/ / / /
 
 
[G/]Time flies by in the [C/]yellow and green
stick ar[Em/]ound and you’ll see what I [D]mean
There’s a [G]mountain top, that I[C]’m dreaming of
If you [Em]need me, you know where I’ll be[D/]       {c:(tap)}
 
{soc}
 I’ll be riding [G]shotgun underneath the [C]hot sun
 Feeling like a [Em]someone {c:(someone,} [D]{c:someone)}
 I’ll be riding [G]shotgun underneath the [C]hot sun
 Feeling like a [Em]someone {c:(34,}[D]{c:12)}

 I’ll be riding [G]shotgun underneath the [C]hot sun
 Feeling like a [Em]someone {c:(someone,} [D]{c:someone)}
 I’ll be riding [G]shotgun underneath the [C]hot sun
 Feeling like a [Em]someone, someone,  [D]someone
 Someone [G/]someone
{eoc}


____________________________________


















