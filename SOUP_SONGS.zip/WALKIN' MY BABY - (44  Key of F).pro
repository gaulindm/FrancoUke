{title:  WALKIN' MY BABY }
{title:BACK HOME}
{subtitle: (4/4  Key of F)}   
{subtitle:(Roy Turk and Fred Ahlert)   }
{time: 2:30}
{metronome: 118}





{c:INTRO:}   
[Gm]/ /     [C7]/ /     [F]/ / / / 

[F]Gee, it's [F6/9]great after [F]bein' out [Dm]late 
[F]Walkin' my [Dm]baby back [D7]home
[Gm]Arm in [C7]arm over [Gm]meadow and [C7]farm 
[Gm]walkin' my [C7]baby back [F]home [C7]

[F]We go a-[F6/9]long harmon-[F]izing a [Dm]song 
[F]Or I'm re[Dm]citin' a [D7]poem
[Gm]Owls go [C7]by and they [Gm]give me the [C7]eye 
[Gm]Walkin' my [C7]baby back [F]home 

{c:BRIDGE:}
{soc:}
   We [Am]stop for a while, she [D7]gives me a smile 
   And [Dm]snuggles her head on my [E7]chest
   We [Am]start in to pet and [D7]that's when I get 
   [G7/]       her talcum all [C7/]over my vest
{eoc:]

[F]After [F6/9]I kinda [F]straighten my [Dm]tie 
[F]She has to [Dm]borrow my [D7]comb
[Gm]One kiss and [C7]then I con-[Gm]tinue a-[C7]gain 
[Gm]Walkin' my [C7]baby back [F]home  

{soc:}
   She's [Am]'fraid of the dark so [D7]I have to park 
   Out[Dm]side of her door till it's [E7]light
   She [Am]says if I try to [D7]kiss her she'll cry 
   [G7/]       I dry her tears [C7/]all through the night
{eoc:}

[F]Hand in [F6/9]hand to a [F]barbecue [Dm]stand 
[F]Right from her [Dm]doorway we [D7]roam
[Gm]Eats and [C7]then it's a [Gm]pleasure a[C7]gain
[Gm]Walkin' my [C7]baby [Am]talkin' my [D7]baby
[Gm]Lovin'  my [C7]baby  
[D7/]I      [D7/]don't  [D7/]mean [D7/]maybe....
[Gm]Walkin' my [C7]baby back [F/]home [C7/] [F/]

{define: D7 0 2 0 2 0}
{define: F6/9 0 0 2 1 0}
