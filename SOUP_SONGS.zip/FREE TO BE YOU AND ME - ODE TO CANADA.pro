{title:FREE TO BE YOU AND ME}
{subtitle:ODE TO CANADA}
{subtitle: 6/8      Key of A  }
{subtitle: (Alan Frew)}
{metronome: 178  }
{time: 3:50  }


[A]/ / /   / / /   / / /   / / /   
/ / /   / / /   / / /   / 

From the [A]isle of Vancouver, to the Labrador Sea
One nation that lives strong and [D]    free  [Dsus4]/ / /   
[D] Where I'm free to be... [A]   me  {c:(3,123,123,1)}


From the songs of the prairies, to the call of the ponds
Heros of times come and [D]   gone   [Dsus4]/ / /
[D] But the memories go [A]on and on and [E7]on

{soc}
  [A]Oh oh oh this is Canada's [D]song   
  [Dsus4]/ / /        [D]/ / /   / / /     

  [A]Oh oh oh where my heart be[D]longs 
  [Dsus4]/ / /        [D]/ / /   / {c:(stop)}
{eoc}

Where you're [A]free to be a dreamer
Free to be who you are
Free to believe in your [D]star  [Dsus4]/ / /       [D]/ / /     
Free to go [A]fa-a-a-[E7]ar
 
{soc}
  [A]Oh oh oh  this is Canada's [D]song   
  [Dsus4]/ / /      [D]/ / /   / / /   
   
  [A]Oh oh oh  where my heart be[D]longs   
  [Dsus4]/ / /       [D]/ / /   / / /

  [A]Oh oh oh where we're free to [D]be   
  [Dsus4]/ / /       [D]/ / /   / / /  
  
  [A]Oh oh oh we're strong and [D]    free   
  [Dsus4]/ / /       [D]/ / /    Free to be! 
{eoc} 

[F#m]/ / /   / / /   / / /   / / /
[D]/ / /   / / /   / / /   / / /
[F#m]/ / /   / / /   / / /   / / /    
[D]/ / /   / / /   / / /   [oh...]/ {c:(stop)}

[A/]Free to be a dreamer, free to be who you are

{soc}
  [A]Oh oh oh this is Canada's [D]song   
  [Dsus4]/ / /        [D]/ / /   / / / 
        
  [A]Oh oh oh where my heart be[D]longs   
  [Dsus4]/ / /       [D]/ / /   / / /

  [A]Oh oh oh where we're free to [D]be   
  [Dsus4]/ / /       [D]/ / /   / / / 
   
  [A]Oh oh oh we're strong and [D]free   
  [Dsus4]/ / /        [D]/ / /   / / /

  [A/]Oh oh [A/]oh This is Canada's [D/]song {c:(23,123,}[D/]{c:123,123)}            
  [A/]Oh oh [A/]oh where I'm free to [D/]be... {c:(23,123,123)}
  Strong and [A/]free
{eoc}

______________________________________________


















