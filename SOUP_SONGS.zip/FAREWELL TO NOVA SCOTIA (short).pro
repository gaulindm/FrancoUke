{title: FAREWELL TO NOVA SCOTIA }
{subtitle:(4/4    Key of C)}   
{subtitle:(unknown)}
{time: 2:30}
{metronome: 200}





{c:tambourine starts 2nd chorus}

{c:INTRO:}
[Am]/ / / /    [F]/ / / /    [Am]/ / / /    / / / 

{c:CHORUS}
{soc}
Fare[C]well to Nova Scotia, you seabound coast
Let your [Am]mountains dark and dreary be
For when [C]I am far a[G7]way on the briny ocean tossed
Will you [Am]ever heave a [F]sigh or a [Am]wish for me?
{eoc}

The [C]sun was setting in the west
The [Am]Birds were singing on every tree
All [C]nature [G7]seemed inclined for to rest but 
[Am]Still there [F]was no [Am]rest for me

{soc}
Fare[C]well to Nova Scotia, you seabound coast
Let your [Am]mountains dark and dreary be
For when [C]I am far a[G7]way on the briny ocean tossed
Will you [Am]ever heave a [F]sigh or a [Am]wish for me?
{eoc}

I [C]grieve to leave my native land
I [Am]grieve to leave my comrades all
And my [C]parents, [G7]whom I held so dear  and my 
[Am]Bonny, bonny [F]lass that I [Am]do adore                 

{soc}
Fare[C]well to Nova Scotia, you seabound coast
Let your [Am]mountains dark and dreary be
For when [C]I am far a[G7]way on the briny ocean tossed
Will you [Am]ever heave a [F]sigh or a [Am]wish for me?
{eoc}

{c:(slowly)}   
Will you [Am]ever heave a [F]sigh or a 
[Am/]Wish [Am/]for [Am/]me? 

