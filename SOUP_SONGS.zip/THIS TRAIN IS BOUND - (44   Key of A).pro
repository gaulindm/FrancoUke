{title: THIS TRAIN IS BOUND}
{title:FOR GLORY }
{subtitle:(4/4   Key of A)}
{time: 4:10}
{metronome: 170}
{c:(#40 is included for when we do both)}








{c:F#dim is like a (Hawaiian) D7}

{c:INTRO:}  
[A]/ / / /     [A7]/ / / /     
[D]/ / / /     [F#dim]/ / / /     
[A]/ / / /     [E7]/ / / /      
[A]/ / / /    / / / /             

[A]This train is bound for glory, this train
This train is bound for glory, [E7]this train
[A]This train is [A7]bound for glory
[D]Don’t carry nothing but the [
F#dim]Righteous and the holy
[A]This train is [E7]bound for glory, [A]this train

[A]This train don't carry no gamblers, this train
This train don't carry no gamblers, [E7]this train
[A]This train don't [A7]carry no gamblers
[D]No High Flyers, [F#dim]big shot ramblers
[A]This train don’t [E7]carry no gamblers [A]this train

[A]This train don't carry no liars, this train
This train don't carry no liars, [E7]this train
[A]This train don't [A7]carry no liars
[D]Truth is what we [F#dim]all desire
[A]This train don't [E7]carry no liars, [A]this train

[A]This train is leaving in the morning, this train
This train is leaving in the morning, [E7]this train
[A]This train is [A7]leaving in the morning
[D]We will see a [F#dim]new day dawning
[A]This train is [E7]leaving in the morning
[A////]this train 

[A7]/ / / /     [D]/ / / /     [F#dim]/ / / /     
[A]/ / / /     [E7]/ / / /      [A]/ / / /    /   [E7]/    [A]/

{c:OUTRO #2: Keep strumming the A chord,}
{c:speed up and go into "Mama Don't Allow"}

[A]Mama don’t allow no music playin’ ‘round here   
(No she don’t)
Mama don’t allow no music playin’ ‘round [E7]here  
(No she don’t)
Well [A]we don’t care what [A7]Mama don’t allow
We’re gonna [D]play our music [F#dim]anyhow
[A]Mama don’t allow no 
[E7]Music playin’ ‘round [A]here 

[A]Mama don’t allow no ukulele playin’ ‘round here  
(No, she don’t)
Mama don’t allow no ukulele playin’ ‘round [E7]here  
(No, she don’t)
Well [A]we don’t care what [A7]Mama don’t allow
We’re gonna [D]play our ukuleles [F#dim]anyhow
[A]Mama don’t allow no 
[E7]Ukulele playin’ ‘round [A]here

[A]Mama don’t allow no toe tappin’ ‘round here  
(No, she don’t)
Mama don’t allow no toe tappin’ ‘round [E7]here  
(No, she don’t)
Well [A]we don’t care what [A7]Mama don’t allow
We’re gonna [D]tap our little toes [F#dim]anyhow
[A]Mama don’t allow no [E7]toe tappin’ ‘round [A]here

[A]Mama don’t allow no whoopdidooin’ around here 
(No, she don’t)
Mama don’t allow no whoopdidooin’ around [E7]here 
(No, she don’t)
Well [A]we don’t care what [A7]Mama don’t allow 
We’re gonna [D]whoop our doodoos [F#dim]anyhow
[A]Mama don’t allow no 
[E7]Whoopdidooin’ around  [A]here 
Mama don’t allow no [E7]music playin’ ‘round [A]here
Mama don’t allow no [E7]ukulele playing ‘round [A]here

{c:(slow)}   No we don’t care what 
[A7]Mama don’t allow
We’re gonna [D]play our ukuleles [F#dim]anyhow! 
{c:(faster)}   [A]Mama don’t allow no 
[E7]music playing ‘round 

[A////]here      [A7]/ / / /     [D]/ / / /     [F#dim]/ / / /,     
[A]/ / / /     [E7]/ / / /      [A]/ / / /    /       [E7]/    [A]/

