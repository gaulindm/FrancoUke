{title:049   VIDEO KILLED }
{title:THE RADIO STAR}
{subtitle: 4/4      Key of C}
{subtitle:Trevor Horn, Geoff Downes, Bruce Woolley }
{subtitle:(The Buggles)}
{time:3:40}
{metronome:132}
 


[C]/ /    [F]/ /    [G]/ / / /
[C]/ /    [F]/ /    [G]/ / / /
 
[C] I heard you [Dm]on the wireless [F]back in Fifty-[G]Two 
[C] Lying a[Dm]wake intent at [F]tuning in on [G]you 
[Em] If I was [F]young it didn't 
[G]Stop you coming through 
([C]Ow-a-[Dm]ow-a)  [G]
 
[C] They took the [Dm]credit 
For your [F]second sympho[G]ny 
[C] Rewritten [Dm]by machine and [F]new technolo[G]gy
[Em] And now I [F]understand 
The [G]problems you can see 

([C]Ow-a-[Dm]ow-a)   [F]     I met your [G]children 
([C]Ow-a-[Dm]ow-a)   [F]     What did you [G]tell them 

{soc} 
   [C]Video killed the r[F]adio star 
   [C]Video killed the r[F]adio star 
{eoc}
 
[C]Pictures [G]came and [F]broke your heart 
([G]Ow-a-a-ow-[Am]ow )  {c:(234)}
 
[C] And now we [Dm]meet in an a[F]bandoned studi[G]o 
[C] We hear the [Dm]playback 
And it [F]seems so long a[G]go 
[Em] And you re[F]member... 
The [G]jingles used to go 
 
([C]Ow-a-[Dm]ow-a)   [F]    You were the [G]first one 
([C]Ow-a-[Dm]ow-a)   [F]    You were the [G]last one 
 
{soc}
   [C]Video killed the r[F]adio star 
   [C]Video killed the r[F]adio star 
{eoc}
 
[C]In my [G]mind and [F]in my car
We [C]can't re[G]wind we've [F]gone too far 
([G]Ow-a-a-ow-[Am]ow)  {c:(234)}  
([G]Ow-a-a-ow-[Am]ow)  {c:(234)}

[F]/ /    [G]/ /    [C]/ /   [F]/ /
[F]/ /    [G]/ /    [C]/ /   [F]/ /
[F]/ /    [G]/ /    [E7]/ /    [Am]/ /

{c:Arpeggio: (Pluck one string at a time}
{c:Starting with the G string)}
[Dm]/       [C]/     [Dm7]/

{c:(solid strums)}
[G/]   [Am/]           [F/]       [Am/]           [F/]       [G/]

{soc} 
  [C]Video killed the r[F]adio star 
  [C]Video killed the r[F]adio star 
{eoc}
 
[C]In my [G]mind and [F]in my car 
We [C]can't re[G]wind we've [F]gone too far 
[C]Pictures [G]came and [F]broke your heart 
[C]Put the [G]blame on [F/]VTR  {c:(4,123)}
                          

You [C]a...   ...[Dm]are a radio 
[F]Sta-a-a-a-a-a-a-[G]ar  
You [C]a...   ...[Dm]are a radio 
[F]Sta-a-a-a-a-a-a-[G]ar  

{soc} 
  [C]Video killed the r[F]adio star 
  [C]Video killed the r[F]adio star 
 
           [C]Video killed the r[F]adio star
  {c:(You a...                     ...are a radio)}
    [C]Video killed the r[F]adio star 
  {c:(Sta-a-a-a-a-a-a-ar)}  
   
           [C]Video killed the r[F]adio star
  {c:(You a...                     ...are a radio)}
    [C]Video killed the r[F]adio star {c:(234)} [C/]
  {c:(Sta-a-a-a-a-a-a-ar)}  {eoc} 

______________________________








