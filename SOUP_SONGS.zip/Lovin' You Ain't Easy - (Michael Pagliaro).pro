{title:LOVIN' YOU AIN'T EASY}
{subtitle:  4/4      Key of C}
{subtitle:(Michael Pagliaro)}
{time:3:30}
{metronome:  127}

 

[C]/ / / /   / /    [Csus4]/ /   
[C]/ / / /   / /    [Csus4]/ /

[C]{c:(12)}  Hitch any ri...de you want to     
[Dm]{c:(12)}  Do anythi...ng you wanna do
[F]{c:(12)}  Just keep ri...din' your [C]way {c:(234,1234)}
 
[C]{c:(12)} Take anyo...ne you want to         
[Dm]{c:(12)} Long as I... can hear from you
[F]{c:(12)} Just be mi...ndin' your w[C]ay {c:(234)}
 
[Bb] Just be [F]mindin' your wa-[C]ay        
[Bb] Just be [F]mindin' your wa-[C]ay {c:(beat)}
 
Lovin' you ain't so easy        
[Dm]{c:(12)}  Would never try... to please me
[F]{c:(12)}  But I've got ti...me any old [C]way {c:(234)}   
[Bb] I've got [F]time any[C]way  {c:(234)}   [Bb]/ /    [F]/ /
 
[G] But you know what you know what you're doin'
[C] And nobody, [E7]nobody knows, but it's
[Am]You, ooo, ooo, wo-oh [D]o-oh
Oh baby [C]why do I   
[Bb] Keep a [F]talkin' to yo[C]u  {c:(234)} 
[Bb] Keep a [F]talkin' to yo[C]u {c:(beat)}
{c:                                        (I...     )}

I guess I must be crazy
{c:(                         ... must be )}         
[Dm]{c:(12)}  Still I fee...l you move me
{c:(cra...zy )}
[F]{c:(12)}  This is a...ll I can [C]say  {c:(234,1234)}
 
{c:(}[C]{c:12)} Hitch any ri...de you want to      
{c:(}[Dm]{c:12)} Do anythi...ng you wanna do
{c:(}[F]{c:12)} Just keep ri...din' your w[C]ay       
[Bb] Just keep [F]ridin' your [C]way 
{c:(234)}   [Bb]/ /    [F]/ /
 
[G] But you know what you know what you're doin'
[C] And nobody, [E7]nobody knows, but it's
[Am]You, ooo, ooo, wo-oh [D]o-oh
Oh baby [C]why do I   
[Bb] Keep a [F]talkin' to yo[C]u   
[Bb] Keep a [F]talkin' to yo[C]u
[Bb] Keep a [F]talkin' to yo[C]u
[Bb] Keep a [F]talkin' to yo[C/]u

______________________________________










