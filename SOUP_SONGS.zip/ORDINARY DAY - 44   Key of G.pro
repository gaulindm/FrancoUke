{title: ORDINARY DAY}
{subtitle:   4/4   Key of G}
{subtitle:  (Great Big Sea)}
{metronome: 130}

{c: INTRO:}
G ////   C ////   G ////   C ///
 

[C]I've got a [G]smile on my face 
And I've got [C]four walls around me [G]   [C] ////
I've got the [G]sun in the sky
And all the [C]waters surround me
[G]Oh, you [D]know...
Yeah, I [G]win now, but sometimes I [C]lose
I've been [G]battered, but I never [C]bruise
It's not so [Am7]bad  [D] and I say

{soc}
[G]Way, hey hey it's just an [C]ordinary [D]day
And it's [G]all your [C]state of [D]mind
At the [G]end of the day
You [C]just got to [D]say it's al[G]right
{eoc}
[C]//// [G]//// [C]//// [G]///
 
Janey [G]sings on the corner
What [C]keeps her from dying? [G]ooo-ooo-[C]oo-ooh
Let 'em [G]say what they want
[C]She won't stop trying
[G]Oh, you [D]know...
She might [G]stumble, if they push her a[C]round
She might [G]fall, but she'll never lie [C]down
It's not so [Am7]bad  [D]and I say

{soc}
[G]Way, hey hey it's just an [C]ordinary [D]day
And it's [G]all your [C]state of [D]mind
At the [G]end of the day
You [C]just got to [D]say it's al[G]right 
[C]////  It's al[G]right, it's al[C]right
It's al[D]right
{eoc}

{c:INSTRUMENTAL}
 [C]////  [D]//  [G]//// [D]//// [G]//  [C]//// 
 [D]// [G]//// [C]//// [G]//// [C]///

In this [G]beautiful life
There's [C]always some sorrow [G]ooo-ooo-[C]oo-ooh
And it's a [G]double-edged knife
But there's [C]always tomorrow
[G]Oh, you [D]know...
It's up to [G]you now, if you sink or [C]swim 
Just keep the [G]faith that your ship will come [C]in
It's not so [Am7]bad  [D]and I say
 
{soc}
[G]Way, hey hey it's just an [C]ordinary [D]day
And it's [G]all your [C]state of [D]mind
At the [G]end of the day
You [C]just got to [D]say
I say 
[G]Way, hey hey it's just an [C]ordinary [D]day
And it's [G]all your [C]state of [D]mind
At the [G]end of the day
You [C]just got to say it's al[G]right
[C]////  It's al[G]right, it's al[C]right
{eoc}
Cause I've got a [G]smile on my face, 
And I've got [C]four walls around [G]me.
