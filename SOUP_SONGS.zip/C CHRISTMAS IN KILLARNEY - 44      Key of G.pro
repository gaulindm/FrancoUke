

{title:C06: CHRISTMAS IN KILLARNEY }
{subtitle:    4/4      Key of G}
{subtitle: (Frank Weldon & John Redmond)}
{time: 1:45 }
{metronome: 134 }


{soc}
   The [G]holly green the ivy green
   The [C]prettiest picture you’ve [G]ever seen
   Is [C]Christmas in Kil[G]larney
   With [D7]all of the folks at [G]home

   It's nice you know to kiss your beau
   While [C]cuddling under the [G]mistletoe
   And [C]Santa Claus you [G]know of course
   Is [D7]one of the boys from [G]home

   [Em]The door is always open
   The neighbours pay a [G]call
   And [D]Father John before he's gone
   Will [A7]bless the house and [D7]all

   How [G]grand it feels to click your heels
   And [C]join in the fun of the [G]jigs and reels
   I’m [C]handing you no [G]blarney 
   The likes you’ve never [C]known
   Is Christmas in [G]Killarney 
   With [D7]all of the folks at [G]home
{eoc}


{soc}
   The [G]holly green the ivy green
   The [C]prettiest picture you’ve [G]ever seen
   Is [C]Christmas in Kil[G]larney
   With [D7]all of the folks at [G]home

   It's nice you know to kiss your beau
   While [C]cuddling under the [G]mistletoe
   And [C]Santa Claus you [G]know of course
   Is [D7]one of the boys from [G]home

   [Em]The door is always open
   The neighbours pay a [G]call
   And [D]Father John before he's gone
   Will [A7]bless the house and [D7]all

   How [G]grand it feels to click your heels
   And [C]join in the fun of the [G]jigs and reels
   I’m [C]handing you no [G]blarney 
   The likes you’ve never [C]known
   Is Christmas in [G]Killarney 
   With [D7]all of the folks at [G]home
{eoc}


[C]It's Christmas in [G]Killarney 
with [D7]all of the folks at [G/]home
















