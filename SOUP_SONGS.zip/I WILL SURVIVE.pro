{title:I WILL SURVIVE}
{subtitle:4/4      Key of Dm}
{subtitle:  Dino Fekaris}
{time: 3:40 }
{metronome:  }


At [Dm/]first I was afraid, I was [Gm/]petrified
Kept thinking [C7/]I could never live without you [F/]by my side
But then I [Dm/]spent so many nights 
Thinking [Gm/]how you did me wrong
I grew [A/]strong, and I learned [A7/]how to get along
 
And so you're [Dm]back, from outer [Gm]space
I just walked [C7]in to find you here 
With that sad [F]look upon your face
I should have [Dm]changed that stupid lock 
I should have [Gm]made you leave your key
If I'd have [A]known for just one second 
You'd be [A7]back to bother me
 
Go on now [Dm]go, walk out the [Gm]door
Just turn a[C7]round now 
'Cause you're not [F]welcome anymore
[Dm] Weren't you the one who tried to 
[Gm]Hurt me with goodbye
Did you think I'd [A]crumble
Did you think I'd [A7]lay down and die

{soc} 
  Oh no, not [Dm]I,      I will sur[Gm]vive
  Oh as [C7]long as I know how to love 
  I [F]know I'll stay alive
  I've got [Dm]all my life to live 
  I've got [Gm]all my love to give
  And I'll [A]survive, I will [A7]survive
  Hey [Dm]hey {c:(234)}  [Gm]/ / / / 
  [C7]/ / / /    [F]/ / / /    
  [Dm]/ / / /    [Gm]/ / / /    
  [A]/ / / /     [A7]/ / / /  
{eoc}
 
It took [Dm]all the strength I had not to [Gm]fall apart
Just trying [C7]hard to mend the pieces 
Of my [F]broken heart
And I spent [Dm]oh so many nights 
Just feeling [Gm]sorry for myself
I used to [A]cry
But now I [A7]hold my head up high

And you see [Dm]me somebody [Gm]new
I'm not that [C7]chained up little person 
Still in [F]love with you
And so you [Dm]felt like dropping in 
And just ex[Gm]pect me to be free
Now I'm [A]saving all my loving 
For some[A7]one who's loving me

Go on now [Dm]go walk out the [Gm]door
Just turn a[C7]round now 
'Cause you're not [F]welcome anymore
[Dm]  Weren't you the one who tried to 
[Gm]Break me with goodbye
Did you think I'd [A]crumble
Did you think I'd [A7]lay down and die

{soc} 
  Oh no, not [Dm]I, I will sur[Gm]vive
  As [C7]long as I know how to love 
  I [F]know I'll stay alive
  I've got [Dm]all my life to live
  I've got [Gm]all my love to give
  And I'll [A]survive, I will [A7]survive
  Hey [Dm/]hey
{eoc}
