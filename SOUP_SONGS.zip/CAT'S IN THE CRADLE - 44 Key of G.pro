{title:CAT'S IN THE CRADLE (SOUP JAM May 11)}
{subtitle: 4/4 Key of G}
{subtitle: Harry Chapin}{metronome:135}
{time: 3:25}
{c:Bb  /  /   Dm / /   G  /  /  /  /    }
{c:Bb  /  /   Dm / /   G  /  /  /  /     /  /  /  /}
[G]My child arrived just the [Bb]other day
He [C]came to the world in the [G]usual way
But there were planes to catch 
and [Bb]bills to pay
[C]  He learned to walk while I [G]was away
And he was [F]talkin' 'fore I knew it 
and [Dm]as  he grew
He'd say [Bb]I'm gonna [Dm]be like [G]you dad
You [Bb]know I'm gonna [Dm]be  like [G]you

And the [G]cat's in the cradle 
and the [F]silver spoon
[Bb]Little boy blue 
and the [C]man in the moon
[G]When you comin' home dad 
I [F]don't know when
But [Bb]we'll get to[Dm]gether [G]then son
You [Bb]know we'll have a [Dm]good time [G]then

My son turned ten just the [Bb]other day
He said [C]Thanks for the ball Dad 
come [G]on let's play
Can you teach me to throw I said [Bb]not today
I got a [C]lot to do he said [G]that's ok
And he [F]walked away 
but his [Dm]smile never dimmed
And said [Bb]I'm gonna [Dm]be  like [G]him yeah
You [Bb]know I'm gonna [Dm]be   like [G]him

And the cat's in the cradle 
and the [F]silver spoon
[Bb]Little boy blue and the [C]man in the moon
[G]When you comin' home dad 
I [F]don't know when
But [Bb]we'll get to[Dm]gether [G]then son
You [Bb]know we'll have a [Dm]good time [G]then

Well my son came from college 
just the [Bb]other day
So [C]much like a man I just [G]had to say
Son I'm proud of you can you [Bb]sit for a while
[C]   He shook his head and [G]he said with a smile
What I'd [F]really like Dad is to 
[Dm] borrow the car keys
[Bb]See you [Dm]later can I [G]have them please

And the cat's in the cradle and the [F]silver spoon
[Bb]Little boy blue and the [C]man in the moon
[G]When you comin' home dad I [F]don't know when
But [Bb]we'll get to[Dm]gether [G]then son
You [Bb]know we'll have a [Dm]good time [G]then

I've long since retired my [Bb]son's moved away
[C]   I called him up just the [G]other day
I said I'd like to see you if [Bb]you don't mind
He said I'd [C]love to Dad if I could [G]find the time
You see my [F]new job's a hassle 
and the [Dm]kids have the flu
But it's [Bb]sure nice [Dm]talking to [G]you Dad
It's been [Bb]sure nice [Dm]talking to [G]you

And as I [F]hung up the phone it o[Dm]ccurred to me
He'd [Bb]grown up [Dm]just like [G]me 
my [Bb]boy was [Dm]just like [G]me

And the cat's in the cradle and the [F]silver spoon
[Bb]Little boy blue and the [C]man in the moon
[G]When you comin' home son I [F]don't know when
But [Bb]we'll get to[Dm]gether [G]then Dad
You [Bb]know we'll have a [Dm]good time [G]then[G/]
