{title: IN MY LIFE  }
{subtitle: Lennon/McCartney (Beatles)}
{subtitle: 4/4      Key of A
{time: 3:00}
{metronome:112  }



{c:INTRO:}
[A]/ / / /    [E7]/ / / / 
[A]/ / / /    [E7]/ / / /

There are [A]places [E7]I    re[F#m]member
All my [D]li-i-i-[Dm]ife, though [A]some have changed
Some for[A]ever, [E7]not for [F#m]better
Some have [D]go-o-o-[Dm]one and [A]some remain
All these [F#m]places have their [D]moments
With [G]lovers and friends I [A]still can recall
Some are [F#m]dead and some are [B7]living
In [Dm]my life, I've [A]loved them all

[A]/ / / /    [E7]/ / / /

But of [A]all these [E7]friends and [F#m]lovers
There is [D]no [Dm]one com[A]pares with you
And these [A]memories [E7]lose their [F#m]meaning
When I [D]think of [Dm]love as [A]something new
Though I [F#m]know I'll never lose a[D]ffection
For [G]people and things that [A]went before
I [F#m]know I'll often stop and think a[B7]bout them
In [Dm]my life, I [A]love you more

[A]/ /     [E7]/ /      [F#m]/ / / /  
[D]/ /     [Dm]/ /      [A]/ / / /
[A]/ /     [E7]/ /      [F#m]/ / / /  
[D]/ /     [Dm]/ /      [A]/ / / /

Though I [F#m]know I'll never lose a[D]ffection
For [G]people and things that [A]went before
I [F#m]know I'll often stop and think a[B7]bout them
In [Dm]my life, I [A]love you more

[A]/ / / /    [E7]/ / / /

In [Dm/]my life... I love you 
[A]more {c:(234)}    [E7]/ / / /   [A] /