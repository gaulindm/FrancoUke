{title: LOOKIN' OUT MY BACK DOOR   }
{subtitle:(4/4   Key of G)}
{subtitle:(Creedence Clearwater Revival)}
{time:3:00}
{metronome: 190}








{c:INTRO:}
Z / / / /    / / / /    / / / /    / / / /      
[F]/ / / /    [C]/ / / /    
[G]/ / / /      [C]/ / / /

[C]Just got home from Illinois 
[Am]Lock the front door, oh boy
[F]Got to set [C]down take a [G]rest on the porch
I[C]magination sets in, [Am]pretty soon I'm singin'
[F]Doo doo [C]doo looking [G]out my back [C]door

There's a [C]giant doing cartwheels
A [Am]statue wearin' high heels
[F]Look at all the [C]happy creatures 
[G]Dancing on the lawn
[C]Dinosaur victrola [Am]list'ning to Buck Owens
[F]Doo doo [C]doo looking [G]out my back [C]door

{c:CHORUS}
{soc}
[G]Tambourines and elephants, are 
[F]Playing in the [C]band
Won't-you-take a ride [Am]on the flyin' [G]spoon 
(doot'n doo doo)
[C]Wond'rous apparition pro[Am]vided by magician
[F]Doo doo [C]doo lookin' [G]out my back [C]door
{eoc}

{c:INSTRUMENTAL}
Z  / / / /    / / / /    / / / /    / / / /    
[C]/ / / /    / / / /     [Am]/ / / /   / / / /
[F]/ / / /      [C]/ / / /     [G]/ / / /    / / / /    
[C]/ / / /    / / / /     [Am]/ / / /   / / / /     
[F]/ / / /      [C]/ / / /     [G]/ / / /     [C]/ / / /

{soc}
[G]Tambourines and elephants, are 
[F]Playing in the [C]band
Won't-you-take a ride [Am]on the flyin' [G]spoon 
(doot'n doo doo)
[C]Wond'rous apparition pro[Am]vided by magician
[F]Doo doo [C]doo lookin' [G]out my back [C]door
{eoc}

[C]Forward troubles Illinois 
[Am]lock the front door, oh boy
[F]Look at all the [C]happy creatures 
[G]Dancing on the lawn

{c:(Big slow down)}
[C]Bother me tomorrow 
[Am]Today I'll find no sorrows
[F]Doo doo [C]doo looking 
[G]Out my back [C/]door {c(234)}

{c:OUTRO: (back up to speed)}
Z  / / / /    / / / /     [F]/ / / /     [C]/ / / /    
[G]/ / / /     [C]/    [G]/    [C]/ 

