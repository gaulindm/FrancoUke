{title:Wild World}
{subtitle:Cat Stevens/Maxi Priest}
{subtitle:4/4




[Am] La-la-la-[D7]la-la-la-la-la, la, [G]la
 La-la-la-[C]la-la-la-la-la, la, [F]la
 La-la-la-[Dm]la-la-la-la-la, la,la, [E7]la-la, 
 
[Am]  Now that I’ve [D7]lost everything to [G]you, 
you say you[C] wanna start something[F] new
And it’s [Dm]breaking my heart you’re 
[E7]leaving baby I’m griev-ing
[Am]  But if you wanna [D7]leave, take good [G]care
Hope you have a [C]lot of nice things to [F]wear
           
But then a [Dm]lot of nice things turn [E7]bad, 
out [G]there [G7/] [Em7/] [G/] [C]
 
[C] Oh, b[G]aby, baby it’s a w[F]ild world
[G]  It’s hard to get [F]by, just upon a [C]smile
[C] Oh, b[G]aby, baby it’s a w[F]ild world
[G]  I’ll always re[F]member you like a [C]child girl [Dm] [E7]
 
[Am]  You know I’ve seen a [D7]lot of what the world can [G]do
And it’s [C]breaking my heart in [F]two
But I [Dm]never want to see you [E7]sad girl

Don’t be a bad  girl


[Am]  But if you want to [D7]leave, take good [G]care
Hope you make a [C]lot of nice friends out [F]there
    
But just re[Dm]member there’s a lot of bad 
[E7]and be[G]ware [G7/] [Em7/] [G/] [C]
 
[C] Oh, b[G]aby, baby it’s a w[F]ild world
[G]  It’s hard to get [F]by, just upon a [C]smile
[C] Oh, b[G]aby, baby it’s a w[F]ild world
[G]  I’ll always re[F]member you like a [C]child girl [Dm] [E7]

[Am]...la-la-la-[D7]la-la-la-la, la, [G]la
La-la-la-[C]la-la-la-la-la la la-la, [F]la
La-la-la-la-[Dm]la-la-la-la la la [E7]la-la, 
Baby, I [E7]love you
[Am]  But if you want to [D7]leave, take good [G]care
Hope you make a [C]lot of nice friends out [F]there
         
But just re[Dm]member there’s a lot of bad 
[E7]and be[G]ware [G7/] [Em7/] [G/] [C]
 
[C] Oh, b[G]aby, baby it’s a w[F]ild world
[G]  It’s hard to get [F]by, just upon a [C]smile
[C] Oh, b[G]aby, baby it’s a w[F]ild world
[G]  I’ll always re[F]member you like a [C]child girl [Dm] [E7]

[C] Oh, b[G]aby, baby it’s a w[F]ild world
[G]  It’s hard to get [F]by, just upon a [C]smile
[C] Oh, [G]baby, baby it’s a [F]wild world
[G]  I’ll always re[F]member you like a [C]child [C]girl 
Slow down on "child girl"
