{title:HERE COMES THE SUN }  
{metronone: 132}
{time:2:45}





{c:(INTRO RIFF)}


[G] Here comes the sun  {c:(RIFF)}  (doot 'in doo doo)      
                                                                      
[C] Here comes the [A7]sun, and I say  
[G] It’s all ri[G/]ght     
{c:RIFF}

[G]  Little darling, it’s been a 
[C]Long, cold, lonely [D7]winter  {c:(RIFF)}
                                                             
[G]  Little darling, it feels like 
[C]Years since it’s been [D7]here  
                                                                   
[G]  Here comes the sun {c:(RIFF)}  (doot 'in doo doo) 
[C]  Here comes the [A7]sun, and I say  
[G]  It’s all ri[G/]ght   

{c:RIFF}

[G]  Little darling, the smiles 
Re[C]turning to their [D7]faces  {c:(RIFF)}
                                                           
[G]  Little darling, it seems like 
[C]Years since it’s been [D7]here
                                                                   

[G]  Here comes the sun {c:(RIFF)}   
[C]  Here comes the [A7]sun, and I say 
[G]  It’s all ri[G/]ght  {c:(RIFF)}  

[G]/ / / /    [D7]/ / / /

[Bb/]Sun, [F/]sun, [C/]sun here it [G]comes {c:(234)}  [D7]/ / / /

[Bb/]Sun, [F/]sun, [C/]sun here it [G]comes {c:(234)}  [D7]/ / / /

[Bb/]Sun, [F/]sun, [C/]sun here it [G]comes {c:(234)}  [D7]/ / / /

[Bb/]Sun, [F/]sun, [C/]sun here it [G]comes {c:(234)}  [D7]/ / / /

[Bb/]Sun, [F/]sun, [C/]sun here it [G]comes {c:(234)}  [D7]/ / / /
    
[D7*]/ /     [D7]/ /     [C]/ / / /    [D]/ / / /

[G] Little darling, I feel that 
[C]Ice is slowly [D7]melting  {c:(RIFF)}
                                                             
[G] Little darling, it seems like 
[C]years since it’s been [D7]clear  

[G] Here comes the sun {c:(RIFF)}  
[C] Here comes the [A7]sun, and I say 
[G] It’s all ri[G/]ght   {c:(RIFF)}

[G] Here comes the sun {c:(RIFF)}   
[C] Here comes the [A7]sun, and I say 
[G] It’s all ri[G/]ght   {c:(RIFF)}
[G] It's all ri[G/]ght  {c:(RIFF)} 

[Bb/]   [F/]      [C/]            [G(gliss)]


{define: D7* 0 2 0 3 0}