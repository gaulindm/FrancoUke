

{title:015   COVER OF THE}
{title: ROLLING STONE }
{subtitle:(4/4     Key of A)}
{subtitle:(Shel Silverstein)}
{time:3:14}
{metronome:146}






[E7]/ / / /    / / / /     
[D]/ / / /    [A]/ / / 

Well we’re [A]big rock singers 
We've got golden fingers
And we're loved everywhere we [E7]go
We sing about beauty and we sing about truth
At ten thousand dollars a [A]show
We take all kind of pills 
To give us all kind of thrills
But the [A7]thrill we've never [D]known
Is the [E7]thrill that'll get you 
When you get your picture
On the cover of the Rolling [A/]Stone

{soc}
(Rolling [E7]Stone) 
Wanna see my picture on the cover
([A]Stone) Wanna buy five copies for my mother
([E7]Stone) Wanna see my smilin' face
On the [D]cover of the Rolling [A]Stone 
{eoc}

I've got a [A]freaky ol' lady name a Cocaine Katy
Who embroiders on my [E7]jeans
I've got my poor old gray-haired Daddy 
Drivin' my limou[A]sine
Now it's all designed to blow our minds
But our [A7]minds won't really be [D]blown
Like the [E7]blow that'll get you 
When you get your picture
On the cover of the Rolling [A/]Stone    

{soc}
(Rolling [E7]Stone) 
Wanna see my picture on the cover
([A]Stone) Wanna buy five copies for my mother
([E7]Stone) Wanna see my smilin' face
On the [D]cover of the Rolling [A]Stone 
{eoc}     

We got a [A]lot of little teenage
Blue-eyed groupies
Who'll do anything we [E7]say
We got a genuine Indian guru 
Who's teachin' us a better [A]way
We got all the friends that money can buy
So we [A7]never have to be a[D]lone
And we [E7]keep gettin' richer 
But we can't get our picture
On the cover of the Rolling [A/]Stone            

{soc}
(Rolling [E7]Stone) 
Wanna see my picture on the cover
([A]Stone) Wanna buy five copies for my mother
([E7]Stone) Wanna see my smilin' face
On the [D]cover of the Rolling [A]Stone 

(Rolling [E7]Stone) 
Wanna see my picture on the cover
[A](Stone) Wanna buy five copies for my mother
[E7](Stone) Wanna see my smilin' face
On the [D]cover of the Rolling [A/]Stone 
{eoc}

_____________________________________











   