{title:BLUE WATER LINE  }
{subtitle:(4/4   Key of C)}
{subtitle:(Martin Seligson)}
{time: 3:40}
{metronome: 178}








{c:INTRO:}
[C]/ / / /    / / / /     
[G7]/ / / /      [C]/ / / 
  
The [C]City Council met last week the 
[F]Vote was four to [C]three
To tear the home town depot down and 
[G7]Build a factory
To [C]take that stretch of history and 
[F]Tear it off the [C]map
To take old engine number nine and 
[G7]Turn it into [C]scrap  {c:(234)}
 
{c:CHORUS:}
{soc}
     [C]    Blue Water, Blue Water
     [F]    Blue Water [C]Line
     [C]    Blue Water, Blue Water 
     [G7]    Blue Water Line
     If you [C]can't afford a quarter, then you 
     [F]ought to give a [C]dime
     If [F]everybody gave then [C]we could save the 
     [G7]      Blue Water [C]Line  {c:(234,123)}
{eoc}
 
Oh, [C]I could tell you stories of the 
[F]Glories of that [C]train
Of the '49er miners and the 
[G7]Time old Jesse James stole a 
[C]thousand golden nuggets in that 
[F]Great train robbe[C]ry
And when old Abe Lincoln rode with 
[G7]Tad upon his [C]knee {c:(234)}

{soc}
     [C]    Blue Water, Blue Water
     [F]    Blue Water [C]Line
     [C]    Blue Water, Blue Water 
     [G7]    Blue Water Line
     If you [C]can't afford a quarter, then you 
     [F]ought to give a [C]dime
     If [F]everybody gave then [C]we could save the 
     [G7]      Blue Water [C]Line  {c:(234,123)}
{eoc}
 
Just [C]twenty thousand quarters and 
[F]Forty thousand [C]dimes
We'll ride again to glory on that 
[G7]Old Blue Water Line
We'll have [C]William Jennings Bryan stokin' 
[F]coal on number [C]nine
So dig inside your pockets for the 
[G7]Old Blue Water [C]Line {c:(234)}

{soc}    
     [C]    Blue Water, Blue Water
     [F]    Blue Water [C]Line
     [C]    Blue Water, Blue Water 
     [G7]    Blue Water Line
     If you [C]can't afford a quarter, then you 
     [F]ought to give a [C]dime
     If [F]everybody gave then [C]we could save the 
     [G7]      Blue Water [C]Line  {c:(234)

{soc}
     [C]    Blue Water, Blue Water
     [F]    Blue Water [C]Line
     [C]    Blue Water, Blue Water 
     [G7]    Blue Water Line
     If you [C]can't afford a quarter, then you 
     [F]ought to give a [C]dime
     If [F]everybody gave then [C]we could save the 
     [G7]      Blue Water [C]Line  {c:(2,3)}
{eoc}
 
If [F]everybody gave then [C]we could save the 
[G7]  Blue Water [C]Line [G7/] [C/]

