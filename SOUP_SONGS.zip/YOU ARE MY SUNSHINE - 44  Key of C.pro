{title: YOU ARE MY SUNSHINE }
{subtitle:  4/4  Key of C   } 
{metronome: 162 }
{time:3:30 }                                              

[C]/ / / /   [G7]/ / / /      [C]/ / / /   /   {c:(stop)}

{c:CHORUS:}
{soc}
     You are my [C]sunshine, my only [C7]sunshine 
     You make me [F]happy when skies are [C]gray 
     You'll never [F]know dear, how much I [C]love you [Am]
     Please don't [C]take my [G7]sunshine a[C]way 
{eoc}

The other [C]night dear, as I lay [C7]sleeping 
I dreamed I [F]held you in my [C]arms 
But when I a[F]woke dear, I was mis[C]taken [Am]
So I [C]hung my [G7]head and I [C]cried 

{soc}
     You are my [C]sunshine, my only [C7]sunshine 
     You make me [F]happy when skies are [C]gray 
     You'll never [F]know dear, how much I [C]love you [Am]
     Please don't [C]take my [G7]sunshine a[C]way 
{eoc}

I'll always [C]love you and make you happy [C7]
If you will [F]only say the [C]same 
But if you [F]leave me and love a[C]nother [Am]
You'll [C]regret it [G7]all some [C]day  

{soc}
     You are my [C]sunshine, my only [C7]sunshine 
     You make me [F]happy when skies are [C]gray 
     You'll never [F]know dear, how much I [C]love you [Am]
     Please don't [C]take my [G7]sunshine a[C]way 
{eoc}

You told me [C]once, dear, you really loved me [C7]
And no one [F]else could come bet[C]ween 
But noW you've [F]left me and love ano[C]ther [Am]
You have [C]shattered [G7]all my [C]dreams 

{soc}
     You are my [C]sunshine, my only [C7]sunshine 
     You make me [F]happy when skies are [C]gray 
     You'll never [F]know dear, how much I [C]love you [Am]
     Please don't [C]take my [G7]sunshine a[C]way  
     Please don't [C]take my [G7]sunshine a[C]way   [G7/]  [C/]
{eoc}