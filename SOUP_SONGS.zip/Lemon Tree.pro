{title:  Lemon Tree}
            



[Intro]
Am  Em  Am  Em  Dm  Em  Am  Em  Am 


[Verse 1]
I'm si[Am]tting here in a[Em] boring room,
It's [Am]just another rainy Sunday [Em]afternoon.
I'm [Am]wasting my time,[Em] I got nothing to do.
I'm [Am]hanging around, I'm[Em] waiting for you,
But [Dm]nothing ever [Em]happens 
- and I [Am]wonder.  [Em] [Am]

I'm dr[Am]iving around in[Em] my car,
I'm d[Am]riving too fast, I'm drivi[Em]ng too far.
I'd [Am]like to change m[Em]y point of view
I fe[Am]el so lonely, I'm w[Em]aiting for you
But [Dm]nothing ever [Em]happens 
- and I [Am]wonder.  [Em] [Am]

[Chorus]
I w[C]onder how, I w[G]onder why
[Am]Yesterday you told me 'bout the [Em]blue blue sky
And [F]all that I can [G]see is 
just a yellow [C]lemon tree. [G7]
I'm [C]turning my head [G]up and down,
[Am]I'm turning turning turning turning 
[Em]turning around
And [F]all that I can [F#dim7]see is 
just another [G]lemon tree. [G7]

[Interlude]
 Am  Am  Em  Em  Am  Am  Em  Em  
Dm  Dm  Em  Em  Am  Em  Am
Dam     dadoudi....

[Verse 2]
I'm si[Am]tting here, I m[Em]iss the power.
I'd l[Am]ike to go out, t[Em]ake in a shower,
But [Am]there's a heavy cloud [Em]inside my head.
I fe[Am]el so tired, put my[Em]self into bed,
But [Dm]nothing ever [Em]happens 
- and I [Am]wonder.  [Em] [Am]

[Bridge]
[E]Isolation - [Am]Is not good for me,
[G]Isolation - [C]I don't want to [E]sit on a lemon tree.

[Verse 3]
I'm [Am]stepping around in a [Em]desert of joy
[Am]Baby anyhow I'll get an[Em]other toy
But [Dm]nothing ever [Em]happens 
- and you [Am]wonder.  [Em] [Am]

[Chorus]
I w[C]onder how, I w[G]onder why
[Am]Yesterday you told me 'bout the [Em]blue blue sky
And [F]all that I can [G]see 
is just another [C]lemon tree. [G7]
I'm [C]turning my head [G]up and down,
[Am]I'm turning turning turning turning 
[Em]turning around
And [F]all that I can [F#dim7]see 
is just a yellow [G]lemon tree. [G7]

[Outro]
I [C]wonder how, I [G]wonder why
[Am]Yesterday you told me 'bout the [Em]blue blue sky
And [F]all that I can [G]see, 
and [F]all that I can [G]see,
And [F]all that I can [G]see 
is just a yellow [C]lemon tree.

