{title:DREAMS}
{subtitle:Fleetwood Mac}



[F]/ / / /     [G]/ / / /     
[F]/ / / /     [G]/ / / /     

[F]  Now there you [G]go again, you say [F]  you want your free-[G]dom
[F]  Well who am [G]I to keep you down  [F]  [G]
[F]  It's only ri-[G]ight that you should [F]play the way you [G]feel it, but [F]listen careful-[G]ly to the so-[F]ound
Of your [G]loneliness

Like a [F]heartbeat drives you [G]mad
In the [F]stillness of re-[G]membering what you had  [F]  [G]
And what you lost,  [F]  [G]    and what you had, [F]  [G]     and what you lost  [F]  [G]

[Am]Thunder only [G]happens when it's [F]raining  [G]
[Am]Players only [G]love you when they're [F]playing  [G]
Say [Am]women, they will [Am]come and they will [F]go   [G]
[Am]When the rain wa-[G]shes you clean you'll [F]know   [G][F][G][F][G]

[F]  Now here I [G]go again, I see [F]the crystal vi-[G]sons        
[F]  I keep my [G]visons to my- [F]self     [G]
[F]It's only me-[G]e who wants to [F]wrap around your [G]dreams and            
[F]Have you any dre-[G]ams you'd like to [F]sell

Like a [F]heartbeat drives you [G]mad
In the [F]stillness of re-[G]membering what you had  [F]  [G]
And what you lost,  [F]  [G]    and what you had, [F]  [G]     and what you lost  [F]  [G] 

[Am]Thunder only [G]happens when it's [F]raining  [G]
[Am]Players only [G]love you when they're [F]playing  [G]
Say [Am]women, they will [Am]come and they will [F]go  [G]
[Am]When the rain wa-[G]shes you clean you'll [F]know [G]   [F]

Oh [Am]thunder only [G]happens when it's [F]raining  [G]
[Am]Players only [G]love you when they're [F]playing  [G]
Say [Am]women, they will [Am]come and they will [F]go  [G]
[Am]When the rain wa-[G]shes you clean you'll [F]know
[G]You'll [F]know  
[G]You will [F]know  
[G]You'll [F]know  [G] [F] [G]  [F] [G/]