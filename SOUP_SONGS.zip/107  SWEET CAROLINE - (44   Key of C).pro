

{title:107  SWEET CAROLINE}
{subtitle:(4/4   Key of C)}
{subtitle:(Neil Diamond)}
{time:4:00}
{metronome:132}

{c:RIFF (***)}

{c:(high G string)    (high or low G string)}
{sot}  
A| - 3 - -      - - 3 - - -
E| - - - -      - 3 - 3 - -
C| - - - -      - - - - - -
G| 0 - 0 -      - - - - - -
{eot}

{c:INTRO:}
[Dm]Do-do-doo, do do do-do-do, do-do-do                                             
Do-do-doo, do do do-do-do, do-do-do 
                                                                            
Do-do-doo, do do   [F/]doo   [Em/]doo   
[Dm/]Doo   [G7/]doo                                          
                                                                                                         
{c:(}[C]{c:12)}   Where it began, {c:(***)   }
{c:(}[F]{c:12)} I can’t begin to knowin’                
{c:(}[C]{c:12)}   But then I know it’s goin’ [G]strong                                       

{c:(}[C]{c:12)}   Was in the spring, {c:(***)   }
{c:(}[F]{c:12)} Then spring became a summer      
{c:(}[C]{c:12)}   Who’d have believed 
You’d come a[G]long     
            
[C]Hands…{c:(234,1234)}    
[Am]  Touching hands
{c:(}[G]{c:12)} Reaching out {c:(234)}    
{c:(}[F]{c:12)}  Touching me, touching  
[G7]You {c:(234,1)}   [G7/]       [F/]     [G7/]
 
[C]Sweet Caro[F/]line,  [F/]Ba,  [Am/]Ba,    [F]Ba
Good times never seemed so 
[G7]Good (so good, so good)  [G7/]       [F/]     [G7/]
[C]I’ve been in[F/]clined, [F/]Ba,  [Am/]Ba,    [F]Ba 
To believe they never 
[G/]Would  [F/]but  [Em/]now  [Dm/]I 
  
{c:(}[C]{c:12)}  Look at the night, {c:(***)   }
{c:(}[F]{c:12)} And it don’t seem so lonely
{c:(}[C]{c:12)}  We fill it up with only [G]two 

{c:(}[C]{c:12)}   And when I hurt, {c:(***) }  
{c:(}[F]{c:12)}  hurtin’ runs off my shoulder
{c:(}[C]{c:12)}   How can I hurt when holding [G]you 

[C]Warm… {c:(234,1234)}  
[Am]  Touching warm {c:(234)}
{c:(}[G]{c:12)} Reaching out {c:(234)}   
{c:(}[F]{c:12)}  Touching me, touching 
[G7]You {c:(234,1)}   [G7/]       [F/]     [G7/]

[C]Sweet Caro[F/]line, [F/]Ba, [Am/]Ba,    [F]Ba
Good times never seemed so 
[G7]Good (so good, so good) [G7/]       [F/]     [G7/]
[C]I’ve been in[F/]clined, [F/]Ba,  [Am/]Ba,    [F]Ba 
To believe they never 
[G/]would  [F/]oh  [Em/]no  [Dm/]no 

[Dm]Do-do-doo, do do do-do-do, do-do-do
Do-do-doo, do do do-do-do, do-do-do
Do-do-doo, do do   [F/]doo   [Em/]doo   
[Dm/]Doo   [G7/]doo

[C]Sweet Caro[F/]line,  [F/]Ba,  [Am/]Ba,    [F]Ba 
Good times never seemed so 
[G7]Good (so good, so good) [G7/]        [F/]      [G7/]
[C]I’ve been in[F/]clined,  [F/]Ba,  [Am/]Ba,    [F]Ba 
To believe they never 
[G/]Would [F/]oh [Em/]no [Dm/]no [C/gliss]

______________________________________










