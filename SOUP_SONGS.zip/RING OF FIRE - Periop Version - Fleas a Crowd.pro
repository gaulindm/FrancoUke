{title:RING OF FIRE - Periop Version }
{subtitle: Fleas a Crowd}
{metronome: 172}
{time: 3:30}






{c:INTRO: (kazoos)}  
[G]/ / / /    [C]/ /     [G]/ / / /    / / / /    
[G]/ / / /    [D7]/ /    [G]/ / / /    / / / /

My [G]hemmroids were [C]out of [G]hand
{c:(do-do  do-do} [C]{c:do do} [G]{c:dooo (234,123)}
So I [G]went to see the [D7]procto [G]man
{c:(do-do  do-do} [D7]{c:do do} [G]{c:dooo (234,1234)}
He [G]said it was [C]no big [G]deal
{c:(do-do  do-do} [C]{c:do do}  [G]{c:dooo (234,1234)}
A little [G]snip I would [D7]hardly[G] feel

{soc}
But [D]I woke up with a [C]burning ring of [G]fire
and I [D]can’t sit down cause my [C]butts on [G]fire
and it burns, burns, burns
The [D]ring of [G]fire, the [D]ring of [G]fire{c:(234,1234)}
 {eoc}

{c:Instrumental: (kazoos)}
[G]/ / / /    [C]/ /     [G]/ / / /    / / / /    
[G]/ / / /    [D7]/ /    [G]/ / / /    / / / /

[G]/ / / /    [C]/ /     [G]/ / / /    / / / /    
[G]/ / / /    [D7]/ /    [G]/ / / /    / / / /


{soc}
But [D]I woke up with a [C]burning ring of [G]fire
and I [D]can’t sit down cause my [C]butts on [G]fire
and it burns, burns, burns
The [D]ring of [G]fire, the [D]ring of [G]fire{c:(234,1234)}
{eoc}

He [G]cut, then he cut [C]some [G]more 
{c:(do-do  do-do} [C]{c:do do} [G]{c:dooo (234,123)}
Man, my [D7]rear is [G]sore
{c:(do-do  do-do} [D7]{c:do do} [G]{c:dooo (234,1234)}
I’m a[G]voiding the  [C]toilet [G]seat
{c:(do-do  do-do} [C]{c:do do}  [G]{c:dooo (234,1234)}
[G]Haven’t gone for at [D7]least a [G]week

{soc}
But [D]I woke up with a [C]burning ring of [G]fire
and I [D]can’t sit down cause my [C]butts on [G]fire
and it burns, burns, burns
The [D]ring of [G]fire, the [D]ring of [G]fire{c:(234,1234)}
 
{eoc}

You’d [G]think, for an [C]extra [G]fee
{c:(do-do  do-do} [C]{c:do do} [G]{c:dooo (234,123)}
[G]He’d throw in a [D7]colosto[G]my
{c:(do-do  do-do} [D7]{c:do do} [G]{c:dooo (234,1234)}
I’ve been [G]sitting here [C]half the [G]night
{c:(do-do  do-do} [C]{c:do do}  [G]{c:dooo (234,1234)}
[G]Squattin’ on a load of [D7]dyna[G]mite

{soc}
But [D]I woke up with a [C]burning ring of [G]fire
and I [D]can’t sit down cause my [C]butts on [G]fire
and it burns, burns, burns
The [D]ring of [G]fire, the [D]ring of [G]fire{c:(234,1234)}
 
{eoc}

{soc}
But [D]I woke up with a [C]burning ring of [G]fire
and I [D]can’t sit down cause my [C]butts on [G]fire
and it burns, burns, burns
The [D]ring of [G]fire, the [D]ring of [G]fire 
{eoc}

{c:(234)}    {c:(}[G/]{c:Do, do-do, do-do, do do dooooo…)} 

{define: D7 0 2 0 2 0}

