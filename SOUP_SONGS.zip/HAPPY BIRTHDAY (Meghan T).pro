{title:HAPPY BIRTHDAY (Meghan T)}
[G/]   {c:(tap)} 
'Cause you know, we're [G]all about that uke 'bout that uke, happy strumming
We're [Am7]all about that uke, 'bout that uke, birthday strumming
We're [D7]all about that uke, 'bout that uke, happy birthday
We're [G]all about that uke, 'bout that [G/]uke (uke, uke, uke) 
{c:(tap)}
 
[G]  Happy birthday strummer, here's what we 'bout to do
[Am7] We'll play a birthday song, and sing it just for you
[D7]  It's special that you're here the least we can do
Is to [G/]celebrate your very special [G/]birthday with you
  
Cause it's [G]your day to get crazy, come on and celeb[Am7]rate
{c:               (Ooo...                                                   sha-oo bop bop, sha-oo bop-}
Let's get [D7]wild don't be shy baby, go 'head and shake your [G]cake  {c:(234,12)} 
{c:bop,      ooo...                                                           sha-oo bop bop, sha-oo)}

  'Cause you know, we're [G]All about that uke 'bout that uke, happy birthday
{c:(bop, bop                        birthday...   } 

We're [Am7]all about that uke 'bout that uke, happy birthday  
{c:         (birthday...         )}

We're [D7]all about that uke 'bout that uke, happy birthday
{c:         (birthday...          )}

We're [G]all about that uke 'bout that [G/]uke   HAPPY BIRTHDAY!
{c:         (birthday...          )}