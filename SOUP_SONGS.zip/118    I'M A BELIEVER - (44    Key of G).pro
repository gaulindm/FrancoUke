

{title:118    I'M A BELIEVER  }
{subtitle:(4/4    Key of G)}
{Subtitle:(Neil Diamond) }
{time:3:28}
{metronome:180}


 



 
[G]/ / / /     [D]/ / / /      
[G]/ / / /    / / / / 

[G]I thought love was [D]only true in [G]fairy tales 
Meant for someone [D]else but not for [G]me [G7] 
[C]  Love was out to [G]get me (do do do [C]do) 
That's the way it [G]seemed  (do do do [C]do) 
Disappointment [G]haunted all my [D]dreams [D/]

{c:CHORUS}
{soc}
   Then I saw her [G]face  [C]       [G]    
   Now [C]I'm a be[G]liever [C]     [G]  
   [C]Not a [G]trace  [C]      [G]     
   Of  [C]doubt in my [G]mind  [C]     [G] 
   [C]I'm in [G/]love (hmmm) [C/]Whoa 
   I'm a  be[G/]liever I couldn't [F/]leave her if I 
   [D]tried 
{eoc}

[G]I thought love was [D]more or less a [G]givin' thing
It seems the more I [D]gave the less I [G]got [G7] 
[C]What's the use in [G]tryin' (do do do [C]do)
All you get is [G]pain (do do do [C]do) 
When I needed [G]sunshine I got [D]rain [D/]

{soc}
     Then I saw her [G]face  [C]       [G]    
     Now [C]I'm a be[G]liever [C]     [G]  
     [C]Not a [G]trace  [C]      [G]     
     Of  [C]doubt in my [G]mind  [C]     [G] 
     [C]I'm in [G/]love (hmmm) [C/]Whoa 
     I'm a  be[G/]liever I couldn't [F/]leave her 
     If I [D]tried
     {eoc}

[G]/ / / /     [D]/ / / /      [G]/ / / /    / / / /   
[G]/ / / /     [D]/ / / /      [G]/ / / /    / / /  
   
Oh [C]    Love was out to [G]get me (do do do [C]do) 
that's the way it [G]seemed (do do do [C]do)
disappointment [G]haunted all my [D]dreams [D/]

{soc}
     Then I saw her [G]face  [C]       [G]    
     Now [C]I'm a be[G]liever [C]     [G]  
     [C]Not a [G]trace  [C]      [G]     
     Of  [C]doubt in my [G]mind  [C]     [G] 
     [C]I'm in [G/]love (hmmm) [C/]Whoa, 
     I'm a  be[G/]liever I couldn't [F/]leave her if I 
     [D]tried
     {eoc}

{soc}
     Then I saw her [G]fa-ace  [C]       [G]     
     Now  [C]I'm a be[G]liever [C]     [G]  
     [C]Not a [G]trace  [C]      [G]     
     Of  [C]doubt in my [G]mind  [C]     [G] 
     Well [C]I’m a be[G]liever yeah 
     [C]Yeah yeah [G]yeah yeah 
     [C]I’m a be[G]liever [C] [G]
     Yeah [C]I'm a be[G]liever  [C]  [G]    
     Yeah [C]I'm a be[G]liever  [C]  [G]   
     Yeah [C]I'm a be[G/]liever 
{eoc}


________________________________










