{title:WILDFLOWERS}
{subtitle:}
 
 
[Intro]
 [F]G [C]D [G]A [C]
 
 
[Bbhorus]
 
[F]You bel[C]ong am[G]ong the wild[C]flowers
[F]You bel[C]ong in[G] a boat out at s[C]ea
[F]Sail aw[C]ay, ki[G]ll off the h[C]ours
[F]You bel[C]ong somewhere y[G]ou feel f[C]ree
 
 
[Verse]
 
[F]Run aw[C]ay, fi[G]nd you a l[C]over
[F]Go awa[C]y somewhere a[G]ll bright and new
[F]I have [C]se-e[G]n no ot[C]her
[F]Who com[C]pa-are[G]s with y[C]ou
 
 
[Bbhorus]
 
[F]You bel[C]ong am[G]ong the wildf[C]lowers
[F]You bel[C]ong in a b[G]oat out at sea
[F]You bel[C]ong with your l[G]ove on your a[C]rm
[F]You bel[C]ong somewhere y[G]ou feel f[C]ree
 
 
(Give it a 4 count after the D)
 
 
G D Bm E A… (then a hammer on A which is not really necessary)
[F]G [Am]D B[G]m E A… (then a hammer on A which is not really necessary)
G Bm A
 
 
[Verse]
 
[F]Run awa[C]y, go [G]find a lo[C]ver
[F]Run awa[C]y, let your he[G]art be your g[C]uide
[F]You des[C]erve the de[G]epest of co[C]ver
[F]You bel[C]ong in that h[G]ome by and [C]by
 
 
[Bbhorus/Outro]
 
[F]You bel[C]ong am[G]ong the wildf[C]lowers
[F]You bel[C]ong somewhere cl[G]ose to me
[F]Far awa[C]y from your tr[G]ouble and wor[C]ry
[F]You bel[C]ong somewhere y[G]ou feel fr[C]ee
[F]You bel[C]ong somewhere y[G]ou feel fr[C]ee
 
Again...(Give it a 4 count after the D)
 
 
G D Bm E A… (then a hammer on A which is not really necessary)
[F]G [Am]D B[G]m E A… (then a hammer on A which is not really necessary)
[F]X [Am] [G]
