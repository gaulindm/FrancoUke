

{title:063  TEACH YOUR CHILDREN }
{subtitle:(4/4  Key of G)}
{subtitle:(Graham Nash)}
{time:3:54}
{metronome:160}

{c:Turn your tablet horizontal}

[G]/ / / /   / / / /    [C]/ / / /   / / / /   
[G]/ / / /   / / / /    [D]/ / / /     [D7]/ / / /

[G]You who are on the [C]road must have a 
[G]Code that you can [D]live by [D7] 
And [G]so become your[C]self because the [G]past 
Is just a [D]goodbye  [D7]

[G]Teach your children [C]well, their father's 
[G]Hell did slowly [D]go by [D7]
And [G]feed them on your [C]dreams
The one they [G]pick’s the one you'll [D]know by   [D7]
[G]  Don't you ever ask them [C]why 
If they told you you would [G]cry 
So just look at them and [Em]sigh… i- [C]igh…   [D/] 
And know they [G]love you {c:(4,1234)}  
[C]/ / / /    / / / /     [G]/ / / /   / / / /     [D]/ / / /    [D7]/ / / 

{soc}
And [G]you            of tender [C]years can't know the   
{c:      (Can you hear     and  do  you  care)  }
              
[G]Fears that your elders [D]grew by   [D7]    (and so please)
{c:(Do  you   see   you     must  be  free  to)}

[G]Help them with your  [C]youth,  they  seek  the  [G]truth     
{c:(Teach your children, you’ll believe    they’ll  make a )} 

 Before they [D]can die  [D7]
 {c: World that  we  can live in)}
{eoc}

[G]Teach your parents [C]well, their children's 
[G]Hell will slowly [D]go by [D7] 
And [G]feed them on your [C]dreams
The one they [G]pick’s the one you'll [D]know by   [D7]
[G]  Don't you ever ask them [C]why 
If they told you you would [G]cry 
So just look at them and  [Em]sigh… i- [C]igh…   [D/] 
And know they [G]love you  {c:(4,1234)}

[C]/ / / /    / / / /     [G]/ / / /    / / / /    
[D]/ / / /     [D7]/ / / /    [G]/


_______________________________
{define: D7 0 2 0 2 0}









