

{title:067  HOME FOR A REST }
{subtitle:(4/4  Key of C)}  
{subtitle:(Spirit of the West)}
{time:4:32}
{metronome: 120}


{c:Count in as in 3/4 time "1,2,3, 2,2..." }
{c:(The first singing note is a C)}




You’ll [Am/]have to ex[G/]cuse me, I’m [C/]not at my [F/]best
I’ve been [C/]gone for a [G/]month, I’ve been [F/]drunk since I [C/]left
These [Am/]so-called va[G/]cations will [C/]soon be my [F/]death
I’m so [C/]sick from the [G/]drink, I need [F/]home for a [C/]rest
       
{c:(faster, 4/4 time)}   
We ar[Am]rived in De[G]cember and [C]London was [F]cold
So we [C]stayed in the [G]bars along [F]Charing Cross [C]road
We [Am]never saw [G]nothing but [C]brass taps and [F]oak
Kept the [C]shine on the [G]bar with the [F]sleeves of our [G]coat
               
{soc}           
   You’ll [G/]have to excuse me, I’m [C/]not at my [G/]best
   I’ve been [C]gone for a [F]week, I’ve been [G]drunk since I left
   These [G/]so-called vacations will [C/]soon be my [G/]death
   I’m so [C]sick from the [F]drink I need [G]home for a [C]rest
   Take me [Am////]home!         [G]/ / / /   [C]/ / / /   [F]/ / / /   
                   [Am]/ / / /   [G]/ / / /   [C]/ / / /   [F]/ / / /       
{eoc}

[Am]  Euston [G]Station the [C]train journey [F]north
[C]In the buffet [G]car we [F]lurched back and [C]forth
Past [Am]old crooked [G]dykes, through [C]Yorkshire’s green [F]fields
We were [C]flung into [G]dance as the [F]train jigged and [G]reeled                

{soc}           
   You’ll [G/]have to excuse me, I’m [C/]not at my [G/]best
   I’ve been [C]gone for a [F]week, I’ve been [G]drunk since I left
   These [G/]so-called vacations will [C/]soon be my [G/]death
   I’m so [C]sick from the [F]drink I need [G]home for a [C]rest
   Take me [Am////]home!       [G]/ / / /   [C]/ / / /   [F]/ / / /   
                 [Am]/ / / /   [G]/ / / /   [C]/ / / /   [F]/ / 
{eoc}

By the [Am]light of the [G]moon, she'd [C]drift through the [F]street
A [C]rare old per[G]fume, so se[F]ductive and [C]sweet
She'd [Am]tease us and [G]flirt as the [C]pubs all closed [F]down
Then [C]walk us on [G]home and de[F]ny us a [G]round

 {soc}           
   You’ll [G/]have to excuse me, I’m [C/]not at my [G/]best
   I’ve been [C]gone for a [F]month, I’ve been [G]drunk since I left
   These [G/]so-called vacations will [C/]soon be my [G/]death
   I’m so [C]sick from the [F]drink I need [G]home for a [C]rest
   Take me [Am////]home!       [G]/ / / /   [C]/ / / /   [F]/ / / /   
                 [Am]/ / / /   [G]/ / / /   [C]/ / / /   [F]/ / / /      
{eoc}
 
The [Am]gas heater’s [G]empty, it’s [C]damp as a [F]tomb
And the [C]spirits we [G]drank like a [F]ghost in the [C]room
I’m [Am]knackered a[G]gain, come on [C]please take me [F]soon
And don’t [C]lift up my [G]head till the [F]twelve bells at [G]noon                
 
{soc}           
   You’ll [G/]have to excuse me, I’m [C/]not at my [G/]best
   I’ve been [C]gone for a [F]month, I’ve been [G]drunk since I left
   These [G/]so-called vacations will [C/]soon be my [G/]death
   I’m so [C]sick from the [F]drink I need [G]home for a [C]rest
   Take me [Am////]home!       [G]/ / / /   [C]/ / / /   [F]/ / / /   
   [Am]/ / / /   [G]/ / / /   [C]/ / / /   [F]/ / / /       [Am/]
{eoc}


___________________________________














