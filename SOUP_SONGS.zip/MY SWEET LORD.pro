{title:MY SWEET LORD }














{c:INTRO: Dm / / / /    G / / / /    Dm / / / /  }
{c:  G / / / /    Dm / / / /    G / / / /    }
{c:C / / / /    Am / / / /    C / / / /    Am / / / /    C / / / /    }
{c:Gdim / / / /    Dm / / / /    G /  }


My sweet [Dm]Lord    [G]      Hmm my [Dm]Lord   
[G]    Hmm my [Dm]Lord  [G]    
I really want to [C]see you   [Am]         
I really want to [C]be with you   [Am]
I really want to [C]see you Lord, but it 
[Gdim]won't take long my 
[Dm]Lord   [G]      Hmm my [Dm]Lord     
[G]     Hmm my [Dm]Lord    [G]

I really want to [C]know you   [Am]    
really want to [C]go with you   [Am]
Really want to [C]show you Lord
That it [Gdim]won't take long my [Dm]lord (halle[G]lujah)

My sweet [Dm]Lord (halle[G]lujah)   
Hmm my [Dm]Lord (halle[G]lujah)
My sweet [Dm]Lord (halle[G]lujah)

I really want to [C]see you, I really want to [C7]see you
Really want to [A7]see you, Lo-ord  
I really want to [D]see you, Lord but it 
[D7]takes so long, my [Em]lord (halle[A]lujah)

My sweet [Em]Lord (halle[A]lujah)      
Hm, my [Em]Lord (halle[A]lujah)
My my my [Em]Lord (halle[A]lujah)

I really want to [D]know you (halle[Bm]lujah), 
really want to [D]go with you (halle[Bm]lujah)
Really want to [D]show you Lord (aaah)

{title:MY SWEET LORD            Page 2}
That it [D7]won't take long, 
my [Em]Lord (halle[A]lujah)
Mm[Em]hmm (halle[A]lujah),    
My sweet [Em]Lord (halle[A]lujah)
Hm, my [Em]Lord (hare [A]krishna),   
My, my, my [Em]Lord (hare [A]krishna)
Oh my sweet [Em]Lord (krishna, [A]krishna)

Now, I really want to [D]see you (hare [Bm]rama)    
Really want to [D]be with you (hare [Bm]rama)    
Really want to [D]see you Lord (aaah)
But it [D7]takes so long, my [Em]Lord (halle[A]lujah)

Hm, my [Em]Lord (halle[A]lujah), 
my, my, my [Em]Lord (hare [A]krishna)
Oh my [Em]Lord (krishna [A]krishna),  
my sweet [Em]Lord (hare [A]hare)
Oh my my [Em]Lord (Guru [A]Brahma)
My sweet [Em]Lord (Mahesh[A]wara)

My sweet [Em]Lord (Guru [A]Sakshaat)
My sweet [Em]Lord (Para[A]brahma)
My, my, my [Em]Lord (Guru [A]Namah)
My sweet [Em]Lord (Hare [A]Rama)

My sweet [Em]Lord (hare [A]krishna)     
My sweet [Em]Lord (hare [A]krishna)
My sweet [Em]Lord (krishna [A]krishna)

