

{title:127 59th STREET BRIDGE SONG  }
{title:(FEELING GROOVY)}
{subtitle:(4/4  Key of C)}
{subtitle:(Paul Simon)}
{time: 2:05}
{metronome: 140}




 
[F]/ /     [C]/ /     [G7]/ /     [C]/ /     
[F]/ /     [C]/ /     [G7]/ /     [C]/ /  

[F] Slow [C]down, you [G7]move too [C]fast 
[F] You got to [C]make the [G7]morning [C]last, just
[F] kickin' [C]down the [G7]cobble [C]stones 
[F] Lookin' for [C]fun and [G7]feelin' [C]groovy…
[F]/ /    [C]/ /    [G7]/ /    [C]/ /

Ba da da [F]da da [C]da da [G7]      feelin' [C]groovy
[F]/ /    [C]/ /    [G7]/ /    [C]/ /

[F] Hello [C]lamppost, [G7]      what cha [C]knowin' 
[F] I've come to [C]watch your [G7]flowers [C]growing 
[F] Ain't cha [C]got no [G7]rhymes for [C]me 
[F] Dootin' do- [C]do-do [G7]feeling [C]groovy… 
[F]/ /    [C]/ /    [G7]/ /    [C]/ /
 
Ba da da [F]da da [C]da da [G7]       feelin' [C]groovy
[F]/ /    [C]/ /    [G7]/ /    [C]/ /

Got [F]no deeds to [C]do, no [G7]promises to [C]keep 
I'm [F]dappled and [C]drowsy and [G7]ready to [C]sleep 
Let the [F]morning time [C]drop all its [G7]petals on [C]me 
[F] Life I [C]love you, [G7] all is [C]groovy… 
[F]/ /    [C]/ /    [G7]/ /    [C]/ /

Ba da da [F]da da [C]da da [G7]      feelin' [C]groovy  
Ba da da [F]da da [C]da da [G7]      feelin' [C]groovy
Ba da da [F]da da [C]da da [G7]      feelin' [C]groovy

[F]/ /    [C]/ /    [G7]/ /    [C]/ 


__________________________________









