
{title: UP HERE IN CANADA}
{subtitle: 4/4      Key of A}
{subtitle: (Clark W.)}
{time:4:10}
{metronome:123}

Coo-loo...


[A]/ / / /   / / / / 

[A]Timmy’s and hockey, syrup and bacon, 
[A]Molson and Mounties, Petro Can Stations
[D]Throwing on some cheese and gravy 
On top of our [A]fries:  (that’s a poutine!)
And we [E7]wear our plaid sweaters 
When we walk amongst the norther-ern [A]lights 
{c:(234,1234)} 

[A]Rockies and prairies, oceans and lakes 
[A]Other than winter all the seasons are great
[D]Brushing off the snow a little longer than we’d 
[A]Li-i-ike   Uh huh uh
But you [E7]won’t hear us complaining 
Cuz [E7]that just wouldn’t be po[A]↑lite (No ma'am.)

{soc}
  Cuz Up [A]here {c:(23)} in Canada    
  The air’s clear, the weather’s adequate
  We all [D]cheer, we’re pretty passionate
  And every[E7]body has a pet polar bear, (and a moose)
  Yeah up [A]here {c:(23)} 
  In Caaa-naaa-da {c:(234,1234)}
{eoc}

[A]Celsius, Kilometers, Prime Ministers and Provinces
We [A]maybe say it different 
But we always keep our promises
We [D]said we’d win the gold back in 
Two thousand and [A]ten,   (and we did)
But [E7]because we’re so nice 
We’ll let you win every now and a[A]gain
{c:(23) (but not too much) (23)} 

{soc}
  Cuz up [A]here {c:(23)} in Canada 
  We like beards (we think they’re fabulous)
  We don’t [D]fear if people laugh at us
  For wearing [E7]six pairs of long underwear (and a touque)
  Yeah up [A]here 
  in Caaa-[E7]naaa-[A]da  {c:(234,1234)}
{eoc}

[D]Basketball, telephones, wonder bras and hockey
[A]Snowmobiles, ketchup chips and even walkie talkies
[D]Peanut butter, garbage bags, the mighty fog horn
Are [A]just few things that you can thank us for

[D]Shatner, Carrey, Meyers, Gosling, Reynolds and Reeves
[A]Candy, Short, and Michael J and all of Schitt's Creek
[D]Celine, Shania, Adams, Beiber, [D/]Buble and [D/]Drake
We’re [E7/]sorry bout Nickleback yeah [NC]that was a mistake
{c:Spoken:} We’re sorry,  we’re sorry  
Yeah we’re sorry, eh {c:(34)}
{c:(Louder)} WE’RE SO, SO SORRY! {c:(23)}

{soc}
Cuz up [A]here in Canada 
We like beer, and our cannabis
And each [D]year, we all get taxed a bunch
But every[E7]body gets free healthcare, (and a goose!)
Yeah up [A]here in Caaa-[E7]naaa-[A]da {c:(234,123)} 

Coo   [A]loo coo-coo   coo-coo   cou-↑cou  {c:(123)}
Coo   [A]loo coo-coo   coo-coo   cou-↓cou    {c:(123)}
Coo   [D]↑loo coo-coo   coo-coo   cou-↑cou    {c:(123)}
Coo   [E7]loo coo-coo   coo-coo   cou-↑cou    {c:(123)}

Coo   [A]loo, coo-coo coo-coo coo-↓coo  [A/] [A/] [A/]
{eoc}
_______________________________________






















