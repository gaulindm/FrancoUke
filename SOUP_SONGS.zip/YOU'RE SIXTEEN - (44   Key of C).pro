{title:YOU'RE SIXTEEN}
{subtitle:(4/4   Key of C)}   
{subtitle:(Robert and Richard Sherman)}
{time: 2:35}
{metronome: 136}

{c:Tambourine}



{c:INTRO:}
[D7]/ / / /    [G7]/ / / /    
[C]/ / / /    [G7]/ / /

You come [C]on like a dream 
[E7]Peaches and cream
[F]Lips like strawberry [C]wine
You're six[D7]teen, you're [G7]beautiful 
And you're [C]mine [G7] 

You're all [C]ribbons and curls 
[E7]Oooh what a girl
[F]Eyes that sparkle and [C]shine
You're six[D7]teen 
You're [G7]beautiful and you're [C]mine 
 
{soc}
[E7]     You're my baby, you're my pet
[A7]     We fell in love on the night we met
You [D7]touched my hand, my heart went pop
[G7/]Oooh when we kissed [G7/]      
I could not [G7/]stop
You walked [C]out of my dreams 
And [E7]into my arms
[F]Now you're my angel di[C]vine
You're six[D7]teen, you're [G7]beautiful
And you're [C]mine {c:(234,1234)}
{eoc}

{c:INSTRUMENTAL:}
[C]/ / / /    [E7]/ / / /    
[F]/ / / /    [C]/ / / /      
[D7]/ / / /    [G7]/ / / /   
[C]/ / / /    / / / /  

{soc}
[E7]     You're my baby, you're my pet
[A7]     We fell in love on the night we met
You [D7]touched my hand, my heart went pop
[G7/]Oooh when we kissed [G7/]      
I could not [G7/]stop
You walked [C]out of my dreams 
And [E7]into my arms
[F]Now you're my angel di[C]vine
You're six[D7]teen, you're [G7]beautiful 
And you're [C]mine {c:(234,1234)}
{eoc}

You're six[D7]teen, you're [G7]beautiful 
And you're [C]mine 
You're six[D7]teen, you're [G7]beautiful 
And you're [C]mine {c:(234,1)}  [G7/]  [C/]  {c:(flutter)}[C9]      




{define: D7 0 2 0 2 0}
{define: C9 0 0 2 0 1}