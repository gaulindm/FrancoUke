{title: PLAY THAT SONG}
{subtitle:       (4/4      Key of C)      }
{subtitle:(Train)}
{time: 3:40}
{metronome: 114}








{c:INTRO:}
[C]/ /    [F]/ /     [Am]/ /      [G]/ / 

[C]Play that [F]song [Am]      the one that [G]makes me go 
[C]All night [F]long [Am]      the one that [G]makes me think
[C]Of  [F]you,  [Am]that's all you [G]gotta 
[C]Do    [F]/ /     [Am]/ /     [G]/ /

[C]Hey mister [F]DJ [Am]when you gonna [G]spin it
My [C]baby's favourite [F]record she's been 
[Am]Waiting for a [G]minute
She in[C]vited all her [F]friends and I’m 
[Am]Buying all the [G]rounds
And they're [C]all dolled [F]up 
DJ [Am]please don’t let me [G]down {c:(beat)}

[C] When you gonna [F]play that song, now 
[Am]   When you gonna [G]earn that pay
[C] When you gonna [F]play that song and 
[Am/]Make  [Am/]my   [G/]day? [G/]She said

{soc}
[C]Play that [F]song [Am]   the one that [G]makes me go 
[C]All night [F]long [Am]    the one that [G]makes me think
[C]Of  [F]you,  [Am]that's all you [G]gotta 
[C]Do  [F]/ /     [Am]Ay-ay-ay, ay [G]Ay ay 

[C]Play that [F]song     [Am]     the one that [G]makes me stay
{c:         (play that so...            ...ong)}
[C]Out till [F]dawn      [Am]  the one that [G]makes me go 
{c:         (all night lo...          …ong)}
[C]Ooo [F]oo, [Am]that's all you [G]gotta [C]do  [F]/ /    
[Am/]Ay  [Am/]Ay    [G/]Ay   [G/]Ay
{eoc}

[C]Hey mister [F]ukulele [Am]when you gonna [G]strum it?
My [C]girl just heard this [F]song and you should 
[Am]Play it cause she [G]loves it
Can you [C]get me off the [F]hook? Get them 
[Am]Fingers picking [G]now
Throw some [C]money in your [F]cup, mister 
[Am]please don't let me [G]down {c:(beat)}

[C] When you gonna [F]play that song, now 
[Am]   Why you gotta [G]     hesitate?
[C] When you gonna [F]play that song and 
[Am/]Make  [Am/]my   [G/]day?   [G/]She said

{soc}
[C]Play that [F]song [Am]      the one that [G]makes me go 
[C]All night [F]long [Am]      the one that [G]makes me think
[C]Of  [F]you,  [Am]that's all you [G]gotta 
[C]Do [F]/ /     [Am]Ay-ay-ay, ay [G]Ay ay 

[C]Play that [F]song     [Am]     the one that [G]makes me stay
{c:         (play that so...            ...ong)}
[C]Out till [F]dawn      [Am]  the one that [G]makes me go 
{c:         (all night lo...          …ong)}
[C]Ooo [F]oo, [Am]that's all you [G]gotta [C]do  [F]/ /  
{eoc}

[Am]Oh, wait till you [G]see my baby 
[C]Mo-oo-oo [F]oo-oove  [Am]     mo-oo-oo- [G]oove
[C]mo-oo-oo [F]oo-oove, [Am]     wait ‘til you [G]see my baby
[C]mo-oo-oo [F]oo-oove, [Am]     mo-oo-oo- [G]oove
[C]mo-oo-oo [F]oo-oove, [Am]     oooh come [G]on now

{soc}
[C]Play that [F]song [Am]      the one that [G]makes me go 
[C]All night [F]long [Am]      the one that [G]makes me think
[C]Of  [F]you,  [Am]that's all you [G]gotta 
[C]Do [F]/ /     [Am]Ay-ay-ay, ay [G]Ay ay 

[C]Play that [F]song     [Am]     the one that [G]makes me stay
{c:         (play that so...            ...ong)}
[C]Out till [F]dawn      [Am]  the one that [G]makes me go 
{c:         (all night lo...          …ong)}

[C]Ooo [F]oo, [Am]that's all you [G]gotta [C]do  [F]/ / 
{eoc}

[Am]That's all you [G]gotta [C]doo-oo-oo [F]oo-oo 
[Am]    Oo-oo-oo [G]oo
[C]Oo-oo-oo [F]oo-oo   [Am]that's all you [G]gotta 
[C]Doo-oo-oo [F]oo-oo [Am]       oo-oo-oo [G]oo
[C]Oo-oo-oo [F]oo-oo   [Am]that's all you [G]gotta [C/(gliss)]do




