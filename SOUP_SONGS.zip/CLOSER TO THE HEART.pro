{title: CLOSER TO THE HEART}
{subtitle: 4/4      Key of A}
{metronome:  }
{time: 3:00 }







{c:INTRO:Martin}

And the [A]men who hold high pl[G]aces
Must [D]be the [G]ones who [A]start
To [A]mold a new re[G]ality
[D]closer [A]to the [G]heart 
[D]closer [A]to the [G]heart
 
The [A]Blacksmith and the [G]Artist
Re[D]flect it [G]in their[A]  art
They [A]forge their crea[G]tivity
[D]closer [A]to the [G]heart 
[D]closer [A]to the [G]heart

{c:Bells}
 
Phi[A]losophers and [G]Ploughmen
[D]Each must [G]know his [A]part
To [A]sow a new men[G]tality 
[D]closer [A]to the [G]heart, yes 
[D]closer [A]to the {soh}[G]heart{eoh}, yeah

{c: A / / / /   / / / /    G / / / /   / / / /}
{c: D / / / /   / / / /    A / / / /   / /}
{c:A/   A/  }
Whoa  whoa
 
Oh, [A]you can be the [G]Captain
and [D]I will [G]draw the [A]chart
[A]Sailing into [G]destiny
[D]closer [A]to the [G]heart 
[D]Closer [A]to the [G]heart

Well [D]closer [A]to the {soh}[G]heart{eoh}, yeah
[D]Closer [A] to the [G]heart
[D]Closer [A] to the [G]heart 
I said [D]closer [A]to the [G]heart
Well [D]closer [A]to your heart, yeah

[D]Closer [A]to your heart, 
[D]closer [A]to your [G]heart
whoa  [G/]  [D/]  [F/]  [A/]


