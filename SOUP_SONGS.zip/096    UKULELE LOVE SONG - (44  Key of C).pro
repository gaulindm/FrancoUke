{title:    UKULELE LOVE SONG   }
{subtitle:(4/4  Key of C)}     
{subtitle:(Mark Anderson)}
{time: 2:40}
{metronome: 152}








{c:INTRO:} 
[F]/ / / /      [G7]/ / / /     
[C]/ / / /    / / / / 

[C] I had a dream last night,  [D]     a dream for two
[G7] I saw a starlit beach,  [C]     and I saw yoo-oou
We walked along the sand,  [D]     hand-in-hand
[G7] I looked into your eyes,  [C]     and heard the band

{c:CHORUS}
{soc}
     [G7]Playin' a ukulele [C]love song
     [G7]Playin' a ukulele [C]tune
     [G7]Playin' a ukulele [C]love song
     [F]Playin' a [G7]song for me and [C]you
{eoc}

[C] I woke up from a dream,  [D]     a dream for two
[G7] I saw a sunlit beach,  [C]     and I saw you
We walked along the sand,  [D]     hand-in-hand
[G7] I looked into your eyes,  [C]     and heard the band

{c:CHORUS}
{soc}
     [G7]Playin' a ukulele [C]love song
     [G7]Playin' a ukulele [C]tune
     [G7]Playin' a ukulele [C]love song
     [F]Playin' a [G7]song for me and [C]you
{eoc}

{c:OUTRO: }
[F]Playin' a [G7]song for me and [C]you
[F]Playin'...  a [G7]song...  for me and [C]you... [G7/] [C/]

