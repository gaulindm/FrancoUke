{title:HE'S GOT THE WHOLE WORLD }
{title:IN HIS HANDS  }
{subtitle: 4/4   Key of C }
{subtitle: (Robert Lindon, William Henry)}
{time: 4:45}
{metronome: 140}






{c:INTRO:} 
[G7]/ / / /     [C]/ / / 
 
{c:CHORUS}                                                                       
{soc}
     He's got the [C]whole world in his hands                 
     He's got the [G7]whole wide world in his hands 
     He's got the [C]whole world in his hands                 
     He's got the [G7]whole world in his [C]hands 
{eoc}
 
He's got the [C]little bitty baby in his hands                     
He's got the [G7]little bitty baby in his hands 
He's got the [C]little bitty baby in his hands 
He's got the [G7]whole world in his [C]hands 

{c:CHORUS}                                                                       
{soc}
     He's got the [C]whole world in his hands                 
     He's got the [G7]whole wide world in his hands 
     He's got the [C]whole world in his hands                 
     He's got the [G7]whole world in his [C]hands
 {eoc}

He's got [C]you and me brother in his hands 
He's got [G7]you and me sister in his hands 
He's got [C]you and me brother in his hands 
He's got the [G7]whole world in his [C]hands

{c:CHORUS}                                                                       
{soc}
     He's got the [C]whole world in his hands                 
     He's got the [G7]whole wide world in his hands 
     He's got the [C]whole world in his hands                 
     He's got the [G7]whole world in his [C]hands 
{eoc}

He's got [C]everybody here in his hands 
He's got [G7]everybody here in his hands 
He's got [C]everybody here in his hands 
He's got the [G7]whole world in his [C]hands

{c:CHORUS}                                                                       
{soc}
     He's got the [C]whole world in his hands                 
     He's got the [G7]whole wide world in his hands 
     He's got the [C]whole world in his hands
   {c:slow down on the last line }            
     He's got the [G7]whole world in his [C]hands
{eoc}





{sot}
15/12/2014
{eot}



