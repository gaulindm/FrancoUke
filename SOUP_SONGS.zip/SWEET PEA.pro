{title:SWEET PEA}
{subtitle:}
[Intro]

[F]/ / / /    [A7]/ / / /    [Dm] [G7] 
[F] [Dm] [Bb] [C7] [F] [Dm] [Bb] [C7]
 
[F]Sweet Pea, [A7]apple of my eye,
[Dm]Don't know when and I[G7] dont know why.
[F]You're the only [Dm]reason I [Bb]keep on [C7]comin' [F]home. [Dm] [Bb] [C7]
 
[F]Sweet Pea, [A7]what's this all about?
[Dm]Don't get your way all you [G7]do is fuss and pout.
[F]You're the only [Dm]reason I [Bb]keep on [C7]comin' [F]home. [Dm] [Bb] [C7]
 
[A7]I'm like the Rock of Gibraltar, I always seem to falter,
And the [Dm]words just get in the way.
Oh I [G7]know I'm gonna crumble, I'm trying to stay humble,
But I[C7] never think before I say. [C7#5]
 
 
[Instrumental Verse]
[F] [A7] [Dm] [G7] [F] [Dm] [Bb] [C7] [F] [Dm] [Bb] [C7]

[F]Sweet pea [A7]people of my soul
[Dm] I know sometimes I'm [G7]out of control
[F]You're the only [Dm]reason I [Bb]keep on [C7]comin' 
[F]You're the only [Dm]reason I [Bb]keep on [C7]comin' 
[F]You're the only [Dm]reason I [Bb]keep on [C7]comin' 
[F]home. [Dm] [Bb] [C7]