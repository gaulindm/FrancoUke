{title: DON'T PASS ME BY}
{subtitle: Richard Starkey}
{metronome: }
{time:3:00 }


I [G]listen for your footsteps, coming up the drive
[C]Listen for your footsteps, but they don't arrive
[D7]Waiting for your knock dear, on my own front door
I don't [C]hear it, does it mean you don't 
Love me any[G]more?

I [G]hear the clock a-ticking, on the mantle shelf
[C]See the hands a-moving, but I'm by myself
I [D7]wonder where you are tonight, why I'm by myself
I don't [C]see you, does it mean you don't 
Love me any[G]more?

{soc}
   [G]Don't pass me by don't make me cry 
   Don't make me blue
   'Cause you know [C]darlin, I love only you
   You never [G]know it hurt me so
   I'd hate to see you go
   Don't pass me [D7]by… don't make me [C]cry  [G]
{eoc}


I'm [G]sorry that I doubted you, I was so unfair
[C]You were in a car crash and you lost your hair
You [D7]said that you would be late, about an hour or two
I Said "[C]that's alright I'm waiting here 
Just waiting to hear from [G]you!"

{soc}
   [G]Don't pass me by don't make me cry 
   Don't make me blue
   'Cause you know [C]darlin, I love only you
   You never [G]know it hurt me so
   I'd hate to see you go
   Don't pass me [D7]by… don't make me [C]cry  [G]

   [G]Don't pass me by don't make me cry don't make me blue
   'Cause you know [C]darlin, I love only you
   You never [G]know it hurt me so, I'd hate to see you go
   Don't pass me [D7]by, don't make me [C]cry  [G]
{eoc}


{define: D7 0 2 0 2 0}