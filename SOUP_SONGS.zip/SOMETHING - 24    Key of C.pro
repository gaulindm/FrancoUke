{t:SOMETHING }
{subtitle:     2/4    Key of C}
{subtitle: (George Harrison)}
{time: 3:00}


{c:Suggested strums:  DdDd, Dddd,}
{c:or:  (pluck G,E and A together}
{c:then pick C,E,C strings)} 

{c:RIFF}
{sot}
   F            D#     G      
A| 0  -  -  - | 1  - | 2  - 
E| 1  -  1  - | 3  - | 3  -
C| -  0  -  0 | -  3 | -  2
G| 2  -  -  - | 0  - | 0  -
{eot}                                              
     
{c:INTRO: } 
{c:(RIFF):   F / /    D# /    G /  }                          
 [C]Something in the way she [Cmaj7]moves 
[C7] Attracts me like no other [F]lover [Am]  [D]Something in the [D7]way she [G]woos me

{c:CHORUS and RIFF}
{soc}       I [Am]don't want to leave her [G#+]now
     You [C]know I believe in [D7]how 
     {c:RIFF:    F / /    D# /    G / }
{eoc}
 [C]Something in her smile she [Cmaj7]knows 
[C7] That I don't need no other [F]lover [Am]  [D]Something in her [D7]style that [G]shows me   


{c:CHORUS and RIFF}
{soc}       I [Am]don't want to leave her [G#+]now
     You [C]know I believe in [D7]how 
     {c:RIFF:    F / /    D# /    G / }
{eoc}

{c:BRIDGE}
{sob}
     [A] You're asking [Dbm7]me will my love [F#m]grow [A]       I don't [D]know, [G]I don't [A]know       You stick a [Dbm7]round and it may [F#m]show [A]       I don't [D]know, [G]I don't [C]know
{eob}
  [C]Something in the way she [Cmaj7]knows  [C7]And all I have to do is [F]think of her [Am]  [D]Something in the [D7]things she [G]shows me  

{soc}       I [Am]don't want to leave her [G#+]now
     You [C]know I believe in [D7]how 
    {c:OUTRO RIFF:    F / /    D# /    G /     A / / / / , }
     {c:    F / /    D# /    G /    C /}
{eoc}



{define: G#+ 0 1 0 0 3}
{define: Dbm7 0 1 1 0 2}
[D#]