{title: Mary Jane's Last Dance}
{subtitle: Tom Petty}








{c:INTRO:} 
{c: Am / / / /   G / / / /    D / / / /    Am / / / /}
{c: Am / / / /   G / / / /    D / / / /    Am / / / /}
{c:Bass now}
{c: Am / / / /   G / / / /    D / / / /    Am / / / /}
{c: Am / / / /   G / / / /    D / / / /    Am / / / /}

[Am]She grew up in an [G]Indiana town
Had a [D]good lookin' mama who [Am]never was around
But she [Am]grew up tall and she [G]grew up right
With them [D]Indiana boys on an [Am]Indiana night

{c: Am / / / /   G / / / /    D / / / /    Am / / / /}
{c: Am / / / /   G / / / /    D / / / /    Am / / / /}

Well she [Am]moved down here at the [G]age of 18
She [D]blew the boys away, it was [Am]more than they'd seen
[Am]I was introduced and we [G]both started groovin'
She [D]said, "I dig you baby but I [Am]got to keep movin'"
{c:(1234)}   [G]on {c:(234)} [D]    keep movin' on [Am]{c:(1234)}
{c: Am / / / /   G / / / /    D / / / /    Am / / / /}

{soc}
{c:CHORUS:}
     [Em7]Last dance with Mary Jane
     One more time to kill the pa...[A]ain
     [Em7]  I    feel summer creepin' in and I'm
     Tired of this town aga...[A]ain    {c:(234,1234)}   [G]    {c:(234,1234)}
{eoc}


{c: Am / / / /   G / / / /    D / / / /    Am / / / /}
{c: Am / / / /   G / / / /    D / / / /    Am / / / /}

Well [Am]I don't know but [G]I've been told
You [D]never slow down, you [Am]never grow old
I'm [Am]tired of screwing up, I'm [G]tired of goin' down
I'm [D]tired of myself, I'm [Am]tired of this town
[Am]Oh my my, [G]oh hell yes
[D]Honey put on that [Am]party dress
[Am]Buy me a drink, [G]sing me a song,
[D]Take me as I come 'cause I [Am]can't stay long

{soc}
{c:CHORUS:}
     [Em7]Last dance with Mary Jane
     One more time to kill the pa...[A]ain
     [Em7]  I    feel summer creepin' in and I'm
     Tired of this town aga...[A]ain    {c:(234,1234)}   [G]    {c:(234,1234)}
{eoc}


{c: Am / / / /   G / / / /    D / / / /    Am / / / /}
{c: Am / / / /   G / / / /    D / / / /    Am / / / /}

There's [Am]pigeons now on [G]Market Square
[D]She's standin' in her [Am]underwear
[Am]Lookin' down from a [G]hotel room
The [D]nightfall will be [Am]comin' soon
[Am]Oh my my, [G]oh hell yes
You've [D]got to put on that [Am]party dress
It was [Am]too cold to cry when I [G]woke up alone
I [D]hit the last number, I [Am]walked to the road

{soc}
{c:CHORUS}
     [Em7]Last dance with Mary Jane
     One more time to kill the pa...[A]ain
     [Em7]  I    feel summer creepin' in and I'm
     Tired of this town aga...[A]ain    {c:(234,1234)}   [G]    {c:(234,1234)}
{eoc}


{c: Am / / / /   G / / / /    D / / / /    Am / / / /}
{c: Am / / / /   G / / / /    D / / / /    Am / / / /}
{c: Am / / / /   G / / / /    D / / / /    Am / / / /}
{c: Am / / / /   G / / / /    D / / / /    Am /}

