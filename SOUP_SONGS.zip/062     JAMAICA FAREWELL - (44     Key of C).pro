

{title:062 JAMAICA FAREWELL  }
{subtitle:(4/4     Key of C)}
{subtitle:(Lord Burgess)}
{time:2:38}
{metronome: 128}






[C]/ / / /     [Dm]/ / / /     
[C]/ /     [G7]/ /      [C]/ / / /   

[C] Down the way where the [F]nights are gay 
And the [C]sun shines [G7]daily on the [C]mountain top 
I took a trip an a [F]sailing ship
And when we [C]reached Ja[G7]maica
I [C]made a stop but I'm

{c:CHORUS}
{soc}
   [C]     Sad to say, I`m [Dm]on my way
   [G7]       Won`t be back for [C]many a day 
   My heart is down, my head is [Dm]turning around 
   I had to [C]leave a little [G7]girl in [C]Kingston town {c:(4,1234)}
{eoc}

[C] Down at the market [F]you can hear 
Ladies [C]cry out while [G7]on their [C]heads they bear
Ackee rice, salt [F]fish are nice
And the [C]rum is [G7]fine any [C]time of year, but I'm 

{soc}
   [C]     Sad to say, I`m [Dm]on my way
   [G7]       Won`t be back for [C]many a day 
   My heart is down, my head is [Dm]turning around 
   I had to [C]leave a little [G7]girl in [C]Kingston town {c:(4,1234)}
{eoc}

[C] Sounds of laughter [F]everywhere
And the [C]dancing [G7]girls swing [C]to and fro
I must declare my [F]heart is there
Though I have [C]been from [G7]Maine to [C]Mexico 
But I'm 

{soc}
   [C]     Sad to say, I`m [Dm]on my way
   [G7]      Won`t be back for [C]many a day 
   My heart is down, my head is [Dm]turning around 
   I had to [C]leave a little [G7]girl in [C]Kingston town   

   I’m    [C]     sad to say, I'm [Dm]on my way
   [G7]       Won't be back for [C]many a day
   My heart is down, my head is [Dm]turning around
   I had to [C]leave a little [G7]girl in [C]Kingston town
   {c:C / / / /    Dm / / / /    }
   {c:C / /    G7 / /    C /   ///}
{eoc}

________________________________















