{title:I FOUGHT THE LAW}
{subtitle:tab     4/4     Key of D}
{subtitle:(Sonny Curtis)}
{metronome:134}
{time:3:30 }





{c:INTRO:}

[D]/ / / /     [G]/ /   [A]/ /   
[D]/ / / /     [G]/    [D]/    [A]/    [D]/

I’m [D]breakin' rocks in the  [G]     hot  [D]sun
I fought the law and the [G]      law  [D]won
I fought the law and the [A]     law  [D]won {c:(234)}  
[G]/ /   [A]/ /      
{c:(}[D]{c:1234)}   [G]/   [D]/   [A]/   [D]/

I [D]needed money 'cause I  [G]     had [D]none 
I fought the law and the  [G]      law  [D]won
I fought the law and the  [A]     law  [D]won {c:(234)}  
[G]/ /   [A]/ /      
{c:(}[D]{c:1234)}   [G]/   [D]/   [A]/   [D]/

I [G]left my baby and I feel so sad       
I [D]guess my race is run
But [G]she's the best girl I've ever had 
[D]I fought the law and the [G]      law  [D]won
I fought the law and the [A]     law  [D]won {c:(234)}  
[G]/ /   [A]/ /      
{c:(}[D]{c:1234)}   [G]/   [D]/   [A]/   [D]/

[D]Robbin' people with a   [G/][G/][G/]six [D/]gun [D/] [D/]
[D]I fought the law and the  [G]      law  [D]won
I fought the law and the  [A]     law  [D]won {c:(234)}  
[G]/ /   [A]/ /      
{c:(}[D]{c:1234)}   [G]/   [D]/   [A]/   [D]/   

I [D]miss my baby and the  [G]     good  [D]fun     
I fought the law and the  [G]      law  [D]won
I fought the law and the  [A]     law  [D]won {c:(234)}  
[G]/ /   [A]/ /      
{c:(}[D]{c:1234)}   [G]/   [D]/   [A]/   [D]/

I [G]left my baby and I feel so sad       
I [D]guess my race is run
But [G]she's the best girl I've ever had 
[D]I fought the law and the [G]      law  [D]won
I fought the law and the [A]     law  [D]won {c:(234)}  
[G]/ /   [A]/ /      
{c:(}[D]{c:1234)}   [G]/     [D]/     [A]/     [D]/

{tag: Shared by Martin}