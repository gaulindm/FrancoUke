{title:Canada Day, Up Canada Way }
{subtitle: 4/4      Key of C}
{zoom-iphone: 0.255930}
{subtitle:  (Stompin' Tom Connors)}
{time:3:27}
{metronome:  190 }
   
[C]/ /    [C7]/ /    [F]/ /     [C]/ /      
[F]/ /     [G7]/ /     [C]/ / / 

It's [C]Canada Day up Canada Way 
on the [F]first day of Ju[C]ly
And we're [F]shouting hooray up [C]Canada Way 
when the [D7]maple leaf flies [G7]high
When the [C]silver jets from East to West 
go [F]streaming through our [C]skies
We'll be [F]shouting hooray up [C]Canada Way 
when the [F]great par[G7]ade goes [C]by  {c:(234)} 
 
{soc}
  [C]Oh Canada, standing tall to[G7]gether
  We'll [C]raise our [C7]hands 
  and [F]hail our [C]flag
  The [F]maple [G7]leaf for[C]ever {c:(34,123)}
{eoc} 
 
It's [C]Canada Day up Canada Way 
on the [F]coast of Labra[C]dor
And we're [F]shouting hooray up [C]Canada Way 
on the [D7]white Pacific [G7]shore
People [C]everywhere have a song to share 
on [F]Canada's holi[C]day
From [F]Pelee Island in the [C]sunny south 
to the [F]North Pole [G7]far a[C]way {c:(234)}
        
{soc}
  [C]Oh Canada, standing tall to[G7]gether
  We'll [C]raise our [C7]hands 
  and [F]hail our [C]flag
  The [F]maple [G7]leaf for[C]ever {c:(34,123)} 
{eoc}

It's [C]Canada Day up Canada Way 
when the [F]long cold winter’s [C]done
And we're [F]shouting hooray up [C]Canada Way 
for the [D7]great days yet to [G7]come
Where [C]maple trees grow maple leaves 
when the [F]Northern sun is [C]high
We're Can[F]adians and we're [C]born again 
on the [F]first day [G7]of Ju[C]ly  {c:(234)}
        
{soc}
  [C]Oh Canada, standing tall to[G7]gether
   We'll [C]raise our [C7]hands 
   and [F]hail our [C]flag
   The [F]maple [G7]leaf for[C]ever {c:34,123)} 
{eoc}

It's [C]Canada Day up Canada Way 
from the [F]lakes to the prairies [C]wide
And we're [F]shouting hooray up [C]Canada Way 
on the [D7]St. Lawrence river[G7]side
People [C]everywhere have a song to share 
on [F]Canada's holi[C]day
From [F]Pelee Island in the [C]sunny south 
to the [F]North Pole [G7]far a[C]way {c:(234)}
        
{soc}
  [C]Oh Canada, standing tall to[G7]gether
  We'll [C]raise our [C7]hands 
  and [F]hail our [C]flag
  The [F]maple [G7]leaf for[C]ever {c:(34,123)}

  We'll [C]raise our [C7]hands and [F]hail our 
  {c:(slow down)}[C]fla...g
  {c:(Slow)}The [F]ma...ple [G7]le...af  fo...r[C]e...ver [C/]
{eoc}
____________________________________________

















