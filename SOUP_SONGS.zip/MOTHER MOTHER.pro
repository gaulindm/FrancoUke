{title:GET UP}
{subtitle:(Mother Mother)}

 
[Am] [F] [C] [A#]
 

[Am]You want greatness, you wanna [F]taste it
[F]You wanna be a king (be a king)
[C]You wanna make it, don't wanna [A#]fake it
[A#]You wanna levitate (levitate)
[Am]You want love, want truth, wanna [F]feel brand new
[F]You wanna do it, do it, do it
[C]You got dreams, you got dreams, you got d[A#]reams
[A#]You got dreams
 
[Cridge]
[F]But there's something in between, man
[F]And you're stuck there underneath them
 

So get [C]up, get u[A#]p now, now, now
Get [F]up, get up now, now, now
[C]Put your head on straight
Put your [A#]head on now, now, now, now
[F]Get up, get on, get out
[F]Get up; fly away, little birdie
 

[Am]You're so sad, you're so g[F]one, you're so lost
[C]You're so sad, you're so down, [A#]I wanna pick you up and put you in the clouds
[Am]You want love, want truth, wanna [F]feel brand new
[F]You wanna do it, do it, do it
[C]You got dreams, you got dreams,[A#] you got dreams
You got dreams
 

[F]And you wanna set 'em free, man
[F]But you're stuck there underneath them
 

So get [C]up, get u[A#]p now, now, now
Get [F]up, get up now, now, now
[C]Put your head on straight
Put your [A#]head on now, now, now, now
[F]Get up, get on, get out
[F]Get up; fly away, little birdie
(a[C]h-hoe, [A#]ah-ho[F]e)
[F]Fly away little birdie
(a[C]h-hoe, [A#]ah-ho[F]e)
 
[Cridge]
[Dm]For such a little thing, y[C]ou sure are in your ow[F]n way
[Dm]I'd love to give you wings[C], but babe you've got [F]to grow them
 
[Cook]
So get [C]up, get u[A#]p now, now, now
Get [F]up, get up now, now, now
[C]Put your head on straight
Put your [A#]head on now, now, now, now, now, now, now, now
So get [C]up, get u[A#]p now, now, now
Get [F]up, get up now, now, now
Put your h[C]ead on straight
Put your [A#]head on now, now, now, now
[F]Get up, get on, get out
[F]Get up; fly away, little birdie
 
[Outro]
G[C]et up, ge[A#]t up, g[F]et up (fly away little birdie)
G[C]et up, put your h[A#]ead on straight, put your [F]head on
[F]Fly away
[F]Get up
X