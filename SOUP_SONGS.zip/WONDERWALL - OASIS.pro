{title:WONDERWALL}
{subtitle:OASIS}
 
 





[Em7]/ / / /    [G]/ / / /    [D]/ / / /     [A]/ / / /
[Em7]/ / / /    [G]/ / / /    [D]/ / / /     [A]/ / / /

[Em7] Today is [G]gonna be the day that they're 
[D]Gonna throw it back to [A]you
[Em7] By now you [G]should have somehow 
Rea[D]lized what you gotta [A]do
[Em7]I don't believe that [G]anybody 
[D]Feels the way I [A]do about you [C]now       
[D]/ / / /    [A]/ / / /   / / / /
 
 
[Em7] Back beat, the [G]word is on the street 
That the [D]fire in your heart is [A]out
[Em7] I'm sure you've [G]heard it all before 
But you [D]never really had a [A]doubt
[Em7]I don't believe that [G]anybody 
[D]Feels the way I [A]do about you [Em7]now    
[G]/ / / /    [D]/ / / /    [A]/ / / / 
 
 
And [C]all the roads we [D]have to walk are [Em7]winding
And [C]all the lights that [D]lead us there are [Em7]blinding
[C]There are many [D]things that I would [G]like to [D]say to [Em7]you 
But I don't know [A]how {c:(34,1234)}  
[A]/ / / /   / / / 
 
{soc}         
   Because [C]maybe {c:(cause }[Em7]{c:maybe)}    [G]  
   You're  [Em7]gonna be the one that 
   [C]Saves me {c:(}[Em7]{c:saves me)}   [G] 
   And [Em7]after [C]all    [Em7]  [G]              
   You're my [Em7]wonder[C]wall  [Em7]           [G]        [Em7] 
{eoc}
 
[Em7] Today was [G]gonna be the day 
But they'll [D]never throw it back to [A]you
[Em7] By now you [G]should have somehow 
Real[D]ized what you're not to [A]do
[Em7]I don't believe that [G]anybody 
[D]Feels the way I [A]do about you [Em7]now   
[G]/ / / /    [D]/ / / /    [A]/ / / 
 
And [C]all the roads that [D]lead you there were [Em7]winding
And [C]all the lights that [D]light the way are [Em7]blinding
[C]There are many [D]things that I would [G]like to [D]say to [Em7]you
But I don't know [A]how {c:(34,1234)} 
[A]/ / / /   / / / 

{soc}        
   Because [C]maybe {c:(cause }[Em7]{c:maybe)}    [G]  
   You're  [Em7]gonna be the one that 
   [C]Saves me {c:(}[Em7]{c:saves me)}   [G] 
   And [Em7]after [C]all    [Em7]  [G]              
   You're my [Em7]wonder[C]wall  [Em7]           [G]       [Em7] 
{eoc}

I said [C]maybe  [Em7]{c:maybe)}    [G]  
You're [Em7]gonna be the one that 
[C]Saves me {c:(}[Em7]{c:saves me)}   [G] 
You're [Em7]gonna be the one that 
[C]Saves me {c:(}[Em7]{c:saves me)}   [G] 
You're [Em7]gonna be the one that 
[C]Saves me {c:(}[Em7]{c:saves me)}   [G]      [Em7]

[C]/ / / /    [Em7]/ / / /    [G]/ / / /    [Em7]/ 
 

 