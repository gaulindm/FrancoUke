{title:COTTON JENNY}
{subtitle:(4/4  Key of C)}      
{subtitle:  Gordon Lightfoot}
{time: 2:20}
{metronome:135}


[C]/ / / /   / / / 
 
There's a [C]house on a hill
By a [F]worn down weathered old [C]mill
And a valley be-[G7]low where the river winds
There's no such thing as bad [C]times

And a soft southern flame
Oh [F]Cotton Jenny's her [C]name
And she wakes him [G7]up when the sun goes down
And the wheels of love go [C]round


{soc}
  Wheels of love go [F]round
  Love go [C]round, love  go [D]round
  A joyful [G7]sound
  He ain't [C]got a penny for [F]Cotton Jenny to [G7]spend
  But then, the wheels go [C]round {c:(234,1234)}  [D]/ / / /   / / /
{eoc}

When a [D]new, day begins
He goes [G]down to the cotton [D]gin
And he makes his [A]time worth while to them
Then he climbs back up a-[D]gain

And she waits by the door
Oh [G]Cotton Jenny he's [D]sore
And she rubs his [A]feet while the sun goes down
And the wheel of love goes [D]round

{soc}
  Wheels of love go [G]round
  Love go [D]round, love  go [E]round
  A joyful [A]sound
  He ain't [D]got a penny for [G]Cotton Jenny to [A]spend
  But then, the wheels go [D] round

  Wheels of love go [G]round
  Love go [D]round, love  go [E]round
  A joyful [A]sound
  He ain't [D/]got a penny for [G/]Cotton Jenny to [A/]spend
  But then, the wheels go [D/] round
{eoc}



