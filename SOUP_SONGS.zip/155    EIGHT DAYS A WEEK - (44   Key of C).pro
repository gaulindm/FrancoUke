

{title:155    EIGHT DAYS A WEEK  }   
{subtitle:(4/4   Key of C)}
{subtitle:(John Lennon & Paul McCartney)}
{time:3:16}
{metronome: 156}

{c:(* means “ba dum” (a quick up-down)}

 


[C]/ / / /     [D]/ / / /     
[F]/ / / /    [C]/ / / /       

[C]Ooh I need your [D]love babe 
[F]Guess you know it's [C]true
[C]Hope you need my [D]love babe 
[F]Just like I need [C]you
[Am/]Hold me [*Am]            [F/]love me 
[*F]   [Am/]Hold me [*Am]            [D/]love me  [*D]
I [C]ain't got nothing but [D]love babe 
[F]  Eight days a [C]week

[C]Love you every [D]day girl 
[F]Always on my [C]mind
[C]One thing I can [D]say girl 
[F]Love you all the [C]time
[Am/]Hold me [*Am]            [F/]love me 
[*F]   [Am/]Hold me [*Am]            [D/]love me   [*D]
[C]Ain't got nothing but [D]love girl 
[F]  Eight days a [C]week

{c:CHORUS}
{soc}
     [G/]Eight days a [G/]week 
     I [Am/]lo-o-o-o-[Am/]ove you 
     [D/]Eight days a [D/]week 
     Is [F]not enough to [G7]show I care
{eoc}

[C]Ooh I need your [D]love babe 
[F]Guess you know it's [C]true
[C]Hope you need my [D]love babe 
[F]Just like I need [C]you
[Am/]Hold me [*Am]            [F/]love me 
[*F]   [Am/]Hold me [*Am]            [D/]love me  [*D]
I [C]ain't got nothing but [D]love babe 
[F]  Eight days a [C]week

[C]Love you every [D]day girl 
[F]Always on my [C]mind
[C]One thing I can [D]say girl 
[F]Love you all the [C]time
[Am/]Hold me [*Am]             [F/]love me 
[*F]   [Am/]Hold me [*Am]            [D/]love me   [*D]
[C]Ain't got nothing but [D]love girl 
[F]  Eight days a [C]week

{soc}
     [G/]Eight days a [G/]week 
     I [Am/]lo-o-o-o-[Am/]ove you 
     [D/]Eight days a [D/]week 
     Is [F]not enough to [G7]show I care
{eoc}

[C]/ / / /    [D]/ / / /    

[F]    Eight days a [C]week     
[F]    Eight days a [C]week   
[F]    Eight days a [C/]wee…k

_____________________________________










