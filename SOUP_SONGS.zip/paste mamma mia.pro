{title:paste mamma mia}
{subtitle:}
[C]   Mamma mia,[Caug]          here I go again  
[F]   My my, [Dm]how can I re[G]sist you?
[C]   Mamma mia,[Caug]         does it show again?  
[F]   my my, [Dm]just how much I've [G]missed you