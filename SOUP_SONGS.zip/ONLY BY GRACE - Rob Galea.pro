{title:ONLY BY GRACE}
{subtitle:Rob Galea}

[Dm]Amazing [C]grace how [Bb]sweet the [F]sound
[Dm] that saved a [C]wretch like [Bb]me
[Dm] I once was[C] lost but[Bb] now I'm [F]found
No longer [Bb]blind - [C]I [Bb]see

[Dm]I have [C]chosen to [Bb]run this [F]race
de[Dm]termined to [C]reach the [Bb]end
but [Dm]I have for[C]gotten it's[Bb] only by [F]grace
that I can [Bb]see, [C]   Your [F]face

{soc}
It's only by [Bb]grace the[C] eagles [F]fly
By that same [Bb]grace, you'll [C]lift me [Dm]high
I lift up my[Bb] hands to You, It's [F]you alone 
Who can [Bb]show me the way
The [Gm]way to the [C]Father's [F]throne
{eoc}

[Dm]Oh I've [C]tried to [Bb]walk a[F]lone  
[Dm] It was to [C]no a[Bb]vail        
[Dm]But when [C]all's been [Bb]said and [F]done
I know [Bb]that I [C]am too [F]frail

{soc}
It's only by [Bb]grace the [C]eagles [F]fly
By that same [Bb]grace, you'll [C]lift me [Dm]high
I lift up my[Bb] hands to You, It's [F]you alone 
Who can [Bb]show me the way

[C]yeah

It's Only by [Bb]grace [C]that I [F]see,
That I can [Bb]be, all I'm [C]called to [Dm]be
I lift up my[Bb] hands to You, It's [F]you alone 
Who can [Bb]show me the way 
The [Gm]way to the [C]Father's [F]throne
{eoc}
