{title: CAREY}
{subtitle: JONI MITCHELL}

[C]/ / / /    [G]/ / / /    [D]/ / / /    [G]/   [Gsus4]/   [G]/ /

The [G]wind is in from Africa 
[D]Last night I couldn't sleep
Oh you know it [C]sure is hard to [G]leave here Carey
But it's really [D]not my home
[G]  My fingernails are filthy I got 
[D]Beach tar on my feet
And I [C]miss my clean white [G]linen 
And my fancy [D]French cologne

{soc}
   Oh [D]Carey get out your [G]cane 
   And I'll put on some [D]silver
   [C]Oh you're a mean old [G]daddy but 
   I [D] like [G] you [Gsus4] [G]
{eoc}

Come on [G]down to the Mermaid Cafe and I will 
[D]Buy you a bottle of wine
And we'll [C]laugh and toast to [G]nothing
And smash our [D]empty glasses down
Let's have a [G]round for these freaks and these soldiers
A [D]round for these friends of mine
Let's have another [C]round for the bright red [G]devil
Who keeps me [D]in this tourist town

{soc}
   Oh [D]Carey get out your [G]cane and 
   I'll put on some [D]silver
   [C]Oh you're a mean old [G]daddy but  
   I [D] like [G] you [Gsus4] [G]
{eoc}

[G]Maybe I'll go to Amsterdam or 
[D]Maybe I'll go to Rome
And [C]rent me a grand pi[G]ano 
and put some flowers [D]round my room
But [G]let's not talk about fare-thee-wells now 
the [D]night is a starry dome
And they're [C]playin' that scratchy [G]rock and roll
Beneath the [D]Matalla Moon

{soc}
   Oh [D]Carey get out your [G]cane and I'll put on some [D]silver
   [C]Oh you're a mean old [G]daddy but I [D] like [G] you [Gsus4] [G]
{eoc}

The [G]wind is in from Africa [D]last night I couldn't sleep
Oh you know it [C]sure is hard to [G]leave here Carey
But it's really [D]not my home
[G]Maybe it's been too long a time since I was [D]scramblin' down in the street
Now they got me [C]used to that clean white [G]linen
And that fancy [D]French cologne

{soc}
{c:CHORUS:}
     Oh [D]Carey get out your [G]cane and I'll put on my finest [D]silver
     We'll [C]go to the Mermaid [G]Cafe have [D]fun to[G]night
     I said [C]oh you're a mean old [G]daddy but y[D]ou're out of [G]sight
{eoc}

[C]/ / / /    [G]/ / / /    [D]/ / / /    [G]/   [Gsus4]/   [G]/

_____________________________________

















