{title:OH MY DARLING FRANKENSTEIN}
{subtitle:}
{time:2:16}
{metronome:124}




I was [G]working with my test tubes 
In my labratory [D7]fine
Then one [C]day I broke my [G]glasses 
And I [D7]made poor Franken[G]stein
He was charming, he was handsome 
And I nailed his head on [D7]tight
Oh his [C]teeth were sharp and [G]pearly 
And his [D7]eyes came out at [G]night

{soc}
   Oh My [G]Darling, oh my Darling 
   Oh my Darling Franken[D7]stein
   You are [C]lost and gone for[G]ever
   Dreadful [D7]sorrow, Franken[G]stein
{eoc}

Then his [G]nose I made it quickly
From a rotten apple [D7]core
And his [C]tongue was nice and [G]purple 
Hanging [D7]down upon the [G]floor
Then the Wolfman came to wo-ork 
"Sir" I said, "What's in your [D7]mouth?"
He said "[C]fangs", I said "you're [G]welcome" 
And he [D7]still is running [G]south

{soc}
   Oh My [G]Darling, oh my Darling 
   Oh my Darling Franken[D7]stein
   You are [C]lost and gone for[G]ever
   Dreadful [D7]sorrow, Franken[G]stein
{eoc}

Franken[G]stein helped in the kitchen 
He was baking up a [D7]cake
When he [C]fell in the Mix[G]master 
And got [D7]whipped up by mis[G]take
Cooking nicely in the oven
Oh the cake it came out [D7]fine
Told my [C]friends that they were [G]rasins
But the [D7]lumps were Franken[G]stein

{soc}
   Oh My [G]Darling, oh my Darling 
   Oh my Darling Franken[D7]stein
   You are [C]lost and gone for[G]ever
   Dreadful [D7]sorrow, Franken[G/]stein
{eoc}
