

{title:036 UP ON CRIPPLE CREEK}
{subtitle:  4/4      Key of A}
{subtitle:(Robbie Robertson)}
{metronome:154}
{time:4:58}


{c:(emphasis on beat 1)}


[A]/ / / /    [D]/ / / /    
[A]/ / / /    [D]/ / / / 
  
When [A]I get off of this mountain
You [D]know where I wanna go
[A] Straight down the [D]Mississippi River 
To the [E7]Gulf of Mexico
To [A]Lake Charles, Louisiana
Little [D]Bessie girl that I once knew
[A]  She told me just to [D]come on by 
If there's [E7]anything that she-could-do
 
{soc} 
  [A]Up on Cripple Creek, she sends me
  [D]If I spring a leak, she mends me
  [E7]I don't have to speak, she defends me
  A [F#m/]drunkard's dream if I [G/]ever did see one 
  [G]/ / / /   / / / /
{eoc}
 
[A]Good luck had just stung me
To the [D]race track I-did-go
[A]  She bet on [D]one horse to win 
And I [E7]bet on another to show
The [A]odds were in my favor 
I [D]had 'em fi...ve to one
[A]  That nag to [D]win came around-the-track
[E7]Sure enough she had-won
 
{soc}
  [A]Up on Cripple Creek, she sends me
  [D]If I spring a leak, she mends me
  [E7]I don't have to speak, she defends me
  A [F#m/]drunkard's dream if I [G/]ever did see one
  [G]/ / / /   / / / /
{eoc} 
 
I [A]took up all of my winnings 
And I [D]gave my little Bessie half
[A] She tore it up and [D]threw it in my face 
[E7]Just for a laugh
And [A]there's one thing in the {soh}whole wide world{eoh} 
[D]I sure would like to see
[A] That's when that little [D]love of mine 
Dips her [E7]doughnut-in-my-tea
 
{soc}
  [A]Up on Cripple Creek, she sends me
  [D]If I spring a leak, she mends me
  [E7]I don't have to speak, she defends me
  A [F#m/]drunkard's dream if I [G/]ever did see one
  [G]/ / / /   / / / /
{eoc}
 
Now [A]me and my mate we were back at the shack 
We had [D]Spike Jones on the box
[A]  She-said-"I-can't-take   the-[D]way-he-sings
But I [E7]love to hear him talk."
Now [A]that just gave my {soh}heart a throb{eoh} 
To the [D]bottom of my-feet
[A] And I swore as I [D]took another pull
My [E7]Bessie-can't-be-beat
 
{soc} 
  [A]Up on Cripple Creek, she sends me
  [D]If I spring a leak, she mends me
  [E7]I don't have to speak, she defends me
  A [F#m/]drunkard's dream if I [G/]ever did see one
  [G]/ / / /   / / / /
  [A]    No, no, [D]no hoo hoo 
  [A]Lodo lodo lo hoo [D]hoo
  [A]    No, no, [D]no hoo hoo 
  [A]Lodo lodo lo hoo [D]hoo  {c:(23)}         
{eoc}
  
There's a [A]flood out in Californ{soh}ia{eoh} 
And up [D]north it's freezing cold
[A]  And this living [D]on the road 
Is [E7]getting pretty old
So I [A]guess I'll call up my big mama 
Tell her [D]I'll be rolling in
But you [A]know deep down
I'm [D]kind of tempted
To [E7]go and see my Bessie again
 
{soc}
  [A]Up on Cripple Creek, she sends me
  [D]If I spring a leak, she mends me
  [E7]I don't have to speak, she defends me
  A [F#m/]drunkard's dream if I [G/]ever did see one
  [G]/ / / /   / / / /    
  [A]    No, no, [D]no hoo hoo 
  [A]Lodo lodo lo hoo [D]hoo
  [A]    No, no, [D]no hoo hoo
  [A]Lodo lodo lo hoo [D]hoo  {c:(234)}   [A]/
{eoc} 
 


-----------
[F#m]















