

{title:022   HARVEST MOON }
{subtitle:(4/4   Key of D)}
{subtitle:(Neil Young) }
{time:3:44}
{metronome: 116}

{c:Riff: Barre 7th fret, lift to pluck E string}
{sot}
A - 7 - - - - - - - - - - -       
E - - - 7 - - - - 0 - - - -          
C - - - - - 7 - - - - - - -       
{eot}

{c:INTRO: 
[D]/ /    [D6]/ /    [Dmaj7]/ / / /
[D]/ /    [D6]/ /    [Dmaj7]/ / / /  

{c:(}[Em7***]{c:123)}     Come a little bit closer   
{c:(}[Em7***]{c:123)}     Hear what I have to say
[D]/ /   [D6]/ /     [Dmaj7]/ / / /     
[D]/ /   [D6]/ /     [Dmaj7]/ / / /

 
{c:(}[Em7***]{c:123)}     Just like children sleepin’  
{c:(}[Em7***]{c:123)}     We could dream this night away 
[D]/ /     [D6]/ /     [Dmaj7]/ / / /      
[D]/ /     [D6]/ /     [Dmaj7]/ / / /


{c:(}[Gmaj7]{c:1,2)}     But there’s a [Em7]full moon risin’
{c:(}[Gmaj7]{c:1,2)}     Let’s go dancin’ in the light
[D]/ /    [D6]/ /     [Dmaj7]/ / / /     
[D]/ /    [D6]/ /     [Dmaj7]/ / / /

{c:(}[Gmaj7]{c:1,2)}     We know where the 
[Em7]music’s playin’
{c:(}[Gmaj7]{c:1,2)}     Let’s go out and feel the night
[D]/ /    [D6]/ /     [Dmaj7]/ / / /     
[D]/ /    [D6]/ /     [Dmaj7]/ / / /

{soc} 
[A7sus4]{c:(1,2)}   Because I’m still in love with [A7]you
I want to see you dance a[A7sus4]gain
Because I’m still in love with [A7]you
On this harvest moon 
[D]/ /    [D6]/ /     [Dmaj7]/ / / /       
[D]/ /    [D6]/ /     [Dmaj7]/ / / /
{eoc}

{c:(}[Em7***]{c:123)}     When we were strangers
{c:(}[Em7***]{c:123)}     I watched you from afar
[D]/ /    [D6]/ /    [Dmaj7]/ / / /  
[D]/ /    [D6]/ /    [Dmaj7]/ / / /


{c:(}[Em7***]{c:123)}     When we were lovers  
{c:(}[Em7***]{c:123)}     I loved {soh}you{eoh} with all my heart
[D]/ /    [D6]/ /     [Dmaj7]/ / / /      
[D]/ /    [D6]/ /     [Dmaj7]/ / / /


{c:(}[Gmaj7]{c:1,2)}     But now its [Em7]gettin late 
{c:(}[Gmaj7]{c:1,2)}     And the moon is climbin’ high
[D]/ /     [D6]/ /     [Dmaj7]/ / / /       
[D]/ /     [D6]/ /     [Dmaj7]/ / / /

[Gmaj7]  I want to [Em7]celebrate
{c:(}[Gmaj7]{c:1,2)}    See it shinin’ in your eye
[D]/ /     [D6]/ /      [Dmaj7]/ / / /       
[D]/ /     [D6]/ /      [Dmaj7]/ / / /

{soc}
[A7sus4]{c:(1,2)}     Because I’m still in love with [A7]you
I want to see you dance a[A7sus4]gain
Because I’m still in love with [A7]you 
On this harvest Moon 
[D]/ /     [D6]/ /     [Dmaj7]/ / / /       
[D]/ /     [D6]/ /     [Dmaj7]/ / / /  
[D]/ /     [D6]/ /     [Dmaj7]/ / / /       [D/]
{eoc}

___________________________________________








{define: Gmaj7 0 0 2 2 2}
{define: A7sus4 0 0 2 0 0}
{define: D6 0 2 2 2 2}
{define: Dmaj7 0 2 2 2 4}
{define: Em7 0 0 2 0 2}



