{title: CLOSER TO FINE        Indigo Girls}




{c:INTRO:}
[F/C]/ / / /    [G7sus4]/ / / /    [Bbadd9]/ / / /   
[Csus4]/ [C]/ [Cadd9]/ [C]/  

[F/C]/ / / /    [G7sus4]/ / / /    [Bbadd9]/ / / /    
[Csus4]/ [C]/ [Cadd9]/ [C]/  

I'm [F/C]trying to tell you [G7sus4]something 'bout my 
[Bbadd9]Life             [Csus4]/ [C]/ [Cadd9]May- [C]be    
[F/C]Give me insight [G7sus4]between black and 
[Bbadd9]White         [Csus4]/ [C]/ [Cadd9]                         And [C]the 
[Csus4]Best thing you've ever done for [Bbadd9]me
Is to  [Csus4]help me take my life less serio[Bbadd9]usly
It's only life [F/C]after all [G7sus]/ / /   yeah  
[Bbadd9]    [Csus4]/ [C]/ [Cadd9]/ [C]/ 


Well [F/C]darkness has a [G7sus4]hunger that's 
In[Bbadd9]satiable [Csus4]/ [C]/ [Cadd9]/ [C]and 
[F/C]Lightness has a [G7sus4]call that's hard to 
[Bbadd9]Hear   [Csus4]/ [C]/ [Cadd9]/ [C]I 
[Csus4]Wrapped my fear around me like a [Bbadd9]blanket 
I [Csus4]sailed my ship of safety till I [Bbadd9]sank it 
I'm crawling on your [F]shores [F]/


{soc}
I [C]went to the doctor I [Bb]went to the [F]mountains 
I [C]looked to the children I [Bb]drank from the [F]fountains 
There's [Csus4]more than one answer to these 
[Bbadd9]Questions pointing me in a [F]crooked line   [F]/
And the [Csus4]less I seek my source for some 
De[Bbadd9]finitive [Bbadd9/]
The closer I [F/C]am to fi-  [G7sus4]i-i-ine    [Bbadd9]
The [Csus4]closer I [F/C]am to fi-  [G7sus4]i-i-ine    
[Bbadd9]    [Csus4]/ [C]/ [Cadd9]/ [C]/ 
{eoc}


I [F/C]went to see the [G7sus4]doctor of 
Phi[Bbadd9]losophy [Csus4]/ [C]/ [Cadd9]/ [C]With a 
[F/C]poster of Ras[G7sus4]putin and a 
[Bbadd9]Beard down to his [Csus4]knee [C]/ [Cadd9]/          [C]He 
[Csus4]Never did marry or [Bbadd9]see a B grade movie 
He [Csus4]graded my performance 
He [Bbadd9]said he could see through me I spent 
[F/C]four years prostrate [Bbadd9]to the higher [Bb]mind 
Got my [C]paper and I was [F]free   [F]/


{soc}
I [C]went to the doctor I [Bb]went to the [F]mountains 
I [C]looked to the children I [Bb]drank from the [F]fountains 
There's [Csus4]more than one answer to these 
[Bbadd9]Questions pointing me in a [F]crooked line   [F]/
And the [Csus4]less I seek my source for some 
De[Bbadd9]finitive [Bbadd9/]
The closer I [F/C]am to fi- [G7sus4]i-i-ine    [Bbadd9]
The [Csus4]closer I [F/C]am to fi- [G7sus4]i-i-ine    
[Bbadd9]     [Csus4]/  [C]/ [Cadd9]/ [C]/ 
{eoc}


I [F/C]stopped by the [G7sus]bar at 
Three A.[Bbadd9]M. [Csus4]/ [C]/ [Cadd9]to [C]seek 
[F/C]solace in a [G7sus4]bottle    
Or    [Bbadd9]possibly   a [C]friend 
And I [Csus4]woke up with a headache like my 
[Bbadd9]Head against a board  
[Csus4]Twice as cloudy as I'd been the [Bbadd9]night before 
And I went in seeking [F]clarity   [F]/


I [C]went to the doctor I [Bb]went to the [F]mountains 
I [C]looked to the children I [Bb]drank from the [F]fountains 
We [C]go to the doctor we [Bb]go to the [F]mountains 
We [C]look to the children we [Bb]drink from the [F]fountains 
We [C]go to the bible we [Bb]go through the [F]workout 
We [C]read up on revival we [Bb]stand up for the [F/]lookout 

There's [Csus4]more than one answer to these 
[Bbadd9]Questions pointing me in a [F]crooked line  [F]/
And the [Csus4]less I seek my source for some 
De[Bbadd9]finitive [Bbadd9/]
The closer I [F/C]am to fi- [G7sus]i-i-ine     [Bbadd9]    
The [Csus4] closer  I [F/C] am to fi- [G7sus]i-i-ine    [Bbadd9] 
The closer I [F/C]am to fi- [G7sus]i-i-ine       
[Bbadd9]  [Csus4]/  [C]/  [Cadd9]/  [C]/  [F/]
{define: G7sus4 0 0 2 1 3}
{define: Bbadd9 0 3 2 1 3}
{define: Fsus4 0 3 0 1 1}
{define: F/C 0 2 0 1 3}