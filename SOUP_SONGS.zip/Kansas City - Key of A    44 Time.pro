{title:Kansas City}
{subtitle:Key of A    4/4 Time}
{subtitle:(Wilbert Harrison - Beatles)}

1,2  1,2,3 

Goin' to [A]  Kansas City, Kansas City here I come,  [A7]
I'm goin' to[D]  Kansas City, Kansas City, here I c[A]ome.  
[A]They got some [E7]pretty little women there, And [D7]  I'm gonna get me [A]one. [E7]

I'm gonna be[A]  standin' on the corner, Twelfth Street and Vine.  [A7]
I'm gonna be [D]standin' on the corner, Twelfth Street and [A]Vine.
[A]With my [E7]Kansas City baby, And a [D7]   bottle of Kansas City [A]wine. [E7]

[A]Well I might take a train, I might take a plane, but if I have to walk
I'm [A7]going just the same, I'm going to [D]  Kansas City
Kansas City here I [A]come
They got some [E7]crazy little women there and [D7]   I'm gonna get me [A]one.[E7]
 

If I [A]stay with that woman I know I'm going to die
Have to find a friendly baby [A7]that's the reason why
I'm goin' to [D]  Kansas City, Kansas City, here I c[A]ome.
[A]They got some [E7]crazy little women there,
And [D7]   I'm gonna get me [A]some.  [E7]



Well I [A/]might take a train,[A(udu)A/]   I might take a plane, [A(udu)A/]   but if I have to [A/]walk
I'm g[A7]oing just the same, I'm going to [D]  Kansas City
Kansas City here I [A]come
They got some [E7]crazy little women there and [D7]    I'm gonna get me [A]one. [E7]   {c:(2,3,4)}

[A/](1,2,3,4)   [D7/] (1,2,3,4)  [A] (1,2,3,4,1,2) [E7/]
 
I'm going to  [A]  Kansas City, Get my baby one time
I'm going to [D]  Kansas City, Get my baby one  [A]time, ...,,yeah, yeah
It's just a-[E7]one, two, three, four,[D7]  Five, six, seven, eight, [A]nine [E7/]
 
Hey, hey, hey, h[A]ey (echo Hey Hey Hey Hey)

Hey Baby (echo Hey Baby)
Ooh, now, [D]gal   (echo Well, gal)
I said, yeah, now, [A]gal (echo well gal)
Woah, now, tell me, [E7]baby
[D7]  What's been wrong with y[A]ou, ....[E7/]yeah 

 
Hey, hey, hey, h[A]ey (echo Hey Hey Hey Hey)

Hey Baby (echo Hey Baby)
Ooh, now, [D]gal   (echo Well, gal)
I said, yeah, now, [A]gal (echo well gal)
Woah, now, tell me, [E7]baby
[D7]  What's been wrong with y[A]ou, yeah [E7]
 
Well, bye-[A]bye (echo bye-bye, bye-bye, bye-bye)
 
Bye-bye baby, (echo bye-bye bye-bye, bye-bye)
Ooh, so [D]long  (echo so long, so long, so long)
Baby, I'm [A]gone (echo bye-bye, bye-bye, bye-bye)
Oh-yeah-now-bye-bye [E7]baby                        
[D7/]  Bye-bye baby bye-[A/]bye, oh, [A7]yeah . . . .
