{title:THE NIGHTS}
{subtitle:(Avicii) Key of Em}
{time: 1:43}

{c:INTRO:   Em / / /   Hey!}
[Em]Once upon a younger year when all our shadows disappeared
The [D]animals inside came out to [Em]play {c:(23)} Hey!
Went [Em]face to face with all our fears, 
learned our lessons through the tears
Made [D]memories we knew would never [Em]fade {c:(23)}

One day, my [C]father, he told me, son, don't [G]let it slip away
He [D]took me in his arms, I heard him [Em]say (beat)
{c:(Hey)}When you get [C]older your wild heart 
will [G]live for younger days
[D]Think of me if ever you're a[D/]fraid

He said, one [C/]day - you'll leave this world be[G/]hind
So live a [D/]life you will re[Em/]member
My father [C/]told me when I was just a [G/]child
These are the [D/]nights that never [Em/]die

My father told me

{c:Instrumental}
{c:C / / / /   G / / / /     D  / / / /     Em  / / / / }                 
{c:                   (hey,hey!                     hey,hey!)}

[Em]When thunderclouds start pouring down, 
light a fire they can't put out
[D]Carve your name into those [Em]shining stars
He said - go venture far beyond the shores, 
don't forsake this life of yours
I'll [D]guide you home no matter where you [Em]are

One day, my [C]father, he told me, son, 
don't [G]let it slip away
When [D]I  was just a kid, I heard him [Em]say
When you get [C]older your wild heart 
will [G]live for younger days
[D]Think of me if ever you're a[D/]fraid

He said, one [C/]day, you'll leave this world be[G/]hind
So live a [D/]life   you will re[Em/]member
My father [C]told me when I was just a [G/]child
These are the [D/]nights that never [Em/]die

My father told me
{c:Instrumental}
{c:C / / / /   G / / / /     D  / / / /     Em  / / / / }                 
{c:                   (hey,hey!                     hey,hey!)}
    
                              
These are the [D/]nights that never [Em/]die
My father told me


