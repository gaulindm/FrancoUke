{title:I'LL FLY AWAY}
{title:WILL THE CIRCLE BE UNBROKEN}
{subtitle:(4/4  Key of C)}
{subtitle:(Albert Brumley)}
{subtitle:(Ada Habershon & Charles Gabriel)}
{time: 4:35}
{metronome:184}







{c:INTRO:}      
[G7]/ / / /    / / / /     
[C]/ / / /    / / / /

[C]Some glad morning when this life is [C7]over 
[F]I'll fly a[C]way 
To a home on [Am]God's celestial shore 
[G7]I'll fly a[C]way
[C]When the shadows of this life are [C7]gone 
[F]I'll fly a[C]way
Like a bird from [Am]prison bars has flown 
[G7]I'll fly a[C]way  

{soc}
     [C]I'll fly away oh [C7]glory 
     [F]I'll fly a[C]way
     When I die halle[Am]lujah by and by 
     [G7]I'll fly a[C]way
{eoc}

[C]Oh how glad and happy when we [C7]meet 
[F]I'll fly a[C]way
No more cold iron [Am]shackles on my feet 
[G7]I'll fly a[C]way   
[C]Just a few more weary days and [C7]then 
[F]I'll fly a[C]way
To a land where [Am]joy shall never end 
[G7]I'll fly a[C]way    

{soc}
     [C]I'll fly away oh [C7]glory
     [F]I'll fly a[C]way
     When I die halle[Am]lujah by and by 
     [G7]I'll fly a[C]way



     Will the [C]circle be un[C7]broken 
     By and [F]by Lord by and [C]by
     There's a better home a-waiting
     In the sky Lord [G7]in the [C]sky
{eoc}

I was [C]singing with my [C7]sisters 
I was [F]singing with my [C]friends
And we all can sing together 
‘Cause the circle [G7]never [C]ends  

{soc}
     Will the [C]circle be un[C7]broken 
     By and [F]by Lord by and [C]by
     There's a better home a-waiting 
     In the sky Lord [G7]in the [C]sky
{eoc}

I was [C]born down in the [C7]valley 
Where the [F]sun refused to [C]shine
But I'm climbing up to the highland 
Gonna make that [G7]mountain [C]mine

{soc}
     Will the [C]circle be un[C7]broken 
     By and [F]by Lord by and [C]by
     There's a better home a-waiting 
     In the sky Lord [G7]in the [C]sky

     Will the [C]circle be un[C7]broken 
     By and [F]by Lord by and [C]by
     There's a better home a-waiting 
     In the sky Lord [G7]in the [C]sky
     In the sky Lord, [G7]in the [C]sky    
     {c:(slow down)}
     In the sky… Lord… [G7]in… the… [C]sky…
{eoc}