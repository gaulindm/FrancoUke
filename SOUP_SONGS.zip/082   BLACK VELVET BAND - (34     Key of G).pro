

{t:082   BLACK VELVET BAND  }
{subtitle:(3/4     Key of C)}         
{subtitle:(collection)}
{time:4:43}
{metronome:168}






[C]/ / /   / / /    [Am]/ / /   / / /    
[F]/ / /    [G]/ / /    [C]/ / /    / /  

In a [C]neat little town they call Belfast
Apprenticed to trade I was [G]bound
And [C]many an hour's sweet [Am]happiness 
I [F]spent in that [G]neat little [C]town
Till bad misfortune came o'er me 
And caused me to stray from the [G]land
Far a[C]way from me friends and re[Am]lations 
To [F]follow the [G]Black Velvet [C]Band

{c:CHORUS}
{soc}
     Her [C]eyes they shone like the diamonds 
     You'd think she was queen of the [G]land
     And her [C]hair hung over her [Am]shoulder 
     Tied [F]up with a [G]Black Velvet [C]Band  
{eoc}

Well [C]I was out strolling one evening 
Not meaning to go very [G]far
When I [C]met with a pretty young [Am]damsel 
Who was [F]sellin' her [G]trade in the [C]bar
When a watch she took from a customer 
And slipped it right into me [G]hand
And the [C]law came and put me in [Am]prison 
Bad [F]luck to your [G]Black Velvet [C]Band 

{soc}
     Her [C]eyes they shone like the diamonds 
     You'd think she was queen of the [G]land
     And her [C]hair hung over her [Am]shoulder 
     Tied [F]up with a [G]Black Velvet [C]Band  
{eoc}

Next [C]mornin' before judge and jury 
For trial I had to ap[G]pear
And the [C]judge he says  
"Young [Am]fellow, me lad 
The [F]case against [G]you is quite [C]clear
And seven long years is your sentence 
You're going to Van Diemens [G]Land
Far [C]away from your friends and re[Am]lations 
To [F]follow the [G]Black Velvet [C]Band" 

{soc}
     Her [C]eyes they shone like the diamonds 
     You'd think she was queen of the [G]land
     And her [C]hair hung over her [Am]shoulder 
     Tied [F]up with a [G]Black Velvet [C]Band   
{eoc}

So [C]come all ye jolly young fellows
I'll have you take warnin' by [G]me
When[C]ever you're into the [Am]liquor me lads 
Be[F]ware of the [G]pretty co[C]lleens
They'll fill you with whiskey and porter 
Until you're not able to [G]stand
And the [C]very next thing that you [Am]know me lads 
You've [F]landed in [G]Van Diemen's [C]Land 

{soc}
     Her [C]eyes they shone like the diamonds 
     You'd think she was queen of the [G]land
     And her [C]hair hung over her [Am]shoulder 
     Tied [F]up with a [G]Black Velvet [C]Band  

     Her [C]eyes they shone like the diamonds 
     You'd think she was queen of the [G]land
     And her [C]hair hung over her [Am]shoulder 
     Tied [F]up with a [G]Black Velvet [C]Band  [G/]  [C/]
{eoc}

_______________________________________










