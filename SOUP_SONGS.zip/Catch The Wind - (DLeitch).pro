{title:Catch The Wind}
{subtitle:(D.Leitch)}
{subtitle:6/8    Key of C}
{time:2:49}
{metronome:174}






{c:INTRO:}
[C]/ / /   / / /    [F]/ / /   [G7]/ / /    
[C]/ / /   / / /    [G7]/ / /   / / / 

In the [C]chilly hours and [F]minutes
Of un[C]certainty, I  [F]want to be
[C]In the warm hold [F]of your [G7]loving [C]mind     [G7]
 
To [C]feel you all a[F]round me
And to [C]take your hand a[F]long the sand
[C]Ah, but I may as well [F]try and [G7]catch the  
[C]Wind [Csus4] [C]
 
When [C]sundown pales the [F]sky
I want to [C]hide a while be[F]hind your smile
[C]And everywhere I'd [F]look 
Your [G7]eyes I'd [C]find       [G7]
 
For [C]me to love you [F]now
Would be the [C]sweetest thing, would [F]make me sing
[C]Ah, but I may as well [F]try and [G7]catch the 
[C]Wind [Csus4] [C]
 
[F]Deedee dee dee, dee dee [Am]deedee
Dee dee [F]deedee dee dee [D7]deedee
Dee de [G]deeee [G7] [Em7] [G7]
 
When [C]rain has hung the [F]leaves with tears
I [C]want you near to [F]kill my fears
To [C]help me to leave [F]all my [G7]blues be[C]hind     [G7]
 
For [C]standing in your [F]heart
Is where I [C]want to be and  [F]long to be
[C]Ah, but I may as well [F]try and [G]catch the 
[C]Wind [Csus4] [C] [G7]


{c:(gentle strumming. Picking shines here)}
[C]/ / /   / / /    [F]/ / /   / / / 
[C]/ / /   / / /    [F]/ / /   / / / 
[C]/ / /   / / /    [F]/ / /   [G7]/ / /    
[C]/ / /   / / /    [G7]/ / /   / / / 

When [C]rain has hung the [F]leaves with tears
I [C]want you near to [F]kill my fears
To [C]help me to leave [F]all my [G7]blues be[C]hind [G7]
 
For [C]standing in your [F]heart
Is where I  [C]want to be and  [F]long to be
[C]Ah, but I may as well [F]try and 
[G7]catch the [C]wind [Csus4] [C]
[C]Ah, but I may as well [F]try and 
[G7]catch the [C]wind [Csus4] [C]
 