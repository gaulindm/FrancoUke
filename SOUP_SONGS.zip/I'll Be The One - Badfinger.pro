{title:I'll Be The One}
{subtitle:Badfinger}
{metronome:165}





 
[D]Where did you [Em]go  
[A]  when you were needed?
Was it [C]someplace I [G]know where they [D]care? {c:(234,1234)}
[D]Cries in the [Em]rain
[A] I'll learn to get by without 
[C]you for the [G]pain in my [D]heart {c:(234,1234)}
 
[Am]I'll be the one, [G]we'll be to[D]gether
[A]I'll be the one, for[C]ever and [G/]ev[G/]er
 
[D]Look at me [Em]now, [A]   am I the loser?
If you [C]can't tell me 
[G]how, tell me [D]why  {c:(234,1234)}
[D]But just the [Em]same
[A] I'll learn to get by without [C]you 
for the [G]pain in my [D]heart {c:(234,1234)} 
 
[Am]I'll be the one, [G]we'll be to[D]gether
[A]I'll be the one, for[C]ever and e[G]ver and [D]ever 
[Em]  oo oo [A]oo {c:(234,1234)} [C]ah [G]ah [D]ah
[Em]  oo oo [A]oo {c:(234,1234)}  [C]ah [G]ah [D]ah {c:(234,1234)}
 
[Am]I'll be the one, [G]we'll be to[D]gether
[A]I'll be the one, for[C]ever and [G]ever and [D]ever {c:(234,1234)}
[C]Ooooh, o[G]oooh, o[D]oooh {c:(234,1234)} 
[C]Ooooh, o[G]oooh, o[D]oooh {c:(234,1234)}
[C]Ooooh, o[G]oooh, o[D]oooh {c:(234,1234)}
[C]riff          [G]            [D/]

