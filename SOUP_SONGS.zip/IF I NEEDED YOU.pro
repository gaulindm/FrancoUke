{title:IF I NEEDED YOU}
{subtitle:}

If I [G]needed you
Would you come to me
Would you come to [C]me
For to [D]ease my ↑[G]pain
If you [G]needed me 
I would come to you
I would swim the [C]seas
For to [D]ease your ↓[G]pain


Well the [G]night's forelorn
And the morning's born
And the morning [C]shines
With the l[D]ights of [G]love
And you'll [G]miss sunrise 
If you close your eyes
And that would [C]break
My [D]heart in [G]two


If I [G]needed you
Would you come to me
Would you come to [C]me
For to [D]ease my ↑[G]pain
If you [G]needed me 
I would come to you
I would swim the [C]seas
For to [D]ease your ↓[G]pain 
 
Baby's [G]with me now 
Since I showed her how
To lay her [C]lily
[D]Hand in [G]mine
Who would [G]ill agree 
She's a sight to see
A treasure [C]for
The [D]poor to [G]find

If I [G]needed you
Would you come to me
Would you come to [C]me
For to [D]ease my ↑[G]pain
If you [G]needed me 
I would come to you
I would swim the [C]seas
For to [D]ease your ↓[G/]pain