{title:QUE SERA SERA    }
{subtitle:tab    3/4    Key of C}
{subtitle:(Jay Livingston & Ray Evans)}
{metronome: 150}
{time:2:30 }





{c:INTRO: }
{c:C / / /   / / /   /   (stop)  “sweetly”}

When I was [C]just a [Cmaj7]little  [C6]girl 
I asked my mother what will I [G7]be
Will I be pretty, [F]will I be [G7]rich
Here’s what she said to [C]me   

{soc} 
   Que se[F]ra, sera
   Whatever will [C]be, will be
   The future’s not [G7]ours to see 
   Que sera, se[C]ra    [G7]
   What will [Dm]be, will [C]be  
{eoc}
 
When I grew [C]up and [Cmaj7]fell     in [C6]love 
I asked my sweetheart, what lies a[G7]head
Will we have rainbows, [F]day after [G7]day?  
[G7]Here’s what my sweetheart [C]said 
 
{soc} 
   Que se[F]ra, sera
   Whatever will [C]be, will be
   The future’s not [G7]ours to see 
   Que sera, se[C]ra    [G7]
   What will [Dm]be, will [C]be  
{eoc}
 
Now I have [C]children [Cmaj7]of     my [C6]own 
They ask their mother, what will I [G7]be
Will I be handsome, [F]will I be [G7]rich?  
[G7]I tell them tende[C]rly  
 
{soc} 
   Que se[F]ra, sera
   Whatever will [C]be, will be
   The future’s not [G7]ours to see 
   Que sera, se[C]ra    [G7]
   What will [Dm]be, will [C]be  [C/]
{eoc}