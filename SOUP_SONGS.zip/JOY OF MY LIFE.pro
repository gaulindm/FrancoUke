{title:JOY OF MY LIFE}
{subtitle:(Chris Stapleton)}
{time: 3:00}





I [A]tiptoed in the room
[D]  I know you got to have your [A]rest
She [A]says, "Come lay beside me
[D] I been waitin' since you [A]left"
 
{soc}
[E7] She's sweet to me
[D] Must be the luckiest man a[A]live
[E7]Did I tell you, baby
[D] You are the joy of my [A]life
{eoc}
 
[A]First time that I saw you
[D] Mmm, you took my breath a[A]way
[A]Might not get to Heaven
But I [F#m/]walked [E/]with the [D/]angels that [A]day
 
{soc}
She [E7]takes me by the hand
[D] I am the luckiest man a[A]live
[E7]Did I tell you, baby
[D] You are the joy of my [A]life
{eoc} 
 
[A]Some may have their riches
[D] Some may have their worldly [A]things
As [A]long as I have you
[D] I'll treasure each and every [A]day
 
{soc}
Just [E7]take me by the hand
[D] I am the luckiest man [A]alive
[E7]Did I tell you, baby
[D] You are the joy of my [A]life

[E7]Did I tell you, baby
[D] You are the joy of my [A/]life
{eoc}
