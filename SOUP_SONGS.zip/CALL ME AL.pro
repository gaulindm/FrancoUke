{title:}
{subtitle:}
 
(full band)
| F  C |  Gm7 C  |
| F  C |  Gm7 C  |
| F  C |  Gm7 C  |
 
[Verse 1]

[F] A man walks down the street
He says[Gm7], Why am I [Csus4]soft in the [C]middle now?
[F] Why am I soft in the middle?
When the[Gm7] rest of my [Csus4]life is [C]so hard!
[F] I need a photo-opportunity
[Gm7] I want a [Csus4]shot at re[C]demption
[F]Don't want to end up a cartoon
In a[Gm7] cartoon [Csus4]gravey[C]ard
 
[Bridge]
[F]Bonedigger, Bonedigger,
[Gm7] Dogs in the [C]moonlight
[F] Far away from my [Gm7]well-lit door [C]
Mr. [F]Beerbelly, Beerbelly
[Gm7]Get these mutts a[C]way from me!
You know, I[F] don't find this stuff a[Gm7]musing any[C]more
 
[Chorus]
[F]If you'll be my [C]bodyguard
Gm7           C         |   F  C |  Gm7 C  |
I can be your long lost pal
[F]I can call you [C]Betty
And [Gm7]Betty, when you c[C]all me
       |   F  C |  Gm7 C  |
You can call me Al
 
[Verse 2]
[F] A man walks down the street
He says[Gm7], Why am I [Csus4]short of at[C]tention?
Got a[F] short little span of attention
And[Gm7] whoa, my [Csus4]nights are [C]so long!
[F] Where's my wife and family?
[Gm7] What if I [Csus4]die   [C]here?
[F] Who'll be my role-model?
[Gm7] Now that my [Csus4]role - [C]model is
 
[Bridge]
[F]Gone, gone
He [Gm7]ducked back down the [C]alley
With some[F] roly-poly, little [Gm7]bat-faced girl [C]
All a[F]long, along
There were [Gm7]incidents and [C]accidents
          F                      | Gm7 C |
There were hints and allegations
 
[Chorus]
[F]If you'll be my [C]bodyguard
Gm7           C         |   F  C |  Gm7 C  |
I can be your long lost pal
[F]I can call you [C]Betty
And [Gm7]Betty, when you c[C]all me
       |   F  C |  Gm7 C  |
You can call me Al ...   Call me Al ...
 
[Solo] (pennywhistle)
| F | Gm7 C | F | Gm7 C |
| F | Gm7 C | F | Gm7 C |
| F | Gm7 C | F | Gm7 C |
| F | Gm7 C | F | Gm7 C |
 
[Interlude]
(guitar and synth)
|     F   C     Gm7 |    F   C     F   |
 
(full band)
| F  C | Gm7 C  |
| F  C | Gm7 C  |
| F  C | Gm7 C  |
 
[Verse 3]
[F] A man walks down the street
 
It's a[Gm7] street in a [Csus4]strange [C]world
[F] Maybe it's the Third World
[Gm7] Maybe it's his [Csus4]first time [C]around
[F] He doesn't speak the language
He[Gm7] holds no [Csus4]curren[C]cy
He[F] is a foreign man
[Gm7] He is sur[Csus4]rounded [C]by the 
 
[Bridge]
[F]Sound, the sound 
[Gm7] Cattle in the [C]marketplace
F                            | Gm7 C |
 Scatterlings and orphanages
He looks a[F]round, around
He sees [Gm7]angels in the [C]architecture
[F] Spinning into infinity
He says, [Gm7]Amen! and [C]Hallelujah!
 
[Chorus]
[F]If you'll be my [C]bodyguard
Gm7           C         |   F  C |  Gm7 C  |
I can be your long lost pal
[F]I can call you [C]Betty
And [Gm7]Betty, when you c[C]all me
       |   F  C |  Gm7 C  |
You can call me Al ...   Call me...
 
[Verse]
[F] Na, na, na, na,[Gm7] na, na, [Csus4]na    [C]na...
[F] Na, na, na, na,[Gm7] na, na, [Csus4]na na [C]na na ...
[F] Na, na, na, na,[Gm7] na, na, [Csus4]na    [C]na...
[F] Na, na, na, na,[Gm7] na, na, [Csus4]na na [C]na na ...
 
[Bridge]
F           | Gm7 C |
Mmmh, mmmh
F           | Gm7 C |
 Mh, mh
F           | Gm7 C |
Mmmh, mmmh
F           | Gm7 C |
 Mh, mh
 
[Break]
| N.C. | % |
(bass solo)
 
[Chorus]
| F  C |  Gm7 C  |
| F  C |  Gm7 C  |
| F  C |  Gm7 C  |
| F  C |  Gm7 C  |
 
[Outro]
F               C              | Gm7 F/C C    |
If you'll be my bodyguard ...
 
| F  C |  Gm7 C  |
 
F              C        | Gm7 F/C C    |
I can call you Betty ...
 
| F  C |  Gm7 C  |
 
F               C              | Gm7 F/C C    |
If you'll be my bodyguard ...
 
| F  C |  Gm7 C  |
 
F              C        | Gm7 F/C C    |
I can call you Betty ...
 
| F  C |  Gm7 C  |
 
(repeat and fade)