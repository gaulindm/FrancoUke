

{title:096  JOHNNY B. GOODE   }
{subtitle:    4/4     Key of A}              
{subtitle: (Chuck Berry)}
{metronome: 154}
{time:2:38}





Deep [A]down in Louisiana close to New Orleans
Way back up in the woods among the evergreens
There [D]stood a log cabin made of earth and wood
Where [A]lived a country boy named Johnny B. Goode
Who [E7]never ever learned to read or write so well
But he could [A]play the guitar 
Just like a ringin' a bell

{c:CHORUS:}
{soc}
     Go! [A]Go! {c:(234)}  Go, Johnny, go! Go!    
     Go, Johnny, go!  [D]Go!
     Go, Johnny, go! [A]Go!   
     Go, Johnny, go! [E7]Go!  {c:(234)} [E7/]      
     Johnny B. [A]Goode {c:(234,123)}
{eoc}

He used to carry his guitar in a gunny sack
Go sit beneath the tree by the railroad track
Old [D]engineers would see him sittin' in the shade
[A]Strummin' with the rhythm that the drivers made
When [E7]people passed him by they would stop and say
Oh [A]my, but that little country boy could play

{soc}
     Go! [A]Go! {c:(234)}  Go, Johnny, go! Go!    
     Go, Johnny, go!  [D]Go!
     Go, Johnny, go! [A]Go!   
     Go, Johnny, go! [E7]Go!  {c:(234)} [E7/]      
     Johnny B. [A]Goode {c:(234,1234)}
{eoc}

His [A]mother told him someday you will be a man
You will be the leader of a big ol' band
[D]Many people comin' from miles around
Will [A]hear you play your music when the sun go down
[E7]Maybe someday your name'll be in lights
Sayin' "[A]Johnny B. Goode tonight” 

{soc}
Go Go [A]Go! Johnny Go!   
Go Go [A]Go! Johnny Go!
Go Go [D]Go! Johnny Go!   
Go Go [A]Go! Johnny Go! {c:(4,1234)}
[E7]GO! {c:(234)}   [E7/]       
Johnny B. [A]Goode!  {c:(234,1)}   [D/]  [A/]
{eoc}


____________________________________
















