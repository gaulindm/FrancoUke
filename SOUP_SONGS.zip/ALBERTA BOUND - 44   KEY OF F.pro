{title:  ALBERTA BOUND}
{subtitle: 4/4   KEY OF F}
{subtitle: (Gordon Lightfoot)}
{Metronome: 200}
{time:3:00}


[G]/ / / /    / / / 

Oh the [G]prairie lights are burning bright
The chinook wind is a-moving in
Tomorrow night I'll be Alberta [C]bo-ound
[D7]Though I've done the best I could
My old luck ain't been so good 
And tomorrow night I'll be Alberta [G]bound
No [G]one I've met could e're forget
The Rocky Mountain sunset
It's a pleasure just to be Alberta [C]bo-ound
I [D7]long to see my next of kin
To know what kind of shape they're in
Tomorrow night I'll be Alberta [G]bound  [G7]

{soc}
  Alberta [C]bound, Alberta [G]bound
  It's good to [D7]be,   Alberta [G]bound  [G7]
  Alberta [C]bound, Alberta [G]bound
  It's good to [D7]be,   Alberta [G]bound
{eoc}

Oh the [G]sky-line of Toronto
Is something you'll get onto
But they say you got to live there for a [C]whi-ile   
And [D7]if you've got the money
You can get yourself a Honey
With a written guarantee to make you [G]smile
But it's snowing in the city 
And the streets are brown and gritty
But I know there's pretty girls all over [C]to-own
Which [D7]never seem to find me
And the one I left behind me
Is the reason that I'll be Alberta [G]bound [G7]

{soc}
  Alberta [C]bound, Alberta [G]bound 
  It's good to [D7]be,   Alberta [G]bound  [G7]
  Alberta [C]bound, Alberta [G]bound
  It's good to [D7]be,   Alberta [G]bound
{eoc}
It's good to [D7]be Alberta [G]bound  
It's good to [D7]be Alberta [G/]bound    [D7/]   [G/]

___________________________________

















