{title: THIS IS ME   }
{subtitle: (4/4  Key of Em)}
{subtitle: (Benj Pasek & Justin Paul) }  
{metronome: 176}
{time: 3:45}






{c:INTRO: thumb drags (or you can pick)}  
[Em/] {c:(234,12)}  {c:(}[D/]{c:34,)  (}[G/]{c:1234,1234)}  
[Em/] {c:(234,12)}  {c:(}[D/]{c:34,)  (}[G/]{c:1234,1234)}  

     
[Em/]  I’m not a stranger [D/]to the [G/]dark
Hide a[C/]way, they [Em/]say  
‘Cause we don’t [D/]want your broken [D/]parts
I’ve l[Em/]earned to be ashamed of [D/]all… [G/]      my scars
Run a[C/]way, they [Em/]say    
No one will [D/]love you as you [D/]are {c:(2,3)} but

{c:(strumming)}
[C]     I won’t let them [D]break me down to dust  [Em]
I know that [D]there’s a place for us   {c:(}[G]{c:1234)}     
For we are glo-o…[D]    rious [D/]      {c:(tap)}

{c:CHORUS}
{soc}
When the [G]sharpest words wanna cut me down
I’m gonna [Em]send a flood, gonna drown them out
I am brave [C]      I am bruised 
I am [D]who I’m meant to be, [D/]      this is me
[G]  Look out ’cause here I come
And I’m [Em]marching on to the beat I drum
I’m not scared [C]    to be seen, I make [D]no apologies 
[D/]    This is me
{eoc}

[G]Oh-oh-oh-oh (Oh-oh-oh-oh)    
[Em]Oh-oh-oh-oh (Oh-oh-oh)
Oh-oh-[C]oh    oh-oh-oh, oh-oh-[D]oh, oh, oh  [D/]

A[Em]nother round of bullets [D]hits my [G]skin
Well, fire a[C]way ’cause to[Em]day
I won’t [D]let the shame sink in
We are [Em]bursting through the [D]barric[G]ades
And [C]reach above the [Em]sun (we are [C]warri[Em]ors)
Yeah, that’s [D]what we will become  {c:(2,3)}

But  [C]    I won’t let them [D]break me down to dust [Em]
I know that [D]there’s a place for us   {c:(}[G]{c:1234)}     
For we are glo-o…[D]    rious [D/]      {c:(tap)}

{c:(chunks)}  
{soc}   
When the [G]sharpest words wanna cut me down  
I’m gonna [Em]send a flood, gonna drown them out   
I am brave [C]    I am bruised
I am [D]who I’m meant to be, [D/]    this is me
[G]  Look out ’cause here I come
And I’m [Em]marching on to the beat I drum
I’m not scared [C]    to be seen 
I make [D]no apologies, [D/]    this is me
{eoc}

[G]Oh-oh-oh-oh (Oh-oh-oh-oh)    
[Em]Oh-oh-oh-oh (Oh-oh-oh)
Oh-oh-[C]oh     oh-oh-oh, oh-oh-[D]oh, oh, oh  [D/]  

{c:(picking or single strums SOFT voice)}
{soc}
When the [G/]sharpest words wanna 
[G/]Cut me down [G/]   [G/]
I’m gonna [Em/]send a flood, gonna 
[Em/]Drown them out  [Em/]   [Em/]
This is brave,  [C/]    This is bruised [C/]   
This is [D/]who I’m meant to be, [D/]     this is me

{c:(full out chunk)}
[G]  Look out ’cause here I come 
And I’m [Em]marching on to the beat I drum 
I’m not scared  [C]     to be seen
I make [D]no apologies, [D/]      this is me  [G/]
{eoc}
