{title:I GOT A FEELIN'}
{subtitle:}
[Intro] (x2)
G C Em C
 
[Chorus] (x4)
I gotta fee[G]ling
That to[C]night’s gonna be a good night
That to[Em]night’s gonna be a good night
That to[C]night’s gonna be a good, good night
 
[Verse]
[G] Tonight’s the night, let’s live it up
[C] I got my money, let’s spend it up
[Em] Go out and smash it, like oh my God
[C] Jump off that sofa, let’s get get off
[G] I know that we’ll have a ball 
If we [C]get down and go out and just loose it all
I [Em]feel stressed and I wanna let it go
Lets go [C]way out, spaced out and losing all control
[G] Fill up my cup, Mazal Tov
[C] Look at her dancing, just take it off
[Em] Lets paint the town, we’ll shut it down
[C] Let’s burn the roof, and then we’ll do it a[G]gain
[G]Let’s do it, let's do it, let’s do it
Let’s [C]do it, and do it, and do it, let’s live it up
And [Em]do it, and do it, and do it, do it, do it
Let’s [C]do it, let's do it, let's do it
 
[Chorus] (x2)
Cause I gotta fee[G]ling - woo hoo -
That to[C]night’s gonna be a good night
That to[Em]night’s gonna be a good night
That to[C]night’s gonna be a good, good night
 
[Verse]
[G] Tonight’s the night, - hey -, let’s live it up - let’s live it up -
[C] I got my money, - I'm paid -, let’s spend it up - let’s spend it up -
[Em] Go out and smash it, - smash it -, like oh my God - like oh my God -
[C] Jump out that sofa, - c'mon - let’s get get off
[G] Fill up my cup, - drank - Mazal Tov - l'haim -
[C] Look at her dancing, - move it, move it -, just take it off
[Em] Lets paint the town, - paint the town - we’ll shut it down - we'll shut it down -
[C] Let’s burn the roof, - the roof - and then we’ll do it[G] again
 
[Verse]
[G]Let's do it, let's do it, let's do it
Let's [C]do it, and do it, and do it, let's live it up
And [Em]do it, and do it, and do it, do it, do it
Let's [C]do it, let's do it, let's do it
[G]Here we come, here we go, we gotta rock
[C]Easy come, easy go, now we on top
[Em]Feel the shot, body rock, rock it don’t stop
[C]Round and round, up and down, around the clock
[G]Monday, Tuesday, Wednesday and Thursday
[C]Friday, Saturday, Saturday to Sunday
[Em]Get get get get get with us, you know what we say
[C]Party every day, Pa-pa-party every day
 
[Chorus] (x2)
Cause I gotta fee[G]ling - woo hoo -
That to[C]night’s gonna be a good night
That to[Em]night’s gonna be a good night
That to[C]night’s gonna be a good, good night    
