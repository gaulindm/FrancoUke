{title:GHOST RIDERS IN THE SKY}
{time:2:47}
{metronome: 194}




[F#m]/ / / /   / / / /

An [F#m]old cowboy went riding out one 
[A]dark and windy day {c:(234,1234,123)}
Up[F#m]on a ridge he rested as he 
[A]went along his way {c:(234,123)}
When [F#m]all at once a mighty herd of 
red eyed cows he saw 
A-[D]plowing through the ragged sky {c:(4,1234,123)} 
and [F#m]up the cloudy draw {c:(234,1234,123)}

Their [F#m]brands were still on fire and their 
[A]hooves were made of steel {c:(234,1234,123)}
Their [F#m]horns were black and shiny and their 
[A]hot breath he could feel {c:(234,123)}
A [F#m]bolt of fear went through him as they 
thundered through the sky 
For he [D]saw the Riders coming hard {c:(4,1234,12)} 
and he [F#m]heard their mournful cry{c:(234,1234)}
  
Yippie yi [A]Yay (yippie yi yay) 
Yippie yi [F#m]yoo-o-o (yippie yi yo-o)
[D]Ghost Riders in the [F#m]sky {c:(234,1234,1234,123)}

Their [F#m]faces gaunt, their eyes were blurred 
their [A]shirts all soaked with sweat {c:(234,1234,123)}
He's [F#m]riding hard to catch that herd 
but [A]he ain't caught 'em yet {c:(234,12)}
'Cause they've [F#m]got to ride forever on that 
range up in the sky 
On [D]horses snorting fire {c:(234,1234,12)}
As they [F#m]ride on hear their cry {c:(234,1234,12)}

As the [F#m]riders loped on by him, he 
[A]heard one call his name {c:(234,1234,12)}
If you [F#m]want to save your soul from Hell 
a-[A]riding on our range {c:(234,123)}
Then [F#m]cowboy change your ways today 
or with us you will ride 
[D]Trying to catch the Devil's herd {c:(4,1234,123)} 
a[F#m]cross these endless skies {c:(234,1234)}

Yippie yi [A]Yay (yippie yi yay)
Yippie yi [F#m]yoo-o-o (yippie yi yo-o)

[D]Ghost Riders in the [F#m]sky {c:(234,1234,1234,1234)}
[D]Ghost Riders in the [F#m]sky {c:(234,1234,1234,1234)}
[D]Ghost Riders in the [F#m]sky {c:(234,1234)}    [F#m/]
