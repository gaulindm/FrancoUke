{title: I’M LOOKING THROUGH YOU}
{subtitle: 4/4      Key of G}
{subtitle: (John Lennon & Paul McCartney)}
{metronome: 168 }
{time: 3:00}






{c:INTRO:}
{c:G / / / /    D / / / /    }
{c:G / /    C / /    G / /    C / / }
{c:G / /    C / /}

[G] I'm [C]looking [Am7]through you
[Em] Where did you [D]go?
[G] I [C]thought I [Am7]knew you 
[Em] What did I [D]know?		
[Em] You don't look [D]diffe[C]rent 
But [G]you [C]have [D]changed
[G] I'm [C]looking [Am7]through you
[C7] You're not the [G//]same [C//]
[G//][C//][G//][C//][G/]

[G] Your [C]lips are [Am7]moving
[Em] I cannot [D]hear
[G] Your [C]voice is [Am7]soothing
[Em] But the words aren't [D]  clear
[Em] You don't sound [D]diffe[C]rent
I've [G]learned [C]the [D]game
[G] I'm [C]looking [Am7]through you
[C7] You're not the [G//]same [C//]
[G//][C//][G//][C//][G//][C//]

{soc}                             
   [C]Why, tell me why
    Did you not [G]treat me right?                   
   [C]Love has a nasty habit 
    Of [Dsus4]disappearing [D]overnight
{eoc}

[G] You're [C]thinking  [Am7]of    me
[Em] The same old [D]way
[G] You [C]were a[Am7]bove me
[Em] But not to[D]day 
[Em] The only [D]diffe[C]rence is 
[G]You're [C]down [D]there
[G] I'm [C]looking [Am7]through you
[C7] Any other [G//]way [C//]
[G//][C//][G//][C//][G//][C//]

{soc}                             
    [C]Why, tell me why
    Did you not [G]treat me right?                   
   [C]Love has a nasty habit 
    Of [Dsus4]disappearing [D]overnight   
{eoc}  

[G] I'm [C]looking [Am7]through you
[Em] Where did you [D]go?
[G] I [C]thought I [Am7]knew you 
[Em] What did I [D]know?		
[Em] You don't look [D]diffe[C]rent 
But [G]you [C]have [D]changed
[G] I'm [C]looking [Am7]through you
[C7] You're not the [G//]same [C//]

[G//]Yeah!, Well, [C//]baby you've 
[G//]Changed,[C//] [G//]ah...[C//]        
I'm looking [G//]through you [C//]
[G//] Yea[C//]h, I'm looking [G//]through you  
[C//]  [G//] [C//]   I'm looking [G/]through you



            




            
