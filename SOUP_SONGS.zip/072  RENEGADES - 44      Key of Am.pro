

{title:072  RENEGADES    }
{subtitle:   4/4      Key of Am}
{subtitle:(X Ambassadors)}
{metronome: 178}
{time:2:59}


{c:(Riptide strum, except for * lines)}





[Am]/ / / /    [C]/ / / /    
[G]/ / / /    [F]/ / / /   
[Am]/ / / /    [C]/ / / /    
[G]/ / / /    [F]/ / / /

[Am] Run away-ee-[C]ay with me   
{c:(la-la-la)}   [G]/ /    {c:(la-la-la)}    [F]/ /   {c:(la-la-la)}
[Am] Lost souls in [C]revelry
{c:(la-la-la)}   [G]/ /    {c:(la-la-la)}    [F]/ /    {c:(la-la-la)}
[Am] Running wild and [C]running free  
{c:(la-la-la)}   [G]/ /    {c:(la-la-la)}    [F]/ /    {c:(la-la-la)}
[Am] Two kids, [C]you and me 
{c:(la-la-la)}   [G]/ /    {c:(la-la-la)}     [F/] 


{soc}
{c:CHORUS (with Oooh’s, E,E,D,C)}
* And I say [Am]Hey, hey hey [C]hey 
*Living [G]like we're rene[F]gades
* Hey hey [Am]hey, hey hey [C]hey
*Living [G]like we're rene[F]gades
Rene[Am]↑gades   [C]      [G]      [F]  
Rene[Am]gades   [C]      [G]      [F]
{eoc}

[Am] Long live the [C]pioneers   
{c:(la-la-la)}   [G]/ /    {c:(la-la-la)}   [F]/ /    {c:(la-la-la)}
[Am] Rebels and [C]mutineers  
{c:(la-la-la)}   [G]/ /    {c:(la-la-la)}   [F]/ /    {c:(la-la-la)}
[Am] Go forth and [C]have no fear   
{c:(la-la-la)}   [G]/ /    {c:(la-la-la)}   [F]/ /    {c:(la-la-la)}
[Am] Come close [C]lend an ear 
{c:(la-la-la)}   [G]/ /    {c:(la-la-la)}     [F/] 


{soc}
{c:CHORUS (with Oooh’s)}
* And I say [Am]Hey, hey hey [C]hey
*Living [G]like we're rene[F]gades
* Hey hey [Am]hey, hey hey [C]hey
*Living [G]like we're rene[F]gades
Rene[Am]↑gades   [C]      [G]      [F]  
Rene[Am]gades   [C]      [G]      [F]
{eoc}


[Am] All hail the [C]underdogs
[G]  All hail the [F]new kids
[Am] All hail the [C]outlaws
{c:(}[G]{c:hey!)} Spielberg's and [F]Kubrick's

[Am] It's our time to [C]make a move
[G] It's our time to [F]make amends
[Am] It's our time to [C]break the rules    
{c:(}[G]{c:hey!)} Let's be[F/]gin  

{soc}
{c:CHORUS (with Oooh’s)}
* And I say [Am]Hey, hey hey [C]hey
*Living [G]like we're rene[F]gades
* Hey hey [Am]hey, hey hey [C]hey
*Living [G]like we're rene[F]gades
Rene[Am]↑gades   [C]      [G]      [F]  
Rene[Am]gades   [C]      [G]      [F]
{eoc}

[Am]/ / / /    [C]/ / / /    
[G]/ / / /    [F]/ / / /   
[Am]/ / / /    [C]/ / / /    
[G]/ / / /    [F]/ / / /   [Am]/

____________________________________









