{title:  MI OH MY     }
{subtitle:(4/4    Key of G)}  
{subtitle:(Matoma)}
{time: 3:10}
{metronome: 186}





{c:INTRO: (Oooh)}
[G]/ / / /    / / / /      
[C]/ / / /      [G]/ / / /      
[C]/ / / /      [G]/ / / /      
[D]/ / / /    / / / / 
 
[G]/ / / /    / / / /      
[C]/ / / /      [G]/ / / /      
[C]/ / / /      [G]/ / / /      
[D]/ / / /    / / / /  

[G/]Mi oh my, when the 
[C/]    Light hits your [G/]smile
There's a [C/]fire that ig[G/]nites 
At the [D/]bottom of my heart
[G/]Mi oh my, if we [C/]   open our [G/]eyes
I think we're [C/]   both gonna 
[G/]find that it's a [D/]    wonderful [D/]life

{c:CHORUS}
{soc}
     [G]Mi oh my, it's a [C]    wonderful [G]life
     It's a [C]    wonderful [G]life with you 
     [D]   by my side

     [G]Mi oh my, it's a [C]    wonderful [G]life
     It's a [C]    wonderful [G]life with you 
     [D]   by my side

[G]/ / / /    / / / /      
[C]/ / / /      [G]/ / / /      
[C]/ / / /      [G]/ / / /      
[D]/ / / /    / / / / 
 
[G]/ / / /    / / / /      
[C]/ / / /      [G]/ / / /      
[C]/ / / /      [G]/ / / /      
[D]/ / / /    / / / /  
{eoc}

[G]   All of our friends [C]   Feet in the [G]sand
[C]   Beneath the [G]stars [D]    it never ends
And we got [G]    no explanation cause there's 
[C]   No expec[G]tations
Just [C]   beautiful [G]faces and 
[D]    Nowhere to go


{c:CHORUS}
{soc}
     [G]Mi oh my, it's a [C]    wonderful [G]life
     It's a [C]    wonderful [G]life with you 
     [D]   by my side

     [G]Mi oh my, it's a [C]    wonderful [G]life
     It's a [C]    wonderful [G]life with you 
     [D]   by my side

[G]/ / / /    / / / /      
[C]/ / / /      [G]/ / / /      
[C]/ / / /      [G]/ / / /      
[D]/ / / /    / / / / 
 
[G]/ / / /    / / / /      
[C]/ / / /      [G]/ / / /      
[C]/ / / /      [G]/ / / /      
[D]/ / / /    / / / /  
{eoc}

[G]Mi oh my, when the 
[C]   light hits your [G]smile
There's a [C]fire that ig[G]nites at the 
[D]bottom of my heart
Ooh [G]mi oh my, if we 
[C]    open our [G]eyes
I think we're [C]    both gonna 
[G]find that it's a [D]    wonderful [G/]life





