{title:LONELY PEOPLE}
{subtitle:  4/4      Key of G}
{subtitle:(America)}
{time:  }





[G]/ / / /    [Em]/ / / /    [Bm]/ / / /   / / / /
[G]/ / / /    [Em]/ / / /    [Bm]/ / / /   / / / /
[C]/ / / /   [D]/ / / /    [G]/ / / /    [Em]/ / / /
[C]/ / / /   [D]/ / / /    [G]/ / / /    [D]/ / / /
 
{c:(}[G]{c:12)}  This is for [Em]all the lonely [Bm]people
{c:(}[G]{c:12)}  Thinking that [Em]life has passed them [Bm]by
{c:(}[C]{c:12)}  Don't give [D]up until you {c:(beat)}
{c:(}[G]{c:12)}  Drink from the [Em]silver cup
{c:(}[C]{c:12)}  And ride that [D]highway in the [G]sky    [D]
 
(ah)
{c:(}[G]{c:12)}  This is for [Em]all the single [Bm]people
{c:(}[G]{c:12)}  Thinking that [Em]love has left them [Bm]dry
{c:(}[C]{c:12)}  Don't give [D]up until you {c:(beat)}
{c:(}[G]{c:12)}  Drink from the [Em]silver cup,
{c:(}[C]{c:12)}  You never [D]know until you [G]try     [D]
 
Well, I'm [C]on [G]my [Am]way
Yes, I'm [C]back [G]to [Am]stay
Well, I'm [C]on [G]my [Am]way [D]back [G]home    [D]    (Hit it)
 
[G]/ / / /    [Em]/ / / /    [Bm]/ / / /   / / / /
[G]/ / / /    [Em]/ / / /    [Bm]/ / / /   / / / /
[C]/ / / /   [D]/ / / /    [G]/ / / /    [Em]/ / / /
[C]/ / / /   [D]/ / / /    [G]/ / / /    [D]/ / / /
 
{c:(}[G]{c:12)}  This is for [Em]all the lonely [Bm]people,
{c:(}[G]{c:12)}  Thinking that [Em]life has passed them [Bm]by
{c:(}[C]{c:12)}  Don't give [D]up until you 
{c:(}[G]{c:12)}  Drink from the [Em]silver cup
{c:(}[C]{c:12)}  She’ll never [D]take you down
{c:(}[G]{c:12)}  Or never [Em]give you up
{c:(}[C]{c:12)}  You never [D]know until you [Em/]try
