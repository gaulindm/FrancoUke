{title:  ON BROADWAY  }
{subtitle:(4/4  Key of A)}
{subtitle:(Barry Mann, Cynthia Weil)}
{subtitle:(Jerry Leiber, Mike Stoller) }
{time: 2:20}
{metronome: 122}








{c:INTRO:} 
[A]/ /    [G]/ /    [A]/ /    [G]/ /    
[A]/ /    [G]/ /    [A]/ /    [G]/ / 

{c:Verse 1}
[A] They say the [G]neon [A]lights are [G]bright 
On [A]Broad[G]way (on [A]Broad[G]way)  
[A] They say there's [G]always [A]magic [G]in the 
[A]Air [G]     (on [A]Broad[G]way)  
[D] But when you're [C]walkin' [D]down that [C]street 
[D] And you ain't [C]had e[D]nough to [E7]eat   
[A] The glitter [G]rubs right [A]off and [G]you're 
Now[A]here[G]      (On [A]Broad[G]way) 

{c:Verse 2}
[A] They say the [G]women [A]treat you [G]fine 
On [A]Broad[G]way  (on [A]Broad[G]way) 
[A] But looking [G]at them [A]just gives [G]me the 
[A]Blues  [G]     (on [A]Broad[G]way)   
[D] 'Cause how ya [C]gonna [D]make some [C]time 
[D] When all you [C]got is [D]one thin [E7]dime 
[A] And one thin [G]dime won't [A]even [G]shine your 
[A]Shoes [G]      (On [A]Broad[G]way)     

{c:Verse 3}
[A] They say that [G]I won't [A]last too [G]long 
On [A]Broad[G]way (on [A]Broad[G]way)   
[A] I'll catch a [G]Greyhound [A]bus for [G]home
They [A]all [G]say (on [A]Broad[G]way)
[D] But they're dead [C]wrong, I [D]know they [C]are   
[D] My uku[C]lele makes [D]me a [E7]star   
[A] And I won't [G]quit till [A]I'm a [G]star 
On [A]Broad[G]way     (On [A]Broad[G]way)   

[A] I won't [G]quit till [A]I'm a [G]star 
On [A]Broad[G]way  [A]/ /     [G]/ /    [A]/

