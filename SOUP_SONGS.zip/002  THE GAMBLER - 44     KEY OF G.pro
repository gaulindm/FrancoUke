

{title:002  THE GAMBLER  }
{subtitle:4/4     KEY OF G  }
{subtitle:(Don Schlitz)}
{time:4:20}
{metronome:  186 }





[D]/ / / /    [G]/ / / /   
[D]/ / / /   [G] / / /

On a [G]warm summer's evening
On a [C]train bound for [G]nowhere
I met up with the gambler
We were both too tired to [D]sleep
So [G]we took turns a-starin' 
Out the [C]window at the [G]darkness
'Til [C]boredom over[G]took us
[D]  And he began to [G]speak

He said, "[G]Son, I've made a life
Out of [C]readin' people's [G]faces
Knowin' what the cards were 
By the way they held their [D]eyes
So if [G]you don't mind my sayin'
I can [C]see you're out of [G]aces
For a [C]taste of your [G]whiskey
I'll [D]give you some ad[G]vice"

So I [G]handed him my bottle
And he [C]drank down my last [G]swallow
Then he bummed a cigarette 
And asked me for a [D]light
And the [G]night got deathly quiet
And his [C]face lost all ex[G]pression
Said, "If you're [C]gonna play the [G]game boy
You gotta [D]learn to play it [G]right”

{soc}
You've got to [G]know when to hold 'em  
[C]    Know when to [G]fold 'em
[C]    Know when to [G]walk away
And know when to [D]run
You never [G]count your money
When you're [C]sittin' at the [G]table
There'll be time e[C]nough for [G]countin'   
[D]    When the dealin's [G]done {c:(234)}
{eoc}

[A]/ / / /   / / / /

[A]Every gambler knows
That the [D]secret to sur[A]vivin'
Is knowin' what to throw away 
And knowin' what to [E7]keep
'Cause [A]every hand's a winner
And [D]every hand's a [A]loser
And the [D]best that you can [A]hope for 
Is to [E7]die in your [A]sleep

And [A]when he'd finished speakin'
He [D]turned back toward the [A]window
Crushed out his cigarette, faded off to [E7]sleep
And [A/]somewhere in the darkness
The [D/]gambler he broke [A/]even
But [D/]in his final [A/]words I found 
An [E7/]ace that I could [A/]keep

{soc}
You've got to [A]know when to hold 'em
[D]   Know when to [A]fold 'em
[D]   Know when to [A]walk away 
And know when to [E7]run
You never [A]count your money
When you're [D]sittin' at the [A]table
There'll be time e[D]nough for [A]countin'  
[E7]    When the dealin's [A/]done
{eoc}

{c:ACAPELLA with CLAPPING }
You've got to know when to hold 'em (when to hold 'em)
Know when to fold 'em (when to fold 'em)

Know when to walk away, and know when to run
You never count your money


When you're sittin' at the table
There'll be time enough for countin'  
When the dealin's done

{soc}
You've got to [A]know when to hold 'em
[D]   Know when to [A]fold 'em
[D]   Know when to [A]walk away 
And know when to [E7]run
You never [A]count your money
When you're [D]sittin' at the [A]table
There'll be time e[D]nough for [A]countin'  
[E7]    When the dealin's [A/]done
{eoc}

__________________________________










