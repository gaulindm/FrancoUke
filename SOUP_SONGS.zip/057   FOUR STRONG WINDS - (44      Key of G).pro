

{title:057   FOUR STRONG WINDS}
{subtitle:(4/4      Key of G)}
{subtitle:(Ian Tyson)}
{time:4:07}
{metronome:128}


{c:(Optional: Advanced chords are }
{c:strummed slowly or picked) } 
             
{c:The RIFF:  }
{c:(On the A string: 0 - 2 - 3 - 5 - 3 - 2 - 0)  }     
                                                                                                                
{c:INTRO:} 
[G]/ / / /    [Am]/ / / /    
[D7]/ / / /    [G]/ / / /
[G]/ / / /    [Am]/ / / /    
[D7]/ / / /   / / 

Think I'll [G]go out to Al[Am]berta
Weather's [D7]good there in the [G]fall 
I got some friends that I could [Am]go 
To working [D7]for {c:(RIFF: 0 - 2 - 3 - 5 - 3 - 2 - 0)  }             
Still I [G]wish you'd change your [Am]mind 
If I [D7]asked you one more [G]time 
But we've [C]been through that a 
[Em]Hundred times or [D7]more 
{c:(RIFF: 0 - 2 - 3 - 5 - 3 - 2 - 0)  }  
                                                                                                                     
{soc}                                                                                                                              
Four strong [G]winds that blow [Am]lonely
Seven [D7]seas that run [G]high                                 
All those things that don't [Am]change 
Come what [D7]may  
{c:(RIFF:  0 - 2 - 3 - 5 - 3 - 2 - 0)  }  
But our [G]good times are all [Am]gone 
And I'm [D7]bound for moving [G]on 
I'll look [C]for you if I'm [Em]ever back this 
[D7]way  {c:(RIFF: 0- 2 - 3 - 5 - 3 - 2 - 0)  }  
{eoc}

If I [G]get there before the [Am]snow flies 
And if [D7]things are looking [G]good 
You could [G]meet me if I 
[Am]Sent you down the [D7]fare  
{c:(RIFF: 0 - 2 - 3 - 5 - 3 - 2 - 0)  }  
But by [G]then it would be [Am]winter
Not too [D7]much for you to [G]do 
And those [C]winds sure can blow 
[Em]Cold way out [D7]there  
{c:(RIFF: 0 - 2 - 3 - 5 - 3 - 2 - 0)  }  
                                                                                                                     
{soc}                                                                                                                              
Four strong [G]winds that blow [Am]lonely
Seven [D7]seas that run [G]high                                 
All those things that don't [Am]change 
Come what [D7]may {c:(RIFF: 0 - 2 - 3 - 5 - 3 - 2 - 0)}  
But our [G]good times are all [Am]gone 
And I'm [D7]bound for moving [G]on 
I'll look [C]for you if I'm [Em]ever back this 
[D7]way  {c:(RIFF: 0 - 2 - 3 - 5 - 3 - 2 - 0)  }  
{eoc}

{c:INSTRUMENTAL:}
[G]/ / / /    [Am]/ / / /    
[D7]/ / / /    [G]/ / / /      
[G]/ / / /    [Am]/ / / /    
[D7]/ / / /   / / 

Still I [G]wish you'd change your [Am]mind 
If I [D7]asked you one more [G]time 
But we've [C]been through that 
A [Em]hundred times or [D7]more   
{c:(RIFF: 0 - 2 - 3 - 5 - 3 - 2 - 0)  }  
                                                                                                                    
{soc}                                                                                                                              
Four strong [G]winds that blow [Am]lonely
Seven [D7]seas that run [G]high                                 
All those things that don't [Am]change 
Come what [D7]may  {c:(RIFF: 0 - 2 - 3 - 5 - 3 - 2 - 0)  }  
But our [G]good times are all [Am]gone 
And I'm [D7]bound for moving [G]on 
I'll look [C]for you if I'm [Em]ever back this 
[D7]way  {c:(RIFF: 0 - 2 - 3 - 5 - 3 - 2 - 0)  }  

I'll look [C]for you if I'm [Em]ever back this 
[D7/gliss]Way 
{eoc}
_________________________________________







{define: D7alt 0 2 2 2 3}
{define: Calt 0 0 0 3 7}
{define: Calt2 0 5 4 3 3}
{define: Emalt 0 0 7 7 7} 
{define: Galt 0 0 2 3 5}
{define: Amalt 0 5 4 0 0}
{define: D7 0 2 0 2 0}

[Galt] [Amalt] [D7alt] [Calt] [Emalt][Calt2]

