{title:EN OTRA VIDA}
{subtitle:}

[Verso 1: Yami Safdie]
En otra [C]vida nos casamos y viajamos por el [Em]mundo
Nos mudamos a un pisito en el se[F]gundo
Y mis [Am]padres son amigos de los [G]tuyos [G7]
Nuestros [C]hijos heredaron mi paciencia y tu son[Em]risa
Caminamos y leemos poe[F]sía
Mierda, [Am]que nos fue genial [G]en otra vida [G7]
 
 
[Pre-Coro: Yami Safdie]
En esta [Dm]no, no sé[G] por qué no
se nos d[Dm]io
Tal vez[G] un capricho de [F]Dios
O el co[C]raje que siempre fal[G]tó a los [G7]dos
 
 
[Coro: Yami Safdie & Lasso]
Pero [C]yo aquí te espera[Dm]ré
Si cambias de opi[Am]nión
No es tarde pa' vol[Dm]ver
A estar [F]juntos tú y [C]yo
 
 
[Verso 2: Lasso]
En otra [C]vida se nos alineó la luna y los pla[Em]netas
La rutina no pasó a ser un pro[F]blema
Nunca [Am]hubo un tеrcero en la [G]cuenta [G7]
Lo sé porquе a [C]veces lo sueño y se siente tan re[Em]al
Que casi empiezo a p[F]ensar
Que el [Am]mal sueño es este y [G]esa es nuestra reali[G7]dad
 
 
[Coro: Yami Safdie & Lasso]
Pero [C]yo aquí te espera[Dm]ré
Si cambias de opi[Am]nión
No es tarde pa' vol[Dm]ver
A estar [F]juntos tú y [C]yo
Aquí te espera[Dm]ré
Si cambias de opi[Am]nión
No es tarde pa' vol[Dm]ver
A estar [F]juntos
 
 
[Outro]
En otra [C]vida escribimos un felices para si[Em]empre
Pero en esta solo me tocó per[F]derte
Y espe[Am]rar que de algún [G]modo me re[C]cuerdes
