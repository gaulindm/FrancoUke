

{title:009    AMAZING GRACE  }
{subtitle:(3/4     Key of C/D)}
{subtitle:(John Newton)}
{time:3:39}
{metronome: 84}

 



 
[C]/ / /      [Am]/ / /     
[G7]/ / /     [C]/ / 

A[C]mazing [C7]grace, how [F]sweet the [C]sound 
That saved a wretch like [G7]me 
I [C]once was [C7]lost, but [F]now am [C]found 
Was [Am]blind, but [G7]now I [C]see 

'Twas [C]grace that [C7]taught my [F]heart to [C]fear 
And grace my fears re[G7]lieved 
How [C]precious [C7]did that [F]grace ap[C]pear 
The [Am]hour I [G7]first be[C]lieved 

Through [C]many [C7]dangers, [F]toils, and [C]snares 
I have already [G7]come
'Tis [C]grace hath [C7]brought me [F]safe thus [C]far 
And [Am]grace will [G7]lead me [C]home [D//]


{c:Key Change to D}
When [D]we've been [D7]there 
Ten [G]thousand [D]years 
Bright shining as the [A7]sun 
We've [D]no less [D7]days 
To [G]sing God's [D]praise 
Than [Bm]when we [A7]first be[D]gun 

A[D]mazing [D7]grace, how [G]sweet the [D]sound 
That saved a wretch like [A7]me 
I [D]once was [D7]lost, but [G]now am [D]found 
Was [Bm]blind, but [A7]now I [G]see... [D/]ee


_________________________________





{define: D7 0 2 0 2 0}

{define: D7 0 0 0 2 0 2 0 *}


