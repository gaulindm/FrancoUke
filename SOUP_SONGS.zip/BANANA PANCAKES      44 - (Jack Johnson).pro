{title:BANANA PANCAKES      4/4     }
{subtitle:(Jack Johnson)}
{metronome: 110}
{time: 3:20}











{c:RIFF}

Well can't you see that it's just [Am]raining
There ain't no need to go out[G]side   [G/]
But, [D7/]ba- [D7/]by, you [G]hardly even [D7]notice 
[Am]When I try to [C7]show you 
This [G]song is meant to [D7]keep you 
From [Am]doing what you're s’[C7]pposed to
[G]Waking up too [D7]early [Am]maybe we could [C7]sleep in
[G]Make you banana [D7]pancakes 
Pre[Am]tend like it's the [C7]weekend [Am]now
We could pretend it all the [G]time
Can't you see that it's just [Am]raining? 
There ain't no need to go out[G]side   [G/]

But just [D7/]may- [D7/]be, ha[G]laka uku[D7]lele 
[Am]Mama made a [C7]baby
[G]Really don't mind to [D7]practice ‘cause 
[Am]You're my little [C7]lady
[G]Lady, lady, [D7]love me ‘cause I [Am]love to lay you [C7]lazy
[G]We could close the [D7]curtains 
Pre[Am]tend like there's no [C7]world [Am]outside  
We could pretend it all the [G]time
Can't you see that it's just [Am]raining? 
There ain't no need to go out[G]side
Ain't no need, ain't no [Am]need 
Mmm, mmm, mmm, [G]mmm
Can't you see, can't you [Am]see-ee-ee? 
Rain all day, and I don't [G]mind

But the [Am]telephone is singing ringing
It's too early don't pick it [D]up
We don't need to we got [Am]everything we need right here
And everything we need is e[D]nough   
Just so easy when the [Bm]whole world fits inside of your arms
Do we [Em]really need to pay attention [C]to the alarm?
Wake up [G]slow, [D]mmm, wake up [G]slow   [G/]

But, [D7/]ba- [D7/]by, you [G]hardly even [D7]notice 
[Am]When I try to [C7]show you 
This [G]song is meant to [D7]keep you 
From [Am]doing what you're s’[C7]pposed to
[G]Waking up too [D7]early [Am]maybe we could [C7]sleep in
[G]Make you banana [D7]pancakes 
Pre[Am]tend like it's the [C7]weekend [Am]now
We could pretend it all the [G]time
Can't you see that it's just [Am]raining? 
There ain't no need to go out[G]side
Ain't no need, ain't no [Am]need
Rain all day, and I really, [G]really, really don't mind
Can't you see, can't you [Am]see, you gotta wake up [Ggliss]slow

{define: D7 0 2 0 2 0}
{tag: Shared by Lynda}