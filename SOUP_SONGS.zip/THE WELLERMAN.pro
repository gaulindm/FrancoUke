

{title:142  WELLERMAN (SEA SHANTY)}
{subtitle: 4/4      Key of Am}
{subtitle:(Unknown Author - New Zealand Whaling Song)}
{time:3:00}
{metronome:96}

{c:The starting note is E}
{c:Jam leader strums Am/}

{c:Drum:  /   /   /   /}

There [Am/]once was a ship that [Am/]put to sea
The [Dm/]name of the ship was the [Am/]Billy o’ Tea
The [Am/]winds blew up, her [Am/]bow dipped down
O [E7/]blow, my bully boys, [Am/]blow    {soh}-Huh!-{eoh}

{soc}
  [F]Soon may the [C]Wellerman come
  To [Dm]bring us sugar and [Am]tea and rum
  [F]One day, when the [C]tonguin’ is done
  We’ll [E7]take our leave and [Am/]go
{eoc}

She [Am/]had not been two [Am/]weeks from shore
When [Dm/]down on her, a [Am/]right whale bore
The [Am/]captain called all [Am/]hands and swore
He’d [E7/]take that whale in [Am/]tow   {soh}-Huh!-{eoh}

{soc}
  [F]Soon may the [C]Wellerman come
  To [Dm]bring us sugar and [Am]tea and rum
  [F]One day, when the [C]tonguin’ is done
  We’ll [E7]take our leave and [Am/]go
{eoc}

Be[Am/]fore the boat had [Am/]hit the water
The [Dm/]wha-ale’s tail came [Am/]up and caught her
All [Am/]hands to the side, har[Am/]pooned and fought her
[E7/]When she dived down [Am/]low   {soh}-Huh!-{eoh}

{soc}
  [F]Soon may the [C]Wellerman come
  To [Dm]bring us sugar and [Am]tea and rum
  [F]One day, when the [C]tonguin’ is done
  We’ll [E7]take our leave and [Am/]go
{eoc}

No [Am/]line was cut, no [Am/]whale was freed
The [Dm/]Captain’s mind was [Am/]not of greed
And [Am/]he belonged to the [Am/]whaleman’s creed
She [E7/]took that ship in [Am/]tow    {soh}-Huh!-{eoh}

{soc}
  [F]Soon may the [C]Wellerman come
  To [Dm]bring us sugar and [Am]tea and rum
  [F]One day, when the [C]tonguin’ is done
  We’ll [E7]take our leave and [Am/]go
{eoc}

For [Am/]forty days, or [Am/]even more
The [Dm/]line went slack, then [Am/]tight once more
All [Am/]boats were lost, there were [Am/]only four
But [E7/]still that whale did [Am/]go    {soh}-Huh!-{eoh}

{soc}
  [F]Soon may the [C]Wellerman come
  To [Dm]bring us sugar and [Am]tea and rum
  [F]One day, when the [C]tonguin’ is done
  We’ll [E7]take our leave and [Am/]go
{eoc}

As [Am/]far as I’ve heard, the [Am/]fight’s still on
The [Dm/]line’s not cut and the [Am/]whale’s not gone
The [Am/]Wellerman makes his [Am/]regular call
To en[Dm/]↑courage the Captain, [Am/]↑crew, and all    

{soc} 
  [F]Da da, da-[C]da da da
  [Dm]Da-da da da-da [Am]da-da da
  [F]Da da, da-[C]da da da
  Da [E7]da-da da-da [Am/]da    {soh}-Huh!{eoh}

  [F]Soon may the [C]Wellerman come
  To [Dm]bring us sugar and [Am]tea and rum
  [F]One day, when the [C]tonguin’ is done
  We’ll [E7]take our leave and [Am/]go
  We’ll [E7/]take our leave and [Am/]go    {soh}HUH!{eoh}
{eoc}


________________________________









