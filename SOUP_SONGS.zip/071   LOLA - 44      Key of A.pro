

{title:071   LOLA                            }
{subtitle:   4/4      Key of A   }
{time:4:33}
{subtitle:(Ray Davies, Dave Davies)}
{metronome: 138}
{time: 4:15  }





{c:INTRO:}    [F]/ - /    [G]/ / / /    
               [A]/ - / - / - / -  

{c:(gently to start, then building throughout)} 
I [A]met her in a club down in old Soho 
Where you [D]drink champagne and it 
[G]Tastes just like Coca [A]Cola  
C-O-L-A [D]cola    [Dsus4]/ /           [D]/ /
 
She [A]walked up to me and she asked me to dance 
I [D]asked her her name and in a 
[G]Dark brown voice she said [A]Lola  
L-O-L-A  [D]Lola  [G]     Lo-Lo-Lo-Lo   [F]Lo...la-a-a
[F]/ / /    [G]/    
[A]/ / / /   / / / /
  
Well [A]I'm not the world's most physical guy 
But when she [D]squeezed me tight she nearly
[G]Broke my spine, oh my [A]Lola  
Lo-Lo-Lo-Lo   [D]Lola   [Dsus4]/ /          [D]/ /

Well [A]I'm not dumb but I can't understand 
Why she [D]walked like a woman and 
[G]Talked like a man oh my [A]Lola 
Lo-Lo-Lo-Lo   [D]Lola  [G]      Lo-Lo-Lo-Lo 
[F]Lo...la-a-a   [F]/ / /    [G]/    
[A]/ / / /   / / / 
  
Well we [E7]drank champagne and danced all night 
[B]Under electric candlelight
She [D]picked me up and sat me on her knee {c:(beat)} 
And said "Dear boy, won't you come home with me"
 
Well [A]I'm not the world's most passionate guy 
But when I [D]looked in her eyes, well 
I [G]almost fell for my [A]Lola 
Lo-Lo-Lo-Lo [D]Lola  [G]    Lo-Lo-Lo-Lo 
[F]Lo...la-a-a   [F]/ / /    [G]/  
[A]Lola, Lo-Lo-Lo-Lo [D]Lola  
[G]    Lo-Lo-Lo-Lo 
[F]Lo...la-a-a    [F]/ / /    [G]/    
[A]/ / / /   / / / 


I [D/]pushed [A/]her a[E7/]way  {c:(}[E7]{c:123)}
I [D/]walked [A/]to the [E7/]door  {c:(}[E7]{c:123)}
I [D/]fell [A/]to the [E7/]floor   {c:(}[E7]{c:123)}
I got [A/]down [A/]on my [F#m/]knees {c:(}[F#m]{c:1234)}
Then [E7]I looked at her and she at me 
 
Well [A]that's the way that I want it to stay 
And I [D]always want it to [G]be that way for my 
[A]Lola, Lo-Lo-Lo-Lo   [D]Lola    [Dsus4]/ /      [D]/ /
[A]Girls will be boys and boys will be girls 
It's a [D]mixed up, muddled up [G]shook up world 'cept for 
[A]Lola, Lo-Lo-Lo-Lo   [D]Lola  {c:(4,1234)}
  
Well [E7]I left home just a week before
And [B]I'd never ever kissed a woman before but
[D]Lola smiled and took me by the hand, {c:(beat)} 
And said 'Dear boy, I'm gonna make you a man'
 
Well [A]I'm not the world's most masculine man but 
I [D]know what I am and I'm [G]glad I'm a man and so is 
[A]Lola, Lo-Lo-Lo-Lo   [D]Lola  [G]     Lo-Lo-Lo-Lo 
[F]Lo...la-a-a    [F]/ / /    [G]/ 
  
[A]Lola, Lo-Lo-Lo-Lo   [D]Lola,  [G]     Lo-Lo-Lo-Lo
[F]Lo...la-a-a    [F]/ / /    [G]/ 

[A]Lola, Lo-Lo-Lo-Lo   [D]Lola,  [G]     Lo-Lo-Lo-Lo 
[F]Lola    [F]/ / /    [G]/    [A]/

_________________________________


{define: Dsus4 0 2 2 3 0}










