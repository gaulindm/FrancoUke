{title:}
{subtitle:}

A| thumb     -           -
E| index         -   -
C| middle    -     -     -
G| ring      -           -

