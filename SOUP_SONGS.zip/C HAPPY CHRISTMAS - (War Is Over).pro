

{title:C08: HAPPY CHRISTMAS   3/4   Key of G }
{subtitle: (War Is Over)}
{subtitle:(John Lennon) }
{metronome: 144}
{time:2:50}


[G]/ / /   / / /   / / /

So this is [G]Christmas
And what have you [Am]done
Another year [D]over 
And a new one has be[G]gun
So this is [C]Christmas 
I hope you have [Dm]fun 
The near and the [G]dear ones 
The old and the [C]young 

{c:CHORUS}
{soc}
A very merry [F]Christmas 
And a happy New [G]Year 
Let's hope it's a [Dm]good one 
Without any [C]fear 
{eoc}

And so this is [G]Christmas,  
{c:                     (War is over)}   
For weak and for [Am]strong
{c:                          (If you want it)}
For rich and the [D]poor ones, 
 {c:                       (War is over )}  
the world is so [G]wrong                          
{c:                      (Now…)}
And so happy [C]Christmas, 
{c:                    (War is over )}    
For the lonely and [Dm]scared                        
{c:                            (If you want it)}
Let's stand up [G]together, 
{c:                      (War is over)}    
what's ours we can [C]share                         
{c:                             (Now…)}
{soc}
A very merry [F]Christmas 
And a happy New [G]Year 
Let's hope it's a [Dm]good one 
Without any [C]fear 
{eoc}

{c:ALL:}
[G]War is over [Am]if you want it
[D]War is over [G]now

A very merry [C]Christmas 
And a happy New [Dm]Year 
Let's hope it's a [G]good one 
Without any [C/]fear

















