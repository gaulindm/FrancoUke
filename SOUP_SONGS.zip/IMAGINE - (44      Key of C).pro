{title:IMAGINE   }
{subtitle:(4/4      Key of C)}
{subtitle:(John Lennon)}
{time: 4:00}
{metronome: 74}


{c:Optional picking pattern}
{c:(first 4 lines of the verses):}

{sot}
        C                         Cmaj7    F             
A - - 3 - - - - - - 3 - - - 2 - - - - - 0 - - - - - 0 - - 0-1-2 -   
E - - 0 - - 0 - - - 0 - - - 0 - - - - - 1 - 1 - - - 1 - - -     
C - - - - 0 - 0 - - - 0 - - - 0 - - - - - 0 - 0 - - - 0 - -    
G - - 0 - - - - - - 0 - - - 0 - - - - - 2 - - - - - 2 - - -
{eot}

{c:The rest of the lines follow a simple}
{c: 4-beat pattern on each chord}
{sot}
A - - X - - - - - - - - -
E - - X- - - X - - - - -
C - - - - X - - X - - - -
G - - X- - - - - - - - - 

{eot}
{c:The three note riff is on the A string}
{c:A| - 0 - 1 - 2 - }
{c:Use it only when you see ***}

{c:INTRO:}
[C]/ / /    [Cmaj7]/      [F]/ / / /    
[C]/ / /    [Cmaj7]/      [F]/ / / /   

[C]  Imagine there's [Cmaj7]no         hea[F]ven  ***
[C]  It's easy if yo-[Cmaj7]ou         try-[F]y  ***
[C]  No hell [Cmaj7]be- lo-   [F]ow us  ***
[C]  Above us [Cmaj7]only         [F]sky
[F]  Imagine [Am]all the peo[Dm]ple     [F]       
[G7]Living for [C/]to[G7/]day, ah ha…

[C]  Imagine there's [Cmaj7]no         coun[F]tries  ***
[C]  It isn't hard [Cmaj7]to        do-[F]o   ***
[C]  Nothing to kill [Cmaj7]or         die- [F]ie for  ***
[C]  And no reli[Cmaj7]gion      to-[F]o
[F]  Imagine [Am]all the peo[Dm]ple     [F]      
[G7]Living life [C/]in [G7/]peace, you-ou…

{soc}
     [F]    You may [G7]say I'm a [C]dreamer  [E7]       
     [F]    But I'm [G7]not the only [C]one   [E7]
     [F]    I hope some [G7]day you'll [C]join us   [E7]       
     [F]     And the [G7]world will [C]be as one
{eoc}

[C]  Imagine no [Cmaj7]posse- [F]ssions  ***
[C]  I wonder if yo-[Cmaj7]ou       ca-[F]an  ***
[C]  No need for greed [Cmaj7]or       hun[F]ger  ***
[C]  A brotherhood [Cmaj7]of         ma-[F]an
[F]  Imagine [Am]all the peo[Dm]ple     [F]      
[G7]Sharing all [C/]the [G7/]world, you-ou…

{soc}
     [F]    You may [G7]say I'm a [C]dreamer    [E7]       
     [F]     But I'm [G7]not the only one [C]      [E7]
     [F]    I hope some [G7]day you'll [C]join us     [E7]       
     [F]     And the [G7]world will [C/(gliss)]live as one
{eoc} 
