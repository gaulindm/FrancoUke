

{title:079 MARGARITAVILLE }
{subtitle:(4/4  Key of G)} 
{subtitle: (Jimmy Buffett)}
{time:4:52}
{metronome: 130}

{c:(Tutorial on the website)}

{c:Optional:} 
{c:INTRO RIFF is played with the }
{c:INTRO chords}

{c:All riffs are on the A string}

{c:INTRO RIFF :}
{c: 5 5 5 3 5,   5 5 5 3 5}
{c: 7 7 7 5 3 2}  {c:(count 234)}
{c:and go to "nibbling”)}


{c:INTRO}
[G]/ / /      [Gsus2]/               [G]/     
[G]/ / /     [Gsus2]/                [G]/ 
[C]/ / /    [D]/     [D7]/      [G]/ / / /   
       
[G]  Nibbling on sponge cake 
Watching the sun bake
All those tourists covered in [D]oil
[D7]  Strumming my four string 
On my front porch swing
[D]  Smell those shrimp 
They’re beginning to [G]boil     [G7]

{c: CHORUS}
{soc}
  [C]       Wastin' a[D]way again in 
  Marga[G]ritaville {c:(3,4)}   [G7]
  [C]       Searching for my  [D]     lost shaker of 
  [G]Salt  (salt  [G7]salt  salt)
  [C]       Some people [D]claim that there’s a 
  [G/]Woman to [C]blame but I 
  [D]Know {c: 7 7 7 5 3 }   It’s nobody’s
  [G]Fault  {c: 5 5 5 3 2  (234)}
                                                        
{eoc}

[G]  Don't know the reason 
Stayed here all season
Nothin' to show but this brand new ta[D]ttoo
[D7]  But it's a real beauty, a Mexican cutie
[D]  How it got here I haven't a [G]clue   [G7]

{soc}
  [C]       Wastin' a[D]way again in 
  Marga[G]ritaville  {c:(3,4)}  [G7]
  [C]       Searching for my [D]      lost shaker of 
  [G]Salt  (salt  [G7]salt  salt)
  [C]       Some people [D]claim that there’s a 
  [G/]Woman to [C]blame, now I 
  [D]Think  {c: 7 7 7 5 3} hell it could be my 
  [G]Fault  {c:5 5 5 3 2  }  {c: (234)}                                                                                                                   
{eoc}

[G]   Blew out my flip flop 
Stepped on a pop top
Cut my heel had to cruise on back [D]home
[D7] But there's booze in the blender
And soon it will render
[D]   That frozen concoction that 
Helps me hang [G]on    [G7]

{soc}
  [C]      Wastin' a[D]way again in 
  Marga[G]ritaville  {c:(3,4)}   [G7]
  [C]      Searching for my [D]      lost shaker of 
  [G]Salt  (salt   [G7]salt   salt)
  [C]      Some people [D]claim that there’s a 
  [G/]Woman to [C]blame, but I 
  [D]Know {c: 7 7 7 5 3}   it’s my own damn 
  [G]Fault   {c:5 5 5 3 2  }  {c: (beat)}
                                                
                                                                                                                            
  [G7]Yes and [C]    some people [D]claim
  That there’s a [G/] woman to [C]blame
  And I [D]know  {c: 7 7 7 5 3  }   
  It’s my own damn 
  [G]fault   {c: A: 5 5 5 3 2  }  {c:(234)}                                                       
{eoc}
                                                                
{c:OUTRO}
[G]/ / /      [Gsus2]/               [G]/     
[G]/ / /     [Gsus2]/                [G]/ 
[C]/ / /    [D]/     [D7]/      [G]/ 


{define: D7 0 2 0 2 0}

______________________________________














