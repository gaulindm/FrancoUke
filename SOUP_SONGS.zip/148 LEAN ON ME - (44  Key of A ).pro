

{title:148 LEAN ON ME  }
{subtitle:(4/4  Key of A )}    
{subtitle:(Bill Withers)}
{time: 3:50}
{metronome: 150}






{c:(hum)}
[A]/ / / /    / / / /      [D]/ / / /    / / / /      
[A]/ / / /    / / / /      
[C#m7]/ / / /      [E7]/ / / /
[A]/ / / /    / / / /      [D]/ / / /    / / / /      
[A]/ / / /    / / / /      
[E7]/ / / /      [A]/ / / /

[A]Sometimes in our li-[D]ives
We all have pa-[A]ain 
We all have so-[C#m7]or…row  [E7]
[A]But, if we are wi-[D]ise
We know that the-[A]ere’s 
Always tomo-[E7]or…row 

{c:CHORUS}
{soc}
   [A]    Lean on me {c:(1234)} 
   When you're not stro-[D]o-ong
   And I'll be your frie-[A]end 
   I'll help you ca-[C#m7]arry  o.[E7].. o-o-o-on
   [A]For… it won’t be lo-[D]o-ong 
   ‘Til I'm gonna ne-[A]eed 
   Somebody to le-[E7]ean on [A]
{eoc}

[A]Please, swallow your pri-[D]ide
If I have thi-[A]ings 
You need to bo-[C#m7]or…row  [E7] 
[A]For, no one can fi-[D]ill 
Those of your ne-[A]eeds 
That you don't le-[E7]et show [A]

{sob}
 You just [A]call on me brother
 When you need a hand
 We all need somebody to le-[E7]ean on  [A]
 I just might have a problem 
 That you'll understand
 We all need somebody to le-[E7]ean on 
{eob}

{soc}
   [A]    Lean on me {c:(1234)}
   When you're not stro-[D]o-ong
   And I'll be your frie-[A]end 
   I'll help you ca-[C#m7]arry     o.[E7].. o-o-o-on
   [A]For… it won’t be lo-[D]o-ong 
   ‘Til I'm gonna ne-[A]eed 
   Somebody to le-[E7]ean on [A]
{eoc}

{sob}
 You just [A]call on me brother
 When you need a hand
 We all need somebody to le-[E7]ean on  [A]
 I just might have a problem 
 That you'll understand
 We all need somebody to le-[E7]ean on [A]
{eob}

[A]If, there is a lo-[D]oad you have to be-[A]ear 
That you can't ca-[C#m7]ar…ry   [E7] 
[A]I'm right up the ro-[D]oad 
I'll share your lo-[A]oad, if you just 
Ca-[E7]all me [A]   pick up the phone and 
[E7]Call me [A]   when you need a (friend)
[E7]Call me [A]   go on and    [E7]call me [A/]


_____________________________________

[C#m7alt]
{define: C#m7 0 1 1 0 2}
{define: C#m7alt 0 4 4 4 4}








