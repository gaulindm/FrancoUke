{title:KING OF THE ROAD}
{subtitle:(4/4     Key of G)}
{subtitle:(Roger Miller)}
{time: 2:40}
{metronome: 122}








{c:INTRO:}    
[G7]/ / / /     [C]/ / / /     
[D7]/ / / /     [G]/ / / /

[G] Trailers for [Am]sale or rent   [D7]
Rooms to let [G]fifty cents
No phone no [Am]pool no pets     [D/]
I ain't got no [D7/]cigarettes ah, but 
[G]   Two hours of [Am]pushing broom
Buys an [D7]    eight by twelve [G]four bit room
I'm a [G7]    man of [C]means, by no means [D7//]
King of the [G]road  {c:(234)}

[G] Third box car [Am]midnight train   [D7]
Destination [G]Bangor Maine
Old worn-out [Am]suit and shoes    [D/] 
I don't pay no [D7/]union dues I smoke 
[G]   Old stogies [Am]I have found
[D7] Short but not too [G]big around 
I'm a [G7]    man of [C]means, by no means [D7//]
King of the [G]road  {c:(2,3)}

I know [G]every engineer on [C]every train
[D7]All of the children and [G]all of their names
And every handout in [C]every town
And [D/]every lock that [D/]ain't locked when 
[D/]no one's a[D7/]round, I sing...

[G] Trailers for [Am]sale or rent   [D7]  
Rooms to let [G]fifty cents
No phone no [Am]pool no pets [D/]  
I ain't got no [D7/]cigarettes
Ah, but [G]   two hours of [Am]pushing broom
Buys an [D7]    eight by twelve [G]four bit room
I'm a [G7]    man of [C]means, by no means
[D7//]  King of the [G]road 
[D7//]  King of the [G]road
[D7//]  King of the [G]road   
{c:(234)} [G/]  [D7/]  [G/]



