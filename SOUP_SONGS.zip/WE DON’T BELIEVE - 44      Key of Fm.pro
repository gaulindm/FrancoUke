{title:WE DON’T BELIEVE }
{t:WHAT’S ON TV}
{subtitle:4/4      Key of Fm}
{metronome: 210}
{time: 3:30}







{c:INTRO: }
{c:F#m / / / /    E7 / / / / }
{c:A / / / /   / (stop) yeah yeah yeah!}
{c:F#m / / / /    E7 / / / / }
{c:A / / / /   / / / / }  
{c:F#m / / / /    E7 / / / / }
{c:A / / / /   / / } 


We don't be[F#m]lieve what's [E7]on T[A]V
Because it's [F#m]what we [E7]want to [A]see
And what we [F#m]want
We know [E7]we can't be[A]lieve
We have all [F#m]learned to [E7]kill our [A]dreams

I [Bm]need to know… that [D]when I fail 
You'll still be [A]    here…     [A7]mm
'Cause [Bm]if you stick around 
I'll [D]sing you pretty sounds
And we'll make [E7]money selling your hair 

[C#/]I don't care what's [D/]in your hair
I just [A/]wanna know what's on your [E7/]mind
I [C#/]used to say I wanna [D/]die before I'm old
But be[A/]cause of you I might think [E7/]twice {c:(2 beats)}
Yeah yeah yeah! 

{c:F#m / / / /    E7 / / / / }
{c:A / / / /    A /   (stop)    Yeah yeah yeah!} 
 
{c:F#m / / / /}  [E7]  {c:“All right”}   [A]  {c:”second verse”}

What if my [F#m]dream does [E7]not hap[A]pen?
Would I just [F#m]change 
What I've [E7]told my [A]friends?
Don't want to [F#m]know who [E7]I would [A]be
When I wake [F#m]up from a [E7]dreamer's [A]sleep

I [Bm]need to know that [D]when I fail 
You'll still be [A]   here… [A7]oh…
'Cause [Bm]if you stick around
I'll [D]sing you pretty sounds
And we'll make [E7]money selling your hair

But [C#/]I don't care what's [D/]in your hair
I just [A/]wanna know what's on your [E7/]mind
I [C#/]used to say I wanna [D/]die before I'm old
But be[A/]cause of you I might think [E7/]twice
[C#/]I don't care what's [D/]in your hair
I just [A/]wanna know what's on your [E7/]mind
I [C#/] used to say I wanna [D/]die before I'm old
But be[A/]cause of you I might think [E7/]twice  {c:(234)}

{sot}
A|- 5 - 
{eot}

{c:Yeah yeah yeah!} 
[F#m]/ / / /    [E7]/ / / /    [A]   oh…     yeah yeah yeah! 
[F#m]/ / / /    [E7]/ / / /    [A]/ / / /   /   yeah yeah yeah!

{c:(loud)}
[F#m]Oh oh [E7]oh oh [A]oh...   yeah yeah yeah!
[F#m]Oh oh [E7]oh oh [A]oh...   yeah yeah yeah!
[F#m]Oh oh [E7]oh oh [A]oh...   yeah yeah yeah!
[F#m]Oh oh [E7]oh oh [A]oh...   yeah yeah yeah!

{c:(quiet)}
[F#m]Oh oh [E7]oh oh [A]oh...   yeah yeah yeah!
[F#m]Oh oh [E7]oh oh [A]oh...   yeah yeah yeah!
[F#m]Oh oh [E7]oh oh [A]oh...   yeah yeah yeah!
[F#m]Oh oh [E7]oh oh [A]oh...  [A/]    YEAH YEAH YEAH!

{define: C# 0 6 5 4 4}
[C#]

