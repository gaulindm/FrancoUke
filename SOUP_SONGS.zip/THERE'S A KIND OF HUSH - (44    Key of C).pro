{t:THERE'S A KIND OF HUSH }
{subtitle:(4/4    Key of C)}
{subtitle:(Les Reed and Geoff Stephens)}
{time: 3:15}
{metronome: 126}

{c:“X” at the end means mute the strings}
{c:with your strumming hand}




{c:INTRO:}   
[C]/ / / /     [G7]/ / / /      
[C]/ / / /      [G7]/ / / /      
[C]/ / / /   / / /  

There's a [C]kind of hush  [E7]    
All over the [Am]world to[C7]night 
All over the [F]world you can hear the [G7]sounds 
Of lovers in [C]love (you [G7]know what I mean) 
Just the [C]two of us  [E7]      
And nobody [Am]else in [C7]sight 
There's nobody [F]else and I'm feeling [G7]good 
Just holding you [C]tight  [C7] 

{c:CHORUS}
{soc}
  So [F]listen very [Dm]carefully 
  [Am]Closer now and [Dm]you will see 
  What I [C]mean... it isn't a [C7]dream 
  The [F]only sound that [Dm]you will hear 
  Is [Am]when I whisper [Dm]in your ear 
  I love [G]you
  For ever and ever [Gaug]/ / / / 
{eoc}

There's a [C]kind of hush [E7]    
All over the [Am]world to[C7]night 
All over the [F]world you can hear the 
[G7]Sounds of lovers in [C]love  [G7]

La   [C]la la   la-la-la    [E7]laaa
La-la   [Am]la la    la-la-la   [C7]laaa
a-la   la-la   [F]laaa   la-la-la-la   [G7]laaa
La-la-la-la   [C]laaaa  [C7] 

{soc}
  So [F]listen very [Dm]carefully 
  [Am]Closer now and [Dm]you will see 
  What I [C]mean... it isn't a [C7]dream 
  The [F]only sound that [Dm]you will hear 
  Is [Am]when I whisper [Dm]in your ear 
   I love [G]you
  For ever and ever [Gaug]/ / / / 
{eoc}

There's a [C]kind of hush [E7]    
All over the [Am]world to[C7]night 
All over the [F]world people just like [G7]us 
Are falling in [C]love...    [G7]        
Are falling in [C]love    [G7]
They’re falling in [C]love... [G7]hush 
they’re falling in [C]love {c(234)}   [X]hush  

{define: Gaug 0 0 3 3 2}