


{title:WITH A LITTLE HELP }
{title:FROM MY FRIENDS}
{subtitle:(4/4    Key of G)}    
{subtitle:(Paul McCartney & John Lennon) }
{time:2:39}
{metronome: 124}       


Lynda

[F]/ /     [C]/ /     [G]/ / / /    
[F]/ /     [C]/ /     [G]/ / / /    

(S)  [G]What would you [D]think if I [Am]sang out of tune
Would you [D]stand up and [D7]walk out on [G]me 
(E)  Lend me your [D]ears and I'll [Am]sing you a song 
And I'll [D]try not to [D7]sing out of [G]key 
Oh I get [F]by with a little [C]help from my [G]friends 
Mm I get [F]high with a little [C]help from my [G]friends 
Mm gonna [F]try with a little [C]help from my [G]friends 

(E)  [G]What do I [D]do when my [Am]love is away, does it 
(S)  [D]Worry you to [D7]be a[G]lone 
(E)  [G]How do I [D]feel by the [Am]end of the day are you 
(S)  [D]Sad because you're [D7]on your [G]own
No, I get [F]by with a little [C]help from my [G]friends 
Mm I get [F]high with a little [C]help from my [G]friends 
Mm gonna [F]try with a little [C]help from my [G]friends 

Do you [Em]need any[A]body
I [G]need some[F]body to [C]love 
Could it [Em]be any[A]body
I [G]want some[F]body to [C]love 

(E)  [G]Would you be[D]lieve in a [Am]love at first sight
(S)  Yes I'm [D]certain that it [D7]happens all the [G]time 
(E)  What do you [D]see when you [Am]turn out the light 
(S)  I can't [D]tell you but I [D7]know it’s [G]mine 
Oh I get [F]by with a little [C]help from my [G]friends 
Mm I get [F]high with a little [C]help from my [G]friends 
Mm I’m gonna [F]try with a little [C]help from my [G]friends 

Do you [Em]need any[A]body 
I [G]need some[F]body to [C]love 
Could it [Em]be any[A]body 
I [G]want some[F]body to [C]love 
Oh I get [F]by with a little [C]help from my [G]friends 
Mm gonna [F]try with a little [C]help from my [G]friends 
Yes I get [F]by with a little [C]help from my 
[G]friends with a little help from my 
[D#]fri....ends {c:(hold for 8)} [G/]


______________________________


{define: D7 0 2 0 2 0}











