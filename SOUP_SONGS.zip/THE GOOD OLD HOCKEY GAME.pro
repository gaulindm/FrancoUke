{title: THE GOOD OLD HOCKEY GAME }
{subtitle:  4/4      Key of C}
{time:3:48}
{metronome:185}
{subtitle:(Stompin' Tom Connors)}                                                                                       

[C]/ / / /    [G7]/ / / /    [C]/ / / /   / / / 

Hel[C]lo out there we're on the air 
it's hockey night to[G7]night
Tension grows, the whistle blows, 
and the puck goes down the [C]ice
The goalie jumps and the players bump 
and the fans all go in[F]sane
Someone roars "[C]Bobby scores!" 
at the [G7]good old hockey [C]game  

{c:CHORUS}
{soc}
  [G7/]Oh! The [C]good old hockey game 
  is the best game you can [G7]name
  And the best game you can name 
  is the good old hockey [C]game {c:(234,123)}
{eoc}

{c:(Spoken):   2nd Period} {c: (123)}

Where [C]players dance with skates a-flash 
the home team trails be[G7]hind
But they grab the puck and go bursting up 
and they're down across the [C]line
They storm the crease like bumble bees 
they travel like a burning [F]flame
We see them slide the [C]puck inside 
it's a [G7]one one hockey [C]game
{soc}
  [G7/]Oh! The [C]good old hockey game 
  is the best game you can [G7]name
  And the best game you can name 
  is the good old hockey [C]game {c:(234,123)}
{eoc}

{c:(Spoken):}
{c:3rd Period,Last game of the playoffs too!} 

Oh [C]take me where those hockey 
players face-off down the [G7]rink
And the Stanley Cup is all filled up 
for the champs who win the [C]drink
Now the final flick of a hockey stick 
and one gigantic [F]scream
"The puck is in!"  The [C]home team wins 
the [G7]good old hockey [C]game

{soc}
  [G7/]Oh! The [C]good old hockey game 
  is the best game you can [G7]name
  And the best game you can name 
  is the good old hockey [C]game 

 [G7/]Oh! The [C]good old hockey game 
 is the best game you can [G7]name
 And the best game you can name 
 is the good old hockey [C]game 

  [G7/]Oh! the [C]good old hockey game 
  is the best game you can [G7]name
  And the best game you can name  
  is {c:(slow down)} the good old hockey [C]game {c:(234)} [C/]
{eoc}

{c:(Spoken):  He shoots he scores!}                                         

_______________________________




















