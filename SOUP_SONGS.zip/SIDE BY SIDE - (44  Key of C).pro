{title:SIDE BY SIDE }
{subtitle:(4/4  Key of C)}     
{subtitle:(Harry M. Woods)}
{time: 2:15}
{metronome: 120}






{c:INTRO:} 
[D7]/ /    [G7]/ /     [C]/ / /
 
Oh, we [C]ain’t got a barrel of [F]mon-[C]ey
Maybe we’re ragged and [F]fun-[C]ny
But we’ll [F]travel a-[D7]long   
[C]Singin’ a [A7]song
[D7]Side  [G7]by   [C]side   [G7]

Oh, we [C]don’t know what’s comin’ to-[F]mor-[C]row
Maybe it’s trouble and [F]sor-[C]row
But we’ll [F]travel the [D7]road   
[C]Sharin’ our [A7]load
[D7]Side   [G7]by  [C]side

{soc}
     Through [E7]    all kinds of weather
     [A7]What if the sky should fall
     Just as [D7]long as we’re together  
     [Dm7]It doesn’t matter at [G7]all    [G7+5]
{eoc}

When they’ve [C]all had their quarrels and 
[F]Par-[C]ted, we’ll be the same as we [F]star-[C]ted
Just a’[F]travellin’ a-[D7]long   
[C]Singin’ a [A7]song
[D7]Side  [G7]by  [C]side

{soc}
     Through [E7]     all kinds of weather 
     [A7]what if the sky should fall
     Just as [D7]long as we’re together 
     [Dm7]It doesn’t matter at [G7]all    [G7+5]
{eoc}

When they’ve [C]all had their quarrels and 
[F]Par-[C]ted we’ll be the same as we [F]star-[C]ted
Just a’[F]travellin’ a-[D7]long,      [C]singin’ a [A7]song
[D7]Side…       [G7]by…     
[C]side {c:(234,1)}  [F/]   [C/]   [C9]{c:(flutter)}



{define: D7 0 2 0 2 0}
{define: G7+5 0 0 3 1 2}
{define: C9 0 0 2 0 1}
