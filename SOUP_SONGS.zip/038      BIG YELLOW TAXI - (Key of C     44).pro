

{title:038 BIG YELLOW TAXI    }
{subtitle:(Key of C     4/4)}
{subtitle:(Joni Mitchell)}
{time:3:03}
{metronome:170}






[C]/ / / /    / / / /  

Sha-[C]oo…bop-bop-bop-bop 
Sha-oo…bop-bop-bop-bop

They [F]paved paradise 
Put up a parking [C]lot    [C7]
With a [F]pink hotel, a [G7]boutique 
And a [C]swinging hot spot

{c:CHORUS:}
{soc}
     {c:(soft)}    [C]Do…n't it al…ways seem-to-go 
     That you [F/]don't know what you’ve 
     Got till it's [C/]gone
     {c:(more lively)} They [F]paved paradise
     [G7]Put up a parking 
     [C]Lot
     {c:(sha-oo…bop-bop-bop-bop)}
     {c:(sha-oo…bop-bop-bop-bop)}
{eoc}

They [F]took all the trees
Put ‘em in a tree mu[C]seum [C7]
And they [F]charged the people a 
[G7]Dollar and a half just to [C]see ‘em   

{soc}
     [C]Do…n't it al…ways seem-to-go 
     That you [F/]don't know what you’ve 
     Got till it's [C/]gone
     They [F]paved paradise, [G7]put up a parking 
     [C]Lot
     {c:(sha-oo…bop-bop-bop-bop)}
     {c:(sha-oo…bop-bop-bop-bop)}
{eoc}

[F]Hey farmer farmer
Put away that DD[C]T now [C7]
Give me [F]spots on my apples, but 
[G7]Leave me the birds and [C]bees… please  

{soc}
     [C]Do…n't it al…ways seem-to-go 
     That you [F/]don't know what you’ve 
     Got till it's [C/]gone
     They [F]paved paradise, [G7]put up a parking 
     [C]Lot
     {c:(sha-oo…bop-bop-bop-bop)}
     {c:(sha-oo…bop-bop-bop-bop)}
{eoc}

[F]Late last night 
I heard the screen door [C]slam [C7]
And a [F]big yellow taxi 
[G7]Took away my old [C]man  

{soc}
[C]Do…n't it al…ways seem-to-go 
That you [F/]don't know what you’ve 
Got till it's [C/]gone
They [F]paved paradise, [G7]put up a parking 
[C]lot
{c:(sha-oo…bop-bop-bop-bop)}
{c:(sha-oo…bop-bop-bop)}

I said, [C]do…n't it al…ways seem-to-go 
That you [F/]don't know what you’ve got 
Till it's [C/]gone {c:(234!!!)}
     
They [F]paved paradise
[G7]Put up a parking [C]lot  
                           {c:(sha-oo…bop-bop-bop-bop)}
They [F]paved paradise
[G7]Put up a parking [C]lot  
                           {c:(sha-oo…bop-bop-bop-bop)}
{c:(high)} They [F]paved paradise
{c:(low)}  [G7]put up a parking [C/]lot  (ha, ha, ha)
{eoc}

_______________________________________













