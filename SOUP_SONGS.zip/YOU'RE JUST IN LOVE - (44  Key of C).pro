

{title: YOU'RE JUST IN LOVE }
{subtitle:(4/4  Key of C)}   
{subtitle:(Irving Berlin)}
{metronome: 154}

{c:1: Men sing Part A,  then Women sing Part B}
{c:2: Men and women sing at the same time}
{c:3: Men and women sing at the same time}
{c:    with REDUCED STRUM to ***, then full strum}

{c:(don't scroll this song. Keep it on your vocal part)}

{c:INTRO: C / / / /   / / / /}
{c:PART A: MEN}
[C]I hear singing and there's no one there
I smell blossoms and the [G7]trees are bare
All day long I seem to walk on air
I wonder why………I wonder  [C]why? ***
I keep tossing in my sleep at night
And what's more, I've [C7]lost my [F]appetite
Stars that used to twinkle [C]in the skies              
Are twinkling [G7]in my eyes I wonder [C]why 
    	
{c: PART B: WOMEN}
[C]  You don't need analyzing
It is not so surprising
That you feel very strange but [G7]nice
Your heart goes pitter patter
You know just what's the matter
Because I've been there once or [C]twice ***
Put your head on my shoulder
You need someone who's older
A rub-down with a [C7]velvet [F]glove
There is nothing you can take
[C]  To relieve that pleasant ache
[G7] You're not sick you're just in 
[C]Love  {c:(234,1)} [G7/]  [C/]



