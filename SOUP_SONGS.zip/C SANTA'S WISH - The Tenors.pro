{title: SANTA'S WISH}
{subtitle: The Tenors}
{time: 3:00}

https://www.youtube.com/watch?v=RtrBcRJC2C8

Verse 1
One Ch[C]ristmas many y[G]ears ago 
when [F]I was just a [C]boy
I walked a[C]long those s[G]nowy streets, 
the w[F]indows full of [G]toys
[C]My mom and dad both h[Em]eld my hands, 
a c[F]rowd was up a[D]head
They [F]gathered 'round a [G]man who sang, 
and [F]this is what he [G]said

Chorus
[C]I'd like to teach the world to sing 
[D]in perfect harmony
I'd [G]like to hold it in my arms 
and [F]keep it company
I'd [C]like to see the world for once 
all [D]standing hand in hand
And [G]hear them echo through the hills 
for [F]peace throughout the [C]land

Verse 2
Then all at [C]once he dis[G]appeared 
wi[F]thin a flash of [C]light
His [C]tattered coat was [G]left behind, 
his s[F]leigh was taking [G]flight
And I [C]still hear that [G]melody 
that e[F]choed through the [D]night
    
Chorus
[C]I'd like to teach the world to sing 
[D]in perfect harmony
I'd [G]like to hold it in my arms 
and [F]keep it company
I'd [C]like to see the world for once 
all [D]standing hand in hand
And [G]hear them echo through the hills 
for [F]peace throughout the [C]land

Bridge
Sing it now [C//]aaa [C6//]aaa [Am7//]aaa [Am//]a a - [D7//]aaa [G7//]aaa [F////]aaa a a [C/]a
[F]As a child I as[Fm]ked the man in [C]red
"Hey Santa, what's your Christmas wish?"
And [F]this is what he [Fm]said...

Chorus
[C]I'd like to teach the world to sing 
[D]in perfect harmony
I'd [G]like to hold it in my arms 
and [F]keep it company
I'd [C]like to see the world for once 
all [D]standing hand in hand
And [G]hear them echo through the hills 
for [F]peace throughout the [C]land

Outro
[C]I'd like to teach the world to sing 
in perfect harmony (let me hear you now)
[C]I'd like to teach the world to sing 
in perfect harmony (Oh oh oh)
[C]I'd like to teach the world to sing 
in perfect harmony
(I'd      Like   to teach the world to Sing)
[C]I'd like to teach the world to sing 
in perfect harmony
(I'd      Like   to teach the world to Sing)
[C]I'd like to teach the world to sing 
in perfect harmony
(I'd      Like   to teach the world to Sing)
[C]I'd like to teach the world to sing 
in perfect harmony




