{title: Coat of Many Colors}
{subtitle: Key of G}
{Artist: Dolly Parton}  
  
Intro:   G  G  G  G ......(Strum the G chord then pick strings CEA) X 4

[G]Back, through the years 
I go wonderin' once again
[G]Back to the seasons of my [C]youth  [C]
I re-[G]call the box of rags 
that someone gave us  [G]
And [G]how my momma put the rags to [C]use  [C]

There were [G]rags of many colours, 
and every piece was small
And I [G]didn't have a coat, 
and it was [D7] way down in the fall
Momma [G]sewed the rags together, 
sewin' [C]every piece with love
She made my [G]coat of many colours, 
that [D7]I was so [G]proud of  [G]

As she [G]sewed she told a story, 
from the bible she had read
About a [G]coat of many colours, 
Joseph [D7]wore and then she said
Per-[G]haps this coat will bring you, 
good [C]luck and happiness
And I just [G]couldn't wait to wear it
And momma [D7]blessed it with a [G]kiss  [G]

My [C]coat of many colours 
that my [G]momma made for me
[C]Made only from rags, 
but I [G]wore is so [D7]proudly [D7]
Al[G]though we had no money 
oh I was [C]rich as I could be
In my [G]coat of many colours, 
my [D7]momma made for [G]me  [G]

...Key Change......E7  E7 

So with [A]patches on my britches, 
and holes in both my shoes
In my [A]coat of many colours 
I [E7]hurried off to school
Just to [A]find the others laughin', 
and a- [D]makin' fun of me
In my [A]coat of many colours, 
my [E7] momma made for [A]me  [A]

And oh I [A]couldn't understand it, 
for I felt I was rich
And I [A]told 'em of the love my momma 
[E7]sewed in every stitch
And I [A]told 'em all the story, 
momma [D]told me while she sewed
And how my [A]coat of many colours
Was worth [E7]more than all their [A]clothes  [A]

But they [D]didn't understand it 
and I [A]tried to make them see
That [D]one is only poor, 
only [A]if they choose to [E7]be  [E7]
Now I [A]know we had no money, 
but I was [D]rich as I could be
In my [A]coat of many colours, 
my [E7]momma made for [D]me  [D]
Made just [A] for me   [A]/ [D]/ [A]/
















