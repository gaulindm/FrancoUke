

{title:016  CHAINS  } 
{subtitle:(4/4   Key of A)}
{subtitle: (Gerry Goffin/Carole King)}
{metronome:142}
{time:3:23}






[A]/ / / /     / / / / 

[A]Chains... my baby's got me locked up in chains
And they ain't the [D7]kind that you can [A]see
Wh-oa these [E7]chains of lo...[D7]ve 
Got a hold on [A]me, yeah    [E7]

[A]Chains... well I can't break away from these chains
Can't run a[D7]round 'cause I'm not [A]free
Wh-oa these [E7]chains of lo...[D7]ve 
Won't let me [A]be, yeah    [A7]

[D7]  I wanna tell you pretty Baby 
[A]   I think you're [A7]fine 
[D7]  I'd like to love you 
But [E7]Darling I'm imprisoned by these

[A]Chains... my baby's got me locked up in chains
And they ain't the [D7]kind that you can [A]see
Wh-oa these [E7]chains of lo...[D7]ve 
Got a hold on [A]me, yeah    [A7]

[D7]  Please believe me when I tell you 
[A]   Your lips are [A7]sweet
[D7]  I'd like to kiss them 
But [E7]I can't break away from all of these
 
[A]Chains... my baby's got me locked up in chains
And they ain't the [D7]kind that you can [A]see
Wh-oa these [E7]chains of lo...[D7]ve 
Got a hold on [A]me, yeah     [E7]

[A]Chains{c: (234,12)}  Chains of lo...ve  
Chains of [D7]lo...ve  Chains of [A]lo...ve 
Wh-oa these [E7]chains of lo...[D7]ve 
Got a hold on [A]me, yeah [A/]  [E7/] [A/]

{define: D7 0 2 0 2 0}

__________________________________________












