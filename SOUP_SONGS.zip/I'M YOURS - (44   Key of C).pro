{t:I'M YOURS    }
{subtitle:(4/4   Key of C)}   
{subtitle:(Jason Mraz)}
{metronome: 144}
{time: 3:25}








{c:INTRO: (emphasis on 2nd beat)}
[C]/ / / /   / / / /    
[G]/ / / /   / / / /    
[Am]/ / / /   / / / /    
[F]/ / / /   / / /  

Well [C]you done done me and you bet I felt it 
I [G]tried to be chill but you're so hot that I melted 
I [Am]fell right through the cracks
Now I'm [F]trying to get back  
Before the [C]cool done run out 
I'll be giving it my bestest 
And [G]nothing's gonna stop me but 
Divine intervention 
I [Am]reckon it's again my turn 
To [F]win some or learn some

{c:CHORUS 1}
But [C]I won't hes-i-[G]tate no more, no [Am]more
It cannot [F]wait, I'm yo..ou..[C]ours  
                                                                             
Well open up your mind and see like [G]me 
Open up your plans and damn you're [Am]free 
Look into your heart and you'll find 
[F]Love love love love 
[C]Listen to the music of the moment 
People dance and [G]sing 
We’re just one big fami[Am]ly    
And it's our God-forsaken right to be 
[F]love, love, love, love, [D/]loved {c:(hold)}
 
{c:CHORUS 2}                                                                          
So [C]I won't hes-i-[G]tate no more, no [Am]more 
It cannot [F]wait, I'm yours, there's no 
[C]Need to compli[G]cate
Our time is [Am]short; this is our [F]fate, I'm yours 

[C]/ / / /   / / / /    [G] / / / /   / / / /    
[Am]/ / / /   / / / /    [F]/ / / /   / /   
I've been spending [C]way too long checking my 
Tongue in the mirror, and 
[G]Bending over backwards just to try to see it clearer  
But my [Am]breath fogged up the glass 
So I [F]drew a new face and laughed
I [C]guess what I'm be saying is there ain't no better 
Reason to [G]rid yourself of vanity and just go with 
The seasons, it's [Am]what we aim to do 
Our [F]name is our virtue

{c:CHORUS 3}
But [C]I won't hesi-[G]tate no more
No [Am]more It cannot [F]wait, I'm sure

{c:(chorus #2 works simultansous with this next part)}
{c:(Just remember the D/ at the end)}

[C]   Well open up your mind and see like [G]me
Open up your plans and damn you're [Am]free 
Look into your heart and you'll find the 
[F]Sky is yours
So [C]please don't, please don't, please don't, there's no 
[G]need to complicate cause our 
[Am]Time is short, my dis, oh dis, oh dis is our 
[F]Fate, I'm you...[D/]ours 