

{title:C22:GRANDMA GOT RUN OVER BY A REINDEER}
{subtitle:4/4     Key of G}
{time: 3:35}


[G]/ / / /     [F/]        [C/]    
[G]/ / / /   / / / /

[G]Grandma got run over by a reindeer
Walking home from our house Christmas [C]Eve
You can say there's no such thing as [G]Santa
But [D]as for me and grandpa 
We be[G]lieve {c:(234)}   [F/]       [C/]       [G/]  
 
She'd been drinking too much [D]egg nog
And we begged her not to [G]go
But she forgot her medi-[C]cation
And she [D]wandered out the door 
Into the [G]snow 
 
[Em] When we found her Christmas [D]morning
At the scene of the a[G]ttack
There were hoofprints on her [C]forehead
And in[D]criminating claw marks 
On her [G/]back  {c:(234,1234)}
 
[G]Grandma got run over by a reindeer
Walking home from our house Christmas [C]Eve
You can say there's no such thing as [G]Santa
But [D]as for me and grandpa 
We be[G]lieve {c:(234)}   [F/]        [C/]        [G/] 

Now were all so proud of [D]grandpa
He's been taking this so [G]well
See him in there watching [C]football
Drinking [D]beer and playing cards 
With cousin [G]Mel 
 
[Em] It's not Christmas without [D]grandma
All the family's dressed in [G]black
And we just can't help but [C]wonder
Should we [D]open up her gifts 
Or send them [G/]back  {c:(234,1234)}
 
[G]Grandma got run over by a reindeer
Walking home from our house Christmas [C]Eve
You can say there's no such thing as [G]Santa
But [D]as for me and grandpa 
We be[G]lieve {c:(234)}   [F/]        [C/]        [G/] 

Now the goose is on the [D]table
And the pudding made of [G]fig
And the blue and silver [C]candles
That would [D]just have matched the hair 
In grandmas [G]wig 
 
[Em] I've warned all my friends and [D]neighbors
Better watch out for your [G]selves
They should never give a [C]license
To a [D]man who drives a sleigh 
And plays with [G/]elves {c:(234,1234)} 
 
[G]Grandma got run over by a reindeer
Walking home from our house Christmas [C]Eve
You can say there's no such thing as [G]Santa
But [D]as for me and grandpa 
We be[G/]lieve {c:(beat)}   [E7/]Sing it Grandpa

[A]Grandma got run over by a reindeer
Walking home from our house Christmas [D]eve
You can say there's no such thing as [A]Santa
But [E7]as for me and grandpa we be[A]lieve {c:(234)}
{c:Slowly}    [G/]         [D/]         [A/]















