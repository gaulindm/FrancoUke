

{title:097   PROUD MARY    }
{subtitle:(4/4  Key of D)}
{subtitle:(John Fogerty)}
{time: 2:35}
{metronome: 140}





[C]/ /     [A]/ /    [C]/ /     [A]/ /     
[C]/ /     [A]/     [G]/     [F]/ / /     [D]/  
[D]/ / / /    / / / /  
       
[D]Left a good job in the city  
Workin' for the man every night and day 
But I never lost one minute of sleepin'  
Worryin' 'bout the way things might have been   

{soc}
     [A]Big wheel keep on turnin'         
     [Bm]Proud Mary, keep on burnin'      
     [D]Rollin' (rollin'), rollin' (rollin') 
     Rollin' on the river
{eoc}
  
[D]Cleaned a lot of plates in Memphis   
Pumped a lot of pain down in New Orleans   
But I never saw the good side of the city  
Till I hitched a ride on a river boat queen 

{soc}
     [A]Big wheel keep on turnin'         
     [Bm]Proud Mary, keep on burnin'      
     [D]Rollin' (rollin'), rollin' (rollin') 
     Rollin' on the river
{eoc}

[C]/ /     [A]/ /    [C]/ /     [A]/ /     
[C]/ /     [A]/     [G]/     [F]/ / /     [D]/ 
[D]/ / / /    / / / /  

[D]If you go down to the river  
Bet you're gonna find some people who live 
You don't have to worry, 'cause you got no money  
People on the river are happy to give 

{soc}
     [A]Big wheel keep on turnin'         
     [Bm]Proud Mary, keep on burnin'      
     [D]Rollin' (rollin'), rollin' (rollin') 
     Rollin' on the river
     [D]Rollin' (rollin'), rollin' (rollin') 
     Rollin' on the river
{eoc}

[C]/ /     [A]/ /,    [C]/ /     [A]/ /     
[C]/ /     [A]/     [G]/     [F]/ / /    [D]/ 


____________________________________











