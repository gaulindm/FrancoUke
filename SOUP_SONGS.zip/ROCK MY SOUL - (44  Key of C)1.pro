{title:ROCK MY SOUL }
{subtitle:(4/4  Key of C)}   
{subtitle:(Peter, Paul & Mary)}
{metronome: 150}

{c:This song is sung as a 'Round'.}
{c:Divide the room into three Groups:  A, B and C. }

{c:First, everyone sings all three verses }
{c:Group A starts:   123, 123, 3, 3}
{c:Group B starts when A gets to ***:  123, 123, 3}
{c:Group C starts when B gets to ***:  123, 123}

{c:INTRO:}  [G7]/ / / /     [C]/ / / / 

{c:Verse 1}
[C]Rock my soul in the bosom of Abraham
[G7]Rock my soul in the bosom of Abraham
[C]Rock my soul in the bosom of Abraham
[G7]Oh, rock-a my [C]soul***

{c:Verse 2}
[C]So high I can’t get over it
[G7]So low I can’t get under it
[C]So wide I can’t get round it
[G7]Oh, rock-a my [C]soul

{c:Verse 3}
[C]Rock my soul
[G7]Rock my soul
[C]Rock my soul
[G7]Oh, rock-a my [C/]soul  [G7/] [C/]

