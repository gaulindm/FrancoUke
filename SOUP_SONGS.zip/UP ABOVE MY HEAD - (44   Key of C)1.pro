{t:UP ABOVE MY HEAD    }
{subtitle:(4/4   Key of C)}  
{subtitle:(Sister Rosetta Tharpe)}
{time: 2:50}
{metronome: 160}







{c:INTRO:}
[C]/ / / /    [G]/ / / /   
[C]/ / / /   /  

Up above my [C]head (up above my head) 
There's music in the air (there's music in the air)
Up above my head (up above my head) 
There's music in the [G]air 
Up above my [C]head  [C7]     
There's music in the [F]air 
I really do be[C]lieve  [G]     
There's a heaven some[C]where

Up in my [C]room (up in my room)
There's music in the air (there's music in the air)
Up in my room (up in my room) 
There's music in the [G]air 
Up in my [C]room [C7]     
There's music in the [F]air
I really do be[C]lieve  [G]     
There's a heaven some[C]where

{c: SOLO (talking) VAMP ON C (all strum)}
Well [C]I had a soul that was weary and worn 
Found a ukulele and now I'm reborn
Strum along and you're happy and free 
All gather round and [C/]uke [C/]with [C/]me!

{c:(Everyone)}
Everywhere I [C]go (everywhere I go) 
There's music in the air  (there's music in the air)
Everywhere I go (everywhere I go)
There's music in the [G]air 
Everywhere I [C]go  [C7]     
There's music in the [F]air
I really do be[C]lieve   [G]     
There's a heaven some[C]where

All around the [C]world (all around the world) 
There's music in the air (there's music in the air)
All around the world (all around the world) 
There's music in the [G]air 
All around the [C]world   [C7]      
Sweet music in the [F]air
I really do be[C]lieve  [G]     
There's a heaven some[C]where

Up above my [C]head (up above my head) 
There's music in the air (there's music in the air)
All around the world (all around the world)
Sweet music in the [G]air 
Everywhere I [C]go  [C7]      
There's music in the [F]air
I really do be[C]lieve,  [G]      
There's a heaven some[C]where
Yes I be[G]lieve       
There's a heaven some[C]where
I really do be[G]lieve     
There's a heaven some[C]where  [G/] [C/]
