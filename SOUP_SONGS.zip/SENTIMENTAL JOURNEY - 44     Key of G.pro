{title:SENTIMENTAL JOURNEY   }
{subtitle:  4/4     Key of G }
{subtitle:(Les Brown, Ben Homer & Bud Green)}
{time:2:50}
{metronome: 108}






{c:INTRO:} 
[G]/ / / /     [D7]/ /     [G]/ /   

[G]  Gonna take a sentimental journey 
[G]  Gonna set my [A7]heart at [D7]ease
[G]  Gonna make a [C7]sentimental journey 
[G]  To renew old [D7]memor[G]ies
 
[G]  Got my bag, I got my reservation 
[G]  Spent each dime I [A7]could af[D7]ford
[G]  Like a child in [C7]wild anticipation 
[G]  Long to hear that [D7]all a[G]board

{c:BRIDGE}
{soc}
     [C]Seven, that's the time we leave at [G]seven 
     I'll be waiting up for [A7]heaven
     Counting every mile of [D7/]railroad [Am7/]track 
     That [Ddim/]takes me [D7/]back
{eoc}

[G]  Never thought my heart could be so yearny 
[G]  Why did I de[A7]cide to [D7]roam
[G]  Gonna take a [C]sentimental journey 
[G]  Sentimental [D7]journey [G]home

{soc}
     [C]Seven, that's the time we leave at [G]seven 
     I'll be waiting up for [A7]heaven
     Counting every mile of [D7/]railroad [Am7/]track 
     That [Ddim/]takes me [D7/]back
{eoc}

[G]  Never thought my heart could be so yearny 
[G]  Why did I de[A7]cide to [D7]roam
[G]  Gonna take a [C]sentimental journey 
[G]  Sentimental [D7]journey [G]home

[G]/ / / /     [D7]/ /     [G]/


[Am7] [Ddim] 

{define: Ddim 0 1 2 1 2}
{define: D7 0 2 0 2 0}