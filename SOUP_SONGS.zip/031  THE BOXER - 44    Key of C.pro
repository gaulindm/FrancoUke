

{title:031 THE BOXER}
{subtitle: 4/4    Key of C}
{subtitle:(Paul Simon)}
{metronome:188}
{time:4:10}






[C]/ / / /   / / / /  

[C]I am just a poor boy
Though my story's seldom [Am]told
I have [G]squandered my resistance
For a [F]pocketful of mumbles such are 
[C]Promises {c:(4,1234,1)}
All lies and [Am]jest still a [G]man hears 
What he [F]wants to hear and disregards the [C]rest  
Hm hm [G]hm... {c:(234,1234)}
[F]hm [G]hm-hm [C]hm...{c:(234,1234,1234,123)}

  
When I [C]left my home and family 
I was no more than a [Am]boy 
In the [G]company of strangers, in the [F]quiet of a 
Railway station [C]running scared {c:(4,1234,12)}
Laying [Am]low seeking [G]out the poorer 
[F]Quarters where the ragged people [C]go
Looking [G]for the places [F]only [G]they would 
[C]Know {c:(234,12)}

{soc}  
 Lie la-[Am]lie    {c:(Boom)}    Lie la-[G]lie  la lie la lie
 Lie la-[Am]lie    {c:(Boom)}    Lie la-[G]lie  la lie la lie   
 La la la-la [C]lie {c:(234,1234,1234,12)}
{eoc}

  
Asking [C]only workman's wages 
I come looking for a [Am]job 
But I get no [G]offers {c:(34,123)} just a 
[F]Come-on from the whores on Seventh 
[C]Avenue {c:(4,1234,1)} I do de[Am]clare there were 
[G]Times when I was [F]so lonesome 
I took some comfort [C]there
La-la [G]la la la la la {c:(234)}  
[F]/ /    [G]/ /    {c:(}[C]{c:1234,12)}
 
Lie la-[Am]lie    {c:(Boom)}   Lie la-[G]lie  la lie la lie
Lie la-[Am]lie    {c:(Boom)}   Lie la-[G]lie la lie la lie  
La la la-la [C]lie {c:(234,1234,1234,123)}

  
Then I'm [C]laying out my winter clothes 
And wishing I was [Am]gone
Going [G]home {c:(234,123)} 
Where the [F]New York City winters aren't 
[C]Bleeding me {c:(4,1234,12)} 
Leading [G]me..  [Am]ee   {c:(234,12)} 
Going [G]home {c:(234,1234)}   
[F]/ /   [G]/ /   {c:(}[C]{c:1234,1234,1234,123)}

  
In the [C]clearing stands a boxer and a fighter 
By his [Am]trade and he [G]carries the reminders
Of [F]ev'ry glove that laid him down 
Or [C]cut him till he cried out in his anger and his 
[Am]Shame "I am [G]leaving, I am [F]leaving" 
But the fighter still re[C]mains do do [G]do {c:(234,1234)}    
[F]/ /    [G]/ /   {c:(}[C]{c:1234,12)}

Lie la-[Am]lie   {c:(Boom)}    Lie la-[G]lie  la lie la lie
Lie la-[Am]lie   {c:(Boom)}    Lie la-[G]lie  la lie la lie  
La la la-la [Am]lie  {c:(Boom)}

Lie la-[G]lie  la lie la lie,  Lie la-[Am]lie   {c:(Boom)}
Lie la-[G]lie  la lie la lie,  La la la-la [Am]lie   {c:(Boom)}
  
Lie la-[G]lie  la lie la lie,  Lie la-[Am]lie    {c:(Boom)}       
Lie la-[G]lie la lie la lie,   la la la la [C/]lie



___________________________________










