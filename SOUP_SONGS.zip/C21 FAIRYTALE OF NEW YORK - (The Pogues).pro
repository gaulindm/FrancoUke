

{title:C21: FAIRYTALE OF NEW YORK}
{subtitle:(The Pogues)}
{time: 3:10}

 


It was Christmas [C/]Eve babe
In the [F/]drunk tank
An old man [C/]said to me 
Won't see an[G]other one  
And then he [C]sang a song
The Rare Old [F]Mountain Dew 
And I turned my [C]face away
And [F]dreamed a[G]bout    [C]you  [G/]
 
Got on a [C]lucky one
Came in eight[F]een to one
I've got a [C]feeling 
This year's for [G]me and you 
So happy [C]Christmas 
I love you [F]baby
I can see a [C]better time 
When [F/]all our [G/]dreams come
 
[C]true   [C]/ / /   / / /   [G]/ / /
[C]/ / /    [F]/ / /    [G]/ / /    [C]/ {c:(stop)}
 
They've got [C]cars big as [G]bars they've got [Am]rivers of [F]gold
But the [C]wind goes right through you no place for the [G]old
When you [C]first took my [Am]hand on a [C]cold Christmas [F]Eve
You [C]promised me broadway was [G]waiting for [C]me
You were [C]handsome. You were pretty
Queen of New York [G]City
When the [C]band finished [F]playing
They [G]howled out for [C]more
[C]Sinatra was swinging all the drunks they were [G]singing
We [C]kissed on the [F]corner
Then [G]danced through the [C]night

And the [F]boys of the NY[Am]PD [G]choir
Were [C]singing 'Galway [Am]Bay'
And the [C]bells were [F]ringing out   [G]      
for Christmas day  
[C]/ / /   / / /   / / /    [G]/ / /
[C]/ / /    [F]/ / /    [G]/ / /    [C]/ {c:(stop)}
 
You're a [C]bum you're a punk, you're an old slut on [G]junk
Living [C]there almost [F]dead on a [G]drip in that [C]bed
You scum bag you maggot, you cheap lousy [G]faggot
Happy [C]Christmas your [F]arse I pray [G]God it's our [C]last 

And the [F]boys of the NY[Am]PD [G]choir
Were [C]singing 'Galway [Am]Bay'
And the [C]bells were [F]ringing out   [G] 
for Christmas day [C/] {c:(stop)}
  
{c:(slower)}[G]      I could have [C]been someone
So could [F]anyone
You took my [C]dreams from me when I first [G]found you
I kept them [C]with me babe, I put them [F]with my own
Can't make it [C]all alone
I've built my [F]dreams [G]around 
[C]you   [C]/ / /   / / /   [G]/ / /    [C]/ / /    [F]/ / /    [G]/ / /    [C]/ /
And the [F]boys of the NY[Am]PD [G]choir
Were [C]singing 'Galway [Am]Bay'
And the [C]bells were [F]ringing out [G] {c:(slower)}
And the [C]bells were [F]ringing out [G] {c:(slower)}
And the [C]bells were [F]ringing out [G] 
For Christmas day [C/]
















