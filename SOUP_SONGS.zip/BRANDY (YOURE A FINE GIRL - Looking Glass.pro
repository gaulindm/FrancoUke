{title:BRANDY (YOUR"E A FINE GIRL}
{subtitle:Looking Glass}
correction notes - chords and words on end of chorus - do do

There's a [C]Port on a [Em]Western [Am]bay
And it [Dm]serves a hundred [A#]ships a [F]day
Lonely [C]sailors pass the [Em]time [Am]away
And [Dm]talk a[F]bout their [C]homes
 
And there's a [C]girl in this [Em]harbor [Am]town
And she [Dm]works layin' [A#]whiskey [F]down
They say [C]Brandy fetch an[Em]other [Am]round
She [Dm]serves them [F]whiskey and [C]wine
 
{c:Chorus}
{soc}
The sailors say [Am]Brandy you're a [F]fine girl (you’re a fine girl)
What a [Am]good wife you would[F] be (such a fine girl)
Your [C]eyes could steal a [G]sailor from the [F]se[C]a [F](do, do, do, do-do, do, do, do, do, do-do...)
 {eoc}
 
[C]Brandy wears a [Em]braided [Am]chain
Made of [Dm]finest [F]silver from the [A#]north of [F]Spain
A [C]locket that [Em]bears the [Am]name
Of the [Dm]man that [F]Brandy [C]loves
 
He [C]came on a [Em]summer's [Am]day
Bringing [Dm]gifts from[ A#] far a[F]way
But he [C]made it clear he [Em]couldn't [Am]stay
No [Dm]harbor [F]was his [C]home
 
{c:Chorus}
 {soc}
The sailors say [Am]Brandy you're a [F]fine girl (you’re a fine girl)
What a [Am]good wife you would[F] be (such a fine girl)
Your [C]eyes could steal a [G]sailor from the [F]se[C]a [F](do, do, do, do-do, do, do, do, do, do-do
 {eoc}
 
{c:Bridge}
Yeah [Am]Brandy used to [C]watch his eyes
When he [F]told his sailor's [G]stories
She could [Am]feel the ocean [C]fall and rise
She [F]saw it's raging [G]glory
But [Am]he had always [A#]told the truth
Lord he [Am]was an honest [F] man
And [C]Brandy does her [G]best to under[F]sta[C]nd [F](do, do, do, do-do, do, do, do, do-do)
 
At [C]night when the [Em]bars close [Am]down
[Dm]Brandy [F]walks through a[A#] silent [F]town
And [C]loves a man who's[Em] not a[Am]round
She [Dm]still can [F]hear him [C]say
 

{c:Chorus}
{soc}
She hears him say [Am]Brandy you're a [F] fine girl (you’re a fine girl)
What a [Am]good wife you would [F]be (such a fine girl)
But my [C]life my lover my [G]lady is the [F]sea[C] [F] (do, do, do, do-do, do, do, do, do, do-do
 
Say [Am]Brandy you're a [F]fine girl (you’re a fine girl)
What a [Am]good wife you would [F]be (such a fine girl)
But my [C]life my lover my [G]lady is the [F]sea[C] [F](do, do, do, do-do, do, do, do, do, do-do 
{eoc}









 