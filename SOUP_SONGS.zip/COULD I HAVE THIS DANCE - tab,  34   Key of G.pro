{title: COULD I HAVE THIS DANCE}
{subtitle:tab,  3/4   Key of G}  
{subtitle:(Wayland Holyfield & Bob House)}
{metronome: 100}
{time:3:00}



[A]/ / /    [D]/ / /    
[E7]/ / /    [A]/ / /

I'll [A]always re[A7]member 
The [D]song they were [E7]playing
The [D]first time we [E7]danced and I [A]knew
As we swayed to the [A7]music 
And [D]held to each [E7]other
[D]I fell in [E7]love with [A]you {c:(23)} [E7]

{soc}{soc}
  Could [A]I have this [A7]dance 
  For the [D]rest of my life?
  Would [E7]you be my partner [D]every [E7]night?
  [A]When we're to[A7]gether it [D]feels so [Dm]right 
  Could [A]I have this dance
  For the [E7]rest of my [A]life? {c:(23)}  [E7]
{eoc}

I'll [A]always re[A7]member 
[D]That magic [E7]moment 
When [D]I held you [E7]close to [A]me
As [A]we moved to[A7]gether   
[D]I knew for[E7]ever 
[D]You're all I'll [E7]ever [A]need {c:(23)} [E7]

{soc}
  Could [A]I have this [A7]dance 
  For the [D]rest of my life?
  Would [E7]you be my partner [D]every [E7]night?
  [A]When we're to[A7]gether it [D]feels so [Dm]right 
  Could [A]I have this dance
  For the [E7]rest... of my 
  [A]Life {c:(23)}  [D]/ / /     [E7]/ / /     [A]/
{eoc}


________________________________________

















