{title:RED RIVER VALLEY  }
{subtitle:tab   4/4    Key of C  }
{c:(Fred Mendelsohn)}
{metronome:158  }
{time:3:50 }





{c:INTRO:}
{c:C / / / /    G7 / / / /    C / / / /   / /}
   
From this [C]valley they say you are going
We will miss your bright eyes and sweet [G7]smile
For they [C]say you are [C7]taking the [F]sunshine
That has [C]brightened our [G7]pathways a[C]while

{soc}
Come and [C]sit by my side, if you love me
Do not hasten to bid me a[G7]dieu
Just re[C]member the [C7]Red River [F]Valley 
And the [C]girl who has [G7]loved you so [C]true
{eoc}
 
Won’t you [C]think of this valley you’re leaving
Oh, how lonely and sad it will [G7]be
Oh [C]think of the [C7]fond heart you’re [F]breaking
And the [C]grief you are [G7]causing [C]me 

{soc}
Come and [C]sit by my side, if you love me
Do not hasten to bid me a[G7]dieu
Just re[C]member the [C7]Red River [F]Valley 
And the [C]girl who has [G7]loved you so [C]true
{eoc}

From this [C]valley they say you are going
When you go, may your true love go [G7]too
Would you [C]leave her be[C7]hind unpro[F]tected
When she [C]loves no [G7]other but [C]you 

{soc}
Come and [C]sit by my side, if you love me
Do not hasten to bid me a[G7]dieu
Just re[C]member the [C7]Red River [F]Valley 
And the [C]girl who has [G7]loved you so [C]true
{eoc}

I have [C]promised you, darling, that never 
Will a word from my lips cause you [G7]pain
And my [C]life, it will [C7]be yours for[F]ever 
If you [C]only will [G7]love me a[C]gain   

{soc}
Come and [C]sit by my side, if you love me
Do not hasten to bid me a[G7]dieu
Just re[C]member the [C7]Red River [F]Valley 
And the [C]girl who has [G7]loved you so [C]true
And the [C]girl who has [G7]loved you so [C/]true
{eoc}
