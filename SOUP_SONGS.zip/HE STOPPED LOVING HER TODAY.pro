{title:   HE STOPPED LOVING HER TODAY}
{time:  2:30}




 
He said I'll love you til I d[C]ie 
She told him you'll forget in [F]time 
As the years went slowly [G]by 
She still preyed upon his m[C]ind
 
He kept her picture on his w[C]all 
Went half crazy now and t[F]hen 
He still loved her through it a[G]ll 
Hoping she'd come back ag[C]ain
  
Kept some letters by his b[C]ed 
Dated nineteen sixty [F]two 
He had underlined in r[G]ed
Every single I love y[C]ou
  
I went to see him just tod[C]ay 
Oh but I didn't see no te[F]ars 
All dressed up to go a[G]way 
First time I'd seen him smile in ye[C]ars
 
{soc}
   He stopped loving her to[C]day
   They placed a wreath upon his d[F]oor
   And soon they'll carry him a[G]way
   He stopped loving her tod[C]ay
{eoc}
 
[C]You know she came to see him one last time
[F]Oh and we all wondered if she would 
[G]And it kept running through my mind
[C]This time he's over her for good
 
{soc}
   He stopped loving her to[C]day
   They placed a wreath upon his d[F]oor
   And soon they'll carry him a[G]way
   He stopped loving her tod[C]ay
{eoc}


