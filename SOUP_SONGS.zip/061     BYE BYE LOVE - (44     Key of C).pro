

{title:061     BYE BYE LOVE}
{subtitle:(4/4     Key of C)}
{subtitle:(Felice & Boudleaux Bryant)}
{time: 2:50}
{metronome: 168}






[C]/ /     [G7]/ /     [C]/ / / /  
[C]/ /     [G7]/ /     [C]/ / / / 

{c:CHORUS}
{soc}
[F]    Bye bye [C]love,   [F]     bye bye [C]happiness 
[F]    Hello [C]loneliness I think I'm a [G7]gonna [C]cry 
[F]    Bye bye [C]love,   [F]     bye bye [C]sweet caress 
[F]    Hello [C]emptiness I feel like [G7]I could [C]die 
Bye bye my [G7]love good[C///]bye [G7/][C/]   
{eoc}

{c:Verse 1}
There goes my [G7]baby with someone [C]new
He sure looks [G7]happy I sure am [C]blue [C7]
He was my [F]baby till she stepped [G7]in
Goodbye to romance that might have [C]been [C7]

{soc}
[F]    Bye bye [C]love,   [F]     bye bye [C]happiness 
[F]    Hello [C]loneliness I think I'm a [G7]gonna [C]cry 
[F]    Bye bye [C]love,   [F]     bye bye [C]sweet caress 
[F]    Hello [C]emptiness I feel like [G7]I could [C]die 
Bye bye my [G7]love good[C///]bye [G7/][C/]    
{eoc}

I'm through with [G7]romance
I'm through with [C]love
I'm through with [G7]counting the stars a[C]bove
And here's the [F]reason that I'm so [G7]free
My lovin' baby is through with [C]me [C7]

{soc}
[F]    Bye bye [C]love,   [F]     bye bye [C]happiness 
[F]    Hello [C]loneliness I think I'm a [G7]gonna [C]cry 
[F]    Bye bye [C]love,   [F]     bye bye [C]sweet caress 
[F]    Hello [C]emptiness I feel like [G7]I could [C]die 
  {eoc}

Bye bye my [G7]love good[C]bye
Bye bye my [G7]love good[C]bye
Bye bye my [G7]love good[C]bye {c:(34,1)} [G7/] [C/]

____________________________









