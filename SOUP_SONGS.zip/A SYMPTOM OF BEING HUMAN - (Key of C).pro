{title:A SYMPTOM OF BEING HUMAN}
{subtitle:(4/4      Key of C) }
{subtitle:(Shinedown)}
{time:4:25}
{metronome:  132}





{c:(Picking only)}
[C]/ / / /   / / / /   
[C]/ / / /   / / / /
[Am]/ / / /   / / / /
[F]/ / / /   / / / /

[C]I can still remember 
Me and Miss November [Am]Rain
Beautiful and [F]strange
[C]Always so inclined
Coloring outside the [Am]lines
Yeah, you were never on [F]time  {c:(234,12)}
You've always been

[Am]Slightly awkward, kinda weird
[F]Upside down and not all here
What's [C]wrong with me and you 
Is crystal [G]clear   [G/]      {c:(23)}

{soc} 
{c:Add BASS}
 Some[C]times I'm in a room where I don't belong
 And the [C]house is on fire and there's no alarm
 And the [Am]walls are melting too
 How about [F]you-u-u-u
 I've [C]never been the favorite, thought I'd seen it all
 'Til I [C]got my invitation to the lunatic ball
 And my [Am]friends are comin' too
 How about [F]you-o-o-ou
 Don't worry, it's [Am/]all      [G/]just a [F/]symptom 
 Of being [C]human  {c:(34,1234)}


[C]/ / / /   / / / /
[Am]/ / / /   / / / /     
[F]/ / / /   / / / /
{eoc} 

[C]Unpack all your baggage
Hide it in the attic, [Am]where
You hope it disap[F]pears
This [C]all seems so familiar
But it doesn't feel like [Am]home
It's just another unk[F]nown  {c:(234,12)}
You've always been 

[Am]Slightly awkward, kinda weird
[F]Upside down and not all here
[C]Right or wrong, it's all so 
crystal [G]clear   [G/]        {c:(23)}
 
Some[C]times I'm in a room where I don't belong
And the [C]house is on fire and there's no alarm
And the [Am]walls are melting too
How about [F]yo-o-o-ou
I've [C]never been the favorite, thought I'd seen it all
'Til I [C]got my invitation to the lunatic ball
And my [Am]friends are comin' too
How about [F]yo-o-o-ou
Don't worry, it's [Am/]all [G/]just a [F/]symptom 
Of being [C]human  
                  (We're all just passing through)
[F]    (Passengers on a ship of fools)
[C]    (We're all just passing through)   
[F]    (Passengers on a ship of fools)

{soc}
Some[C]times I'm in a room where I don't belong
{c:               (we're all just passing through)}
And the [C]house is on fire and there's no alarm
{c:                    (passengers on a ship of fools)}
And the [Am]walls are melting too 
{c:                     (we're all just passing through    }
How about [F]yo-o-o-o
                     {c:(passengers on a ship of fools)}
I've [C]never been the favorite, thought I'd seen it all
{c:           (we're all just passing through)}
'Til I [C]got my invitation to the lunatic ball
{c:           (passengers on a ship of fools)}
And my [Am]friends are comin' too
{c:                     (we're all just passing through)}
On a ship of [F]fo-o-ools
{c:                          (passengers on a ship of fools)}
Don't worry, it's [Am/]all [G/]just a [F/]symptom...{c:(two slow beats)}

of being human
{eoc}

{c:Picking only starts on "human" and slows at the end}
[C]/ / / /   / / / /    [C]/ / / /   / / / /
[Am]/ / / /    [F]/   /   /   /