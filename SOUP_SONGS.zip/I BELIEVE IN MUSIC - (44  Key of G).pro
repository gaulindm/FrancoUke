{title:I BELIEVE IN MUSIC }
{subtitle:(4/4  Key of G)}
{subtitle:(Mac Davis)}
{time: 3:20}
{metronome: 156}







{c:INTRO:} 
[G]/ / / /   / / / /    
[Am]/ / / /   / / / / 
[C]/ / / /    [D]/ / / /    
[G]/ / / /   / / / /   

[G]I could just sit around making music [Am]all day long  
As [D]long as I'm making music 
I know I can’t [C]do nobody wrong  {c:(}[G]{c:1234)}

And who knows, maybe someday I'll come 
[Am]Up with a song {c:(4,123)}
That makes [D]people want to stop their 
Fussing and fighting just [C]long enough to sing a[G]long  

{soc}
     [G]I.. I believe in [Am]music  
     [C]I..  [D]I    believe in [G]love 
{eoc}

[G]Music is love, and love is music if you 
[Am]Know what I mean 
And [D]people who believe in music are the happiest 
[C]People I've ever [G]seen 

So clap your hands and stomp your feet and 
[Am]Shake your tambourine 
[D]Lift your voices to the sky
God [C]loves you when you sing  [G]  
{c:(Everybody sing)}

{soc}
     [G]I..I believe in [Am]music   
     [C]I..  [D]I    believe in [G]love {c:(Sing it to me children)}

     [G]I..I believe in [Am]music {c:(Lord knows that) }
     [C]I..  [D]I    believe in [G]love  
{eoc}

[G]Music is the universal language, and 
[Am]Love is the key {c:(4,1234)}
To [D]brotherhood and peace and understanding, and 
[C]Living in harmo[G]ny 
 
So take your brother by the hand 
[Am]   Sing along with me
And [D]find out what it really means to feel 
[C]Young and rich and [G]free 
{c:(Everybody sing) }

{soc}
     [G]I..I believe in [Am]music  {c:(Don’t ya know it now) }
     [C]I..  [D]I    believe in [G]love {c:(Sing it to me children) }
     
     [G]I..I believe in [Am]music {c:(Let me tell ya that)} 
     [C]I..  [D]I    believe in [G]love   

     [G]I..I believe in [Am]music {c:(Oh you know that) }
     [C]I..  [D]I    believe in [G]love  {c:(Sing it all together now) }

     [G]I..I believe in [Am]music {c:(Let me hear ya now) }
     
     {c:(slower)}
     [C]I..  [D/]I…  I believe in [G/(gliss)]love
{eoc}
