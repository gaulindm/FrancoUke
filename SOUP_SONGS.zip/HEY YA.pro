{title:HEY YA}
{subtitle:}
[G] My baby don't [C]mess around
Because she loves me so
And thi[D]s I know f[Em]or sure
[G]But does sh[C]e really wanna
But cant stand to see me
Walk out[D] the d[Em]oor
[G]Dont try to figh[C]t the feeling
Cause the thought alone
Is killing[D] me righ[Em]t now
[G]I thank god for[C] mom and dad
For sticking two together
Cause we [D]dont know [Em]how
[G]Heeeey ya[C]aaaa...
[D]Hey y[Em]aaaaa...
[G]Heeeey y[C]aaaaa...
[D]Hey y[Em]aaaaa...
[G]You think you got it, O[C]h you think you got it
But got it just dont get it
[D]Till theres not[Em]hing at all
[G]We get together, [C]Oh we get together
But separates always better
[D]When theres fe[Em]elings involved
[G]If what they say is[C] Nothing is forever
Then what makes, then what makes, then what makes, then what makes, then what 
makes
[D]Love ex[Em]ception
[G]So why you why you[C] why you why you why you
Why you are so in denial
[D]When we know wer[Em]e not happy here...
[G]Heeeey ya[C]aaaa...
[D]Hey y[Em]aaaaa...
[G]Heeeey y[C]aaaaa...
[D]Hey y[Em]aaaaa...
[G]Shake it Shake shake it, [C]Shake it  shake shake it
Shake it shake shake it
[D]Shake it like a [Em]polaroid picture
[G]Heeeey ya[C]aaaa...
[D]Hey y[Em]aaaaa...
[G]Heeeey y[C]aaaaa...
[D]Hey y[Em]aaaaa..
