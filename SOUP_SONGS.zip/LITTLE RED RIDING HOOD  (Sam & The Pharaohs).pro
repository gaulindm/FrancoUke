{title:LITTLE RED RIDING HOOD }
{subtitle:tab, 4/4    Key of Am}
{subtitle: (Sam & The Pharaohs)  }
{metronome: 134}
{time: 3:30}





{c:INTRO:}
[F]/ / / /    [E7]/ / / /    [Am]/ / / /    [E7]/ / / /


[Am]Hey there, Little Red [C]Riding Hood
[D] You sure are lookin' good
[F]You're everything a [E7]big bad wolf could 
[Am]Want  {c:(234)}   [E7/]      Listen to me!
[Am]   Little Red [C]Riding Hood 
[D]   I don't think little big girls should
[F]   Go walkin' in these 
[E7]Spooky old woods a[Am]lone  {c:(234)} [E7/]Owwww!

[C]  What big eyes you have
[Am] The kind of eyes that drive wolves mad
So [D]just to see that you don't get chased
I think I  ought [G7/]       to walk [G7/] 
With you for [G7/]a       ways  [G7/]
[C]   What full lips you have
[Am] They're sure to lure someone bad
So un[D]til you get to Grandma's place
I think you ought [G7/]       to walk [G7/]  
With me and [G7/] be      safe [G7/]

[Am]    I'm gonna keep my [C]sheep suit on
[D] Till I'm sure that you've been shown
That [F]I can be trusted 
[E7]Walkin' with you a[Am]lone  {c:(234)}  [E7/]Owwww!
[Am]  Little Red [C]Riding Hood
[D] I'd like to hold you if I could
But [F]you might think I'm a [E7]big bad wolf
So I [Am]won't   {c:(234)}  [E7/]Owwwww!

[C]   What a big heart I have
[Am]  The better to love you with
[D]  Little Red Riding Hood
[G7]  Even bad wolves can be good
[C]  I'll try to keep satisfied
[Am]  Just to walk close by your side
[D]Maybe you'll see things my way
Before [G7/]     we get [G7/]     
to Grand[G7/]ma's    place  [G7/]

[Am] Little Red [C]Riding Hood 
[D]  You sure are lookin' good
[F]You're everything a [E7]big bad wolf could 
[Am]Want  {c:(234)}    [E7/]Owwww!

I mean [Am]Baaa...  [C] / / / /    
[D]Baaa...  [E7] / / / /   [Am] /


