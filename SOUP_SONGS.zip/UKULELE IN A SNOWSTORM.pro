{title:UKULELE IN A SNOWSTORM}
{subtitle:}

Doodle [D]doodle doodle doodle
Doodle doodle doodle doodle
(beat) root doo doo [A]doo doo

Doodle doodle doodle doodle
Doodle doodle doodle doodle
(beat) root doo doo [D]doo doo 

[D]Blizzard blowin round, 5 feet on the ground
But your [E7]strings transform  [A/]     cold into [A7]wa-a-arm
When the [D]weather makes me sad I oughta
[D]  Sing out that I’m glad I got a
[E7]Ukulele [A]    in a [D]snowstorm {c:(4,1234)}  ba ba-dump-a-dump-ump
Now I’m [D]singing to the shoreline and 
[D] Strummin that sunshine
‘Cause your [E7]chords transport {c:(234)}  
[A/]   Without even [A7/]needing an airport
[D]On a day that’s cloudy you can fly me right to Maui
That’s a [E7]     uku[A]lele     in a [D]snowstorm {c:(4,1234)} Ah..... 8 beats

[F#7]If I’m feelin wacky
If I’m [Bm]feeling like a kook
[E7]I just pick you up
[A/] ‘Cause there’s nothing [A7/]like a uke… to make me
[D]Feel like I’m swaying
In the breeze where I’m laying

Oh the [E7]joy it brings [A/] with just 4 [A7/]strings
When the [D]darkness makes me sad, I oughta
[D] Sing out that I’m glad, I got a
[E7] Ukulele [A]in a [D]snowstorm

[G]Palm trees are gently [D]waving 
My heart is [A]aching because I [D]love you [D7]
[G]Moonlight shining so bri[D]ghtly 
I travel [A]nightly, lonesome and [D]blue {c:(234,123)}
When the weather makes me sad I oughta
[D] Sing out that I’m glad, I got a
[E7] Uku[A]lele in a [D]snowstorm 
[E7] Yeah it’s a uku[A]lele in a sno[D]wstorm 
 
Doodle [D]doodle doodle doodle
Doodle doodle doodle doodle
(beat) root doo doo [A]doo doo

Doodle doodle doodle doodle
Doodle doodle doodle doodle
(beat) root doo doo [D/]doo doo 


{define: F#7  0 6 6 6 7}