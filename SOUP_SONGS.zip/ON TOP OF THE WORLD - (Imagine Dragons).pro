{title:ON TOP OF THE WORLD}
{subtitle:(Imagine Dragons)}
 
[C]/ / / /    [F]/ / / /   
[G]/ / / /    [Dm]/ / / /
 
 
[C]  If you love somebody
[F]  Better tell them while they're here cause
[G]  They just may run away from [Dm]you
[C]  You'll never know what went well
[F]  Then again it just depends on
[G]  How long of time is left for [Dm]you
[C]  I've had the highest mountains
[F]  I've had the deepest rivers
[G]  You can have it all but life keeps [Dm]moving  
 
 
[Am/] Now take it in but don't look [G/]down
 
{soc}
Cause I'm on top of the [F]world-ay
I'm on top of the [C]world-ay
Waiting on this for a [G]while now
Paying my dues to the [Dm]dirt
I've been waiting to [F]smile-ay
Been holding it in for a [C]while-ay
Take it with me if [G]I can
Been dreaming of this since a c[Dm]hild
I'm on top of the world  [C]
{eoc} 
 
 
[C]I've tried to cut these corners
[F]Try to take the easy way out
[G]I kept on falling short of something [Dm]
 
[C]I could'a gave up then but
[F]Then again I could’nt have cause
[G]I've traveled all this way for something [Dm]
 
Now[Am] take it[G] in but don't look down
 
{soc}
Cause I'm on top of the [F]world-ay
I'm on top of the [C]world-ay
Waiting on this for a [G]while now
Paying my dues to the [Dm]dirt
I've been waiting to [F]smile-ay
Been holding it in for a [C]while-ay
Take it with me if [G]I can
Been dreaming of this since a c[Dm]hild
I'm on top of the world  [C]
Cause I'm on top of the [F]world-ay
I'm on top of the [C]world-ay
Waiting on this for a [G]while now
Paying my dues to the [Dm]dirt
I've been waiting to [F]smile-ay
Been holding it in for a [C]while-ay
Take it with me if [G]I can
Been dreaming of this since a c[Dm]hild

{eoc} 
 

[F]And I know it's hard when you're falling down
[C]And it's a long way up when you hit the ground
[G]Get up now, get up, get up now[Dm].
 
[F]And I know it's hard when you're falling down
[C]And it's a long way up when you hit the ground
[G]Get up now, get up, get up now. [Dm]
 
 
[Chorus]
 
Cause I'm on top of the [F]world (Hey!)
I'm on top of the [C]world (Hey!)
Waiting on this for a [G]while now
Paying my dues to the [Dm]dirt
I've been waiting to [F]smile  (Hey!)
Been holding it in for a [C]while (Hey!)
Take it with me if [G]I can
Been dreaming of this since a c[Dm]hild
I'm on top of the world [C]
