{title: WHOLE WIDE WORLD}
{subtitle:(Wreckless Eric)}
{metronome:  }
{time:  }




[C]/ / / /    [F]/ / / /    
[C]/ / / /    [F]/ / / /


[C]When I was a [F]young boy
My ma[C]ma she said to m[F]e
"There's [C]only one girl in the [F]world for you
And she [C]probably lives in Ta[F]hiti"

I'd go the [C]whole wide world 
I'd go the whole wide world just to [F]find her {c:(234)}

[C]Maybe she's in the Ba[F]hamas 
Where the [C]Caribbean Sea is [F]blue
[C]Weeping in the tropical [F]moonlit night 
Because [C]nobody's talkin' bout [F]you
 
I'd go the wh[C]ole wide world 
I'd go the whole wide world just to [F]find her
I'd go the wh[C]ole wide world
I'd go the whole wide world 
To find out where they [F]hide her 
I'd go the wh[C]ole wide world 
I'd go the whole wide world just to [F]find her {c:(234,123)}


Why am I h[C]anging around in the r[F]ain out here 
[C]Trying to think of a gi[F]rl
Why are my [C]eye’s filling up with these l[F]onely tears 
When there's [C]girls all over the [F]world
Is she [C]lying on a tropical [F]beach somewhere 
[C]Underneath the tropical [F]sun? 
[C]Hiding away in the [F]heat wave there 
[C]Hoping that I won’t be lo[F]ng?
 

I should be [C]lying on a sunswept [F]beach with her 
Ca[C]ressing her warm brown [F]skin
And [C]then in a year or [F]maybe not quite
We'll be [C]sharing the same next of [F]kin

I'd go the wh[C]ole wide world 
I'd go the whole wide world just to fi[F]nd her
I'd go the wh[C]ole wide world 
I'd go the whole wide world 
To find out where they [F]hide her
I'd go the wh[C]ole wide world 
I'd go the whole wide world just to fi[F]nd her
I'd go the wh[C]ole wide world 
I'd go the whole wide world 
to find out where they [F]hide her {c(234)} [C/]Yeah!

