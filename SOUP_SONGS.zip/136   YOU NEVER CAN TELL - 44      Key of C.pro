

{title:136   YOU NEVER CAN TELL }
{subtitle:     4/4      Key of C         }
{subtitle:(aka "C'EST LA VIE")  by Chuck Berry    }
{metronome:145 }
{time:3:55}






{c:            G /    (234)                       C/  (23)}
{sot}
    A| - 7 - 7 - 6 - 5 - 3 - 2 -
    E| - - - - - - - - - - - 3 -
    C| 7 - 7 - 6 - 5 - 4 - - 2 -
{eot} 

It was a [C]teenage wedding 
And the old folks wished them well
You could see that Pierre did truly 
Love the mademoi[G]selle
And now the young Monsieur and Madame 
Have rung the chapel bell
"C'est la vie" say the old folks 
"It goes to show you never can [C]tell"  
{c:(234,123)}


They furnished [C]off an apartment 
With a two room Roebuck sale
The coolerator was crammed 
With TV dinners and ginger [G]ale
But when Pierre found work 
The little money comin' worked out well
"C'est la vie" say the old folks 
It goes to show you never can [C]tell  
{c:(234,123)}

 
They had a [C]hi-fi phono 
Boy, did they let it blast
Seven hundred little records
All rock, rhythm and [G]jazz
But when the sun went down 
The rapid tempo of the music fell 
"C'est la vie" say the old folks 
"It goes to show you never can [C]tell" 
{c:(234,123)}
 
They bought a [C]souped-up jitney 
Was a cherry red fifty-three
Drove it down to Orleans 
To celebrate their anniversa[G]ry
It was there where Pierre was wedded 
To the lovely mademoiselle
"C'est la vie" say the old folks 
"It goes to show you never can [C]tell"  
{c:(234,1234)}

{c:(kazoos, as a verse)} 
[C]/ / / /   / / / /   / / / /   / / / /

[C]/ / / /   / / / /    [G]/ / / /   / / / /
 
[G]/ / / /   / / / /   / / / /   / / / / 

[G]/ / / /   / / / /    [C]/ / / /   / / /  
  
It was a [C]teenage wedding 
And the old folks wished them well
You could see that Pierre did truly 
Love the mademoi[G]selle
And now the young Monsieur and Madame 
Have rung the chapel bell
"C'est la vie" say the old folks 
"It goes to show you never can [C]tell"  
{c:(234,123)}

"C'est la [G]vie" say the old folks 
"It [G/]goes to show you never can [C/]tell"  

______________________________










