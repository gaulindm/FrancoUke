

{title:054 WILL YOU STILL }
{title:LOVE ME TOMORROW}
{subtitle:(4/4     Key of A)}    
{subtitle:(Gerry Goffin & Carole King)}
{time:4:37}
{metronome: 130}





[F]/ / / /     [G7]/ / / /     
[C]/ / / /     [G7]/ / / / 

[C]  Tonight you're mine com[F]pletely [G7]     
[C]  You give your love so [G7]sweetly 
To[E7]night the light of [Am]love is in your eyes   
[F]  But will you [G7]love me to[C]morrow [G7] 

[C]  Is this a lasting [F]treasure [G7] 
[C]  Or just a moment's [G7]pleasure 
Can [E7]I believe the [Am]magic of your sighs 
[F]  Will you still [G7]love me to[C]morrow [C7] 

{c: BRIDGE}
{soc}
     [F]    Tonight with words un[Em]spoken
     [F]    You said that [G7]I'm the only [C]on… [C7]e 
     [F]    But will my heart be [Em]broken 
      When the [Am]night  
      Meets the [D7]morning [Dm7]su-u-u- [G7]un 
{eoc}

[C]  I'd like to know that [F]your love [G7] 
[C]  Is a love I can be [G7]sure of 
So [E7]tell me now and [Am]I won't ask again 
[F]  Will you still [G7]love me to[C]morrow  [C7]       

{soc}
     [F]    Tonight with words un[Em]spoken
     [F]    You said that [G7]I'm the only [C]on…[C7]e 
     [F]    But will my heart be [Em]broken 
      When the [Am]night  
      Meets the [D7]morning [Dm7]su-u-u- [G7]un 
{eoc}

[C]  I'd like to know that [F]your love [G7] 
[C]  Is a love I can be [G7]sure of 

So [E7]tell me now and [Am]I won't ask again 
{c:(slowly)} 
[F]    Will you still [G7]love me to[C]morrow [C7]
[F]    Will you still [G7]love me to[C]morrow [C7]
{c:(slower)} 
[F]    Will you still [G7]love me to[C]morrow [C/]

_____________________________________
{define: D7 0 2 0 2 0}











