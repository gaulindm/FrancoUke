{title:SUNSHINE MEDLEY }
{subtitle: 4/4    Key of C}
{subtitle:YOU ARE MY SUNSHINE (J. Davis, C. Mitchell)}
{subtitle:LET THE SUNSHINE IN (1:S. Hamblen)(2:G. MacDermot, J. Rado, G. Ragni)
{metronome:176}
{time: 2:40 }





[C]/ / / /    [G7]/ / / /    
[C]/ / / /   /

You are my [C]sunshine, my only [C7]sunshine
You make me [F]happy when skies are [C]grey
You’ll never [F]know dear how much I [C]love you   [Am]    
Please don’t [C]take my [G7]sunshine a[C]way

So let the [F]sunshine in, [C]face it with a grin 
[G7]Smilers never lose, and [C]frowners never win
So let the [F]sunshine in [C]face it with a grin 
[G7]Open up your heart and let the [C]sun [G7]shine [C]in     

My [C]mother told me [F]something 
That [C]everyone should know
Its [G7]all about the devil 
And I’ve [C]learned to hate him so
I know he’ll be un[F]happy 
‘Cause I’ll [C]never wear a frown
Maybe [G7]if we keep on smiling 
He'll get [C]tired of [G7]hangin' [C]round

{sob}
  So let the [F]sunshine in,        [C]face it with a grin
{c:(You are my }[F]{c:sunshine, my only }[C]{c:sunshine)}
                 [G7]Smilers never lose, and [C]frowners never 
{c:(You make me }[G7]{c:happy, when skies are }[C]{c:grey)}
 Win so let the [F]sunshine in,              [C]face it  
  {c:(You'll never }[F]{c:know Dear, how much I }[C]{c:love you)}

With a grin. [G7]Open up your heart and let the
 
[C]Sun [G7]shine [C]in {c:(slow 234, }[E7]{c:1234)}
{eob}

[Am]Le...t the [E7]sunshine, le...t the [Am]sunshine in
The [F]su-un shine [C]in  [E7]/ /
[Am]Le...t the [E7]sunshine, le...t the [Am]sunshine in 
The [F]su-un shine [C]in  [E7]
 
[Am]Le...t the [E7]sunshine, le...t the [Am]sunshine in
The [F]su-un shine [C]in  [E7]/ /
[Am]Le...t the [E7]sunshine, le...t the [Am]sunshine in 
The [F]su-un shine [C/]in
 
 
