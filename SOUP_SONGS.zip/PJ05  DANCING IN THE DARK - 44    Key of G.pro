{title: DANCING IN THE DARK }
{subtitle:   4/4    Key of G }
{subtitle:  (Bruce Springsteen)}
{metronome: 148 }
{time:3:40}







{c:INTRO:}
[G]/ / / /    [Em]/ / / /    
[G]/ / / /    [Em]/ / / /   
[G]/ / / /    [Em]/ / / /    
[G]/ / / /    [Em]/ / / /   

[G]  I get up {soh}in{eoh} the [Em]evening {c:(3,4)}
{c:(}[G]{c:123)}   And I [Em]ain’t got nothing to [G]say
I come home {soh}in{eoh} the [Em]morning  
[G]  I go to bed [Em]feeling the same [C]way
{soh}I{eoh} ain't nothing but [Am]tired   {c:(3,4)}  
{c:(}[C]{c:1,2)}  Man I'm just [Am]tired and bored with my[G]self  {c:(2,3)}
Hey there [Em]Baby    {c:(34,}[G]{c:123)}   
I could [Em]use just a little [D]help
You can't start a fire… 
You can't start a fire without a [C]spark
This gun's for [Am]hire     
[C]   Even if we're just [Am]dancing in the 
[G]Dark {c:(234)}  [Em]/ / / /    
[G]/ / / /    [Em]/ / / /

[G]  Messages keep getting [Em]clearer
[G]  Radio's on and I'm [Em]moving 'round the [G]place
I check my look in the [Em]mirror
[G]  I wanna change my [Em]clothes my hair my [C]face
Man I ain't getting [Am]nowhere 
{c:(}[C]{c:1,2)}  I'm just [Am]living in a dump like [G]this
There's something happening [Em]somewhere
{c:(}[G]{c:123)} Baby [Em]I just know that there [D]is

You can't start a fire… 
You can't start a fire without a [C]spark
This gun's for [Am]hire    
[C]  Even if we're just [Am]dancing in the 
[G]Dark {c:(234)}   [Em]/ / / /    
[G]/ / / /    [Em]/ / / /   
[G]/ / / /    [Em]/ / / /   
[G]/ / / /    [Em]/ / / /  

[Em] You sit around getting [G]older
[C] There's a joke here some[D]where and it's on [Em]me
I'll shake this world off my [G]shoulders 
[C]  Come on baby the [D]laugh's on me

[G]  Stay on the streets of [Em]this town
[G]  And they'll be [Em]carving you up all [G]right
They say you gotta stay [Em]hungry
[G]  Hey baby I'm [Em]just about starving to[C]night
I'm dying for some [Am]action {c:(3,4)}
I’m sick of sitting 'round here trying to write this 
[G]Book, I need a love re[Em]action    
[G]  Come on now, [Em]Baby give me just one [D]look

You can't start a fire…  
[Am]    Sitting 'round crying over a broken [C]heart
This gun's for [Am]hire    
[C]   Even if we're just [Am]dancing in the [D]dark
You can't start a fire…  {c:(3,4)}
Worrying about your little world falling a[C]part
This gun's for [Am]hire    
[C]  Even if we're just [Am]dancing in the 
[G]Dark {c:(234,}[Em]{c:1234)}
[G] Even if we're just [Em]dancing in the 
[G]Dark {c:(234,}[Em]{c:1234)}
[G] Even if we're just [Em]dancing in the 
[G]Dark {c:(234,}[Em]{c:1234)}  [G/]
 
