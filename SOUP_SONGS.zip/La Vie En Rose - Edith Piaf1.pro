{title: LA VIE EN ROSE}
{subtitle: Edith Piaf}
{metronome: 80}
{time: 2:15}






[G]Quand il me prend dans ses [Gmaj7]bras
Il me parle tout [G6]bas
Je vois la [Bbdim]vie       en    [Am7]ro…   [D7]se

[Am7]Il me dit des mots d'a-[D7]mour
Des mots de tous les [Am7]jours
Et [D7]ça me fait quelque [G]chos[Am7]e  [D7]

[G]Il est entré dans mon [Gmaj7]coeur
Une part de bon-[G6]heur
Dont [G7]je connais la [C]cause

[Cm6]C'est lui pour moi, moi pour [G]lui dans la vie
[A7]Il me l'a dit, l'a ju-[Am7]ré pour la [D7]vie 



[G]Et dès que je l'aper-[Gmaj7]çois
Alors je sens en [Am7]moi
Mon [D7]coeur qui [G]bat [D7]


[G]Hold me close and hold me [Gmaj7]fast
The magic spells you [G6]cast
This is la [Bbdim]vie      en   [Am7]ro...    [D7]se

[Am7]When you kiss me heaven [D7]sighs
And though I close my [Am7]eyes
I [D7]see la vie en [G]ro-[D7]se 

[G]When you press me to your [Gmaj7]heart
I'm in a world a-[G6]part
A [G7]world where roses [C]bloom

[Cm6]And when you speak angels [G]sing from above
[A7]Everyday words seem to [Am7] turn into [D7]love songs

[G]Give your heart and soul to [Gmaj7]me
And life will always [Am7]be
La [D7] vie en  [G/]rose  [Gmaj7/]


{define: Cm6 0 2 3 3 3}
{define: D7 0 2 0 2 0}
{define: Bbdim 0 0 1 0 1}
