{title: PIANO MAN}
{subtitle: 3/4    key of C}
{subtitle:(Billy Joel  1973)}

{c:Intro:}
[C]/ / /    [G]/ / /    [F]/ / /    [C]/ / / 
[F]/ / /    [C]/ / /    [D7]/ / /    [G]/ / /  
[C]/ / /    [G]/ / /    [F]/ / /     [C]/ / /  
[F]/ / /    [G]/ / /    [C]/ / /     [G]...

It's [C]nine o'[G]clock on a [F]Saturday[C]
The [F]regular [C]crowd shuffles [D7]in [G]
There's an [C]old man [G]sitting [F]next to me[C]
Making [F]love to his [G]tonic and [C]gin [G]

He says, "[C]Son, can you [G]play me a [F]memory[C]
I'm [F]not really [C]sure how it [D7]goes [G]
But it's [C]sad and it's [G]sweet 
and I [F]knew it com[C]plete
When [F]I wore a [G]younger man's [C]clothes."

[Am]la la la, di da [D7]da
[Am]La la, di di [D7]da da [G]dum [F] [C] [G7]

[C]Sing us a [G]song, you're the [F]piano man[C]
[F]Sing us a [C]song to[D7]night [G]
Well, we're [C]all in the [G]mood for a [F]melody[C]
And [F]you've got us all [G]feeling al[C]right [G]

Now [C]John at the [G]bar is a [F]friend of mine[C]
He [F]gets me my [C]drinks for [D7]free [G]
And he's [C]quick with a [G]joke 
and he'll [F]light up your [C]smoke
But there's [F]some place that [G]he'd rather [C]be [G]

He says, "[C]Bill, I be[G]lieve this is [F]killing me."[C]
As the [F]smile ran a[C]way from his [D7]face [G]
"Well I'm [C]sure that I [G]could be a [F]movie star[C]
If [F]I could get [G]out of this [C]place"

[Am]la la la, di da [D7]da
[Am]La la, di di [D7]da da [G]dum [F] [C] [G7]

Now [C]Paul is a [G]real estate [F]novelist[C]
Who [F]never had [C]time for a [D7]wife [G]
And he's [C]talking with [G]Davy
who's [F]still in the [C]Navy
And [F]probably [G]will be for [C]life [G]

And the [C]waitress is [G]practicing [F]politics[C]
As the [F]businessman [C]slowly gets [D7]stoned [G]
Yes, they're [C]sharing a [G]drink 
they call [F]loneliness[C]
But it's [F]better than [G]drinking a[C]lone [G]


[C]Sing us a [G]song, you're the [F]piano man[C]
[F]Sing us a [C]song to[D7]night [G]
Well, we're [C]all in the [G]mood for a [F]melody[C]
And [F]you've got us all [G]feeling al[C]right [G]

It's a [C]pretty good [G]crowd for a [F]Saturday[C]
And the [F]manager [C]gives me a [D7]smile [G]
'Cause he [C]knows that it's [G]me 
they've been [F]coming to [C]see
To [F]forget about [G]life for a w[C]hile [G]

And the [C]piano, it [G]sounds like a [F]carnival[C]
And the [F]microphone [C]smells like a [D7]beer [G]
And they [C]sit at the [G]bar 
and put [F]bread in my [C]jar
And say, "[F]Man, what are [G]you doing [C]here?" [G]

[Am]la la la, di da [D7]da
[Am]La la, di di [D7]da da [G]dum [F] [C] [G7]


[C]Sing us a [G]song, you're the [F]piano man[C]
[F]Sing us a [C]song to[D7]night [G]
Well, we're [C]all in the [G]mood for a [F]melody[C]
And [F]you've got us all [G]feeling al[C]right [G]
