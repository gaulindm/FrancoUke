

{title:132  OOH LA LA  }
{subtitle:   4/4    Key of G   }                
{subtitle:(Ronnie Lane, Ronnie D. Wood)}
{metronome: 156 }
{time:3:40  }


{c:The RIFF can be picked through the INTRO}
{c:CHORUS and INSTRUMENTAL}

{sot}
A| 5 5 5 7 5 - 2 - 0 - 0 - 3 3 3 2 - -
E| - - - - - - - 3 - - - - - - - - 3 - 
{eot}



[G]/ / / /    / / / /    [Am7]/ / / /     [C]/ / / / 
[G]/ / / /    / / / /    [Am7]/ / / /     [C]/ / / / 

[G]Poor old granddad
I [Am7]laughed at all his words
I [G]thought he was a bitter man
He [Am7]spoke of women's ways
They'll [G]trap you, then they use you 
And be[Am7]fore you even know
For [G]love is blind and you’re far too kind 
Don’t [Am7]ever ↑let it show {c:(234)}

{c:CHORUS}
{soc}
  I [G]wish that I knew what I know [Am7]now {c:(234)}   
  [C]When I was younger
  I [G]wish that I knew ↑what I know [Am7]now {c:(234)}  
  [C]When I was stronger
{eoc}

The [G]can-can's such a pretty show
They'll [Am7]steal your heart away
But [G]backstage, back on earth again
The [Am7]dressing ↑rooms are gray
They'll [G]come on strong and it ain't too long
Boy they [Am7]make you feel a man
But [G]love is blind and you soon will find 
You’re [Am7]just a ↑boy again

{soc}
 Ooh la [G]la   {c:(234,12)}             
  {c:       (I wish that I knew) } 
           Ooh la [Am7]la  yeah  [C]yeah  
{c:(What I know now       When I was younger}
 Ooh la [G]la   {c:(234,12)}                    
        {c:( I wish that I knew) } 
               Ooh la [Am7]la  yeah [C]yeah  {c:(234)}
{c: (↑What I know now     When I was stronger)}
{eoc}

{sot}
A| 5 5 5 7 5 - 2 - 0 - 0 - 3 3 3 2 - -
E| - - - - - - - 3 - - - - - - - - 3 - 
{eot}

[G]/ / / /    / / / /    
[Am7]/ / / /     [C]/ / / /     
[G]/ / / /    / / / /    
[Am7]/ / / /     [C]/ / /  
{eoc}
 
When you [G]want her lips, you get a cheek 
Makes you [Am7]wonder where you are
If you [G]want some more, and she's fast asleep
Leaves you [Am7]twinklin' ↑with the stars
[G]Poor young grandson
There's [Am7]nothing I can say
You'll [G]have to learn, just like me 
And [Am7]that's the ↑hardest way
Ooh la [G]la {c:(234,12)} 
Ooh la [Am7]la      yeah [C]yeah
Ooh la [G]la  {c:(234,12)}   
Ooh la [Am7]la      yeah [C]yeah

 Ooh la [G]la   {c:(234,12)}             
  {c:       (I wish that I knew) } 
           Ooh la [Am7]la  yeah  [C]yeah  
{c:(What I know now       When I was younger}
 Ooh la [G]la   {c:(234,12)}                    
       {c:( I wish that I knew) } 
             Ooh la [Am7]la  yeah [C]yeah  {c:(234)}
{c:(↑What I know now     When I was stronger)}

 Ooh la [G]la   {c:(234,12)}             
  {c:      (I wish that I knew) } 
            Ooh la [Am7]la  yeah  [C]yeah  
{c:(What I know now       When I was younger}
 Ooh la [G]la   {c:(234,12)}                    
        {c:( I wish that I knew) } 
              Ooh la [Am7]la  yeah [C]yeah            ooh la [G/]la
{c:(↑What I know now      When I was ooh la la)}
{eoc}

_________________________________











