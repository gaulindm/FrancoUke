

{title:TELL MY MA   }
{subtitle:(4/4     Key of C)}
{subtitle:(Collection)}
{time:2:27}
{metronome: 186}

{c:Count right into the song  1,2,1234…}





{soc}
     [C]Tell my ma when I go home
     The [G7]boys won't leave the [C]girls alone
     They pulled my hair, they stole my comb
     But [G7]that's alright till [C]I go home

     She is handsome, [F]she is pretty
     [C]She's the Belle of [G7]Belfast city
     [C]She's a-courtin'  [F/]one,  [F/]two   [F/]three
     [C]Please won't you [G7]tell me [C]who is she? 
     {c:(4,1234)}
{eoc}

[C]Albert Mooney says he loves her
[G7]all the boys are [C]fighting for her
Knock on her door and ring on the bell
[G7]Sayin', "Oh my true love, [C]are you well?"
Here she comes as [F]white as snow
[C]rings on her fingers and [G7]bells on her toes
[C]Old Johnny Murray he [F]says she'll die
If she [C]doesn't get the [G7]fellow with the [C]roving eye

{c:CHORUS}
{soc}
     [C]Tell my ma when I go home
     The [G7]boys won't leave the [C]girls alone
     They pulled my hair, they stole my comb
     But [G7]that's alright till [C]I go home

     She is handsome, [F]she is pretty
     [C]She's the Belle of [G7]Belfast city
     [C]She's a-courtin'  [F/]one, [F/]two [F/]three
     [C]Please won't you [G7]tell me [C]who  is she?   
     {c:(4,123)}
{eoc}

Let the [C]wind and the rain and the hail blow high 
And the [G7]snow come tumbling [C]from the sky
She's as sweet as apple pie
[G7]she'll get her own lad [C]by and by
When she gets a [F]lad of her own she 
[C]won't tell her ma 'til [G7]she comes home
[C]Let the boys come [F]as they will  
For it's [C]Albert [G7]Mooney [C]she loves still

{c:CHORUS}
{soc}
     [C]Tell my ma when I go home
     The [G7]boys won't leave the [C]girls alone
     They pulled my hair, they stole my comb
     But [G7]that's alright till [C]I go home

     She is handsome, [F]she is pretty
     [C]She's the Belle of [G7]Belfast city
     [C]She's a-courtin' -- [F/]one, [F/]two [F/]three
     [C]Please won't you [G7]tell me 
     [C/]who [C/]is [C/]she?
{eoc}

________________________________________












