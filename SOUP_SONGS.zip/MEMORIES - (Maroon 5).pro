{title:MEMORIES }
{subtitle:(Maroon 5)}
{subtitle: 4/4  Key of G}
{time:  }
{metronome:  }


[G]/ / / /    [D]/ / / /
[Em]/ / / /    [Bm]/ / / /
[C]/ / / /    [G]/ / / /
[C]/ / / /    [D7]/ / / /

[G]Here’s to the ones that we [D]got
[Em]Cheers to the wish you were 
[Bm]Here but you’re not
‘Cause the [C]drinks bring back all the [G]memories
Of [C]everything we’ve been [D]through

[G]Toast to the ones here to[D]day
[Em]Toast to the ones that we [Bm]lost on the way
‘Cause the [C]drinks bring back all the [G]memories
And the [C]memories bring back [D]memories 
Bring back [G/]you {c:(beat)}

There’s a [G]time that I remember[D]
When I [Em]did not know no pai[Bm]n
When I be[C]lieved in fo[G]rever
And every[C]thing would stay the sa[D]me
Now my [G]heart feel like December[D]
When some[Em]body say your nam[Bm]e
‘Cause I [C]can’t reach out to [G]call you
But I [C]know I will one [D]day, ay

[G] Everybody [D]hurts sometimes
[Em]Everybody hurts some [Bm]day, ay-ay
[C] But everything'll [G]be alright
[C]Go and raise a glass and [D]say, ay

[G]Here’s to the ones that we [D]got
[Em]Cheers to the wish you were 
[Bm]Here but you’re not
‘Cause the [C]drinks bring back all the [G]memories
Of [C]everything we’ve been [D]through

[G]Toast to the ones here to[D]day
[Em]Toast to the ones that we [Bm]lost on the way
‘Cause the [C]drinks bring back all the [G]memories
And the [C]memories bring back [D]memories
Bring back [G]you, doot-doo [D]doot-doo-doo 
[Em]doot do-do-do-do [Bm]doot-doo-doo 
[C]Doot do-do-do-do [G]doot doo-doo
[C]Memories bring back [D]memories, bring back [G/]you

There’s a [G]time that I remember[D]
when I [Em]never felt so lo[Bm]st
When I [C]felt all of the [G]hatred 
Was too [C]powerful to sto[D]p 
Now my [G]heart feel like an ember[D] 
And it’s [Em]lighting up the da[Bm]rk
I’ll car[C]ry these torches [G]for ya 
And you [C]know I never dro[D]p, yeah


[G] Everybody [D]hurts sometimes 
[Em]everybody hurts some[Bm]day, ayy-ayy
[C]  But everything'll [G]be alright 
[C]Go and raise a glass and [D]say, ayy


[G]Here’s to the ones that we [D]got
[Em]Cheers to the wish you were 
[Bm]Here but you’re not
‘Cause the [C]drinks bring back all the [G]memories
Of [C]everything we’ve been [D]through


[G]Toast to the ones here to[D]day  
[Em]Toast to the ones that we [Bm]lost on the way
‘Cause the [C]drinks bring back all the [G]memories
And the [C]memories bring back [D]memories
Bring back [G]you

doot-doo [D]doot-doo-doo 
[Em]Doot do-do-do-do [Bm]doot-doo-doo 
[C]Doot do-do-do-do [G]doot doo-doo [C]Memories bring back [D]memories, bring back 

[G]You, doot-doo [D]doot-doo-doo 
[Em]Doot do-do-do-do [Bm]doot-doo-doo 
[C]Doot do-do-do-do [G]doot doo-doo   
[C]Memories bring back [D]memories, bring back [G/]you

___________________________________









