{title: I'LL FOLLOW THE SUN}
{subtitle: Lennon/McCartney}
{time:2:16}





Intro: [C]/ / / /    [F]/ /    [C]/ /

[G]One day [F7]you'll look 
[C]     To see I've [D7]gone
For to[C]morrow may [Am/C]rain       so
[D7]    I'll [G7]follow the [C]sun [F] [C]

[G]Some day [F7]you'll know 
[C]    I was the [D7]one
But to[C]morrow may [Am/C]rain       so
[D7]    I'll [G7]follow the [C]   sun [C7]

And now the [Dm7] time has come
And [Fm6]so my love I must [C]go [C7]
And though I [Dm7]lose a friend
[Fm6] In the end you will [C]know [Dm]oh

[G]One day [F7]you'll find 
[C]     That I have [D7]gone
For to[C]morrow may [Am/C]rain       so
[D7]    I'll [G7]follow the [C]   sun [F] [C]

Riff with chords over: 
[G]/ / / /     [F7]/ / / /     
[C]/ / / /    [D7]/ / / /

{sot}
A|----0--325
E|--3---3---
C|-2-3------
{eot}

Yes to[C]morrow may [Am/C]rain      so
[D7]    I'll [G7]follow the [C]   sun [C7]

And now the [Dm7]time has come
And [Fm6]so my love I must [C]go [C7]
And though I [Dm7]lose a friend
[Fm6]In the end you will [C]know [Dm] oh

[G]One day [F7]you'll find 
[C]     That I have [D7]gone
For to[C]morrow may [Am/C]rain so
[D7]    I'll [G7]follow the [C]  sun [F] [C]

