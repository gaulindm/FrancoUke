{title: FIVE FOOT TWO }
{subtitle:(4/4     Key of C)}
{subtitle:(Joe Young, Ray Henderson)}
{subtitle:(& Sam M. Lewis)}
{time:2:00}
{metronome:180}



{c:KAZOO SONG!}



{c:INTRO:}  
[D7]/ / / /     [G7]/ / / /     
[C]/ / / /    / / / /


[C]Five foot two, [E7]eyes of blue 
But [A7]oh! what those five feet could do 
Has [D7]anybody [G7]seen my [C]gal?

[C]Turned up nose, [E7]turned down hose 
[A7]Flapper, yes sir, one of those
Has [D7]anybody [G7]seen my [C]gal?

{soc}
     Now if you [E7]run into a five foot two 
     [A7]covered with fur 
     [D7]Diamond rings and all those things 
     [G7/]Betcha' life it isn't her,  but...
{eoc}

[C]Could she love, [E7]could she woo? 
[A7]Could she, could she, could she coo?    
Has [D7]anybody [G7]seen my [C]gal?                

{c:KAZOO/INSTRUMENTAL (until “sing”)}
[C]Five foot two, [E7]eyes of blue 
But [A7]oh! what those five feet could do 
Has [D7]anybody [G7]seen my [C]gal?

[C]Turned up nose, [E7]turned down hose 
[A7]Flapper, yes sir, one of those
Has [D7]anybody [G7]seen my [C]gal?

{soc}
     Now if you [E7]run into a five foot two
     [A7]covered with fur 
     [D7]Diamond rings and all those things 
     [G7/]Betcha' life it isn't her,  but...
{eoc}

{c:(sing)}
  [C]Could she love, [E7]could she woo? 
  [A7]Could she, could she, could she coo?    
  Has [D7]anybody [G7]seen my
  Has [D7]anybody [G7]seen my
  Has [D7]anybody [G7]seen my 
  [C]ga-a-l? [G7/]  [C/]                                           
{define: D7 0 2 0 2 0}



