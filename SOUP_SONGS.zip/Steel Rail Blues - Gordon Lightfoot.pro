{title: STEEL RAIL BLUES}
{subtitle: Gordon Lightfoot}
 

[C]/ / / /   / / /

[C]Well I got my mail late last night
A letter from a girl who [C7]found the time to [F]write
To her lonesome boy somewheres in the [C]night
She [F]sent me a railroad ticket too
To take me to her loving [C]arms
And the big steel [Am]rail
Gonna carry me [G7]home to the one I  
[C//]love [Em//]  [Am//]  [G7]

Well I [C]been out here many a long days
I haven't found a place that [C7] I   could call my [F]own
Not a two bit bed to lay my body [C]on
I [F]been stood up I been shook down
I been dragged into the [C]sand
And the big steel [Am]rail 
Gonna carry me [G7]home to the one I 
[C//]love [Em//]  [Am//]  [G7]


[F]Ooh   [Em]ooh   [Am]ooh  woo-hoo [C]hoo 
[F//] Ooo's  [Em//]   [Am//]   [G7//]   [C]

Well I [C]been up tight most every night
Walking along the [C7]streets of this old [F]town
Not a friend around to tell my troubles [C]to
My [F]good old car she done broke down
'Cause I drove it into the [C]ground
And the big steel [Am]rail 
Gonna carry me [G7]home to the one I 
[C//]love[Em//]  [Am//]  [G7]

Well [C]look over yonder across the plain
The big drive wheels a-[C7]pounding along the [F]ground
Gonna get on board and I'll be homeward [C]bound
Now [F]I ain't had    a home cooked meal
And Lord I need one [C]now
And the big steel [Am]rail 
Gonna carry me [G7]home to the one I 
[C//]love [Em//]  [Am//]  [G7]


[F]Ooh   [Em]ooh   [Am]ooh  woo-hoo [C]hoo 
[F//] Ooo's  [Em//]   [Am//]   [G7//]   [C]

Now [C]here I am with my hat in my hand
Standing on the broad high[C7]way will you give a [F]ride
To a lonesome boy who missed the train last [C]night
I [F]went in town for one last round
And I gambled my ticket a[C]way
And the big steel [Am]rail 
Won't carry me [G7]home to the one I 
[C//]love[Em//]  [Am//]  [G7]


[F]Ooh   [Em]ooh   [Am]ooh  woo-hoo [C]hoo 
[F//] Ooo's  [Em//]   [Am//]   [G7//]   [C]

[F]Ooh   [Em]ooh   [Am]ooh  woo-hoo [C]hoo 
[F//] Ooo's  [Em//]   [Am//]   [G7//]   [C]
