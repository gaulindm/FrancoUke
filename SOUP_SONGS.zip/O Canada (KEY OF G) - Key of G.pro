{title:OH CANADA (KEY OF G)}
{subtitle: 4/4      Key of G}
{time: 2:00  }
{metronome: 190  }

[G]/ / / /    [Gaug]/ / / /    [C]/ / / /    [Am]/ / / /    
[G]/ / / /   [D7]/ / / /    [G]/ / / /   / / / /

[G]Oh   [D]Cana-[Em]da, our [G]home and native [D]land 
[G]True [A7]patriot [D]love
In all of [A7]us com-[D]mand

With [D7]glowing hearts, we [G]see thee rise
Our [C]true north [Am]strong and [D]free
From [D7]far and wide, Oh [G]Canada
We [D]stand on [A7]guard for [D7]thee

[G]God [D]keep our [Em]land    [Am]Glorious and [D]free 
[G]Oh   [Gaug]Cana -  [C]da,  we [Am]stand  on  [G]guard  [D]for   [G]thee 
Oh [Gaug]Cana - [C]da, we  [Am]stand  on [G]guard  [D7]for  [G/]thee

{define: Gaug  0 0 3 3 2}
______________________________________
















