{title: Can You Feel The Love Tonight  }
{subtitle: Elton John}
{metronome: 140}
{time: 3:45}








{c:INTRO}
{c:F  / / / /     C  / / / /    }
{c:Am  / / / /   F  / / / /   }
{c:Dm7  / / / /     Am  / / / /  }
{c:G / / / /    / / / /}

[F]There's a calm sur[C]render 
[F]To the rush of [C]day
[F]When the heat of the [C]rolling world 
[Dm7]Can be turned a[G]way
 
[F]An enchanted [C]moment 
[F]And it sees me [C]through
[F]  It's enough for this [C]restless warrior 
[Dm7]Just to be with [G]you  {c:(234,123)}

{c:CHORUS}
{soc}
And [C]can you fe[G]el the lo[Am]ve   tonight[F]
[C]   It is whe[F]re we are[G]  {c:(234,1234)}
[F]   It's enou…[C]gh  for this 
[Am7]Wide-eyed [F]wanderer
[Dm7]That  [Am7]we've  [G]got 
this far {c:(234)} [G7]  {c:(23)}

And [C]can you [G]feel the lo[Am]ve   tonight[F]
[C]   How it's la[F]id to rest[G]  {c:(234,1234)}
[F]   It's enou…[C]gh to make 
[Am7]Kings and [F]vagabonds
Be[Dm7]lieve  [Am]the  [G]very be[C]st    
{eoc}

[F]There's a time for [C]everyone 
[F]If they only [C]learn
[F]That the twisting ka[C]leidoscope 
[Dm7]Moves us all in [G]turn

[F]There's a rhyme and [C]reason 
[F]To the wild out[C]doors
[F]When the heart of the [C]star-crossed voyager 
[Dm7]beats in time with [G]yours  {c:(234,123)}


{soc}
And [C]can you fe[G]el the lo[Am]ve   tonight[F]
[C]   It is whe[F]re we are[G]  {c:(234,1234)}
[F]   It's e...nough[C]   for this 
[Am7]wide-eyed [F]wanderer
[Dm7]That  [Am7]we've [G]got 
this far {c:(234)}  [G7]   {c:(123)}

And [C]can you [G]feel the lo[Am]ve   tonight[F]
[C]   How it's la[F]id to rest[G]  [(234,1234)]
[F]   It's enou…[C]gh to make 
[Am7]kings and [F]vagabonds
Be[Dm7]lieve  [Am]the  [G]very best[C] {c:(234,1234)}
{eoc}

[F]  It's enou…[C]gh    to make 
[Am7]kings and [F]vagabonds
Be[Dm7]lieve  [Am]the  [G]very  [C/]best