

{title:MRS. ROBINSON }
{subtitle:(4/4    Key of D)} 
{subtitle:(Paul Simon & Art Garfunkel)}
{time: 3:45}
{metronome:192}



Lynda


[E7]  / / / /   / / / /   
       / / / /   / / / /

[E7]Dee, de-de-de dee dee de de 
De de, de-de dee.. {c:(234,1234)}

[A7]Doo, do-do-do doo doo, do-do 
doo…{c:(234,1234)}

[D]   De-de-de-de [G]dee dee, dee dee 
[C]Dee dee de-de [Am]dee… {c:(234,1234)}

[E7]/ / / /   / / / /    
[D7]/ / / /   / {c:(stop)}

{c:CHORUS}
{soc}
     And here's to [G]you Mrs. [Em]Robinson
     [G]Jesus loves you [Em]more than you will 
     [C]Know  [Am]       wo wo [D]wo   [D7]
     God bless you [G]please Mrs. [Em]Robinson
     [G]Heaven holds a [Em]place for those who [C]pray
     Hey hey [Am]hey...hey hey [E7]hey 
     
     {c:(234,1234,1234,123)}
{eoc}
                                               
We'd [E7]like to know a little bit 
About you for our files {c:(234,123)}
We'd [A7]like to help you learn to help yourself
[D] Look around you, [G]all you see are 
[C]Sympathetic [Am]eyes {c:(234,1234)}
[E7] Stro…oll around the grounds un[D7]til 
You feel at [D7/]home

{soc}
     And here's to [G]you Mrs. [Em]Robinson
     [G]Jesus loves you [Em]more than you will 
     [C]Know  [Am]       wo wo [D]wo   [D7]
     God bless you [G]please Mrs. [Em]Robinson
     [G]Heaven holds a [Em]place for those who 
     [C]Pray…Hey hey [Am]hey...hey hey [E7]hey 
     
    {c:(234,1234,1234,123)}
{eoc}
                                        
[E7] Hide it in a hiding place where 
No one ever goes {c:(234,1234)}
[A7] Put it in your pantry with your cupcakes
[D] It’s a little [G]secret just the 
[C]Robinson's a[Am]ffair {c:(234,1234)}
[E7] Mo…ost of all, you've got to 
[D7]hide it from the [D7/]kids

{soc}
     Coo coo ca [G]choo Mrs. [Em]Robinson
     [G]Jesus loves you [Em]more than you will 
     [C]Know  [Am]       wo wo [D]wo   [D7]
     God bless you [G]please Mrs. [Em]Robinson
     [G]Heaven holds a [Em]place for those who 
     [C]Pray…Hey hey [Am]hey...hey hey [E7]hey 

     {c:(234,1234,1234,123)}
{eoc}
                               
[E7] Sitting on a sofa on a 
Sunday afternoon {c:(234,1234)}
[A7] Going to the candidates debate
[D] Laugh about it, [G]shout about it 
[C]When you've got to [Am]choose {c:(234,1234)}
[E7] Ev'ry way you look at it, you [D7]lose  [D7/]

Where have you [G]gone Joe Di [Em]Maggio?
A [G]nation turns its [Em]lonely eyes to 
[C]You    [Am]      woo woo [D]woo   [D7]
What’s that you [G]say Mrs [Em]Robinson?
[G]Joltin’ Joe has [Em]left and gone a[C]way
Hey hey [Am]hey...hey hey [E7]hey {c:(234,1234)}

{c:E7   / / / /   / / / /    A  /  }    
         
____________________________________







{define: D7 0 2 0 2 0}



