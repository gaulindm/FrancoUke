{title:PUT A LITTLE LOVE}
{title:IN YOUR HEART }
{subtitle:(4/4      Key of C)}
{subtitle:(Jackie DeShannon)}
{time: 2:45}
{metronome:110}

{c:Count right into the song “1,2,1234”}







[C]Think of your fellow man 
Lend him a helping hand
[F]  Put a little love in your [C]heart 
You see it's getting late 
[C]Oh please don't hesitate
[F]  Put a little love in your [C]heart 
And the world will be a [G]better place
And the [C]world will be a [G]better place
For you…  and me…
You just wait… and see… 

[C]Another day goes by 
[C]  And still the children cry
[F]  Put a little love in your [C]heart 
If you want the world to know 
[C]  We won't let hatred grow 
[F]  Put a little love in your [C]heart
And the world (and the world) 
Will be a [G]better place
And the [C]world (and the world) 
Will be a [G]better place
For you (for you) and me (and me)
You just wait (you just wait) and see… 

[C]Take a good look around 
[C]  And if you looking down
[F]  Put a little love in your [C]heart
[C]I hope when you decide 
[C]  Kindness will be your guide 
[F] Put a little love in your [C]heart
And the world (and the world) 
Will be a [G]better place
And the [C]world (and the world) 
Will be a [G]better place
For you (for you) and me (and me)
You just wait (you just wait) and see...
(People now)

[F]Put a little love in your [C]heart  
(each and every day)
[F]Put a little love in your [C]heart  
(the ukulele way)
[F]Put a little love in your [C]heart  
(that’s what we say)
[F]Put a little love in your [C]heart  
(come on now)
[F]Put a little love in your [C(gliss)]heart

