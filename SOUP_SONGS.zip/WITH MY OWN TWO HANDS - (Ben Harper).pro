{title:WITH MY OWN TWO HANDS}
{subtitle:    (Ben Harper)}
{subtitle:  4/4      Key of G}
{metronome:150 }
{time: 4:00 }






{c:INTRO:}
{c: Em / / / /    D  / / / / }
{c: G  / / / /   / /}

I can [G]change the world
With my own [C]two [G]hands
Make it a [G]better place
With my own [C]two [G]hands
Make it a [G]kinder place 
With my own [C]two [G]hands
With my [Em]own, with my [D]own 
Two [G]hands {c:(2,3)} [C/]  [G/]

I can make [G]peace on earth
With my own [C]two [G]hands
I can clean [G]up the earth 
With my own [C]two [G]hands
I can reach [G]out to you
With my own [C]two [G]hands
With my [Em]own, with my [D]own 
Two [G]hands {c:(2,3)} [C/] [G/]
With my [Em]own, with my [D]own 
Two [G]hands {c:(2,3)} [C/] [G/]

I'm gonna make it a [G]brighter place 
With my own [C]two [G]hands
I'm gonna make it a [G]safer place 
With my own [C]two [G]hands
I'm gonna help the [G]human race 
With my own [C]two [G]hands
With my [Em]own, with my [D]own 
Two [G]hands {c:(2,3)} [C/] [G/]
With my [Em]own, with my [D]own 
Two [G]hands {c:(2,3)} [C/] [G/]

I can [G]hold you, in my own [C]two [G]hands
I can [G]comfort you, with my own [C]two [G]hands
But you got to [G]u… u-use
Use your own [C]two [G]hands
Use your [Em]own, use your [D]own 
Two [G]hands {c:(2,3)} [C/] [G/]
Use your [Em]own, use your [D]own 
Two [G]hands {c:(2,3)} [C/] [G/]

With our [Em]own, with our [
[D]Own two [G]hands {c:(2,3)} [C/] [G/]
With our [Em]own, with our 
[D]Own two [G]hands {c:(2,3)} [C/] [G/]
With my [Em]own with my 
[D]Own two [G/]hands
            