{title:  HO, HEY    }
{subtitle:tab    4/4      Key of C}
{subtitle:The Lumineers  }
{subtitle:(Wesley Schultz & Jeremy Fraites) }
{metronome:142 }
{time:2:48}


{c:Verse 1: Women do "ho/hey" and men sing melody}
{c:Verse 2: Men do "ho/hey" and women sing melody }
{c:Verse 3: Choose melody or ho/heys (not both) }

{c:Verse 1: Count-in: "1234,123..."}




[F/]      ([C/]Ho)     {c:(}[C]{c:d-du-ud)}         
[F/]      ([C/]Hey)    {c:(}[C]{c:d-du-ud)}
[F/]      ([C/]Ho)     {c:(}[C]{c:d-du-ud)}         
[F/]      ([C/]Hey)    {c:(}[C]{c:d-du-ud)}
[F/]      ([C/]Ho)      I've been [C]trying to do it right [F/]      ([C/]Hey)    I've been [C]living a lonely li-i- [F/]ife      ([C/]Ho)      I've been [C]sleeping here instead [F/]      ([C/]Hey)    I've been [C]sleeping in my be-e- [F/]ed      ([Am/]Ho)      [Am]Sleeping [G]in my be-e-
[F/]ed      ([C/]Hey)    {c:(}[C]{c:d-du-ud)} 
[F/]      ([C/]Ho)      {c:(}[C]{c:d-du-ud)}

{c:(Verse 2: SWITCH to Men singing Ho/Hey)}
[F/]      ([C/]Ho)      So [C]show me family     
[F/]      ([C/]Hey)     All the [C]blood that I will bleed [F/]      ([C/]Ho)       I don't [C]know where I belong [F/]      ([C/]Hey)     I don't [C]know where I went wro-o-
[F/]ong    ([Am/]Ho)       but [Am]I    can [G]write a so-o-
[F/]ong    ([C/]Hey)     {c:(beat)}   [C/]      {c:(beat)}   [C/]      {c:(beat)}

{c:CHORUS:}
{soc}
     I belong with [Am]you, you belong with [G]me
     You're my sweet   [C]    heart      I belong with [Am]you, you belong with [G]me, you're my 
     [F/]sweet    ([C/]Ho)      {c:(}[C]{c:d-du-ud)}            
     [F/]         ([C/]Hey)     {c:(}[C]{c:d-du-ud)}
     [F/]          ([C/]Ho)      {c:(}[C]{c:d-du-ud)}           
     [F/]          ([C/]Hey)     {c:(}[C]{c:d-du-ud)}
{eoc}

{c:Verse 3}
[F/]     ([C/]Ho)       I don't [C]think you're right for him [F/]     ([C/]Hey)     Think of [C]what it might have been if 
[F/]you   ([C/]Ho)       Took a [C]bus to China Town [F/]     ([C/]Hey)      I'd be [C]standing on Cana-a-
[F/]al      ([Am/]Ho)        [Am]         And [G]Bowery-y- 
[F/]y       ([C/]Hey)      {c:(}[C]{c:d-du-ud)}       
[F/]     ([Am/]Ho)        And she'd be [Am]standing [G]next to me-
[F/]e       ([C/]Hey)      {c:(beat)}   [C/]      {c:(beat)}   [C/]      {c:(beat)}

{c:CHORUS}
{soc}
     I belong with [Am]you, you belong with [G]me 
     You're my sweet  [C]    heart      I belong with [Am]you, you belong with [G]me 
     You're my sweet  [C]    heart {c:(4,123)}

     And [Am]lo...ove, we [G]need it now  {c:(}[C]{c:123)}      Let's [Am]ho...ope  for so[G]me  {c:(234,123)}      Cause [Am]oh... we're [G]bleeding out [C]

     I belong with [Am]you, you belong with [G]me
     You're my sweet   [C]    heart      I belong with [Am]you, you belong with [G]me, you're my 
     [F/]Sweet     ([C/]Ho)     {c:(}[C]{c:d-du-ud)}           
     [F/]        ([C/]Hey)     {c:(}[C]{c:d-du-ud)}      
     [F/]               ([C/]Ho)     {c:(}[C]{c:d-du-ud)}           
     [F/]        ([C/]He...y!) 
{eob}
