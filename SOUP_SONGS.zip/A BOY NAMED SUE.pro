{title:A BOY NAMED SUE    4/4    Key of G}
{time:4:00}









Well my [G]daddy left home when I was three
And he [C]didn't leave much to ma and me
Just [D]this old guitar and an empty bottle of [G]booze
Now [G]I don't blame him cause he run and hid 
But the [C]meanest thing that he ever did
Was be[D]fore he left, he went and named me [G]'Sue'

Well he [G]must've thought that was quite a joke 
And it [C]got a lot of laughs from lots of folks
It [D]seems I had to fight my whole life [G]through
Some [G]gal would giggle and I'd get red 
And [C]some guy'd laugh and I'd bust his head
I [D]tell ya, life ain't easy for a boy named [G]'Sue'

Well I [G]grew up quick and I grew up mean
My [C]fists got hard and my wits got keen
I'd [D]roam from town to town to hide my [G]shame
But I [G]made me a vow to the moon and stars 
I'd [C]search the honky-tonks and bars
And [D]kill that man that gimme that awful [G]name

Well it was [G]Gatlinburg in mid-July 
And I'd [C]just hit town and my throat was dry
I [D]thought I'd stop and have myself a [G]brew
At an [G]old saloon on a street of mud 
[C]There at a table, dealing stud
Sat the [D]dirty, mangy dog that named me [G]'Sue'

Well, I [G]knew that snake was my own sweet dad 
From a [C]worn-out picture that my mother'd had
And I [D]knew that scar on his cheek and his evil [G]eye
He was [G]big and bent and gray and old 
And I [C]looked at him and my blood ran cold
And I [D]said "My name is 'Sue!' 
[G]How do you do?  Now you gonna die!"

Well I [G]hit him hard right between the eyes 
And [C]he went down, but to my surprise
He come [D]up with a knife and cut off a piece of my [G]ear
But I [G]busted a chair right across his teeth 
And we [C]crashed through the wall and into the street
[D]Kicking and a-gouging in the mud 
And the blood and the [G]beer

I [G]tell ya, I've fought tougher men 
But I [C]really can't remember when
He [D]kicked like a mule and he bit like a croco[G]dile
I [G]heard him laugh and then I heard him cuss 
He [C]went for his gun and I pulled mine first
He [D]stood there lookin' at me and I saw him [G]smile

And [G]he said "Son, this world is rough 
And if a [C]man's gonna make it he's gotta be tough
And I [D]knew I wouldn't be there to help you a[G]long
So I [G]give ya that name and I said goodbye 
I [C]knew you'd have to get tough or die
And [D]it's the name that 
Helped to make you [G]strong" Yeah!

He said "Now [G]you just fought one hell of a fight 
And I [C]know you hate me, and you got the right
To [D]kill me now, and I wouldn't blame you if you [G]do
But you [G]ought to thank me before I die 
For the [C]gravel in yer guts and the spit in yer eye
Cause [D]I'm the son-of-a-beep that named you [G]'Sue'"

I got [G]all choked up and I threw down my gun 
And I [C]called him my pa, and he called me his son,
And [D]I come away with a different point of [G]view
And I [G]think about him, now and then
Every [C]time I try and every time I [C/]win

And if I ever have a son
I think I'm gonna name him…
Bill or George, anything but Sue
I still hate that name! [G/]
