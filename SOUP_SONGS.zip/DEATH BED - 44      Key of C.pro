{title:DEATH BED }
{subtitle:  4/4      Key of C}
{subtitle: (Powfu)}
{time: }
{metronome: }







[C]/ / / /   / / / /

[C]Don't stay awake for too long, [Em]don't go to bed
I'll make a cup of [F]coffee for your head
It'll get you up and [Fm]going out of bed

[C]Don't stay awake for too long, [Em]don't go to bed
I'll make a cup of [F]coffee for your head
It'll get you up and [Fm]going out of bed

{c:(1)} 
Yeah, I don't [C]wanna fall asleep, I don't wanna pass away
I been [Em]thinking of our future 'cause I'll never see those days
I don't [F]know why this has happened, but I probably deserve it
I [Fm]tried to do my best, but you know that I'm not perfect

I been [C]praying for forgiveness, you've been praying for my health
[Em]When I leave this earth, hopin' you'll find someone else
'Cause [F]yeah, we still young, there's so much we haven't done
Getting [Fm]married, start a family, watch your husband with his son

I [C]wish it could be me, but I won't make it out this bed
I [Em]hope I Go to heaven so I see you once again
My [F]life was kinda short, but I got so many blessings
[Fm]Happy you were mine, it [Fm/]sucks that it's all ending

{c:(both)} 
[C]Don't stay awake for too long, [Em]don't go to bed
I'll make a cup of [F]coffee for your head
It'll get you up and [Fm]going out of bed (Yeah, ayy)

[C]Don't stay awake for too long, [Em]don't go to bed
I'll make a cup of [F]coffee for your head
It'll Get you up and [Fm]going out of bed (Ayy, yeah)

{c:(4)}
I'm [C]happy that you're here with me, I'm sorry if I tear up
When [Em]me and you were younger, you would always make me cheer up
[F]Taking goofy videos and walking through the park
You would [Fm]jump into my arms every time you heard a bark

[C]Cuddle in your sheets, sang me sound asleep
I [Em]sneak out throuGh your kitchen at exactly 1:03
[F]Sundays went to church, on Mondays watched a movie
[Fm]Soon you'll be alone, sorry t[Fm/]hat you have to lose me
 

[C]Don't stay awake for too long, [Em]don't go to bed
I'll make a cup of [F]coffee for your head
It'll get you up and [Fm]going out of bed

[C]Don't stay awake for too long, [Em]don't go to bed
I'll make a cup of [F]coffee for your head
It'll get you up and [Fm]going out of bed

[C]Don't stay awake for too long, [Em]don't go to bed
I'll make a cup of [F]coffee for your head
It'll get you up and [Fm]going out of bed  [Fm/]
