{title:I CAN'T HELP FALLING }
{title:IN LOVE WITH YOU}
{subtitle:(tab    6/8   Key of C)}   
{subtitle:(Peretti, Creatore & Weiss)}
{time: 3:30}
{metronome: 130}

{c:Suggested picking pattern:}  
{c:Pluck A and G strings together}
{c:then E string, then C string} 

{c:(Count in using 3/4 time   “123,223…”)}

{c:INTRO: }
[F]/ / /   [G]/ / /     [Am]/ / /     [Dm]/ / /     
[C]/ / /    [G]/ / /     [C]/ / /   / / /   

[C]Wise [G]men [Am]say 
Only [F]fools [C]rush  [G]in  [G7]
But  [F]I   [G]can't  [Am]help  [Dm]falling in 
[C]Love  [G]with  [C]you
[C]Shall  [G]I    [Am]stay  
Would it [F]be  [C]a   [G]sin
If  [F]I   [G]can't [Am]help [Dm]falling in 
[C]Love [G]with [C]you 

{c:CHORUS }
{soc}
   [Em]Like a river [Am]flows 
   [Em]surely to the [Am]sea
   [Em]Darling so it [Am]goes
   [Em]Some things are [A7]meant to [Dm]be  [G]
   [C]Take [G]my  [Am]hand
   Take my [F]whole [C]life [G]too
   For  [F]I  [G]can't [Am]help [Dm]falling in 
   [C]Love [G]with [C]you 

   [Em]Like a river [Am]flows 
   [Em]surely to the [Am]sea
   [Em]Darling so it [Am]goes
   [Em]Some things are [A7]meant to [Dm]be [G]
   [C]Take [G]my  [Am]hand 
   Take my [F]whole [C]life [G]too
   For  [F]I  [G]can't [Am]help [Dm]falling in  
   [C]Love [G]with [C]you 
{eoc}

For  [F]I  [G]can't [Am]help [Dm]falling in 
[C]Love [G]with [C]you [C/gliss]


