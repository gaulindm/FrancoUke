{title:CATS IN THE CRADLE (In Development)}
{subtitle:tab      4/4      Key of D}
{subtitle:(Harry Chapin, Sandra Chapin)}
{metronome: 144}
{time: 5:00}







[D]/ / / /  [D6] / /   [D] / /  [Cadd9]  [C]   [D]

My [D]child arrived just the [F]other day
He [G]came to the world in the [D]usual way
But there were planes to catch and [F]bills to pay
[G]  He learned to walk while I [D]was away
And he was [C]talkin' 'fore I knew it, and [Am]as he grew
He'd say [F]“I’m gonna [Am]be like [D]you dad
You [F]know I'm gonna [Am](or C)be like [D]you"

And the [D]cat's in the cradle and the [C]silver spoon
[F]Little boy blue and the [G]man on the moon
[D]When you comin' home dad?
I [C]don't know when, but [F]we'll get to[Am](orC)gether [D]then son
You [F]know we'll have a [Am]good time [D]then

My [D]son turned ten just the [F]other day
He said, "[G]Thanks for the ball, Dad, come [D]on let's play
Can you teach me to throw", I said "[F]Not today
I [G]got a lot to do", he said, "[D]That's ok"
And he [C]  he walked a[G]way but his [Am]smile never [G]dimmed
And said, "I'm [F]gonna [Am]be like him, [D]yeah
You [F]know I'm gonna [Am]be like [D]him"

And the [D]cat's in the cradle and the [C]silver spoon
[F]Little boy blue and the [G]man on the moon
[D]When you comin' home dad?
I [C]don't know when, but [F]we'll get to[Am]gether [D]then son
You [F]know we'll have a [Am]good time [D]then

Well, he [D]came home from college just the [F]other day
So [G]much like a man I just [D]had to say
"Son, I'm proud of you, can you [F]sit for a while?"
[G] He shook his head and he [D]said with a smile
"What I'd [C]really like, [G]Dad, is to [Am]borrow the car [G]keys
[F]See you later, can I [D]have them please?"

And the [D]cat's in the cradle and the [C]silver spoon
[F]Little boy blue and the [G]man on the moon
[D]When you comin' home son?
I [C]don't know when, but [F]we'll get to[Am]gether [D]then 
You [F]know we'll have a [Am]good time [D]then

[C]   [D]   [Bm]   [E]  2x

I've [D]long since retired, my [F]son's moved away
I [G]called him up just the [D]other day
I said, "I'd like to see you if [F]you don't mind"
He said, "I'd [G]love to, Dad, if I can [D]find the time
You see my [C]new job's a [G]hassle and [Am]kids have the [G]flu
But it's [F]sure nice [Am]talking to [D]you, Dad
It's been [F]sure nice [Am]talking to [D]you"

And [C]as I hung up the [G]phone it oc[Am]curred to [G]me
He'd [F]grown up [Am]just like [D]me
My [F]boy was [Am]just like [D]me

And the [D]cat's in the cradle and the [C]silver spoon
[F]Little boy blue and the [G]man on the moon
[D]When you comin' home son?
I [C]don't know when, but [F]we'll get to[Am]gether [D]then 
You [F]know we'll have a [Am]good time [D]then

{define: Cadd9 0 0 2 0 3}

