{title:9 to 5}
{subtitle:}

[D]Tumble out of bed and I stumble to the kitchen
[G]Pour myself a cup of ambition
[D]And yawn and stretch and try to come to [A7] life.
[D]Jump in the shower and the blood starts pumping
[G]Out on the street the traffic starts jumping
With [D] folks like me on the [A] job from 9 to [D] 5

[NC] Working [G] 9 to 5, what a way to make a living
Barely [D]getting by, it's all taking and no giving
They just [G] use your mind and they never give you credit
It's [E] enough to drive you [A] crazy if you let it
[G] 9 to 5, for service and devotion
You would [D] think that I would deserve a fair promotion
Want to [G] move ahead but the boss won't seem to let me
I [E] swear sometimes, that man is [A] out to get me

They [D] let you dream just to watch them shatter
You're [G] just a step on the boss man's ladder
But [D] you've got dreams he'll never take [A7] away
You're [D] in the same boat with a lot of your friends
[G] Waiting for the day your ship'll come in
The [D] tides gonna turn and it's [A] all gonna roll your way [D]

[NC] Working [G] 9 to 5, what a way to make a living
Barely [D] getting by, it's all taking and no giving
They just [G] use your mind and you never get the credit
It's [E] enough to drive you [A] crazy if you let it
Working [G] 9 to 5, yeah they've got you where they want you
There's a [D] better life, and you think about it don't you
It's a [G] rich man's game, no matter what they call it
And you [E] spend your life putting [A] money in his pocket [D]

[G] 9 to 5, what a way to make a living
Barely [D] getting by, it's all taking and no giving
They just [G] use your mind and then they never give you credit
It's [E] enough to drive you [A] crazy if you let it
[G] 9 to 5, yeah they've got you where they want you
There's a [D] better life, and you dream about it don't you
It's a [G] rich man's game, no matter what they call it
And you [E] spend your life putting [A] money in his pocket [D]