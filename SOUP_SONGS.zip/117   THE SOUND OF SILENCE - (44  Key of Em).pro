

{title:117   THE SOUND OF SILENCE }
{subtitle:(4/4  Key of Em)}                   
{subtitle: (Paul Simon) }
{metronome: 96}
{time:4:09}


{c:INTRO: Picking ONLY for the Intro/Outro}

[Esus2alt]
{sot}
A - 2 - 2 - 2 - 2 - 2 - 
E - - 2 - - - 2 - - - -
C 4 - - - 4 - - - 4 - -   
G - - - - - - - - - - - 
{eot}
Hello darkness my old [D]friend
I've come to talk with you a[Em]gain
Because a vision softly-[C]y creep[G]ing
Left its seeds while I wa-[C]as sleep[G]ing
And the [C]vision that was planted in my [G]brain
Still re- [Em]mains {c:(234,1)}  
Within the [D]sound of [Em]silence   [Em/]     

In restless dreams I walked a[D]lone
Narrow streets of cobble[Em]stone
Neath the halo of a-[C]a street [G]lamp
I turned my collar to the [C]cold and [G]damp
When my [C]eyes were stabbed by the 
Flash of a neon [G]light
That split the [Em]night {c:(234,1)}  
And touched the [D]sound of [Em]silence   [Em/]

And in the naked light I [D]saw
Ten thousand people maybe [Em]more
People talking withou- [C]out speak[G]ing
People hearing withou- [C]out listen[G]ing
People writing [C]songs that voices never [G]share
And no one [Em]dare {c:(234,1)}  
Disturb the [D]sound of [Em]silence   [Em/]

Fools said I, you do not [D]know
Silence like a cancer [Em]grows
Hear my words that I mi-[C]ight teach [G]you
Take my arms that I mi-[C]ight reach [G]you
But my [C]words like silent raindrops [G]fell {c:(234,1234)}
And [Em]echoed,  in the [D]wells of [Em]silence    [Em/]

And the people bowed and [D]prayed
To the neon god they [Em]made
And the sign flashed out i-it[C]s warn[G]ing
In the words that it wa-[C]as form[G]ing
And the sign said the [C]words of the prophets
Are written on the subway [G]walls 
And tenement [Em]halls {c:(234)}
And [G]whisper'd in the [D/]sounds 
of [Esus2alt]silence {c:(tabs, slowing…234,12)

{c:(start picking on “silence”)} 

{sot}
A - 2 - 2 - 2 - 2 - 2 - 2 -
E - - 2 - - - 2 - - - 2 - -
C 4 - - - 4 - - - 4 - - - - 
G - - - - - - - - - - - - - 
{eot}

[Em/]
____________________________________
{define: Esus2alt 0 0 4 2 2}








