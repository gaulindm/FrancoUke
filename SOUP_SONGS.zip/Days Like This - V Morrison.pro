{title:Days Like This}
{subtitle:V. Morrison}
{subtitle: 4/4 Time}
{time:2:44}
{metronome:91}









{c: Note: Multiple voices on the shaded lyrics}

{c: INTRO:}
[Bb]   [F]      [Bb]         [F/]
[Bb]   [F]      [Bb]         [F]
                                                                    
{soh}When it's [F]not always [Dm]raining{eoh}  
There’ll be [Bb]days like [F]this
{soh}When there’s [F]no one com[Dm]plaining{eoh}  
There’ll be [Bb]days like [F]this
When every[Bb]thing falls into [C]place 
Like the [F/]flick of a [C/]switch  [Dm/]   
Well my [Gm]mama told me [C] 
{soh}There’ll be [Bb]days like [F]this{eoh}    
[Bb]  [F]
                                  
{soh}When you [F]don't need to [Dm]worry{eoh} 
There’ll be [Bb]days like [F]this  
{soh}When no [F]one's in a [Dm]hurry{eoh}
There’ll be [Bb]days like [F]this 
When you [Bb]don't get betrayed [C]
by that [F/]old Juda[C/]s kiss [Dm/]
Oh my [Gm]mama told me [C] 
{soh}There’ll be [Bb]days like [F]this{eoh}   
[Bb]  [F]

{soh}When you [F]don’t need an [Dm]answer{eoh}  
There’ll be [Bb]days like [F]this
{soh}When you [F]don’t meet a [Dm]chancer{eoh} 
There’ll be [Bb]days like [F]this
When all the [Bb]parts of the [C]puzzle 
Start to [F/]look [C/]like they fit[Dm/]
Then I [Gm]must rem[C]ember 
{soh}There’ll be [Bb]days like [F]this{eoh}   
[Bb]   [F]

{soh}When every[F]one is up [Dm]front{eoh} 
And they’re [Bb]not playing [F]tricks
{soh}When you d[F]on’t have no free[Dm]loaders{eoh} 
Out to [Bb]get their [F]kicks
When its [Bb]nobody’s [C]business 
The [F/]way that [C/]you wanna [Dm/]live
I just [Gm]have to rem[C]ember 
{soh}There’ll be [Bb]days like [F]this{eoh}     
[Bb]   [F]

When no one [F]steps on my [Dm]dreams 
{soh}There’ll be [Bb]days like [F]this{eoh}
When people under[F]stand what I [Dm]mean 
{soh}There’ll be [Bb]days like [F]this{eoh}
When you r[Bb]ing out the [C]changes 
Of how [F/]everything [C/]is [Dm/]
Oh my [Gm]mama told me [C]
{soh}There’ll be [Bb]days like [F]this{eoh}
Oh my [Gm]mama told [C]me 
{soh}There’ll be [Bb]days like [F]this{eoh}
Oh my [Gm]mama told [C]me 
{soh}There’ll be [Bb]days like [F]this{eoh}
Oh my [Gm]mama told [C]me 
{soh}There’ll be [Bb]days like [F]this{eoh}
Oh my [Gm]mama told [C]me 
{soh}There’ll be [Bb]days like [F/]this{eoh}
