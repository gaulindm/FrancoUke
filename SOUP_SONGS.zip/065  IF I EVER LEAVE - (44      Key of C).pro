

{title:065  IF I EVER LEAVE }
{title:THIS WORLD ALIVE}
{subtitle:(4/4      Key of C)}
{subtitle:(Flogging Molly)}
{time:4:17}
{metronome:200}






[C]/ / / /   / / / /   

/ / / /   / / / /

[C]Ooo - oo - oo  {c:(234,1234)}  
        
Ooo - oo - oo  {c:(234,123)}  

If I [C]ever leave this world alive
I'll [F]thank ya' for the things you did 
In [C]my life  {c:(4,1234,1234,123)}
If I ever leave this world alive
I'll [F]come back down and sit beside your 
[C]Feet tonight  {c:(234,123)}
Wherever I [G]am you'll always be
More than   [Am]       just a memo[F]ry 
If I [C]ever…  leave this [G]   world 
A[C]live 
   Ooo - oo - oo {c:(234,1234)}

   Ooo - oo - oo {c:(234,123)}

If I [C]ever leave this world alive
I'll [F]take on all the sadness, that I 
[C]Left behind 
If I ever leave this world alive
The [F]madness that you feel will 
[C]Soon subside 
So in a [G]word, don't shed a tear 
I'll be [Am]here when it all gets [F]weird  
If I [C]ever…  leave this [G]   world   
A[C]live   
   Ooo - oo - oo {c:(234,1234)}

{c:INSTRUMENTAL (with spoons or kazoo)}
[C]/ / / /   / / / /      [F]/ / / /   / / / /    
[C]/ / / /   / / / /   / / / /    / / / /

[C]/ / / /   / / / /      [F]/ / / /   / / / /    
[C]/ / / /   / / / /   / / / / 

So when in [G]doubt, just call my name 
Just be- [Am]       fore you go in[F]sane  
If I [C]ever…  leave this   [G]     world 
Hey, I may [Am]never… leave this    [F]   world 
But if I [C]ever… leave this [G]   World 
Al[C]ive {c:(234,1234,}  [G]{c:123)} she says

{c:(tambourine here)}
I'm [C]okay!  I'm alright! 
Though you have [Am]      gone… from my [F]life 
You said that it [C]would
Now everything   [G]      should 
Be all [C]right {c:(234,1234,}  [G]{c:123)} she says

{c:(don't hold back!)}
I'm [C]okay!!  I'm alright!! 
Though you have [Am]       gone… from my [F]life
You said that it [C]would
Now everything [G]    should 
Be all [C]right  {c:(234,1234,1)} 
Yeah, should be all 

[C]Right 
Ooo - oo - oo  
Ooo - oo - oo 
Ooo - oo - oo   
Ooo - oo - oo {c:(234)} [C/] [G/] [C/]

_________________________________









