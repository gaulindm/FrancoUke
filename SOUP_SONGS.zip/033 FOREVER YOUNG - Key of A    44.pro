

{title:033 FOREVER YOUNG}
{subtitle: Key of A    4/4}
{subtitle:Audra Mae (Orig by Bob Dylan 1973) }
{metronome: 145}
{time:3:09}

{c:(The optional RIFF starts on}
{c: the "three" of the count-in)}

{c: "1,  2,  1 2 }[RIFF]{c:3 4"} 
     
{c:RIFF}
{sot}                                               
A|- - - 0 2 4 - 5 2 4 -   
E|- 0H2 - - - - - - - -   


A|- - - 0 2 4 - 5 2 0 -    
E|- 0H2 - - - - - - - -             
{eot} 

[A]/ / / /    / / / /    
/ / / /    / / / /    
[A]/ / / /    / /     [E7]/ /     
[A]/ / / /   / /

May God [A]bless and keep you always          
May your [D]wishes all come [A]true {c:(234,123)}
May you always do for others 
And let [E7]others do for you
May you [A]build a ladder to the stars 
And [D]climb on every [Bm]rung {c:(234,12)}
May you [A]stay  [E7]    forever [A]young {c:(234,12)}
May you [A]stay  [E7]    forever [A]young  {c:(234,12)}
     
May you [A]grow up to be righteous
May you [D]grow up to ↑be [A]true {c:(234,123)}
May you always know the truth 
And see the [E7]lights surrounding you
May you [A]always be courageous
Stand [D]upright and be [Bm]strong {c:(234,12)}
May you [A]stay [E7]    forever [A]young {c:(234,12)}
May you [A]stay [E7]    forever [A]young {c:(234,12}[RIFF]{c:34)}


{c:RIFF (through the instrumental)}
{sot}                                               
A|- - - 0 2 4 - 5 2 4 -   
E|- 0H2 - - - - - - - -   


A|- - - 0 2 4 - 5 2 0 -    
E|- 0H2- - - - - - - - -            
{eot} 

[A]/ / / /    / / / /    
/ / / /    / / / /    
/ / / /    / /     [E7]/ /     
[A]/ / / /   / /

May your [A]hands always be busy
May your [D]feet always ↑be [A]swift {c:(234,123)}
May you have a strong foundation 
↑When the [E7]winds of changes shift
May your [A]heart always be joyful 
May your [D]song always be [Bm]sung  {c:(234,12)}
May you [A]stay [E7]    forever [A]young {c:(234, 12)}
May you [A]stay [E7]    forever [A]young [A/]

___________________________














