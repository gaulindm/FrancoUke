{title:HITCHIN A RIDE}
{subtitle:}

[Verse 1]
[C]A thumb goes up, a car goes by, 
it's nearly 1 a.m. 
 
and here am I..
hitchin a [F]ride, [G7]hitchin' a [C]ride..
gotta get me [F]home, 
[G7]by the morning [C]light.
[C]I got no fare to ride a train, 
I'm nearly drowning 
 
in the pouring rain..
hitchin' a [F]ride, [G7]hitchin' a [C]ride..
gotta get me [F]home, 
[G7]to my baby's [C]side.
 
[Chorus]
[F]Ride, ride, [G7]ride, hitchin' a [C]ride.
[F]Ride, ride, [G7]ride, hitchin' a [C]ride.
 
[Verse 2]
[C]Long distance call I got today, she sounded 
 
lonely so I'm on my way..
hitchin a [F]ride, [G7]hitchin' a [C]ride..
gotta get me [F]home,
[G7]keep her satis[C]fied.
 
[Interlude]
 
[Chorus]
[F]Ride, ride, [G7]ride, hitchin' a [C]ride.
[F]Ride, ride, [G7]ride, hitchin' a [C]ride.
 
[Verse 3]
[C]A thumb goes up, a car goes by, oh, won't somebody 
 
stop and help a guy?
hitchin' a [F]ride, [G7]hitchin' a [C]ride..
been away too [F]long 
[G7]from my baby's [C]side.
 
[Chorus]
[F]Ride, ride, [G7]ride, hitchin' a [C]ride.
[F]Ride, ride, [G7]ride, hitchin' a [C]ride.
 
[Chorus]
[F]Ride, ride, [G7]ride, hitchin' a [C]ride.
[F]Ride, ride, [G7]ride, hitchin' a [C]ride.
 
[Outro]
[C7]Ride, ride...(x5)(Fade.)
 