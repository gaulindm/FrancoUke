

{title:124   CHICKEN FRIED        }
{subtitle: 4/4   Key of G  }                   
{subtitle: Zac Brown Band (Zac Brown & Wyatt Durrette)}
{metronome:180}
{time:3:46}

{c:(normal count-in)}





{c:(}[G/]{c:1234,} [G/]{c:12)}
You know I like my [G/]chicken fried 
Cold beer on a [D/]Friday night
A pair of jeans that [C/]fit just right
And the radio [G]o...[D].....[G]n {c:(234,123)}


Well I was raised up beneath the 
[D]shade of a Georgia [C]pine
And that's [D]home you know
[G]Sweet tea, pecan [D]pie and homemade [C]wine
Where the [D]peaches grow
And [G]my house it's not [D]much to talk 
A[C]bout {c:(234)}  {c:(}[D]{c:123)}
But it's [G]filled with love that's [D]grown in 
Southern [C]ground {c:(234)} [D/]

{c:CHORUS:}
{soc}
And a little bit of [G]chicken fried
Cold beer on a [D]Friday night
A pair of jeans that [C]fit just right
And the radio [G]u......[D]p
I like to see the [G]sun…rise
See the love in my [D]woman's eyes
Feel the touch of a [C]precio...us child
And know a mother's [G]lo…[D]ve {c:(234)}
{eoc}

It's [G]funny how it's the [D]little things in [C]life 
That [D]mean the most
Not [G]where you live, [D]what you drive or the 
[C]Price tag on your [D]clothes
There's no [G]dollar sign on a [D]piece of mind 
[C]This I've come to [D]know
So if [G]you agree have a [D]drink with me
Raise your [C]glasses for a [D/]toast

{soc}
To a little bit of [G]chicken fried
Cold beer on a [D]Friday night
A pair of jeans that [C]fit just right
And the radio [G]u......[D]p
I like to see the [G]sun…rise
See the love in my [D]woman's eyes
Feel the touch of a [C]precio...us child
And know a mother's [G]lo...[D].....[G]ve {c:(234)}  [G/]
{eoc}
                                                          
I thank God [G/]for my life 
And for the [D/]red and white
May freedom for[C/]ever fly
Let it [G/]ri....[D/]ng 
Salute the [G/]ones who died
The ones that [D/]give their lives
So we don't have to [C/]sacrifice
All the things we [G/]lo....[D/]ve

{soc}
Like our [G]chicken fried 
Cold beer on a [D]Friday night
A pair of jeans that [C]fit just right 
And the radio [G]u......[D]p
I like to see the [G]sun…rise
See the love in my [D]woman's eyes
Feel the touch of a [C]precious child
And know a mother's [G]lo...[D/]ve
{eoc}

{c:(a capella here)}

Getcha little chicken fried
And cold beer on a Friday night
A pair of jeans that fit just right
And the radio u…↑..p

{c:(start strumming again here)}

I like to see the [G]sunrise
See the love in my [D]woman's eyes
Feel the touch of my [C]precio...us child
And know a mother's [G]lo....[D]....[G/]ve


______________________________________













