{title:HERE'S TO NEVER GROWING UP}
{subtitle: 4/4      Key of G}
{subtitle:(Avril Lavigne)}
{metronome:164  }
{time: 4:00 } 

"One, two", one two three"  
{c:(start note is D)}

Singing [Z]Radiohead at the top of our lungs
With the boom box blaring as we're falling in love
Got a bottle of whatever but it's getting us drunk 
Singing, "here's to never growing up"

[G]  Call up all our friends
[Em]  Go hard [C]this weekend
[G]  For no dang reason
[Em]I don’t think we’ll [C]ever change
[G]  Meet you at the spot
[Em]  Half past [C]ten o’clock
[G]  We don’t ever stop
[Em]And we’re never [G]gonna change
 
[Am]Say, won’t you [C]say forever
[Am]Stay, if you [C]stay forever
[Am]Hey, we can [G]stay forever [C]young  [C/]    {c:(23)}
 
{soc}
 Singing [G]Radiohead at the top of our lungs
 With the [Em]boom box blaring as we're [C]falling in love
 Got a [G]bottle of whatever but it's getting us drunk 
 Singing "[Em]here's to never [C]growing up"
 We'll be [G]running down the street yelling 
 "Don't look back"
 I'm like "[Em]yeah whatever we're still [C]living like that"
 When the [G]sun's going down we’ll be raising our cups 
 Singing [Em]here’s to never [C]growing up"
 [G]    Oh Oh Oh, Oh Oh Oh
 [Em]Here’s to never [C]growing up
 [G]    Oh Oh Oh, Oh Oh Oh 
 [Em]Here’s to never [C]growing up
{eoc} 
 
[G]  We live like rock stars
[Em]  Dance on [C]every bar 
[G]  This is who we are
[Em]  I don’t think we’ll [C]ever change
[G] They say just grow up 
[Em]  But they [C]don’t know us 
[G] We don’t give a crap
[Em]And we’re never [C]gonna change
 
 
[Am]Say, won’t you [C]say forever
[Am]Stay, if you s[C]tay forever
[Am]Hey, we can s[G]tay forever [C]young  [C/]    {c:(23)}
 
 
{soc}
  Singing [G]Radiohead at the top of our lungs
  With the [Em]boom box blaring as we're [C]falling in love
  Got a [G]bottle of whatever but it's getting us drunk 
  Singing "[Em]here's to never [C]growing up"
  We'll be [G]running down the street yelling 
  "Don't look back"
  I'm like "[Em]yeah whatever we're still [C]living like that"
  When the [G]sun's going down we’ll be raising our cups 
  Singing [Em]here’s to never [C]growing up"
  [G]  Oh Oh Oh, Oh Oh Oh
  [Em]Here’s to never [C]growing up
  [G]  Oh Oh Oh, Oh Oh Oh 
  [Em]Here’s to never [C]growing up
{eoc} 

[Am]Say, won’t you [C]say forever
[Am]Stay, if you s[C]tay forever
[Am]Hey, we can s[G]tay forever [C]young  [C/]    {c:(23)}
  
{soc}
  Singing [G]Radiohead at the top of our lungs
  With the [Em]boom box blaring as we're [C]falling in love
  Got a [G]bottle of whatever but it's getting us drunk 
  Singing "[Em]here's to never [C]growing up"
  We'll be [G]running down the street yelling 
  "Don't look back"
  I'm like "[Em]yeah whatever we're still [C]living like that"
  When the [G]sun's going down we’ll be raising our cups 
  Singing [Em]here’s to never [C]growing up"
  [G]  Oh Oh Oh, Oh Oh Oh
  [Em]Here’s to never [C]growing up
  [G]  Oh Oh Oh, Oh Oh Oh 
  [Em]Here’s to never [C]growing up
  [G]  Oh Oh Oh Oh, Oh Oh Oh Oh
  [Em/]Here’s to never [C/]growing up
{eoc}
 
