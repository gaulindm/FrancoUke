

{title:SWEET GEORGIA BROWN }
{subtitle:(4/4    Key of D)}
{subtitle:(Ben Bernie, Maceo Pinkard)}
{subtitle:(& Kenneth Casey)}
{time:2:29}
{metronome: 160}


[F]/ / / /    [D7]/ / / /    
[G7]/ /    [C7]/ /    [F]/ / / /

[D7]No gal made has got a shade on 
[D7]  Sweet Georgia Brown 
[G7]Two left feet, oh, so neat, has 
[G7]  Sweet Georgia Brown 
[C7]They all sigh, and wanna die, for 
[C7]  Sweet Georgia Brown I'll tell you just [F]why {c:(234)} [F/]    
You [C7/]know I don't [F]lie… [A7]much 

[D7]It's been said she knocks 'em dead when 
[D7]She lands in town [G7]Since she came, why it's a shame how 
[G7]She’s cooled ‘em down 
[Dm/]  Fellas [A7]she can't get are 
[Dm/]  Fellas [A7]she ain't met [F]Georgia claimed her, [D7]Georgia named her
[G7]   Sweet [C7]Georgia [F]Brown 

{c:INSTRUMENTAL: }

[D7]/ / / /   / / /    [Db7]/    [D7]/ / / /   / / / /

[G7]/ / / /   / / /    [Edim7]/    [G7]/ / / /   / / / /

[C7]/ / / /   / / / /   / / / /   / / / /

[F]/ / / /   / /    [C7]/ /    [F]/ / / /    [A7]/ / / /

[D7]All those tips the porter slips to 
[D7]  Sweet Georgia Brown
[G7]They buy clothes at fashion shows with 
[G7]  One dollar down
[Dm/] Oh boy, [A7]tip your hats…  
[Dm/]  Oh joy, [A7]she’s “the cats”
[F]Who’s that, Mister?  [D7]T’ain’t her sister
[G7]   Sweet [C7]Georgia [F]Brown
[F]Georgia claimed her, [D7]Georgia named her
[G7]   Sweet [C7]Georgia [F/]Brown   [F6/] 

________________________________________





{define: D7 0 2 2 2 3}
{define: F6/ 0 5 5 5 5}
{define: Edim7 0 0 1 0 1}
{define: Db7 0 1 1 1 2}
{define: D7alt 0 2 0 2 0}









