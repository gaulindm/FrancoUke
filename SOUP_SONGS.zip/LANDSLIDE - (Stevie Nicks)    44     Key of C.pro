{title:  LANDSLIDE}
{subtitle: 4/4     Key of F}
{subtitle:(Stevie Nicks)    }
{time:3:03}
{metronome:  }


[F]/ / / /    [C]/ / / / /    [Dm]/ / / /    [C]/ / / /    
[F]/ / / /    [C]/ / / / /    [Dm]/ / / /    [C]/ / / / 
 
{c:(}[F]{c:12)}  I took my [C]love and I took it down   [Dm]/ / / /     [C]/ / / /
{c:(}[F]{c:12)}  I climbed a [C]mountain and I turned a[Dm]round   [C]/ /
And I [F]saw my re[C]flection in the 
[Dm] Snow-covered [C]hills
Till the [F]landslide [C]brought me do[Dm]wn  {c:(234,}[C]{c:123)}          
 
Oh, [F]mirror in the sky-[C]y, what is [Dm]love {c:(234,}[C]{c:12)}
Can the [F]child within my [C]heart rise [Dm]     above [C]
Can I [F]sail through the [C]changin' [Dm]ocean ti-i-[C]ides
Can I [F]      handle the [C]seasons [Dm]of my li-i-[C]ife
 
[F]      hm   [C]mmm...I don’t [Dm]know[C]  
mmm[F]... m[C]mm... [Dm]  [G7]  
 
Well, [C]I've been a[G]fraid of ch[Am]anging 'cause I
[F]Built my [C]life around [Dm]you    [G7]
But [C]time makes you [G7]bolder, [Am]children get older
And [F]I'm getting [C]older [Dm]too    [C]sooo
 
[F][C][Dm][C]
[F][C][Dm][G7] 
 
Well, [C]I've been a[G]fraid of [Am]changing 'cause I
[F]Built my [C]life around [Dm]you  [G7]
But [C]time makes you [G7]bolder, [Am]children get older
And [F]I'm getting [C]older [Dm]too  [C] 
 
[F]I'm getting [C]older [Dm]too  [C] 

 
So-[F/]o take this [C/]love, take it down [Dm]   [C]
Yeah  [F]  and if you climbed a [C]mountain and ya tu[Dm]rn around [C]
And if you [F]see my re[C]flection in the [Dm]snow-covered [C]hills
Well the [F]landslide has [C]brought you [Dm]down  [C]     
          
And if you [F]see my re[C]flection in the [Dm]snow-covered [C]hills
Well [F]maybe   [C]    [Dm]    [C]
 [F]maybe   [C]    [Dm]    [C]
 [F]maybe   [C]    [Dm]    [C]
The [F/]landslide will [C/]bring it [Dm/]down 
