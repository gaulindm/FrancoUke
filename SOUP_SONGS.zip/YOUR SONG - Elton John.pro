

{title: YOUR SONG }
{subtitle:Elton John}
{subtitle: 4/4}
{metronome:128}
{time:4:10}


[G]/ / / /   / / / /

[G]   It's a little bit [C]funny 
[D]   This feeling in[Bm7]side
[Em]  I'm not one of [Em7]those who can  
[A7]           Easily [C]hide 
[G]  I don't have much [D]money 
But [B7]    boy if I [Em]did
[G]  I'd buy a big [Am]house where   
[C]  We both could [D]live

[G]   If I were a [C]sculptor  
[D]   But then again [Bm7]no   
Or a [Em]man who makes [Em7]potions 
In a [A7]     travelling [C]show 
[G]   I know it's not [D]much but it's the 
[B7]best I can [Em]do
[G]My gift is my [Am]song   
[C]    and this one's for [G]you

{soc}
[D]    And you can tell [Em]ev'rybody 
[Am]      This is your [C]song
[D]    It may be [Em]quite simple but   
[Am]      Now that it's [C]done 
[Em]      I hope you don't mind
[Em7]         I hope you don't mind 
[A7]      That I put down in [C/]words  
How [G]wonderful [Am]life is 
While [C]you're in the world [D]
{eoc}


[G]  I sat on the [C]roof  
[D]    I kicked off the  [Bm7]moss
Well a [Em]few of the [Em7]verses  yeah they  
[A7]     got me quite [C]cross
[G]   But the sun's been [D]quite kind while
[B7]   I wrote this [Em]song
[G]  It's for people like [Am]you that  
[C]    keep it turned [D]on 

[G]   So excuse me for- [C]  getting      
[D]       but, these things I [Bm7]do
You see  [Em]      I've for- [Em7]gotten if they're 
[A7] Green or they're [C]blue
[G]   Anyway the [D]thing is what [B7]I really mean  [Em]  
[G]  Yours are the [Am]sweetest eyes 
[C]    I've ever [G]seen[G]


{soc}
[D]    And you can tell [Em]ev'rybody 
[Am]       This is your [C]song
[D]    It may be [Em]quite simple but   
[Am]      Now that it's [C]done 
[Em]      I hope you don't mind
[Em7]         I hope you don't mind 
[A7]  That I put down in [C/]words  
How [G]wonderful [Am]life is 
while [C]you're in the world [D]
[Em]       I hope you don't mind
[Em7]         I hope you don't mind 
[A7]     That I put down in [C/]words  
How [G/]wonderful [Am/]life is 
while [C/]you're in the world [G/]
{eoc}


[B7alt]
{define: D7 0 2 0 2 0}
{define: B7alt 0 4 3 2 0}