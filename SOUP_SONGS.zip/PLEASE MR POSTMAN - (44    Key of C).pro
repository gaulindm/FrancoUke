{t:     PLEASE MR. POSTMAN }
{subtitle:(4/4    Key of C)}     
{subtitle:(G. Dobbins, W. Garrett)}
{subtitle:(F. Gorman, B. Holland, & R. Bateman)}
{time: 3:05}
{metronome: 132}


{c:(Choose either the bracketted}
{c:or not bracketted parts; not both!)}



[C/]{c:(Wait!)}    Oh yeah, wait a minute Mr. Postman 
[Am/]{c:(Wait!)}    Wa-a-a-ait Mr. Postman

{soc}                                                    
[C]                                                                                            
    {c:(Mr. Postman, look and see)}

Oh [Am]yeah…                                           please
          {c:(is there a letter in your bag for me?)}

[F]Please, Mr. Po-o-ostman                               
         {c:(I’ve been waiting… such a long time)}

Oh [G]yeah
            {c:(since I heard from that boy of mine)}
{eoc}

{c:(Ahhs…)}
[C]  There must be some word today-ay-[Am]ay
From my boyfriend so far away
[F]  Please Mr. Postman, look and see  
[G]   If there's a letter, a letter for me
[C] I've been standing here waiting Mr. Postman
[Am]   So-o-o patiently [F]    for just a card, or just a letter
[G]  Saying he's returning home to me


{soc}
 Please Mr. [C]Postma-a-a-an…                                                                  
                             {c:(Mr. Postman, look and see)}

 Oh [Am]yeah                                                please     
            {c:(Is there a letter in your bag for me)}

 [F]Please, Mr. Po-o-ostman                          oh [G]yeah         
         {c:(I’ve been waiting… a long long time)} 
           
{c:(since I heard from this boyfriend of mine)}
{eoc}


{c:(Ahhs…)}
[C]  So many days, you pass me by-y-[Am]y    
You saw the tear standing in my eye
[F]  You wouldn't stop to make me feel better 
[G]  By leaving me a card or a letter

{soc}
Mr. [C]Postma-a-a-an…                                                                  
                    {c:(Mr. Postman, look and see)}

 Oh [Am]yeah                                               please     
            {c:(Is there a letter in your bag for me)}

 [F]Please, Mr. Po-o-ostman                          oh [G]yeah         
         {c:(I’ve been waiting… a long long time)} 
           
{c:(since I heard from this boyfriend of mine)}
{eoc}


You gotta [C]wait a minute, wait a minute, oh yeah,           
                {c:(Wait a minute wait a minute, Mr. Postman)} 
[Am]Wait a minute, wait a minute
{c:(Wait a minute, wait a minute, Mr. Postman)}
You gotta [F]wait a minute, wait a minute, oh yeah 
                {c:(Wait a minute, wait a minute, Mr. Postman)}   
You gotta [G/]Check it and see, one more [G/]time for me 


You gotta [C]wait a minute, wait a minute, oh yeah,           
              {c:(Wait a minute wait a minute, Mr. Postman)} 
[Am]wait a minute, wait a minute
{c:(Wait a minute, wait a minute, Mr. Postman)}
You gotta [F]wait a minute, wait a minute, oh yeah 
                {c:(Wait a minute, wait a minute, Mr. Postman)}  
De[G/]liver the letter the [G/]sooner the better


{soc}
[C]Wait a minute, wait a minute ,oh yeah,       
{c:(Wait a minute wait a minute, Mr. Postman)}
[Am]Wait a minute, wait a minute, oh yeah
{c:(Wait a minute, wait a minute, Mr. Postman)}
[F]Wait a minute, wait a minute, oh yeah,       
{c:(Wait a minute wait a minute, Mr. Postman)} 
[G]Wait a minute, wait a minute, oh yeah
{c:(Wait a minute, wait a minute, Mr. Postman)}


{c:(fading)}
[C]Wait a minute, wait a minute ,oh yeah,       
{c:(Wait a minute wait a minute, Mr. Postman)}
[Am]Wait a minute, wait a minute, oh yeah
{c:(Wait a minute, wait a minute, Mr. Postman)}
[F]Wait a minute, wait a minute, oh yeah,       
{c:(Wait a minute wait a minute, Mr. Postman)} 
[G]Wait a minute, wait a minute, oh yeah
{c:(Wait a minute, wait a minute, Mr. Postman)}  [C/]
{eoc}

