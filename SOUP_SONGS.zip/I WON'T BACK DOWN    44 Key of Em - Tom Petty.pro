{title: I WON'T BACK DOWN    4/4 Key of Em }
{subtitle: Tom Petty}

{c:INTRO: Em / /   D / /   G / / / /     Em / /   D / /   G / / /}
           
Well, I [Em]    won't [D]  back [G]down, no I[Em]   won't[D]   back [G]down
You could [Em]stand me [D]up at the [C]gates of hell but I [Em]   won't [D]  back [G]down

No, I'll [Em]    stand [D]  my [G]ground, won't be [Em]  turned [D]   a[G]round
And I'll [Em]keep this [D]world from [C]draggin' me down
Gonna [Em]     stand [D]  my [G]ground and I [Em]   won't [D]  back [G]down

{c:CHORUS:}
{soc}
     [C/]  [G/]  [C]Hey[G/]  [D]baby,[G/]   [C] there ain't no easy [G/]way o[D]ut
     [G/]  [C]Hey[G/] [D]I will [Em]stand [D]my [G]ground and I [Em]won't [D]  back [G]down
{eoc}


Well, I[Em]    know [D]  what's [G]right, I got[Em]    just [D] one [G]life
In a [Em]world that [D]keeps on [C]pushin' me around
But I'll [Em]    stand [D] my [G]ground and I [Em]    won't [D] back [G]down

{c:CHORUS:}
{soc}
     [C/]  [G/]  [C]Hey[G/]  [D]baby,[G/]   [C] there ain't no easy [G/]way o[D]ut
     [G/]  [C]Hey[G/], [D]I will [Em]stand [D]my [G]ground and I [Em]won't [D]  back [G]down
{eoc}

 
{c:INSTRUMENTAL:}
{c:Em / /   D / /   G / / / /   Em / /   D / /   G / / / /}
{c:Em / /   D / /   C / / / /   Em / /   D / /   G / / / /   Em / /   D / /   G / /}




{c:I WON'T BACK DOWN}                                        {c:PAGE 2}

{c:CHORUS:}
{soc}
     [C/]  [G/]  [C]Hey[G/]  [D]baby,[G/]   [C] there ain't no easy [G/]way o[D]ut
     [G/]  [C]Hey[G/], [D]I [Em]won't [D] back [G] down
     [C/]  [G/]  [C]Hey[G/]  [D]baby,[G/]   [C] there ain't no easy [G/]way o[D]ut
     [G/]  [C]Hey[G/], [D]I will [Em]stand [D]my [G]ground
{eoc}

And I [Em]   won't [D]  back [G]down
No, I [Em]   won't [D]  back [G/]down
