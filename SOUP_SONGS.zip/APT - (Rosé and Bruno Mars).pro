{title:APT}
{subtitle:(Rosé and Bruno Mars)}


Intro:
    N.C.
    Chaeyeongiga johaneun
    N.C.
    Raendeom geim
    N.C.
    Raendeom geim
    N.C.
    Game start

Chorus:
    N.C.
    Apateu, apateu
    N.C.
    Apateu, apateu
    N.C.
    Apateu, apateu
    N.C.
    Uh, uh huh, uh huh
     
    N.C.
    Apateu, apateu
    N.C.
    Apateu, apateu
    N.C.
    Apateu, apateu
    N.C.
    Uh, uh-huh, uh-huh

[Am]Kissy face, kissy face, sent to your phone [G]but
[Am]Iʼm trying to kiss your lips for real (Uh-huh, uh-huh)
[Am]Red hearts, red hearts
That’s what I’m on [G]yeah
[Am]Come give me somethinʼ I can feel, oh-oh, oh

Pre-Chorus:
    [F]Donʼt you want me like I [G]want you, baby?
    [Am]Donʼt you need me like I [C]need you now?
    [F]Sleep tomorrow, but to[G]night, go crazy
    [Am]All you gotta do is just [C]meet me at the

Chorus:
    [Am]Apateu, apateu
    [G]Apateu, apateu
    [Am]Apateu, apateu
    [G]Uh, uh-huh, uh-huh
     
    [Am]Apateu, apateu
    [G]Apateu, apateu
    [Am]Apateu, apateu
    [G]Uh, uh-huh, uh-huh

It’s what[Am]ever (Whatever), it’s whatever (Whatever)
Itʼs whatever (Whatever) you like ([G]Woo)
[Am]Turn this apateu into a club (Uh-huh, uh-huh)
I’m talkinʼ [Am]drink, dance, smoke, freak
Party all night ([G]Come on)
[Am]Geonbae, geonbae, girl, what’s up?
 
Oh-oh, oh

Pre-Chorus:
    [F]Donʼt you want me like I [G]want you, baby?
    [Am]Donʼt you need me like I [C]need you now?
    [F]Sleep tomorrow, but to[G]night, go crazy
    [Am]All you gotta do is just [C]meet me at the

Chorus:
    [F]Apateu, apateu
    [G]Apateu, apateu
    [Am]Apateu, apateu
    [C]Uh, uh-huh, uh-huh
     
    [F]Apateu, apateu
    [G]Apateu, apateu
    [Am]Apateu, apateu
    [C]Uh, uh-huh, uh-huh

Bridge:
    [Em]Hey, so now you know the game
     
    Are you ready?
     
    ʼCause I’m comin to get ya, get ya, get ya
     
    [Am]Hold on, hold [G]on
    I’m on my [C]way [Am]
    [Am]Yeah, yeah, yeah-yeah, [G]yeah
    I’m on my [C]way [Am]
     
    [Am]Hold on, hold [G]on
    I’m on my [C]way [Am]
    [Am]Yeah, yeah, yeah-yeah, [G]yeah
    I’m on my [D]way

Pre-Chorus:
    [F]Donʼt you want me like I [G]want you, baby?
    [Am]Donʼt you need me like I [C]need you now?
    [F]Sleep tomorrow, but to[G]night, go crazy
    [Am]All you gotta do is just [C]meet me at the

Chorus:
    [F]Apateu, apateu
    [G]Apateu, apateu
    [Am]Apateu, apateu
    Just [C]meet me at the (Uh, uh-huh, uh-huh)
     
    [F]Apateu, apateu
    [G]Apateu, apateu
    [Am]Apateu, apateu
    Just [C]meet me at the (Uh, uh-huh, uh-huh)
     
    [F]Apateu, apateu
    [G]Apateu, apateu
    [Am]Apateu, apateu
    Just [C]meet me at the (Uh, uh-huh, uh-huh)
     
    [F]Apateu, apateu
    [G]Apateu, apateu
    [Am]Apateu, apateu
    [C]Uh, uh-huh, uh-huh
