{title: Johnny Be Fair}
{subtitle: }

[Am] / / / /    [Am] / / / /

Well [Am]Johnny be fair and Johnny be fine and [G]wants me for to [Am]wed
And I would marry Johnny, but my father [G]up and [E7]said
I'm [Am]sad to tell you daughter what your mother [G]never [E7]knew
But [Am]Johnny is a [G]son of mine and [F]so he's [E7]kin to [Am]you

[Am] / / / /

Well [Am]Jimmy be fair and Jimmy be fine and [G]wants me for to [Am]wed
And I would marry Jimmy, but my father  [G]up and [E7]said
I'm [Am]sad to tell you daughter what your mother [G]never [E7]knew
But [Am]Jimmy too is a [G]son of mine and [F]so he's [E7]kin to [Am]you

[Am] / / / /

Well [Am]Billy be fair and Billy be fine and [G]wants me for to [Am]wed
And I would marry Billy, but my father [G]up and [E7]said
I'm [Am]sad to tell you daughter what your mother [G]never [E7]knew
But [Am]Billy too, is a [G]son of mine and [F]so he's [E7]kin to [Am]you

[Am] / / / /

You [Am]never seen a girl so sad and [G]sorry as I [Am]was
The boys in town are all my kin and my father [G]is the [E7]cause
[Am]If this does continue, I shall die a [G]single [E7]miss
[Am]I will go to [G]mother and comp[F]lain to [E7]her of [Am]this

[Am] / / / /

Oh [Am]daughter haven't I taught you, to for[G]give and to for[Am]get
Even if all this is true, still you [G]needn't [E7]fret
Your [Am]father may be father to all the [G]boys in [E7/]town, (spoken),but still
He's [Am]not the one who [G]sired you, so [F]marry [E7]who you [Am]will
He's [Am]not the one who [G]sired you, so [F]marry [E7]who you [Am/]will
