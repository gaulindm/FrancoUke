

{title:EX’S And OH’S  }
{subtitle:(4/4   Key of Am)}
{subtitle:(Elle King)}
{time:3:52}
{metronome: 146}


Lynda


{c:INTRO:}
 [Am]/ /    [C]/ /    [Am]/ /    [E7]/ /
 [Am]/ /    [C]/ /    [Am]/ /    [E7]/ /
  
Well, [Am]I        had me a [C]boy 
Turned him [Am]into a [E7]man
I [Am]showed him all the [C]things that he 
[Am]Didn't under[E7]stand, whoa {c:(234)} [E7/]       
And then I let him [Am]go     [C]      [Am]          [E7]
Now, there's [Am]one in Cali[C]fornia who's been 
[Am]Cursing my [E7]name
'Cause [Am]I         found me a [C]better lover 
[Am]In the U[E7]K,  hey, hey {c:(234)} [E7/]   
Until I made my geta[Am]way   [C]     [Am]         [E7]       
[Am]     [C]    [Am]       [E7]

{c:CHORUS}
{soc}
      [Z]One, two, three, they gonna run back to me
     'Cause I’m the best baby 
     That they never gotta keep
     One, two, three, they gonna run back to me
     They always [++]wanna come, [+]but they 
     Never [++]wanna leave [+]

     [C]Ex's and the [G]oh, oh, ohs they [Am]haunt me
     Like [E7]gho-o-osts they [C]want me to make 'em 
     [G]A-a-all they [Dm]won't let [F]go, ex's and 
     [Am]Oh's      [C]     [Am]         [E7]         
     [Am]       [C]     [Am]        [E7]
{eoc}

I [Am]had a summer [C]lover 
Down in [Am]New Or[E7]leans
Kept him [Am]warm in the [C]winter, left him 
[Am]Frozen in the [E7]spring, my my {c:(234)}   [E7/]        
How the seasons go [Am]by    [C]     [Am]         [E7]
[Am]I get [C]high, and I [Am]love to get [E7]low
So the [Am]hearts keep [C]breaking, and the 
[Am]Heads just [E7]roll, you know {c:(234)}  [E7/]       
That's how the story [Am]goes    [C]     [Am]         [E7]         
[Am]       [C]     [Am]        [E7] 


[Z]One, two, three, they gonna run back to me
'Cause I’m the best baby 
That they never gotta keep
One, two, three, they gonna run back to me
They always [++]wanna come, [+]but they 
Never [++]wanna leave  [+]

[C]Ex's and the [G]oh, oh, ohs they [Am]haunt me
Like [E7]gho-o-osts they [C]want me to make 'em 
[G]A-a-all they [Dm]won't let [F]go 

My [C]ex's and the [G]oh, oh, ohs they [Am]haunt me
Like [E7]gho-o-osts they [C]want me to make 'em 
[G]A-a-all, they [Dm]won't let [F]go, ex's and 
[Am]Oh's      [C]     [Am]         [E7]         
[Am]      [C]     [Am]        [E7]

[Z]One, two, three, they gonna run back to me
Climbing over mountains and sailing overseas
One, two, three, they gonna run back to me
They always [++]wanna come, [+]but they 
Never [++]wanna leave  [+] 

My [C]Ex's and the [G]oh, oh, ohs they [Am]haunt me
Like [E7]gho-o-osts they [C]want me to make 'em 
[G]A-a-all, they [Dm]won't let [F]go… 

[C]Ex's and the [G]oh, oh, ohs they [Am]haunt me
Like [E7]gho-o-osts they [C]want me to make 'em 
[G]A-a-all, they [Dm]won't let [F]go, ex's and 
[Am]Oh's    [C]      [Am]          [E7]          
[Am]         [E7]     [Am/]

_____________________________________


















