{title:LOVERS IN A DANGEROUS TIME
}
{subtitle:}
[G] Don't the hours grow [Am]shorter as the days go [F]by [F]
[G] We never get to [Am]stop and open our [F]eyes [F]
[G] One minute you're [Am]waiting for the sky to [F]fall [F]
[G] Next your dazzled by the [Am]beauty of it [F]all [F]

[G]Love[Am]rs in a dangerous [F]time [F]
[G]Love[Am]rs in a dangerous [F]time [F]

[G] These fragile [Am]bodies of touch and [F]taste [F]
[G] This vibrant [Am]skin, this hair like [F]lace [F]
[G] Spirits [Am]open to the touch of [F]grace [F]
[G] Never a [Am]breath you can afford to [F]waste [F]

[G]Love[Am]rs in a dangerous [F]time [F]
[G]Love[Am]rs in a dangerous [F]time [F]
[G]Love[Am]rs in a dangerous [F]time [F]
[G]Love[Am]rs in a dangerous [F]time [F]

[G]     [Am]         [F]       [F]
          
[G] When you're l[Am]overs in a dangerous [F]time   [F]
[G] Sometimes you're made to feel as [Am]if your love's a [F]crime [F]
[G] Nothing worth having comes [Am]without some kind of [F]fight [F]
[G] Gotta kick at the [Am]darkness till it bleeds day[F]light [F]

[G]Love[Am]rs in a dangerous [F]time [F]
[G]Love[Am]rs in a dangerous [F]time [F]
[G]Love[Am]rs in a dangerous [F]time [F]
[G]Love[Am]rs in a dangerous [F]time [F]

