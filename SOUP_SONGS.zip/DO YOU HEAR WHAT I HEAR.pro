{title:C25: DO YOU HEAR WHAT I HEAR}
{subtitle:4/4     Key of G   (Noel Regney)}
{time:3:05}
{metronome: 94 }


{c:gentle picking on G intro}

[G]/ / / /   / / /

Said the [G]night wind to the [D]little [G]lamb
[G]Do you see what I see  
(do you see what I see)
[G]Way up in the sky, [D]little [G]lamb
[G]Do you see what I see 
(do you see what I see)
A [Em]star, a star [Bm]dancing in the night
With a [C]tail as [D]big as a [B7]kite
With a [C]tail as [D7]big as a [G]kite {c:(234,123)}
 
Said the [G]little lamb to the [D]shepherd [G]boy
[G]Do you hear what I hear  
(do you hear what I hear)
[G]Ringing through the sky, [D]shepherd [G]boy?
[G]Do you hear what I hear  
(do you hear what I hear)

A [Em]song, a song [Bm]high above the trees
With a [C]voice as [D]big as the [B7]sea
With a [C]voice as [D7]big as the [G]sea {c:(234,123)}
 
Said the [G]shepherd boy to the [D]mighty [G]king
[G]Do you know what...
(do you know what...)
(do you know what I know)
[G]In your palace warm, [D]mighty [G]king?
[G]Do you know what... 
(do you know what...)
(do you know what I know)

A [Em]Child, a Child [Bm]shivers in the cold
Let us [C]bring Him [D]silver and [B7]gold
Let us [C]bring Him [D7]silver and [G]gold {c:(234,123)}
 
Said the [G]king to the people [D]every [G]where
[G]Listen to what... 
(listen to what...)
(listen to what I say...)
[G]Pray for peace, people [D]every [G]where
[G]Listen to what...
(listen to what...)
(listen to what I say)
 
[Em]A Child, a child, [Bm]sleeping in the night
He will [C]bring us [D]goodness and [B7]light
He will [C]bri...ng us [D7]goodness... 
And [G]light {c:(234)}  [G/]
















