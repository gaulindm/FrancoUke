{title:I REMEMBER EVERYTHING}
{subtitle:(John Prine)}
{time:3:21}
{metronome: 92 }



[G]/ / / /   / /


I’ve been down this [G]road before
I remember every [Am]tree
Every single [D]blade of grass
Holds a special place for [G]me
And I remember every town
And every hotel [Am]room
And every song I [D]ever sang
On a guitar out of [G]tune
 
{soc}
  I remember [C]everything
  Things I can’t for[G]get
  The way you turned and [A7]smiled on me
  On the night that we first [D]met
  And I remember [C]every night
  Your ocean eyes of [G]blue
  How I miss you in the [D]morning light
  Like roses miss the [G]dew
{eoc}
 
[C]/ / / /   / / / /
[G]/ / / /   / / / /
[D]/ / / /   / / / /
[G]/ / / /   / /
 
I’ve been down this [G]road before
Alone as I can [Am]be
Careful not to [D]let my past
Go sneaking up on [G]me
Got no future in my happiness
Though regrets are very [Am]few
Sometimes a little [D]tenderness
Was the best that I could [G]do
 
{soc}
  I remember [C]everything
  Things I can’t for[G]get
  Swimming pools of [A7]butterflies
  That slipped right through the [D]net
  And I remember [C]every night
  Your ocean eyes of [G]blue
  How I miss you in the [D]morning light
  Like roses miss the [G]dew
{eoc}
 
How I miss you in the [D]morning light
Like roses miss the [G]dew [C/] [G/]
