{title:  FREIGHT TRAIN      }
{subtitle:(4/4      Key of C)}
{subtitle:(Elizabeth Cotton)}
{time: 2:25}
{metronome: 190}







{c:INTRO: }
[C]/ /    [G7]/ /    [C]/ / / /
[C]/ /    [G7]/ /    [C]/ / / /

{c:CHORUS}
{soc}
  [C]Freight train, freight train, [G7]goin'so fast
  Freight train, freight train, [C]goin' so fast
  [E7]Please don't say what [F]train I'm on
  So they [C]won't know [G7]where I'm [C]gone
{eoc}

[C]Freight train, freight train, [G7]goin' round the bend
Freight train, freight train, [C]comin' back again
[E7]One of these days turn that [F]train around
And go [C]back to [G7]my home [C]town

{soc}
  [C]Freight train, freight train, [G7]goin' so fast
  Freight train, freight train, [C]goin' so fast
  [E7]Please don't say what [F]train I'm on
  So they [C]won't know [G7]where I'm [C]gone
{eoc}

[C]One more place I'd [G7]like to be
One more place I’d [C]like to see
To [E7]watch them old Blue Ridge [F]Mountains climb
When I [C]ride old [G7]Number [C]Nine

{soc}
  [C]Freight train, freight train, [G7]goin'so fast
  Freight train, freight train, [C]goin' so fast
  [E7]Please don't say what [F]train I'm on
  So they [C]won't know [G7]where I'm [C]gone
{eoc}

[C]When I die Lord, [G7]bury me deep
Down at the end of [C]Chestnut Street
[E7]Where I can hear old [F]Number Nine
As [C]she comes [G7]down the [C]line

{soc}
  [C]Freight train, freight train, [G7]goin'so fast
  Freight train, freight train, [C]goin' so fast
  [E7]Please don't say what [F]train I'm on
  So they [C]won't know [G7]where I'm [C]gone
{eoc}
   
[C]/ /    [G7]/ /    [C]/ / / /
[C]/ /    [G7]/ /    [C]/ 


