

{title:C02: AWAY IN A MANGER  }
{subtitle:  Key of G    3/4}
{subtitle:(Franz Gruber)}
{time: 2:00}
{metronome:94 }



[G7]/ / /    [C]/ / /    
[Dm]/ /    [G]/    [C]/ / 

A[C]wa…y in a manger
no [F]crib for a [C]bed
The [G]little Lord Jesus 
laid [C]down his sweet head

The [C]stars in the bright sky 
looked [F]down where he [C]lay
The [G7]little Lord [C]Jesus 
a[Dm]sleep on [G]the [C]hay

The [C]cattle are lowing
the [F]baby a[C]wakes
The [G]little lord Jesus
no [C]crying he makes

I [C]love Thee Lord Jesus
look [F]down from the [C]sky
And [G7]stay by my [C]cradle 
till [Dm]morning [G]is [C]nigh

Be [C]near me Lord Jesus
I [F]ask Thee to [C]stay
Close [G]by me for ever 
and [C]love me I pray

Bless all the dear children 
in [F]Thy tender [C]care
And [G7]fit us to [C]Heaven 
To [Dm]live with [G]Thee [C/]there


















