

{title:154  DO WAH DIDDY-DIDDY }
{subtitle:(4/4    Key of C)}      
{subtitle:(Jeff Barry & Ellie Greenwich)}
{time:3:01}
{metronome:128}






[C]/ / / /     [F]/ /     [C]/   {c:(stop)} 

There she was just a walkin' down the street 
Singin' “[C]Do wah diddy diddy [F]dum diddy [C]doo” 
[C]Snappin' her fingers and [F]shufflin' her [C]feet 
Singin' “[C]Do wah diddy diddy [F]dum diddy [C/]doo” 
She looked good ([C/]looked [C/]good) 
She looked fine ([C/]looked [C/]fine) 
She looked [C/]good she looked [C/]fine 
And I [C/]nearly lost my [C/]mind 

Be[C]fore I knew it she was [F]walkin' next to [C]me 
Singin' “[C]Do wah diddy diddy [F]dum diddy [C]doo” 
[C]Holdin' my hand just as [F]natural as can [C]be 
Singin' “[C]Do wah diddy diddy [F]dum diddy [C/]doo” 
We walked on ([C/]walked [C/]on) 
To my door ([C/]my [C/]door) 
We walked [C/]on to my [C/]door 
Then we [C/]kissed a little [C/]more 
{c:(}[C]{c:1234)} [C7]      Whoa-whoa I [Am]knew we was falling in lo-o-ove 
{c:(}[F]{c:1234,1)} Yes I did and so I 
[G7]Told her all the things I'd been dreamin' of 

Now [C]we're together nearly [F]every single [C]day 
Singin' “[C]Do wah diddy diddy [F]dum diddy [C]doo” 
A-[C]we're so happy and that’s [F]how we're gonna [C]stay 
Singin' “[C]Do wah diddy diddy [F]dum diddy [C/]doo” 
I'm hers ([C/]I’m [C/]hers), she's mine ([C/]she's [C/]mine) 
I'm [C/]hers she's [C/]mine wedding [C/]bells are gonna [C/]chime
{c:(}[C]{c:1234)} [C7]      Whoa-whoa I [Am]knew we was falling in love 
{c:(}[F]{c:1234,1)} Yes I did and so I 
[G7]Told her all the things I'd been [G7/]dreamin' of

Now [C/]we're together nearly every single day
Singing [C]“Do wah diddy diddy [F]dum diddy [C]doo”
A-[C]we're so happy and that's [F]how we're gonna [C]stay
Singin' “[C]Do wah diddy diddy [F]dum diddy [C/]doo”
Well I'm hers ([C/]I’m [C/]hers), she's mine ([C/]she's [C/]mine)
I'm [C/]hers, she's [C/]mine, wedding [C/]bells are gonna [C/]chime
[G7] Whoa-oh-oh-oh, {c:(beat)} oh yeah {c:(3,4)}
  
[C]Do wah diddy diddy [F]dum diddy [C]doo {c:(we'll sing it)}

[C]Do  wah  diddy  diddy   [F]dum diddy [C]doo

[C]Do wah diddy diddy [F]dum diddy [C/]doo

_______________________________

















