{title:     DRUNKEN SAILOR    }
{subtitle: 4/4    Key of Dm}       
{metronome: 90 }
{time: 3:00}




{c:INTRO: four strums}
[Dm] /   /   /   / 
                                         
[Dm]What shall we do with a drunken sailor
[C]What shall we do with a drunken sailor
[Dm]What shall we do with a drunken sailor
[C]Early in the [Dm]mornin

{soc}
     [Dm]Hoo-ray, and up she rises  
     [C]Hoo-ray, and up she rises
     [Dm]Hoo-ray, and up she rises  
     [C]Early in the [Dm/]mor[Dm/]ning
{eoc}

[Dm]Put him in a long-boat 'til he's sober
[C]Put him in a long-boat 'til he's sober
[Dm]Put him in a long-boat 'til he's sober
[C]Early in the [Dm]morning 
                                  
{soc}
     [Dm]Hoo-ray, and up she rises  
     [C]Hoo-ray, and up she rises
     [Dm]Hoo-ray, and up she rises  
     [C]Early in the [Dm/]mor[Dm/]ning
{eoc}

[Dm]Put him in the scuppers with a hosepipe on him
[C]Put him in the scuppers with a hosepipe on him
[Dm]Put him in the scuppers with a hosepipe on him
[C]Early in the [Dm]morning                                    

{soc}
     [Dm]Hoo-ray, and up she rises  
     [C]Hoo-ray, and up she rises
     [Dm]Hoo-ray, and up she rises  
     [C]Early in the [Dm/]mor[Dm/]ning
{eoc}

[Dm]Put him in the hold with the Captain's daughter
[C]Put him in the hold with the Captain's daughter
[Dm]Put him in the hold with the Captain's daughter
[C]Early  in the [Dm]morning 

{soc}
     [Dm]Hoo-ray, and up she rises  
     [C]Hoo-ray, and up she rises
     [Dm]Hoo-ray, and up she rises  
     [C]Early in the [Dm/]mor[Dm/]ning
{eoc}

[Dm]Shave his belly with a rusty razor
[C]Shave his belly with a rusty razor
[Dm]Shave his belly with a rusty razor
[C]Early in the [Dm]morning 
    
{soc}
     [Dm]Hoo-ray, and up she rises  
     [C]Hoo-ray, and up she rises
     [Dm]Hoo-ray, and up she rises  
     [C]Early in the [Dm/]mor[Dm/]ning
{eoc}