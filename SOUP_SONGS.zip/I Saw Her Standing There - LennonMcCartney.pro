{title: I SAW HER STANDING HER THERE}
{SUBTITLE: 4/4      Key of C}
{subtitle: Lennon/McCartney}
{metronome: 164}
{time 2:25}




{c:MARTIN says }
{c:”one two three four!”}

{c:INTRO:  C7 ////   C7 ////   C7 ////  C7 //}

Well she was [C7]just seventeen
And you [F]know what I [C7]mean
And the way she looked, was way beyond com[G7]pare 
So [C]how could I [C7]dance with a[F]nother [Fm]wooo
When I [C]saw her [G7]standing [C]there

Well [C7]she looked at me
And [F]I, I could [C7]see
That before too long, I’d fall in love with [G7]her 
[C]She wouldn’t [C7]dance with a[F]nother [Fm]woooo
When I [C]saw her [G7]standing [C]there

Well my [F]heart went boom
When I crossed that room
And I held her hand in [G7]mi-i-i-i-[F]ine  [F/]

Whoa we [C7]danced through the night
And we [F]held each other [C7]tight
And before too long, I fell in love with [G7]her 
Now [C]I’ll never [C7]dance with a[F]nother [Fm]woooo
When I [C]saw her [G7]standing [C]there

Well my [F]heart went boom
When I crossed that room
And I held her hand in [G7]mi-i-i-i-[F]ine  [F/]

Ooh we [C7]danced through the night
And we [F]held each other [C7]tight
And before too long, I fell in love with [G7]her 
Now [C]I’ll never [C7]dance with a[F]nother [Fm]wooo
Since I [C]saw her [G7]standing [C]there 
Oh since I saw her [G7]standing [C]there
Yeah well since I [C]saw her [G7]standing 
[F]there…  [C]{c:dudu}