

{title:C09: HAVE YOURSELF A MERRY }
{title:LITTLE CHRISTMAS}
{subtitle:   4/4  Key of G}
{subtitle:(Ralph Blane)}
{metronome:84  }
{time:2:33}


[G]/ /    [Em]/ /     [Am]/ /     [D7]/ /   
[G]/ /    [Em]/ /     [Am]/ /     [D7]/ / 
       
[G]Have your[Em]self a 
[Am]Merry little [D7]Christmas
[G] Let your [Em]heart be [Am]light   [D7] 
[G]From now [Em]on our [Am]troubles will be 
[D7]out of [B7]sight   [E7]         [A7]        [D7]

[G]Have your[Em]self a 
[Am]Merry little [D7]Christmas
[G] Make the [Em]Yuletide [Am]gay  [D7]
[G]From now [Em]on our [Am]troubles will be 
[B7]Miles a[Em]way {c:(234)}    [G]    {c:(234)}

[C]Here we [Cm]are as in [Bm]olden days
Happy [Am]golden days [D7]     of   [Gmaj7]Yore
[Em]Faithful friends who are [Bm]dear to us
Gather [D]near to us [A7]    once [D7]more

[G]Through the [Em]years we 
[Am]All will be to[D7]gether
[G] If the [Em]fates al[Am]low     [D7]
[G]Hang a [Em]shining [Am]star 
Upon the [D7]highest [B7]bough {c:(234)} [G7]  {c:(23)}
And [C]have yourself a 
[Am]Merry little [D7]Christmas [G/gliss]now














{define: D7  0 2 0 2 0}
