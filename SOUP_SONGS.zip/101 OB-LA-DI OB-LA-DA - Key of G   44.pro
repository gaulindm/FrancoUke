

{title:101  OB-LA-DI OB-LA-DA  }
{subtitle: Key of G   4/4}
{subtitle:Paul McCartney, John Lennon (The Beatles)}
{metronome:128}
{time:3:25}


{c:KAZOO}





{c:A string: }[D/]{c:5-555-55}[D/]{c:5-4-5-2 }  [G]/ / / /    / / / /

[G]Desmond has a barrow in the [D]market place
[D7]Molly is the singer in a [G]band
Desmond says to [G7]Molly "Girl I [C]like your face" 
And Molly [G]says this 
As she [D7]takes him by the [G]hand {c:(23)}

{soc}
     Ob-la-[G]di ob-la-da life goes [D]on [Em]brah 
     [G]La, la how the [D7]life goes [G]on
     Ob-la-di ob-la-da life goes [D]on [Em]brah 
     [G]La, la how the [D7]life goes [G]on  {c:(234)}
{eoc}

[G]Desmond takes a trolley to the [D]jeweller’s store 
[D7]Buys a twenty carat golden [G]ring (↑ring)
Takes it back to [G7]Molly waiting [C]at the door
And as he [G]gives it to her 
[D7]She begins to [G]sing (↑sing)

{c:(add la la’s to all choruses now)}
{soc}
   Ob-la-[G]di ob-la-da life goes [D]on [Em]brah 
   [G]La, la how the [D7]life goes [G]on
   Ob-la-di ob-la-da life goes [D]on [Em]brah 
   [G]la, la how the [D7]life goes [G]on  {c:(234)}
{eoc}

[C] In a couple of years they have built a 
Home sweet {c:(kazoo)} [G]home  [Gsus2]/ /         [G]/ /    [G7]/ /
[C] With a couple of kids running in the yard 
Of [G]Desmond and Molly [D7]Jones  {c:(beat)}  
Ha ha ha ha

[G]Happy ever after in the [D]market place 
[D7]Desmond lets the children lend a [G]hand
Molly stays at [G7]home and does her [C]pretty face 
And in the [G]evening she still 
[D7]Sings it with the [G]band, yes

{soc}
   OB-LA-[G]DI, ob-la-da life goes [D]on [Em]brah 
   [G]La, la how the [D7]life goes [G]on, yeah
   OB-LA-DI, ob-la-da life goes [D]on [Em]brah
   [G]la la how the [D7]life goes [G]on  {c:(234)}
{eoc}

[C] In a couple of years they have built a 
Home sweet {c:(kazoo)} [G]home  [Gsus2]/ /         [G]/ /    [G7]/ /
[C] With a couple of kids running in the yard
Of [G]Desmond and Molly [D7]Jones  
(ha ha ha ha ha)

[G]Happy ever after in the [D]market place
[D7]Molly lets the children lend a [G]hand
Desmond stays at [G7]home 
And does his [C]pretty face
And in the [G]evening she’s a 
[D7]Singer with the [G]band, yeah

{soc}
  OB-LA-[G]DI, OB-LA-DA, life goes [D]on [Em]brah
  [G]La, la how the [D7]life goes [G]on, yeah
  OB-LA-[G]DI, OB-LA-DA, life goes [D]on [Em]brah
  [G]La, la how the [D7]life goes [Em]on 
  {c:(ha,ha,ha,ha,ha)} 
  But if you want some fun {c:(ha, ha, ha...)}    
  Sing  [G/]Ob-la-[D7/]di- bla-[G/]da!  Hey!
{eoc}

{define Gsus2: 0 0 2 3 0}

_________________________________________









