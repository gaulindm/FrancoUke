{title: MAD WORLD}
{subtitle:4/4    Key of Am}
{subtitle: (Gary Jules)
{metronome: }
{time:3:19}







{c:INTRO:}  
[Am]/ / / /    [C]/ / / /     
[G]/ / / /    [D]/ / / /
[Am]/ / / /    [C]/ / / /     
[G]/ / / /    [D]/ / / /

[Am]   All around me are fa[C]miliar faces
[G]Worn out places, [D]worn out faces
[Am]   Bright and early for their [C]daily races
[G]Going nowhere, [D]going nowhere
{c:(}[Am]{c:123)}   Their tears are filling [C]up their glasses
[G]No expression, [D]no expression
[Am]   Hide my head, I want to [C]drown my sorrow
[G]No tomorrow, [D]no tomorrow
 
 
{c:CHORUS}
[Am]   And I find it kinda [D]funny, I find it kinda [Am]sad
The dreams in which I'm [D]dying are the best I've ever [Am]had
I find it hard to [D]tell you, I find it hard to [Am]take
When people run in [D]circles, it's a very, very
[Am]   Mad [D]world
[Am]   Mad [D]world
 
 
[Am]   Children waiting for the [C]day they feel good
[G]Happy birthday, [D]happy birthday
[Am]   Made to feel the way that [C]every child should
[G]Sit and listen, [D]sit and listen
[Am]   Went to school, and I was [C]very nervous
[G]No one knew me, [D]no one knew me
[Am]   Hello, teacher, tell me [C]what's my lesson
[G]Look right through me, [D]look right through me
 
 
{c:CHORUS}
[Am]   And I find it kinda [D]funny, I find it kinda [Am]sad
The dreams in which I'm [D]dying are the best I've ever [Am]had
I find it hard to [D]tell you, I find it hard to [Am]take
When people run in [D]circles, it's a very, very
[Am]   Mad [D]world
[Am]   Mad [D]world
[Am]   Enlarge your [D]world
[Am]   Mad [D]world    [Am/]
