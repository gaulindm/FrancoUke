

{title:BIRD ON A WIRE }
{subtitle:(3/4      Key of C)} 
{subtitle:(Leonard Cohen) }
{time:4:03}
{metronome: 152}






[C]/ / /     [G7]/ / /     [C]/ / /   /  {c:(stop)}

Li…ke a [C]bird on a [G7]wire
Like a [C]drunk in a [C7]midnight [F]choir   I have [C]tried in my [G7]way 
To be [C]free  [Csus4](123)        [C](123,1) Li…ke a [C]worm on a [G7]hook
Like a [C]knight from some 
[C7]Old-fashioned [F]book  I have [C]saved all my [G7]ribbons 
For [C]thee  ([Csus4]123)      ([C]123,123)

If [F]I… if I have been un[C]kind  I [D7]hope that you can just let it go [G7]by  [G7+5] If [F]I… if I have been un[C]true I [D7]hope you know it was never to [G7]you  [G7+5]

Like a [C]baby still[G7]born
Like a [C]beast   [C7]       with his [F]horn  I have [C]torn every[G7]one 
Who reached out for [C]me ([Csus4]123)     ([C]123,1) But I [C]swear by this [G7]song 
And by [C]all that [C7]I have done [F]wrong  I will [C]make it [G7]all up to 
[C]Thee ([Csus4]123)     ([C]123,123)

[F]  I saw a beggar leaning 
On his wooden [C]crutch  He [D7]said to me
"You must not ask for so [G7]much"  [G7+5] And a [F]pretty woman 
Leaning in her darkened [C]door  She [D7]cried to me
"Hey, why not ask for [G7]more?  [G7+5]

Like a [C]bird on a [G7]wire
Like a [C]drunk in a [C7]midnight [F]choir  I have [C]tried in my [G7]way to be [F]free  [C/gliss]

________________________________




{define: Csus4 0 0 0 1 3}
{define: D7 0 2 0 2 0}
{define: G7+5 0 0 3 1 2}









