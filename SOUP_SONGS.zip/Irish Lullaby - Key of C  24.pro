{title:Irish Lullaby}
{subtitle:Key of C  2/4}




[C/]

[C]Over in Killarney  [Am]many years a[G]go  
Me [C]Mother sang a [Am]song to me 
In [D7]tones so sweet and [G]low  
Just a [C]simple little ditty
In her [Am]good ould Irish [G]way 
And l'd [F]give the world if [C]she could 
[Am]Sing that [D7]song to me this [G]da-[Gaug]ay

[C]Too-ra-loo-ra-[C7]loo-ral   
[F]Too-ra-loo-ra-[D7]li
[C]Too-ra-[F]loo-ra-[C]loo-ral [Am]       
[D7]hush now don't you [G]cry [G7]
[C]Too-ra-loo-ra-[C7]loo-ral   
[F]Too-ra-loo-ra-[D7]li
[C]Too-ra-[F]loo-ra-[C]loo-ral [A7]   
that's an [D7]I-i-rish [G]lul-uh-la-[C]by 

[C]Oft in dreams I wander  [Am]to that cot a[G]gain 
I  [C]feel her arms a-[Am]huggin' me 
As [D7]when she held me [G]then. 
And I [C]hear her voice a -hummin' to me 
[Am]As in days of [G]yore  
When she [F]used to rock me [C]fast as[Am]leep 
Out[D7]side the cabin [G]do-[Gaug]or 


[C]Too-ra-loo-ra-[C7]loo-ral   
[F]too-ra-loo-ra-[D7]li
[C]Too-ra-[F]loo-ra-[C]loo-ral  [Am]       
[D7]Hush now don't you [G]cry  [G7]
[C]Too-ra-loo-ra-[C7]loo-ral   
[F]Too-ra-loo-ra-[D7]li
[C]Too-ra-[F]loo-ra-[C]loo-ral  [A7]   
That's an [D7]I-i-rish [G]lul-uh-la-[C]by 

That's an [D7]I-i-rish [G]lul-uh-la-[C]by
{c:slow down}
that's an [D7]I-i-rish [G]lul-uh-la-[C/]by

{define: Gaug 0 0 3 3 2}