{title:WAKE ME UP      4/4      Key of Dm}
{subtitle:AVICII}


 
[Intro]
[Dm]/ / / /    [Bb]/ / / /    [F]/ / / /    [C]/ / / /
[Dm]/ / / /    [Bb]/ / / /    [F]/ / / /    [C]/ / / /


[Dm] Feeling my [Bb]way through the [F]darkness
[Dm] Guided [Bb]by a beating [F]hea-↑art  
[Dm] I can’t [Bb]tell where the [F]journey will end
[Dm] But I [Bb]know where to [F]start 
[Dm] They tell me [Bb]I’m too [F]young to understand
[Dm] They say I’m [Bb]caught up in a [F]drea-↑am 
[Dm] Well life will [Bb]pass me by if [F]I don’t open up my eyes
[Dm] Well that’s [Bb]fine by [F]me 
 
{c:CHORUS:}
So wake me [Dm]up when [Bb]it’s all [F]over  [C]
When I’m [Dm]wiser [Bb]and I’m [F]older  [C]
All this [Dm]time I was [Bb]finding my[F]self and [C]I,
[Dm] Didn’t [Bb]know I was [F]lost  [C]
So wake me [Dm]up when [Bb]it’s all [F]over  [C]
When I’m [Dm]wiser [Bb]and I’m [F]older  [C]
All this [Dm]time I was [Bb]finding my[F]self and [C]I
[Dm] I didn’t [Bb]know I was [F]lost [C]
 
[Verse]
[Dm]I tried [Bb]carrying the [F]weight of the [F]world
[Dm]But I [Bb]only have two [F]hands [F]
[Dm]Hope I get[Bb] the chance to [F]travel the [F]world
[Dm]And I [Bb]don’t have any [F]plans [F]
[Dm]Wish that [Bb]I could stay fo[F]rever this [F]young
[Dm]Not a[Bb]fraid to close my [F]eyes [F]
[Dm]Life’s a [Bb]game made for [F]every[F]one
[Dm]And [Bb]love is a [F]prize [F]
 
[Fhorus]
So wake me [Dm]up when [Bb]it’s all [F]ove[C]r
When I’m [Dm]wiser [Bb]and I’m [F]old[C]er
All this [Dm]time I was [Bb]finding [F]mys[C]elf
And I [Dm]didn’t [Bb]know I was [F]los[C]t
So wake me [Dm]up when [Bb]it’s all [F]ove[C]r
When I’m [Dm]wiser [Bb]and I’m [F]old[C]er
All this [Dm]time I was [Bb]finding [F]mys[C]elf
And I [Dm]didn’t [Bb]know I was [F]los[C]t
 
[Outro]
[Dm]I didn’t [Bb]know I was [F]los[C]t
[Dm]I didn’t [Bb]know I was [F]los[C]t
[Dm]I didn’t [Bb]know I was [F]los[C]t
[Dm]I didn’t [Bb]know I (did[F]n’t[C] know I, didn’t know I)
X