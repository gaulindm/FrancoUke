{title:HEY THERE DELILAH }
{subtitle  4/4     Key of D}
{subtitle:(Plain White T's)}
{metronome:104}
{time:3:06}





{c:INTRO:}
[D]/ / / /    
[F#m]/ / / /    
[D]/ / / /    
[F#m]/ / / /

[D] Hey there, Delilah
What's it [F#m]like in New York city?
I'm a [D]thousand miles away
But girl to[F#m]night you look so pretty
Yes, you [Bm(2,3,4)]do
[G]  Times square can't [A]shine as bright as [Bm]you
I swear, it's [A]true   {c:(234)}

[D] Hey there, Delilah
Don't you [F#m]worry about the distance
I'm right [D]there if you get lonely
Give this [F#m]song another listen
Close your [Bm]eyes   {c:(234)}
[G] Listen to my [A]voice, it's my dis[Bm]guise
I'm by your [A]side   {c:(234)}

[D]Oh, it's what you do to [Bm]me
[D]Oh, it's what you do to [Bm]me
[D]Oh, it's what you do to [Bm]me
[D]Oh, it's what you do to [Bm]me
What you do to [D]me

[D] Hey there, Delilah
I know [F#m]times are gettin' hard
But just be[D]lieve me, girl
Someday I'll pay the [F#m]bills with this guitar
We'll have it [Bm]good
[G] We'll have the [A]life we knew we [Bm]would
My word is [A]good  {c:(234)}

[D] Hey there, Delilah
I've got [F#m]so much left to say
If every [D]simple song I wrote to you
Would [F#m]take your breath away
I'd write it [Bm]all
[G] Even more in [A]love with me you'd [Bm]fall
We'd have it [A]all    {c:(234)}

[D]Oh, it's what you do to [Bm]me
[D]Oh, it's what you do to [Bm]me
[D]Oh, it's what you do to [Bm]me
[D]Oh, it's what you do to [Bm]me

A t[G]housand miles seems pretty far
But [A]they've got planes and trains and cars
I'd [D]walk to you if I had no other [Bm]way
Our [G]friends would all make fun of us
And [A]we'll just laugh along because we [D]know
That none of them have felt this [Bm]way
De[G]lilah, I can promise you
That [A]by the time we get through
The [Bm]world will never ever be the same
And you're to [A]blame  {c:(234,1234)}

[D] Hey there, Delilah
You be [F#m]good, and don't you miss me
Two more [D]years and you'll be done with school
And [F#m]I'll be makin' history like I [Bm]do
[G] You'll know it's [A]all because of [Bm]you
[G] We can do what[A]ever we want [Bm]to
[G] Hey there, De[A]lilah, here's to [Bm]you
{c:Slow down}
This ones for [A]you
