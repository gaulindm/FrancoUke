{title:TEQUILA SUNRISE    }
{subtitle: 4/4   Key of G}
{subtitle:(G. Frey & D. Henley)}
{time:2:50}
{metronome:112}


{c:tip: to make the riff easy, keep the G chord shape}




{c:INTRO:}
[G]/ /    [G6]/ /    [G]/ /    [G6]/ /    
[G]/ /    [G6]/ /    [G]/   {c:(234)}

{sot}                   
A| -2-2-0- - -  (optional intro riff is played    
E| - - - - 3 -  during the (234) count)
{eot}

[Am]/ / / /    [D7]/ / / /    
[G]/ /    [G6]/ /    [Gmaj7]/ /    [G6]/ /
 
[G] It's another tequila sunrise  
[D] Starin' slowly 'cross the [Am]sky... 
[D7] Said good↑[G]bye...  [G6]/ /    [Gmaj7]/ /       [G6]/ /

[G] He was just a hired hand  
[D] Workin' on the drea...ms-he-planned to [Am]try...
[D7] The days go [G]by...  [G6]/ /    [Gmaj7]/ /       [G6]/ /

{c:(Add oos)} 
[Em] Every night when the [C]sun goes down  
[Em] Just another [C]lonely-boy in-town     [Em]/ / / /
And [Am]she's ↑out runnin' 
[D7]Ro...{c:(234)}...↑oo...oo-oo-ound  

[G]  She wasn't just ano...ther woman 
[D]  And I couldn't kee...p from co...min' [Am]on    
[D7] It's been so ↑[G]lo-↓o-↑o-↓o[G6]ng    [Gmaj7]/ /   [G6]/ /

[G] Oh, and it's a hollow feelin' 
[D] When it comes do...wn to dea...lin' [Am]friends
[D7] It never [G]e... [G6]e... e-ends   [G/]     {c:(234)}

[G]/ / / /   / / / /    
[D]/ / / /   / / / /    
[Am]/ / / /    [D7]/ / / /    
[G]/ /    [G6]/ /    [Gmaj7]/ /    [G6]/ /

[Am] Take another [D]shot of courage 
{c:(Ooo...                    ↑ooo                    )}
[Bm] Wonder why the [E7]right words never [Am]co... [B]me
{c:(Ooo...                          ↓ooo                         co... ↓me) }        
You just get [Em]numb {c:(234)}  [A]
{c:                    (↓nu...              ↓umb)} 

[G]  It's another tequila sunrise 
[D]  This old world still looks the [Am]same
[D7] Another [G]fra...[G6]ame      [Gmaj7]/ /    [G6]/ /

[G]/ /    [G6]/ /    [Gmaj7]/ /    [G6]/ /
 
[G]Oo... [G6]oo... [Gmaj7]oo...     [G6]oo...       [G/]                                           

