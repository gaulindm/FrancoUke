
{title:THE WEIGHT}
{subtitle:(4/4      Key of G)}
{subtitle:(Robbie Robertson)}
{time:5:10}
{metronome: 145}






[G]/ / / /      [Bm7]/ / / /      
[C]/ / / /     [G]/ / / /

[G]  I pulled into [Bm7]Nazareth, just 
[C]feeling about half past [G]dead
[G]  I just need some [Bm7]place where 
[C]I can lay my [G]head
[G]  Hey, Mister, can you [Bm7]tell me 
Where a [C]man might find a [G]bed
[G]  He just grinned, and [Bm7]shook my hand 
“[C]No" was all he [G]said

{soc}
   [G]    Take a [D]load off [C]Fanny
   [G]    Take a [D]load for [C]free
   [G]    Take a [D]load off, [C]Fanny {c:(3,4)}
   [C]/ /   Aa…aa…and…
   
   You put the load, put the load right on 
   [G//]me   [Bm7]/ /      [Em]/ /     [G]/ /      
   [C]/ / / /    / / / /
{eoc}

[G] I picked up my [Bm7]bag, I went 
[C]Looking for a place to [G]hide
[G] When I saw [Bm7]Carmen and the devil 
[C]Walking side by [G]side
[G] I said, “Hey, [Bm7]Carmen, come 
[C]On, let's go down[G]town”    
[G] She said, “[Bm7]I got to go, but my 
[C]Friend can stick a[G]round”

{soc}
   [G]    Take a [D]load off [C]Fanny
   [G]    Take a [D]load for [C]free
   [G]    Take a [D]load off, [C]Fanny {c:(3,4)}
   [C]/ /   Aa…aa…and…
   
   You put the load, put the load right on 
   [G//]me   [Bm7]/ /      [Em]/ /     [G]/ /      
   [C]/ / / /    / / / /
{eoc}

[G] Go down, Miss [Bm7]Moses, there's 
[C]Nothing you can [G]say
[G] It's just old [Bm7]Luke, and Luke's 
A[C]’waiting on the judgement [G]day
[G] Well, Luke, my [Bm7]friend, what 
A[C]bout young Anna [G]Lee
[G] He said, "Do me a [Bm7]favor, son, won't you 
[C]Stay and keep Anna Lee [G]company?”

{soc}
   [G]    Take a [D]load off [C]Fanny
   [G]    Take a [D]load for [C]free
   [G]    Take a [D]load off, [C]Fanny {c:(3,4)}
   [C]/ /   Aa…aa…and…
   
   You put the load, put the load right on 
   [G//]me   [Bm7]/ /      [Em]/ /     [G]/ /      
   [C]/ / / /    / / / /
{eoc}

[G] Crazy Chester [Bm7]followed me and he 
[C]Caught me in the [G]fog
[G] He said, “I will [Bm7]fix your rack if 
[C]You'll take Jack my [G]dog”
[G] I said, “Wait a minute, [Bm7]Chester 
You know [C]I'm a peaceful [G]man” 
[G] He said, “That's [Bm7]okay, boy 
Won't you [C]feed him when you [G]can” 

{soc}
   [G]    Take a [D]load off [C]Fanny
   [G]    Take a [D]load for [C]free
   [G]    Take a [D]load off, [C]Fanny {c:(3,4)}
   [C]/ /   Aa…aa…and…
   
   You put the load, put the load right on 
   [G//]me   [Bm7]/ /      [Em]/ /     [G]/ /      
   [C]/ / / /    / / / /
{eoc}

[G] Catch a [Bm7]cannonball now, to 
[C]Take me down the [G]line
[G] My bag is [Bm7]sinkin’ low, and I 
[C]Do believe it's [G]time
[G] To get back to Miss [Bm7]Fanny 
You know [C]she's the only [G]one 
[G] Who sent me [Bm7]here with her 
Re[C]gards for every[G]one

{soc}
   [G]    Take a [D]load off [C]Fanny
   [G]    Take a [D]load for [C]free
   [G]    Take a [D]load off, [C]Fanny {c:(3,4)}
   [C]/ /   Aa…aa…and…
   
   You put the load, put the load right on 
   [G//]me   [Bm7]/ /      [Em]/ /     [G]/ /      
   [C]/ / / /    / / / /

   [G]/ /    [Bm7]/ /      [Em]/ /     [G]/ /   
   [C]/ / / /    / / / /      [G]/
{eoc}

____________________________________
















