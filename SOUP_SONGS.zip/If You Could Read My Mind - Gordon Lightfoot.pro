{title:IF YOU COULD READ MY MIND}
{subtitle:  4/4      Key of A}
{subtitle:Gordon Lightfoot}
{time:4:30}
{metronome:132}


[A]/ / / /   / / / /

[A] If you could read my mind love
[G] What a tale my thoughts could tell
[A] Just like an old time movie
[G] 'bout a ghost from a wishin' well
[A] In a castle [A7]dark or a [D]fortress strong
With [E7]chains upon my [F#m]feet
You [D]know that ghost is [A]me
And [D]I will never [A]be set free
As [Bm7]long as I'm a [E7]ghost that you can't [A]see   [A]
 
 
[A] If I could read your mind love
[G] What a tale your thoughts could tell
[A] Just like a paperback novel
[G] The kind that drugstores sell
[A] When you reach the [A7]part where the [D]heartaches come
The [E7]hero would be [F#m]me
But [D]heroes often [A]fail
And [D]you won't read that [A]book again
Bec[Bm7]ause the ending's [E7]just too hard to [A]take   [A]
 
[G]/ / / /   / / / /
[A]/ / / /   / / / /
[G]/ / / /   / / / /
 
[A] I'd walk a[A7]way like a [D]movie star
Who gets [E7]burned in a three way [F#m]script
[D]Enter number [A]two
A [D]movie queen to [A]play the scene
Of [Bm7]bringing all the [E7]good things out in[F#m] me
But for [D]now love, let's be [A]real
I [D]never thought I could [A]act this way 
And I've [Bm7]got to say that I [E7]just don't get it
[D]I don't know where [A]we went wrong
But the [Bm7]feelin's gone
And I [E7]just can't get it [A]back 

 
[A] If you could read my mind love
[G] What a tale my thoughts could tell
[A] Just like an old time movie
[G] 'bout a ghost from a wishin' well
[A] In a castle [A7]dark or a [D]fortress strong
With [E7]chains upon my [F#m]feet
But [D]stories always [A]end
And [D]if you read be[A]tween the lines
You'll [Bm7]know that I'm just [E7]tryin' to under[F#m]stand
The [D]feelin's that you [A]lack
I [D]never thought I could [A]feel this way
And I've [Bm7]got to say that I [E7]just don't get it
[D]I don't know where [A]we went wrong
But the [Bm7]feelin's gone
And I [E7]just can't get it [A]back   [A]

{c:(slow down)}
[G]/ / / /   / / / /
[A]/ / / /    /

________________________________

















 