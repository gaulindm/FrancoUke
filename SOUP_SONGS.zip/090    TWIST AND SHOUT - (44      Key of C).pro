

{t:090  TWIST AND SHOUT  } 
{subtitle:(4/4      Key of C)}
{subtitle:(Phil Medley & Bert Burns)}
{time:2:39}
{metronome:134}





[C]/ /     [F]/ /     [G7]/ / / /     
[C]/ /     [F]/ /     [G7]/ /

Well [G7]shake it up [C]baby, now 
([F]Shake it up [G7]baby)
Twist and [C]shout ([F]twist and [G7]shout)
C'mon, c'mon, c'mon, c'mon [C]baby, now 
([F]Come on [G7]baby)
C’mon and work it on [C]out 
(Come on and [F]work it on [G7]out) 

Well, work it on [C]out, now 
([F]Work it on [G7]out)
You know you look so [C]good 
([F]Look so [G7]good)
You know you got me [C]goin', now 
([F]Got me [G7]goin')
Like I knew you [C]would 
(Like I [F]knew you [G7]would)  

Well shake it up [C]baby, now 
([F]Shake it up, [G7]baby)
Twist and [C]shout ([F]twist and [G7]shout)
C'mon, c'mon, c'mon, c'mon [C]baby, now 
([F]Come on [G7]baby)
C’mon and work it on [C]out 
([F]Work it on [G7]out)
Well you twist little [C]girl 
([F]Twist little [G7]girl)
You know you twist so [C]fine 
([F]Twist so [G7]fine)
Come on and twist a little [C]closer now 
([F]Twist a little [G7]closer)
Let me know that you're [C]mine 
(Let me [F]know you’re [G7]mine) {c:(234)}

{c:INSTRUMENTAL:}
[C]/ /     [F]/ /     [G7]/ / / /     
[C]/ /     [F]/ /     [G7]/ / / /

{c:(BUILDING)}

[G]/ / / /         / / / /          / / / /         / / / /   
Aahh...   aahh...      aahh...     aahh...    

{c:(let loose!)}                
[G7]/ / / /   / /    
Aahhh…!


Yeah shake it up [C]baby, now 
([F]Shake it up, [G7]baby)
Twist and [C]shout ([F]twist and [G7]shout)
C'mon, c'mon, c'mon, c'mon [C]baby, now 
([F]Come on [G7]baby)
Come on and work it on [C]out 
([F]Work it on [G7]out)
Well you twist little [C]girl 
([F]Twist little [G7]girl)
You know you twist so [C]fine 
([F]Twist so [G7]fine)
Come on and twist a little [C]closer now 
([F]Twist a little [G7]closer)
And let me know that you're [C]mine 
(Let me [F]know you’re [G7]mine)

Well shake it, shake it, shake it [C]baby, now 
([F]Shake it up [G7]baby)
Well shake it, shake it, shake it [C]baby, now 
([F]Shake it up [G7]baby)
Well shake it, shake it, shake it [C]baby, now 
([F]Shake it up [G7]baby) 

[G]/ / / /       / / / /         / / / /     
Ahhh...   aahh...     aahh... 

{c:(firmly) } 
[G7/]  [G7/]          [G7/]            [F/]       [F/]       [F/]       [C/]
 
________________________________________










