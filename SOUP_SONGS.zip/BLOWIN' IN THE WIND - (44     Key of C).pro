{title: BLOWIN' IN THE WIND  }
{subtitle:(4/4     Key of C)}      
{subtitle:(Bob Dylan)}
{time: 3:20}
{metronome: 168}






 
{c:INTRO:}
[F]/ / / /     [G7]/ / / /     
[C]/ / / /    / / / /

[C]How many [F]roads must a [C]man walk down
Before you [F]call him a [G7]man
Yes ‘n [C]how many [F]seas must a [C]white dove [Am]sail
Be[C]fore she [F]sleeps in the [G7]sand
Yes n’ [C]how many [F]times must the [C]cannonballs fly
Before they’re for[F]ever [G7]banned

{c:CHORUS}
{soc}
     The [F]answer my [G7]friend is 
     [C]Blowin’ in the [Am]wind
     The [F]answer is [G7]blowin’ in the [C]wind
{eoc}

[C]How many [F]times must a [C]man look up
Before he can [F]see the [G7]sky
Yes ‘n [C]how many [F]ears must [C]one man [Am]have
Be[C]fore he can [F]hear people [G7]cry
Yes n’ [C]how many [F]deaths will it [C]take till he knows
That too many [F]people have [G7]died                       

{soc}
     The [F]answer my [G7]friend is 
     [C]Blowin’ in the [Am]wind
     The [F]answer is [G7]blowin’ in the [C]wind
{eoc}

[C]How many [F]years can a [C]mountain exist
Before it’s [F]washed to the [G7]sea
Yes ‘n [C]how many [F]years can some [C]people ex[Am]ist
Be[C]fore they’re [F]allowed to be [G7]free
Yes n’ [C]how many [F]times can a [C]man turn his head
And pretend that he [F]just doesn’t [G7]see                 

{soc}
     The [F]answer my [G7]friend is 
     [C]Blowin’ in the [Am]wind
     The [F]answer is [G7]blowin’ in the [C]wind

     The [F]answer my [G7]friend is 
     [C]Blowin’ in the [Am]wind
     The [F]answer is [G7]blowin’ in the [C]wind  [C/]
{eoc}
