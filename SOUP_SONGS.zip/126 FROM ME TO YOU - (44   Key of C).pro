

{t:126 FROM ME TO YOU }
{subtitle:(4/4   Key of C)}      
{subtitle:(Paul MacCartney & John Lennon)}
{time:2:35}
{metronome:136}

{c:INTRO:  "one, two, three"} 





Dah dah [C]dah  
Dah dah dum dum  [Am]dah…
Dah dah [C]dah
Dah dah dum dum  [Am]dah…           
 
If there's [C]anything that you [Am]want  
If there's [C]anything I can [G7]do
Just [F]call on me and I'll [Am]send it along 
With [C]love from [G7]me to [C]you

I've got everything that you [Am]want
Like a [C]heart that's oh so [G7]true
Just [F]call on me and I'll [Am]send it along 
With [C]love from [G7]me to [C]you

{c:CHORUS}
{soc}
  I got [Gm]arms that long to [C7]hold you
  And [F]keep you by my side
  I got [D7]lips that long to kiss you 
  And [G]keep you satis[Gaug///]fied    (oooo)
{eoc}

If there's [C]anything that you [Am]want
If there's [C]anything I can [G7]do
Just [F]call on me and I'll [Am]send it along 
With [C]love from [G7]me to [C]you {c:(234)}
[C]/ / / /      [Am]       From me     
[C]/ / / /       [G7]      To you
Just [F]call on me and I'll [Am]send it along 
With [C]love from [G7]me to [C]you

{soc}
 I got [Gm]arms that long to [C7]hold you
 And [F]keep you by my side
 I got [D7]lips that long to kiss you 
 And [G]keep you satis[Gaug///]fied    (oooo)
{eoc}

If there's [C]anything that you [Am]want
If there's [C]anything I can [G7]do
Just [F]call on me and I'll [Am]send it along 
With [C]love from [G7]me to [C]you  {c:(23)}
To you {c:(23)} to you {c:(23)}

Dah dah dah
Dah dah dum dum [Am/]daahh...

___________________________________
{define: D7 0 2 0 2 0}
{define: Gaug/// 0 0 3 3 2}










