{title:SUGAR, SUGAR  }
{subtitle:    4/4      Key of D       }
{subtitle: (Jeff Barry & Andy Kim - The Archies)  }
{metronome:130}
{time:3:07}



{c:High G string RIFF (*****)} {c:Low G string RIFF (*****)}                        
{sot}  
A| 0 0 5 0 2 -   A| 0 0 5 0 2 -
E| - - - - - -   E| - - - - - 3  
C| - - - - - -   C| - - - - - -  
G| - - - - - 0   G| - - - - - - 
{eot}

{c:INTRO:}
{c:D  / / / /    G  / / / /    }

{c:D  / / / /    G  / / / /} 
                                                                               
{c:CHORUS}
{soc}
 [D]Sugar {c:(* * * }[G]{c:* *)}
 
 Ah Honey [D]Honey {c:(* * * }[G]{c:* *)}
  
 You are my [D]candy [G]girl    [A]
        
 And you've got me [D]wanting you  [G]      [A]
     
 [D]Honey  {c:(* * * }[G]{c:* *)}
 
 Ah Sugar [D]Sugar {c:(* * * }[G]{c:* *)}
 
 You are my [D]candy [G]girl   [A]
    
 And you've got me [D]wanting you 
 {c:(}[G]{c:ba da-ba}  [A]{c:ba da)} 
{eoc}

[D]I just can't believe the 
[G]Loveliness of [D]loving you 
(I just can't be[G]lieve it's [D]true) 
[D]I just can't believe the 
[G]wonder of this [D]feeling too 
(I just can't be[G]lieve it's [A]true) {c:(2,3)} ah  

{c:High G string RIFF (*****)}  {c:Low G string RIFF (*****)}                        
{sot}  
A| 0 0 5 0 2 -   A| 0 0 5 0 2 -
E| - - - - - -   E| - - - - - 3  
C| - - - - - -   C| - - - - - -  
G| - - - - - 0   G| - - - - - - 
{eot}

{soc}
 [D]Sugar {c:(* * * }[G]{c:* *)}
 Ah Honey [D]Honey {c:(* * * }[G]{c:* *)} 
 You are my [D]candy [G]girl    [A] 
 And you've got me [D]wanting you  [G]      [A]
      
 [D]Honey  {c:(* * * }[G]{c:* *)} 
  Ah Sugar [D]Sugar {c:(* * * }[G]{c:* *)} 
  You are my [D]candy [G]girl   [A] 
  And you've got me [D]wanting you 
  {c:(}[G]{c:ba da-ba}  [A]{c:ba da)} 
{eoc}

[D]When I kissed you, girl 
I [G]knew how sweet a [D]kiss could be  
(I know how sweet a [G]kiss can [D]be)
[D]Like the summer sunshine 
[G]Pour your sweetness [D]over me 
(pour your sweetness [G]over [A]me)
Oh-oh-oh-{soh}oh{eoh}-oh

{sob}
 [D]Pour a little sugar on it [G]honey            
 [D]Pour a little sugar on it [G]baby
 [D]I'm gonna make your [G]life so sweet 
 [A7]     Hey hey yeah!  
 [D]Pour a little sugar on it [G]Honey  (Oh [A7]yeah!)   

{sob}
 [D]Pour a little sugar on it [G]honey            
 [D]Pour a little sugar on it [G]baby
 [D]I'm gonna make your [G]life so sweet 
 [A7]     Hey hey yeah!  
 [D]Pour a little sugar on it [G]Honey  (Oh [A7]yeah!)   

 
[D]Sugar           {c:(* * * }[G]{c:* *)}  
{c:(}[D]{c:ba da-ba-ba da,  } [G]{c:ba da-ba-ba da)} 
      
Ah Honey [D]Honey      {c:(* * * }[G]{c:* *)}
{c:                  (}[D]{c:ba da-ba-ba da, }[G]{c:ba da-ba-ba da )} 

You are my [D]candy     [G]girl      [A]         
{c:                    (}[D]{c:ba da-ba }[G]{c:ba-da }[A]{c:↑baa…         )}
And you've got me [D]wanting you     [G]         [A]
{c:                                  (}[D]{c:ba da-ba ba-da }[G]{c:ba…}[A]{c:↑ah…)}
   
[D]Honey       {c:(* * * }[G]{c:* *)}
{c:(}[D]{c:Honey, honey, }[G]{c:sugar, sugar... )}   

Ah Sugar [D]Sugar     {c:(* * * }[G]{c:* *)}
{c:                 (}[D]{c:Honey, honey, }[G]{c:sugar, sugar)} 

You are my [D]candy     [G]girl     {c:(}[A]{c:1234)}         [D/]   
{c:                    (}[D]{c:ba da-ba }[G]{c:ba-da  }[A]{c:↑baaa…)}   [D/]


___________________________________















