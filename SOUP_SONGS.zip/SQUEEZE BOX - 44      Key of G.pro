{title:SQUEEZE BOX}
{subtitle:  4/4      Key of G}
{subtitle:(Pete Townsend)}
{metronome:142}
{time:2:43}





{c:NOTE:”Griff”: G chord, adding}
{c:a pinky on beats 2 and 4 }
{c:on the C string, 4th fret }

{c:”Driff”: pinky on E string, 3rd fret}
{c:”Criff”: index on the E string, 1st fret}
 


{c:INTRO: (beats one and three)}
[G]/    [D]/    [G]/    [D]/
[G]/    [D]/    [G]/    [D]/

[Griff]/ / / /   / / / /
/ / / /   / / / /
 
[Griff]Mama's got a squeeze box she wears on her chest
And when Daddy comes home he never gets no rest

{soc}
  'Cuz she's [Driff]playing all night 
  And the [Criff]music's all right
  [Driff]Mama's got a squeeze box
  [Criff]Daddy never sleeps at [Griff]night {c:(234,123)} 
{eoc}

Well the [Griff]kids don't eat and the dog can't sleep
There's no escape from the music in the whole damn street

{soc}
  'Cuz she's [Driff]playing all night 
  And the [Criff]music's all right
  [Driff]Mama's got a squeeze box
  [Criff]Daddy never sleeps at [Griff]night {c:(234,123)}
{eoc}
 
{c:BRIDGE}
She goes [Griff]in and out and in and out 
And in and out and in and out
 
{soc}
  'Cuz she's [Driff]playing all night 
  And the [Criff]music's all right
  [Driff]Mama's got a squeeze box
  [Criff]Daddy never sleeps at [Griff]night {c:(234,123)}
{eoc}
 
She goes “[G/]squeeze me, [G/]   
Come on and [G/]squeeze me  [G/]
Come on and [D/]tease me like you [D/]do
I'm [C/]so in love with [C/]you”
[D/]Mama's got a squeeze box
[C/]Daddy never sleeps at [Griff]night {c:(234,1234)}

[Griff]/ / / /   / / / / 
  
[Driff]/ / / /   / / / /
[Criff]/ / / /   / / / /

[Driff]/ / / /   [Criff]/ / / /
[Griff]/ / / /   / / / 
 
{c:BRIDGE}
She goes [Griff]in and out and in and out 
And in and out and in and out
 
{soc}
  'Cuz she's [Driff]playing all night 
  And the [Criff]music's all right
  [Driff]Mama's got a squeeze box
  [Criff]Daddy never sleeps at [Griff]night {c:(234,dudu)}
{eoc}
 
 

