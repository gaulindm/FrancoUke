{title: MY  GRANDFATHER'S CLOCK }
{subtitle:(4/4   Key of C)}
{subtitle:(Henry Clay Work)}
{metronome: 108}
{time: 2:15}
 
{c:INTRO: (Tick tock, tick tock--fingerpicking)}

{c:(High G) Tabs    (Ukes with a low G can }
{c:pluck open C and G strings, alternately)}                                     

{sot}
A- - 3 - - - 3 - - - 3 - - - 3 - - - - -          
E- - - - 3 - - - 3 - - - 3 - - - 3 - - -        
C- - - - - - - - - - - - - - - - - - - -          
G- - - - - - - - - - - - - - - - - - - -
{eot}
          
My [C]Grandfather's [G7]clock was too 
[C]Large for the [F]shelf
So it [C]stood ninety [G7]years on the [C]floor
It was taller by [G7]half than the 
[C]Old [C7]man him[F]self
But it [C]weighed not a [G7]penny weight [C]more
It was bought on the [Am]morn of the 
[F]Day that he was [G7]born
And was [C]always his [Am]treasure and 
[F]Pride, [G7]but it [C/]stopped [G7/]short 
[C/]Never to [C7/]go a[F/]gain
When the [C]old [G7]man [C]died 

{c:CHORUS}
{soc}
Ninety [C]years without slumbering {c: (Stop)} 
Tick tock tick tock  {c:(pluck as in intro)}
His [C]life's seconds numbering {c: (Stop)} 
Tick tock tick 
But it [C/]stopped [G7/]short 
[C]Never to [C7]go a[F]gain
When the [C]old [G7]man [C]died
{eoc}

At [C]watching its [G7]pendulum 
[C]Swing to and [F]fro
Many [C]hours he had [G7]spent as a [C]boy
As he grew into [G7]manhood the 
[C]Clock [C7]seemed to [F]know
For it [C]shared every [G7]sorrow and [C]joy
And it struck twenty- [Am]four 
As he [F]entered in the [G7]door
With his [C]blushing and  [Am]beautiful 
[F]Bride [G7], but it [C/]stopped [G7/]short 
[C]Never to [C7]go a[F]gain
When the [C]old [G7]man [C]died 

{soc}
Ninety [C]years without slumbering {c: (Stop)} 
Tick tock tick tock 
His [C]life's seconds numbering {c: (Stop)} 
Tick tock tick, but
It [C/]stopped [G7/]short [C]never to [C7]go a[F]gain
When the [C]old [G7]man [C/]died  [G7/] [C/]
{eoc}