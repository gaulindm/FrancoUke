{title:AINT SHE SWEET }
{subtitle:4/4   Key of C  }                                               
{metronome: 148}
{time: 3:00}







{c:INTRO:}
{c:  D7  / /    G7  /  /    C   /  /    G7  /  /}

[C]Ain't [C#dim]she   [Dm7]sweet?[G7] 
See her [C]coming [C#dim]down the [Dm7]street! [G7]
Now I [C]ask you [E7]very [A7]confi[A7+5]dentially 
[D7]Ain't [G7]she [C]sweet? [G7] 
 
[C]Ain't [C#dim]she   [Dm7]nice? [G7]
Look her [C]over [C#dim]once or [Dm7]twice. [G7]
Now I [C]ask you [E7]very [A7]confi[A7+5]dentially 
[D7]Ain't [G7]she [C]nice? 

{c:BRIDGE}
{soc}
     [C]Just cast an [F9]eye in her di[C]rection 
     Oh, me! Oh, [F9]my! 
     Ain't that per[C]fection?  [Dm7]    [G7] 
{eoc}

[C]I [C#dim]re…  [Dm7]peat, [G7]
Don't you [C]think that's [C#dim]kind of [Dm7]neat? [G7]
Now I [C]ask you [E7]very [A7]confi[A7+5]dentially 
[D7]Ain't [G7]she [C]sweet?

{soc}
     [C]Just cast an [F9]eye in her di[C]rection 
     Oh, me! Oh, [F9]my! 
     Ain't that per[C]fection?  [Dm7]    [G7] 
{eoc}

[C]I [C#dim]re...   [Dm7]peat, [G7]
Don't you [C]think that's [C#dim]kind of [Dm7]neat? [G7]
Now I [C]ask you [E7]very [A7]confi[A7+5]dentially 
[D7]Ain't [G7]she [C]sweet?

{c:OUTRO (Slowly)}
    Now I [C]ask you [E7]very [A7]confi[A7+5]dentially

{c:(Really slowly)} 
    [D7]Ai-ai-ai-ain't [G7]she-e-e-e [C]swee-e-e-e-eet? [G7]  [C]

{define: C#dim 0 0 1 0 1}
{define: D7 0 2 0 2 0}