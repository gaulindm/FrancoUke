{title:KEEP ON THE SUNNY SIDE   }
{subtitle:(4/4     Key of C)}
{subtitle:(Ada Blenkhorn & J. Howard Entwisle)}
{time: 3:10}
{metronome: 176}









{c:INTRO:}   
[C]/ / / /     [G7]/ / / /     
[C]/ / / /    / / / /

{c:CHORUS}
{soc}
     [C]Keep on the [C7]sunny side
     [F]Always on the [C]sunny side
     Keep on the sunny side of [G7]life
     It will [C]help you every [C7]day it will 
     [F]Brighten all the [C]way
     If you keep on the [G7]sunny side of [C]life 
{eoc}

There’s a [C]dark and a [F]troubled side of [C]life
But there’s a bright and sunny side [G7]too
Though you meet with the darkness and [C]strife
The [G7]sunny side you also may [C]view 

{soc}
     [C]Keep on the [C7]sunny side 
     [F]Always on the [C]sunny side
     Keep on the sunny side of [G7]life
     It will [C]help you every [C7]day it will 
     [F]Brighten all the [C]way
     If you keep on the [G7]sunny side of [C]life
{eoc}

[C]Though the storm and its [F]furies rage to[C]day
Crushing hope that we cherish so [G7]dear
The cloud and storm in time will pass a[C]way
And the [G7]sun again will shine bright and [C]clear 

{soc}
     [C]Keep on the [C7]sunny side
     [F]Always on the [C]sunny side
     Keep on the sunny side of [G7]life
     It will [C]help you every [C7]day it will 
     [F]brighten all the [C]way
     If you keep on the [G7]sunny side of [C]life 
{eoc}

[C]Let us greet with a [F]song of hope each [C]day
Though the moment be cloudy or [G7]fair
And let us trust in our Saviour al[C]ways
To [G7]keep us every one in His [C]care 

{soc}
     [C]Keep on the [C7]sunny side
     [F]Always on the [C]sunny side
     Keep on the sunny side of [G7]life
     It will [C]help you every [C7]day it will 
     [F]Brighten all the [C]way
     If you keep on the [G7]sunny side of [C]life 
     If you keep on the [G7]sunny side of [C]life 
     If you keep on the [G7]sunny side of [C]life  [G7/]   [C/] 
{eoc}