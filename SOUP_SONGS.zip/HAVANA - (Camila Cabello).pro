{title: HAVANA}
{subtitle:(Camila Cabello)}
{time:3:39}





{c:(Use a full D7 chord)}


{c:INTRO: }

[Gm]/ /      [Cm]/ /      [D7]/ / / /

[Gm]/ /      [Cm]/ /      [D7]/ / / /

Ha[Gm]vana, oo-na-[Cm]na  [D7] Half of my heart is in 
Ha[Gm]vana, oo-na-[Cm]na  [D7] He took me back to East 
At[Gm]lanta, na-na-[Cm]na  [D7]   Oh, but my heart is in 
Ha[Gm]vana, there's [Cm]somethin' 'bout his [D7]manners 
Havana, ooh na-[Gm]na  [Cm]    [D7]    
[Gm]    [Cm]    [D7]

He [Gm]didn't walk up with that "[Cm]how you doin'?"  
[D7]   (When he came in the room) 
He [Gm]said there's a lot of girls [Cm]I can do with  
[D7]   (But I can't without you)
I [Gm]knew him forever [Cm]in a min[D7]ute 
(That summer night in June)
And [Gm]papa says he got [Cm]malo in him [D7]
He got me feelin' like

[Gm]Ooh...[Cm]oo [D7]ooh.    I knew it when I [Gm]met him
I [Cm]loved him when I [D7]left him
Got me feelin' like      [Gm]Ooh...[Cm]Oo [D7]ooh
And then I had to [Gm]tell him
I [Cm]had to go- [D7/]o, na-na-na-na-na

Ha[Gm]vana, oo-na-[Cm]na [D7]   half of my heart is in 
Ha[Gm]vana, oo-na-[Cm]na [D7]    he took me back to East 
At[Gm]lanta, na-na-[Cm]na [D7]   oh, but my heart is in 
Ha[Gm]vana, my [Cm]heart is in Ha[D7]vana
Havana, ooh na-[Gm]na  [Cm]   [D7]  
[Gm]  [Cm]  [D7]

[Gm] Jeffe[Cm]ry just gradua[D7]ted, fresh on campus, man 
[Gm]   [Cm]Fresh out East At[D7]lanta with no manners, damn
[Gm]Fresh out East a [Cm]bump a bump 
[D7]Bump-er like a traffic jam 
[Gm] Hey, [Cm]       I was quick to  [D7]Pay that girl like Uncle Sam 
[Gm] Back it on [Cm]me, shawty [D7]cravin' on me get to digging on me  
[Gm] She waited on [Cm]me, shawty [D7]cakin' on me, got the bacon on me  
[Gm] This is history in the [Cm]makin' on me
[D7] Point blank, close range, that B 
[Gm]  If it cost a mil[Cm]lion, that's me    [D7]         I was gettin' mula, baby 

Ha[Gm]vana, ooh na-[Cm]na [D7]  half of my heart is in 
Ha[Gm]vana, ooh-na-[Cm]na [D7]   he took me back to East 
At[Gm]lanta, na-na-[Cm]na  [D7]  oh, but my heart is in 
Ha[Gm]vana, my [Cm]heart is in Ha[D7]vana
Havana, ooh na






[Gm]Oo na-na, [Cm]    oh na-na-[D7]na
Take me back, back, back like
[Gm]Oo na-na, [Cm]    oh na-na-[D7]na
Take me back, back, back like
[Gm]Oo na-na, [Cm]    oh na-na-[D7]na
Take me back, back, back like
[Gm]Oo na-na, [Cm]   oh na-na-[D7]na
Take me back, back, back

[Gm]Ooh... [Cm]oo…      [D7]oo
[Gm]Ooh... [Cm]oo…      [D7]oo

Ha[Gm]vana, oo-na-[Cm]na [D7]  half of my heart is in 
Ha[Gm]vana, oo-na-[Cm]na [D7]   he took me back to East 
At[Gm]lanta, na-na-[Cm]na (uh huh)  [D7]
Oh, but my heart is in Ha[Gm]vana (ay)
My [Cm]heart is in Ha[D7]vana
Havana, ooh na-[Gm/]na

{define: D7 0 2 2 2 3}


