{title: THE UNICORN  }
{subtitle:(4/4     Key of G)}    
{subtitle:(Shel Silverstein)}
{time:4:00}
{metronome: 130}







{c:INTRO:}
[G]/ / / /    [Am]/ / / /    
[D7]/ / / /    [G]/ / / /

A [G]long time ago 
When the [Am]earth was green  
There was [D7]more kinds of animals 
Than [G]you'd ever seen  
They'd run around free 
While the [Am]world was being born  
But the [G]loveliest of all was the 
[Am/]u-   [D7/]ni- [G/]corn   

{soc}
There was [G]green alligators  
And [Am]long-necked geese 
Some [D7]humpty-back camels and some 
[G]Chimpanzees  
Some cats and rats and elephants
But [Am]sure as you're born 
The [G]loveliest of all was the 
[Am/]u-   [D7/]ni-   [G]corn    
{eoc}

But the [G]Lord seen some sinnin' 
And it [Am]caused him pain  
He [D7]said "Stand back—
I'm [G]gonna make it rain"  
He said "Hey, brother Noah, 
I'll [Am]tell you what to do  
[G]Build me a [Am/]float[D7/]ing [G/]zoo."{c:(beat)}
   
{soc}
     Bring some 'a those [G]green alligators 
     And a [Am]couple of geese  
     Two [D7]humpty-back camels 
     And two [G]chimpanzees  
     Two cats, two rats, two elephants 
     But [Am]sure as you're born  
     [G]Don't you forget my 
     [Am/]u-  [D7/]ni-  [G]corn 
{eoc}

Old [G]Noah was there and 
He [Am]answered the callin'  
And he [D7]finished up the ark 
As the [G]rain started fallin'  
He marched in the animals [Am]two by two  
And he [G]called out as 
[Am/]They [D7/]went [G/]through:  

{soc}
     "Hey Lord, I got you [G]green alligators 
      And a [Am]couple of geese  
     Some [D7]humpty-back camels 
     And two [G]chimpanzees 
     Two cats, two rats, two elephants 
     But [Am]Lord, I'm so forlorn
     I [G]just don't see your 
     [Am/]u-   [D7/]ni-   [G]corn" 
{eoc}

Well, [G]Noah looked out 
Through the [Am]driving rain  
The [D7]unicorns were hiding 
[G]Playing silly games 
They were kickin' and a-splashin' while the 
[Am]Rain was pourin' 
[G]Oh them silly [Am/]u-  [D7/]ni-   [G/]corns  

{soc}
There was [G]green alligators  
And [Am]long-necked geese 
Some [D7]humpty-back camels 
And some [G]chimpanzees 
Noah cried "close the door 
‘Cause the [Am]rain is pourin'
We [G]just can't wait for no 
[Am/]u-   [D7/]ni-   [G]corn
{eoc}

And then the [G]ark started moving 
And it [Am]drifted with the tide  
The [D7]unicorns looked up 
From the [G]rocks and cried  
And the water came up and sort of 
[Am]Floated them away {c:(pause)}
{c:(spoken)} And [G/]that's why you've 
Never seen a unicorn, to this very day  

{soc}
But you'll see [G]green alligators  
And a [Am]whole mess of geese  
You'll see [D7]humpty-back camels 
And [G]chimpanzees  
You'll see cats and rats and elephants  
But [Am]sure as you're born  
You're [G]never gonna see no 
[Am]u...... [D7]ni....... [G]corns."   [D7/] [G/]
{eoc}


{define: D7 0 2 0 2 0}