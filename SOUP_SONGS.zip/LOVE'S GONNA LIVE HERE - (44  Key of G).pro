{t:LOVE'S GONNA LIVE HERE  }
{subtitle:(4/4  Key of G)}  
{subtitle:(Buck Owens)}
{time:2:40}
{metronome: 180}






{c:INTRO: }
[G]/ / / /    [D7]/ / / /    
[G]/ / / /   / /  

Oh the [G]sun's gonna shine in my 
[C]   Life once [G]more
Love's gonna live here a[D7]gain 
[G]Things are gonna be the way they 
[C]   Were be[G]fore 
Love's gonna [D7]live here a[G]gain 

{c:CHORUS}
{soc}
[G]     Love's gonna live here 
[C]     Love's gonna live here 
[G]     Love's gonna live here a[D7]gain 
[G]     No more loneliness, [C]  only happiness
[G]     Love's gonna [D7]live here a[G]gain   
{eoc}

{c:INSTRUMENTAL}
Oh the [G]sun's gonna shine in my 
[C] Life once [G]more
Love's gonna live here a[D7]gain 
[G]Things are gonna be the way they 
[C] Were be[G]fore 
Love's gonna [D7]live here a[G]gain 

{c:SING}
I [G]hear bells a ringin', I [C]hear birds a singin'
[G]     Love's gonna live here a[D7]gain
I [G]hear bees a hummin'
Well I [C]know the day's a-comin'
[G] Love's gonna [D7]live here a[G]gain

{soc}
[G]     Love's gonna live here 
[C]     Love's gonna live here 
[G]     Love's gonna live here a[D7]gain 
[G]     No more loneliness, [C]  only happiness
[G]     Love's gonna [D7]live here a[G]gain 

[G]     Love's gonna live here 
[C]     Love's gonna live here 
[G]     Love's gonna live here a[D7]gain 
[G]     No more loneliness, [C]  only happiness
[G]     Love's gonna [D7]live here a[G]gain   
[G]     Love's gonna [D7]live here a[G]gain  [D7/] [G/]
{eoc}

{define: D7 0 2 0 2 0}
