{title:  BLAME IT ON THE UKULELE }
{subtitle:(4/4  Key of G)}
{subtitle: (Barry Mann & Cynthia Weil)} 
{subtitle:(Tune: Blame It On The Bossa Nova) }
{time: 2:50}
{metronome: 146}






{c:INTRO:}  
[G]/ / / /    / / / /   
/ / / /    /   {c:(stop)} 

I was at a [G]fling when it caught my [D7]ear
That little four string thing 
With a sound so [G]cle-e-ear
When I played a [G7]chord 
Fireworks a[C]ppeared 
I'd [G]never be the [D7]same again I [G]feared [G/]

Blame it on the uku[D7]lele 
With its magic [G]spell 
Blame it on the uku[D7]lele 
That we play so [G]well   [G7]
Oh it all began with [C]just one little chord
But soon it was a [G]sound we all adored 
Blame it on the uku[D7]lele  [D7/]       
The sound of [G]love  [G/]

{soc}
   {c:(Boys)} Is it a gui[D7]tar  
   {c:(Girls)} no no, a ukulele 
   {c:(Boys)} Or a mando[G]lin 
   {c:(Girls)} no no, a ukulele
   {c:(Boys)} Maybe it’s the [D7]sound  
   {c:(Girls) } yeah yeah, the ukulele
   {c:(All)} [G/]    The [C/]sound [C/]of  [G/]love {c:(234,1)}
{eoc}

Now I have many [G]ukes
Tenor and concert [D7]too 
One of every size 
Won't be enough for [G]you-ou-ou
All my friends play uke  [G7]    
And we're never [C]blue   
Come [G]join our jam and 
[D7]You can play one [G]too [G/]
Come and play the uku[D7]lele 
With its magic [G]spell 
Come and play the uku[D7]lele 
Makes you feel so [G]well   [G7] 
Oh it all began with [C]just one little chord 
But soon it was a [G]sound we all adored 
Blame it on the uku[D7]lele   [D7/]        
The sound of [G]love  [G/]

{soc}
   {c:(Boys)} Is it a gui[D7]tar  
   {c:(Girls)} no no, a ukulele 
   {c:(Boys)} Or a mando[G]lin 
   {c:(Girls)} no no, a ukulele
   {c:(Boys)} Maybe it’s the [D7]sound  
   {c:(Girls) } yeah yeah, the ukulele
   {c:(All)} [G/]      The [C/]sound [C/]of  [G/]love   
   [G///] 
{eoc}




{define: D7 0 2 0 2 0}
