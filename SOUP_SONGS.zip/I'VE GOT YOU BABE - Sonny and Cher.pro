{title:I'VE GOT YOU BABE}
{subtitle:Sonny and Cher}

Intro: [F] [Bb] [F] [Bb]

[F] They say we're young and [Bb] we don't know
[F] Won't find [Bb] out [Eb] ‘til we [C] grow
Well [F] I don't know if [Bb] all that's true
Cause [F] you got me and [Bb] baby [Eb] I got [C] you 
[F]Babe [Bb] I got [F] you babe [Bb] I got [F] you babe [Bb}

They [F] say our love won't [Bb] pay the rent
Be[F]fore it's earned our [Bb] money's [Eb] all been [C] spent
I [F] guess that's so we don't [Bb] have a pot
But at [F] least I'm sure of [Bb] all the [Eb] things we [C] got
[F] Babe [Bb] I got [F] you babe [Bb] I got [F] you babe

I got [Gm] flowers in the [C] spring I got [Gm] you to wear my [C] ring
And when I'm [F] sad you're a [Bb] clown
And if I get [Gm] scared you're always a[C]round
So [F] let them say your [Bb] hair's too long
But [F] I don't care with [Bb] you I [Eb] can't go [C] wrong
Then [F] put your little [Bb] and in mine
There [F] ain't no hill or [Bb] mountain [Eb] we can't [C] climb
[F] Babe [Bb] I got [F] you babe [Bb] I got [F] you babe [Bb}

[F] [Bb] [F] [C}

[F] I got you to [Bb] hold my hand [F] I got you to [C] understand
[F] I got you to [Bb] walk with me [F] I got you to [C] talk with me
[F] I got you to [Bb] kiss goodnight [F] I got you to [C] hold me tight
[F] I got you [Bb] I won't let go [F] I got you to [C] love me so
[F] [Bb] [F] [C] [Bb] I got [F] you babe [F] [Bb] I got [F] you babe
[Bb] I got [F] you babe [Bb] I got [F] you babe