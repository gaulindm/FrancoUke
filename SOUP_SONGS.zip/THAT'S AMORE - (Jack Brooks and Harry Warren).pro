{title: THAT'S AMORE   }
{subtitle: Key of C    3/4}
{subtitle: (Jack Brooks and Harry Warren)}
{metronome: 160 }
{time:3:20 }











{c:INTRO: Flutter on chords:}
{c:first note is G}

[Cm]   In Napoli… where love is [Fm]king...

When boy meets [Cm]girl... here's what they [G7]say…

{soc}
[Tacet]When… the… [C]moon hits your eye 
Like a big pizza pie, that's a[G7]more 
(that's amore)
When the world seems to shine 
Like you've had too much wine, that's a[C]more 
(that's amore)

Bells will ring ting-a-ling-a-ling 
Ting-a-ling-a-ling and you'll sing vita [G7]bella 
{c:(vita bell, ↑vita bell, ↑vita bell)}

Hearts will play tippy tippy tay
Tippy tippy tay, like a gay taran[C]tella

When the [C]stars make you drool 
Just like a pasta fazool that's a[G7]more 
(that's amore)
When you dance down the street 
With a cloud at your feet, you're in 
[E7]Love {c:(23,123)} [C#dim7]{c:(123,1)} 
When you [Dm]walk in a dream but you 
[Fm]Know you're not dreaming, Sig[C]nore
Scuzza [G7]me but you see back in old Napoli 
That's a[C]more {c:(123,123)}[C/]  
{eoc}

{c:With Gusto!}
{soc}
When... the... [C]moon hits your eye 
Like a big pizza pie, that's a[G7]more 
(that's amore)
When the world seems to shine
Like you've had too much wine, that's a[C]more 
(that's amore)

Bells will ring ting-a-ling-a-ling 
Ting-a-ling-a-ling and you'll sing vita [G7]bella 
{c:(vita bell, ↑vita bell, ↑vita bell)}

Hearts will play tippy tippy tay
Tippy tippy tay, like a gay taran[C]tella 
(lucky fella)

When the [C]stars make you drool 
Just like a pasta fazool that's a[G7]more 
(that's amore)
When you dance down the street 
With a cloud at your feet you're in 
[E7]Love {c:(23,123)} [C#dim7]{c:(123,1)} 
{eoc}

{c:Slow down and flutter on chords}

{soc}
When you [Dm]walk in a dream 
But you [Fm]know you're not dreaming
  
{c:(Resume tempo)} Sign[C]ore… 
Scuzza [G7]me but you see 
Back in old Napoli, that's a[C]more {c:(3,123,123,1)}
{eoc}

{c:OUTRO:}
Scuzza [G7]me but you see 
Back in old Napoli, that's a[C]more {c:(3,123,12)} [G7/][C/]    


