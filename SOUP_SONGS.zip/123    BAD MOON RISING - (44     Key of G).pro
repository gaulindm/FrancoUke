

{t:123  BAD MOON RISING }
{subtitle:    4/4     Key of G     }  
{subtitle:(John Fogerty)}
{time:3:30}
{metronome: 178}







[G]/ / / /    [D]/ /    [C]/ / 
[G]/ / / /   / / / / 

[G]I see a [D7]bad [C]moon [G]rising    
I see [D7]trouble [C]on the [G]way
I see [D7]earth[C]quakes and [G]lightnin’   
I see [D7]bad [C]times [G]today

{c:CHORUS}
 {soc}
     [C]Don't go around tonight
     It’s [G]bound to take your life
     [D7]There’s a [C]bad moon on the [G]rise
     [C]Don't go around tonight
     It’s [G]bound to take your life
     [D7]There’s a [C]bad moon on the [G]rise 
{eoc}

[G]I hear [D7]hurri-[C]canes a [G]blowin'   
I know the [D7]end is [C]comin' [G]soon
I fear [D7]rivers [C]over[G]flowin’   
I hear the [D7]voice of [C]rage and [G]ruin

 {soc}
     [C]Don't go around tonight
     It’s [G]bound to take your life
     [D7]There’s a [C]bad moon on the [G]rise
     [C]Don't go around tonight
     It’s [G]bound to take your life
     [D7]There’s a [C]bad moon on the [G]rise 
{eoc}

[G]Hope you [D7]got your [C]things [G]together
Hope you are [D7]quite pre[C]pared to [G]die
Looks like we're [D7]in for [C]nasty [G]weather
One eye is [D7]taken [C]for an [G]eye.....Well

 {soc}
     [C]Don't go around tonight
     It’s [G]bound to take your life
     [D7]There’s a [C]bad moon on the [G]rise
     [C]Don't go around tonight
     It’s [G]bound to take your life
     [D7]There’s a [C]bad moon on the [G]rise
      [D7]There’s a [C]bad moon on the [G]rise   [G/]
{eoc}

_____________________________________

                            
{define: D7 0 2 0 2 0}












