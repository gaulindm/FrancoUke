{title:WE WISH YOU A MERRY CHRISTMAS }





We [G]wish you a Merry [C]Christmas 
We [A]wish you a Merry [D]Christmas 
We [G]wish you a Merry [C]Christmas 
And a [C]Happy [D]New [G]Year 

Good tidings we [D]bring to [C]you and your [D]kin 
Good [G]tidings for [D]Christmas 
And a [C]Happy [D]New [G]Year 

Oh, [G]bring us some figgy [C]pudding 
Oh, [A]bring us some figgy [D]pudding 
Oh, [G]bring us some figgy [C]pudding 
And a [C]cup of [D]good [G]cheer 

We [G]won't go until we [C]get some 
We [A]won't go until we [D]get some 
We [G]won't go until we [C]get some 
So [C]bring some [D]out [G]here 

Good tidings we [D]bring to [C]you and your [D]kin 
Good [G]tidings for [D]Christmas 
And a [C]Happy [D]New [G]year 
We [G]wish you a Merry [C]Christmas 
We [A]wish you a Merry [D]Christmas 
We [G]wish you a Merry [C]Christmas 
And a [C]Happy [D]New [G]Year 

We [G]wish you a Merry [C]Christmas 
We [A]wish you a Merry [D]Christmas  
(Slowly)We [G]wish you a Merry [C]Christma...s 
And a [C]Happy [D]New [G]Year