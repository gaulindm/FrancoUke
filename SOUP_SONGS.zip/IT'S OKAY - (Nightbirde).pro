{title:IT'S OKAY}
{subtitle:(Nightbirde)}
{subtitle:  4/4      Key of C}
{metronome:   }
{time:3:25}






[C/] {c:(234)}   [Dm/]       {c:(234)}   
[F/] {c:(234)}   [F/]     {c:(234)}

[C/] {c:(2,3)}  I mo[Dm/]ved to California in the 
[F/]Summertime    [F/]
[C/]  {c:(2,3)} I chan[Dm/]ged my name thin{soh}kin'{eoh} that it would 
[F/]change my mind   [F/]
[C/]  {c:(2,3)} I tho[Dm/]ught that all my problems they would 
[F/]stay behind  [F/]
I was a [C/]stick of dynamite and it just [Dm/]was a matter of time 
[F/]     yeah   [F/]     {c:(2,3)}

{soc}
Oh [Am/]dang, oh [Am/]my, now [Am]I can't hide
Said I [G/]knew my[G/]self but I [G]guess I lied
It's [C/]okay, it's o[C/]kay, it's o[F]kay, it's okay
If you're [Am/]lost, we're all a [Am/]little lost and [G]it's all right
It's [C/]okay, it's o[C/]kay, it's o[F]kay, it's okay
If you're [Am/]lost, we're all a [Am/]little lost and [G]it's all right
It's all [C/]right  [C/]     it's all [F]right, it's all right 
It's all [Am/]right  [Am/]         {c:(}[G]{c:1234)}
{eoc}

[C/] [C/]      I-I [Dm]wrote a hundred pages but I 
[F/]burned 'em all, [F/]        [F]     yeah I burned 'em all
[C/] [C/]      I [Dm]blow through yellow lights and don't look 
[F/]Back at all, [F/]        [F]        I don't look back at all 
[C/] [C/]     Yeah [Dm]you can call me reckless, I'm a 
[F/]Cannonball, [F/]        [F]     I'm a cannonball
[C/] [C/]     Don't know [Dm]why I take the tightrope and 
Cry   [F/]when I fall, [F/]        I [F]cry when I fall

{soc}
Oh [Am/]dang, oh [Am/]my, now [Am]I can't hide
Said I [G/]knew what I want[G/]ed but I [G]guess I lied
It's [C/]okay, it's o[C/]kay, it's o[F]kay, it's okay
If you're [Am/]lost, we're all a [Am/]little lost and [G]it's all right
It's [C/]okay, it's o[C/]kay, it's o[F]kay, it's okay
If you're [Am/]lost, we're all a [Am/]little lost and [G]it's all right
It's all [C/]right  [C/]     it's all [F]right, it's all right
It's all [Am/]right  [Am/]           {c:(}[G]{c:1234)}
{eoc}

[C/]Oh, [C/]oh    [F]oh     
it's all [Am/]right  [Am/]           [G]
[C/]oh, [C/]oh    [F]oh     
it's all [Am/]right, [Am/]        its all  [G]right its all right
[C/]Oh, [C/]     oh-[F]oh         
Its all [Am/]right    [Am/]       [G]     
[C/]Oh,  [C/]      oh-[F]oh     
Its all [Am/]right     [Am/]       
To be [G/]lost sometimes  {c:(pause)}

{soc}
It's [C/]okay, it's o[C/]kay, it's o[F]kay, it's okay
If you're [Am/]lost, we're all a [Am/]little lost  
And [G]it's all right
It's [C/]okay, it's o[C/]kay, it's o[F]kay, it's okay
If you're [Am/]lost, we're all a [Am/]little lost 
And [G]it's all right
It's all [C/]right  [C/]     it's all [F]right, it's all right
It's all [Am/]right   [Am/]          {c:(}[G]{c:1234)}


It's [C/]okay, it's o[C/]kay, it's o[F]kay, it's okay
If you're [Am/]lost, we're all a [Am/]little lost  
And [G/]it's all right    [C/]
{eoc}