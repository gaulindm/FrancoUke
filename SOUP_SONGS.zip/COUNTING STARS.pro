{title:COUNTING STARS}
{subtitle:4/4      Key of Am}
{subtitle:  Ryan Tedder (OneRepublic)
{time:4:00  }
{metronome:  }

{c:(intro picking pattern)}

{sot}
G|- X - - - - X - - - - -
C|- - X - X - - X - X - -
E|- X - X - - X - X - - - 
A|- X - - - - X - - - - - 
{eot}

[Am/] {c:(234)}

[Am]Lately, I've been, [C]I've been losing sleep
[G]  Dreaming about the things that [F]we could be
But [Am]baby I've been, [C]I've been praying hard
[G]  Said, no more counting dollars 
[F]We'll be counting stars {c:(4,12)}
{c:(slower)}   Yeah we'll be counting... 

{c:(strum)} 
[Am]Stars {c:(234)}  [C]/ / / /
[G]/ / / /    [F]/ / / 
 
I see this [Am]life like a swinging vine 
[C]Swing my heart across the line
[G]In my face is flashing signs
[F] Seek it out and ye shall find
[Am]Old, but I'm not that old 
[C]Young, but I'm not that bold
And [G]I don't think the world is sold
[F] On just doing what we're told
 
{soc}
  [Am]      I-I-I-I- [C]I feel something so [G]right 
  Doing the [F]wrong thing  {c:(34)}
  [Am]      I-I-I-I- [C]I  feel something so [G]wrong 
  Doing the [F]right thing
  [F]   I couldn't lie, couldn't lie, couldn't li-ie
  [F/]Everything that kills me makes me feel [Am]alive
{c:                                                                     (Lately...)} 

  [Am]Lately I been, [C]I been losing sleep
  [G]    Dreaming about the things that [F]we could be
  [Am]Baby I been, [C]I been prayin' hard
  [G]   Said no more counting dollars
  [F]We'll be counting stars
  [Am]Lately I been, [C]I been losing sleep
  [G]   Dreaming about the things that [F]we could be
  But [Am]baby, I've been, [C]I've been praying hard
  [G]   Said no more counting dollars
  [F]We'll be, we'll be counting 
  [Am]Stars {c:(234)}  [C]/ / / /
  [G]/ / / /    [F]/ / / 
 {eoc} 

I feel your [Am/]love and I feel it burn 
[C/]Down this river, every turn
[G/]Hope is our four-letter word 
[F/]Make that money, watch it burn
[Am]Old, but I'm not that old 
[C]Young, but I'm not that bold
[G]I don't think the world is sold
[F] On just doing what we're told
 
{soc}
[Am]      I-I-I-I- [C]I feel something so [G]wrong 
doing the r[F]ight thing
[F]   I couldn't lie, couldn't lie, couldn't lie
[F/]Everything that drowns me makes me wanna [Am]fly
{c:                                                                              (Lately)} 
[Am]Lately, I've been, [C]I've been losing sleep
[G]  Dreaming about the things that [F]we could be
But [Am]baby, I've been, [C]I've been praying hard
[G]  Said, no more counting dollars
[F]We'll be counting stars
(ooo's)[Am]Lately, I've been, [C]I've been losing sleep
[G]  Dreaming about the things that [F]we could be
But [Am]baby, I've been, I[C]'ve been praying hard,
[G]  Said, no more counting dollars
[F]We'll be, we'll be counting stars {c:(234,1234)}
{eoc}
 
{c:(Clap)}
Take that money and watch it burn 
Sink in the river the lessons I learned
Take that money and watch it burn 
Sink in the river the lessons I learned
[Am]Take that money and watch it burn 
Sink in the river the lessons I learned
[Am]Take that money and watch it burn 
Sink in the river the lessons I learned
[F/]Everything that   [Dm/]kills me makes me feel a[Am]live
{c:                                                                       (Lately...)}
 

[Am]Lately, I've been, [C]I've been losing sleep
[G]  Dreaming about the things that [F]we could be
But [Am]baby, I've been, [C]I've been praying hard
[G]  Said, no more counting dollars
[F]We'll be counting stars
{c:(Ooo's)} [Am]Lately, I've been, [C]I've been losing sleep
[G]  Dreaming about the things that [F]we could be
But [Am]baby, I've been, [C]I've been praying hard
[G]  Said, no more counting dollars
[F]We'll be, we'll be counting

{c:(Ooo's)}
[Am]Take that money and watch it burn 
Sink in the river the lessons I learned
[Am]Take that money and watch it burn 
Sink in the river the lessons I learned
[Am]Take that money and watch it burn 
Sink in the river the lessons I learned
[Am/]Take that money and watch it burn 
[Am/]Sink in the river the lessons I learned
