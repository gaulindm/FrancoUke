{title:OH CANADA (KEY OF C)}
{subtitle: Key of C}

[C]/ /    [C7]/  /     [F]/  /     [Dm]/  /     
[C]/ /     [G7]/  /     [C]/  /  /  /   


[C]Oh   [G]Cana-[Am]da, our [C]home and native [G]land 
[C]True [D7]patriot [G]love, in all of [D7]us com-[G]mand

With [G7]glowing hearts, we [C]see thee rise
Our [F]true north [Dm]strong and [G]free
From [G7]far and wide, Oh [C]Canada
We [G]stand on [D7]guard for [G7]thee

[C]God [G]keep our [Am]land [Dm]glorious and [G]free 
[C]Oh   [C7]Cana -  [F]da, we  [Dm]stand  on  [C]guard  [G]for   [C]thee 
Oh [C7]Cana - [F]da, we  [Dm]stand  on [C]guard  [G7]for   [C]thee


