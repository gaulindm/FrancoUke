{t: PUFF THE MAGIC DRAGON }
{subtitle:(4/4  Key of C)}
{subtitle:(Leonard Lipton & Peter Yarrow)}
{time: 4:30}
{metronome: 148}






{c:INTRO: }
[F]/ / / /   [C]/ /    [Am]/ /    [D7]/ /   
[G7]/ /     [C]/ /   [G]/ /  

[C]Puff, the magic [Em]dragon [F]lived by the [C]sea
And [F]frolicked in the [C]autumn [Am]mist 
In a [D7]land called Hona[G7]lee
[C]Little Jackie [Em]Paper [F]loved that rascal [C]Puff
And [F]brought him strings and [C]sealing [Am]wax 
And [D7]other [G7]fancy [C]stuff. [G7]Oh

{c:CHORUS}
{soc}
     [C]Puff, the magic [Em]dragon [F]lived by the [C]sea 
     And [F]frolicked in the [C]autumn [Am]mist 
     In a [D7]land called Hona[G7]lee 
     [C]Puff, the magic [Em]dragon [F]lived by the [C]sea 
     And [F]frolicked in the [C]autumn [Am]mist 
     In a [D7]land called [G7]Hona[C]lee
{eoc}

To[C]gether they would [Em]travel 
On a [F]boat with billowed [C]sail
And [F]Jackie kept a [C]lookout [Am]perched 
On [D7]Puff’s gigantic [G7]tail
[C]Noble kings and [Em]princes 
Would [F]bow whene'r they [C]came
[F]Pirate ships would [C]lower their [Am]flags 
When [D7]Puff roared [G7]out his [C]name. [G7]Oh   

{soc}
     [C]Puff, the magic [Em]dragon [F]lived by the [C]sea 
     And [F]frolicked in the [C]autumn [Am]mist 
     In a [D7]land called Hona[G7]lee 
     [C]Puff, the magic [Em]dragon [F]lived by the [C]sea 
     And [F]frolicked in the [C]autumn [Am]mist 
     In a [D7]land called [G7]Hona[C]lee
{eoc}

A [C]dragon lives for[Em]ever 
But [F]not so little [C]boys
[F]Painted wings and [C]giant's [Am]rings 
Make [D7]way for other [G7]toys
[C]One grey night it [Em]happened
Jackie [F]Paper came no [C]more
And [F]Puff that mighty [C]dragon [Am]         
He [D7]ceased his [G7]fearless [C]roar. [G7]Oh   

{soc}
[C]Puff, the magic [Em]dragon [F]lived by the [C]sea 
     And [F]frolicked in the [C]autumn [Am]mist 
     In a [D7]land called Hona[G7]lee 
     [C]Puff, the magic [Em]dragon [F]lived by the [C]sea 
     And [F]frolicked in the [C]autumn [Am]mist 
     In a [D7]land called [G7]Hona[C]lee
{eoc}

{c:(softly, but keep the same pace)}
His [C/]head was bent in [Em/]sorrow 
[F/]green scales fell like [C/]rain
[F/]Puff no longer [C/]went to [Am/]play 
A[D7/]long the cherry [G7/]lane
With[C/]out his life-long [Em/]friend 
[F/]Puff could not be [C/]brave
So [F/]Puff that mighty [C/]dragon [Am/]sadly 
[D7/]Slipped in[G7/]to his [C/]cave. [G7/]Oh,   

{soc}
     [C]Puff, the magic [Em]dragon [F]lived by the [C]sea 
     And [F]frolicked in the [C]autumn [Am]mist 
     In a [D7]land called Hona[G7]lee 
     [C]Puff, the magic [Em]dragon [F]lived by the [C]sea 
     And [F]frolicked in the [C]autumn [Am]mist 
     In a [D7]la...nd  cal...led [G7]Hon...a...[C]lee... [G7/] [C/]   
{eoc}
 
{define: D7 0 2 0 2 0}
