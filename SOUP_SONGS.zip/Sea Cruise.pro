{title: SEA CRUISE  }
{subtitle:4/4    Key of C   (Frankie Ford)}
{metronome: 158  }
{time:3:00  }







Intro: [C]/ / / /   / / / /

[C]Old man rhythm gets in my shoes 
it’s [C]no use a-sittin’ and a-singin’ the blues
So [G]be my guest, you’ve got nothin’ to lose 
[C]won’t you let me take you on a, sea cruise?

Chorus:
[C]Ooo-wee {C:(bop bop)} ooo-wee baby, 
[C]Ooo-wee {C:(bop bop)} ooo-wee baby
[G]Ooo-wee {C:(bop bop)} ooo-wee baby, 
[C]Won’t you let me take you on a, sea cruise?

Bridge:
I [F]feel like jumpin’, baby 
won’t you join me [C]please.         [C]                                                                      {c:(Ah oom bop bop, ah oom bop bop)}

I [F]don’t like beggin’, 
but now I’m on bended [G]knees.         [G7]
{c:(Ah ah aaaaah we-e-ell)}

I [F]got to get rockin’, get my hat off the rack, 
I [C]got the boogie woogie like a knife in the back
So [G]be my guest, you’ve got nothing to lose, 
[C]Won’t you let me take you on a, sea cruise?

Chorus: 
[C]Ooo-wee {C:(bop bop)} ooo-wee baby, 
[C]Ooo-wee {C:(bop bop)} ooo-wee baby
[G]Ooo-wee {C:(bop bop)} ooo-wee baby, 
[C]Won’t you let me take you on a, sea cruise?

Instrumental bridge:
I [F]feel like jumpin’, 
baby won’t you join me [C]please[C]
I [F]don’t like beggin’ 
but now I’m on bended [G]knees[G7]

I [C]got to get to movin’ baby, I ain’t lyin’
My [C]heart is beatin’ rhythm and it’s right on time
So [G]be my guest, you’ve got nothing to lose, 
[C]won’t you let me take you on a, sea cruise?

Chorus:
[C]Ooo-wee {C:(bop bop)} ooo-wee baby, 
[C]Ooo-wee {C:(bop bop)} ooo-wee baby
[G]Ooo-wee {C:(bop bop)} ooo-wee baby, 
[C]Won’t you let me take you on a,sea cruise?

Bridge:
I [F]feel like jumpin’, baby 
won’t you join me [C]please         [C]
                                                                              {C:(Ah oom bop bop, ah oom bop bop)}
I [F]don’t like beggin’, 
but now I’m on bended [G]knees.  [G7]
                                                                                  {C:(Ah ah aaaaah   We-e-ell)}

Chorus:
[C]Ooo-wee {C:(bop bop)} ooo-wee baby, 
[C]Ooo-wee {C:(bop bop)} ooo-wee baby
[G]Ooo-wee {C:(bop bop)} ooo-wee baby, 
[C]Won’t you let me take you on a, [C/]sea [C/]cruise?
         


