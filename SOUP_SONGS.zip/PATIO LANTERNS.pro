{title:PATIO LANTERNS}
{subtitle:4/4      Key of G}
{subtitle: (Kim Mitchell)}
{time: 3:50 }
{metronome:126}

{c:(optional riff on the G chord throughout)} 
{sot}
A| - 2 - 0 - 2 - 0 
E| - - - - - - - -
C| - - - - - - - -
G| - - - - - - 0 -
{eot}

[G]/ / / /   / / / /

[G] Our ho-ouse had the biggest patio-o
[G] Our ho-ouse had all the summer [C]sha-ade  [Csus4]/ /   
[C] We had patio [G]lanterns  {c:(34,1234)}
[G] I'd spend half the night making lemona-ade
[G] Which we drank a lot, cause we were all so 
[C]Shy-y-y    [Csus4]/ /   [C]/ /    Shy and [G]nervous  {c:(34,1234)}
 
 
[D] Who was gonna be 
[C]Who would be the first to dance                                  
[D] Who was gonna be 
[C]who would be the first to kiss 
Under those patio [G]lanterns  {c:(34,12)}  

[C]/   [C]/   [D]   Those patio lanterns 
They were the [C]stars [G]in the s[Gsus4]ky      [G]
[D] Those patio lanterns 
[C]Lighting [G]up our l[Gsus4]ives     [G]
[D] Those patio lanterns 
They were the [C]stars [G]in the s[Gsus4]ky    [G]
[D] Those patio lanterns 
Lighting up our [C]li-i...ives    [C/]             
Oh, those patio [G]lanterns {c:(34,1234)}
 
[G] And I was stuck on Joy, that was her name
[G] We didn't talk much 
She was a nervous [C]girl   [Csus4]/ /  
[C] I was a nervous [G]bo-oy {c:(34,1234)} 
[G] We stuck together like glue on glue
[G] Dancing to an old song 
Bobby Vinton's Blue on [C]Blue   [Csus4]/ /         
[C] Heartache on [G]heartache  {c:(34,1234)}
  
[D] Who was gonna be 
[C]Who would be the first to dance
[D] Who was gonna be 
[C]Who would be the first to kiss 
under those patio [G]lanterns  {c:(34,12)}
 
[C]/    [C]/    [D]    Those patio lanterns 
They were the [C]stars [G]in the s[Gsus4]ky         [G]
{c:                                               (stars     in the)} 
[D] Those patio lanterns 
{c:(sky-y-y...                           )}
[C]Lighting [G]up our l[Gsus4]ives       [G]
{c:                           (lighting up our)}
[D] Those patio lanterns
{c:(li-i-i...                         ves... )} 
They were the [C]stars [G]in the s[Gsus4]ky           [G]
{c:                                               (stars     in the)}
[D] Those patio lanterns
{c:(sky-y-y...                       )} 
Lighting up our [C]li...ives    [C/]           
Oh, those patio [G/]lanterns
_________________________________

















