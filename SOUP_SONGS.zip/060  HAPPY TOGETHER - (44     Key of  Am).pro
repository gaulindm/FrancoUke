

{title:060  HAPPY TOGETHER}
{subtitle:(4/4     Key of  Am)}
{subtitle:(Garry Bonner & Alan Gordon)}
{time: 3:10}
{metronome: 124}

{c:Verses are soft, and choruses are louder}





{c:INTRO: (SOFT. Emphasize 2nd and 4th beats)}

[Am]/ / / /   / / / /   
[Am]/ / / /   / / /   

Imagine  [Am]me and you, I do, I think about you 
[G]Day and night, it's only right to think about the 
[F]Girl you love and hold her tight 
So happy to[E7]gether

If I could [Am]call you up, invest a dime, and you say you    
               {c:(Call…        you…          up...  )         }                                  
Be[G]long to me, and ease my mind, imagine how the   
  {c:(Ease…       my…                     mind…)} 
[F]World could be so very fine, so happy to[E7]gether
{c:(Ver…                ry…           fine…                  together)}

{soc}
     [A]I can't see me [G]loving nobody but                       
     {c:(Ah…                 ah...  )}       
     [A]You, for all my [C]life    
     {c:(Ah...                  ah...)}                                      
     [A]When you're with me, [G]baby, the skies will be        
     {c:(Ah…                                ah...  ) }               
     [A]Blue, for all my [C]life {c:(234)}    
     {c:(Ah...                   ah...      )}
{eoc}

[Am]Me and you and you and me, no matter how they 
{c:(You...      and…                  me...  )}   
[G]Toss the dice it had to be, the only one for
{c:(Dice...       will...           be…)}              
[F]Me is you and you for me, so happy to[E7]gether   
{c:(You ...   for...                 me...                   together)}

{soc}
     [A]I can't see me [G]loving nobody but 
     {c:(Ah...               ah…)  }       
     [A]You,    for all my   [C]life       
     {c:(Baaa, ba-ba-ba-baaa…  )}
     [A]When you're with me, [G]baby, the skies will be      
     {c:(Ah...                               ah...  )}        
     [A]Blue,   for all my   [C]life {c:(234)}
     {c:Baaa, ba-ba-ba-baaa…  )}
{eoc}

[Am]Me and you and you and me, no matter how they 
{c:(You...      and…                  me...  )}   
[G]Toss the dice it had to be, the only one for
{c:(Dice...       will...           be…)}              
[F]Me is you and you for me, so happy to[E7]gether   
{c:(You ...   for...                 me...                  together)}

{soc}
     [A]Ba ba ba ba    [G]ba, ba-ba baa ba-ba   
     {c:(Baaa...            baa, ba-ba-ba) }    
     [A]Baa, ba-ba-ba    [C]baaaa ...             
     {c:(Baa ba-ba-ba    baa…)}
     [A]Ba ba ba ba    [G]ba, ba-ba baa ba-ba   
     {c:(Baaa...            baa, ba-ba-ba)  }     
     [A]Baa, ba-ba-ba    [C]baaaa {c:(234,1234)}             
     {c:(Baa ba-ba-ba     BAA…(hold for 8) )}
{eoc}

[Am]Me and you and you and me, no matter how they 
{c:(You...      and…                  me...  )}   
[G]Toss the dice it had to be, the only one for
{c:(Dice...        will...          be…)}              
[F]Me is you and you for me 
{c:(You ...   for...                 me…)}
So happy to[E7]gether (oo-oo-oo-[Am]oo)            
                  {c:(Together)}
                     
How is the  [E7]Weather   (Oo-oo-oo-[Am]oo)             
We're happy to[E7]gether              [Am]   
                          {c:(Baa, ba-ba-ba Baa…)}  
So happy to[E7]gether            [Am]
{c:(ba-ba-ba Baa, ba-ba-ba Baa…)}  
     Happy to[E7]gether             [Am]                
{c:(ba-ba-ba Baa, ba-ba-ba Baa…)}       
So happy to[E7]gether           [Am]  
{c:(ba-ba-ba Baa, ba-ba-ba Baa…)} 
So happy to[E7]gether {c:(3,4)} [A/]
 {c:(ba-ba-ba Baaaa…)}  

______________________________________













