

{title:041     DON'T BE CRUEL }
{subtitle:(4/4  Key of D)}
{subtitle:(Elvis Presley)}
{time:2:43}
{metronome: 164}





[G]/ / / /     [A7]/ / / /      
[D]/ / / /    / / / /

You [D]know I can be found
Sittin' home all [D7]alone
If [G]you can't come around 
At [D]least please telephone
Don't be [Em7]cruel   [A]   
To a heart that's [D]true

[D]Baby if I made you mad 
For something I might have [D7]said
[G]Please let's forget the past 
The [D]future looks bright ahead
Don't be [Em7]cruel    [A]   
To a heart that's [D]true

{soc}
   I don't [G]want no other [A7]love
  [G]Baby it's just [A7]you I'm 
   Thinking [D]of {c:(234,1234)}
{eoc}

[D]Don't stop thinking of me 
Don't make me feel this [D7]way
Come [G]on over here and love me 
You [D]know what I want you to say
Don't be [Em7]cruel   [A]   
To a heart that's [D]true

{soc}
  Why [G]should we be a[A7]part
  I [G]really love you [A7]baby
  Cross my [D]heart {c:(234,123)}
{eoc}

Let's [D]walk up to the preacher
And let us say I [D7]do
[G]Then you'll know you'll have me
And I'll [D]know that I'll have you
Don't be [Em7]cruel   [A]   
To a heart that's [D]true

{soc}
  I don't [G]want no other [A7]love
  [G]Baby it's just [A7]you I'm 
  Thinking [D]of {c:(234,12)}
{eoc}

Don't be [Em7]cruel, (ooo [A]ooo) 
To a heart that's [D]true
Don't be [Em7]cruel (ooo [A]ooo) 
To a heart that's [D]true

{soc}
   I don't [G]want no other [A7]love
  [G]Baby it's just [A7]you 
  I'm thinking [D]of  {c:(234,1)} [A7/] [D/]
{eoc}

___________________________________





{define: D7 0 2 0 2 0}





