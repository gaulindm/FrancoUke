

{title:C15: SANTA BABY      4/4      Key of C }
{subtitle: (Philip Springer & Joan Javits)}
{metronome: 116}
{time:3:12}


[C]/ /    [A7]/ /    [F]/ /    [G7]/ /   

[C] Santa [A7]Baby, just [F]slip a sable 
[G7]Under the [C]tree, for [A7]me     [F]    
Been an [G7]awful good [C]girl
Santa [A7]Baby, so [F]hurry down the [G7]chimney 
To[C]night  [A7]/ /     [F]/ /   [G7]/ /

[C] Santa [A7]baby, a [F]'54 con[G7]vertible [C]too 
Light [A7]blue   [F]    I'll wait [G7]up for you 
[C]Dear Santa [A7]baby
So [F]hurry down the [G7]chimney to[C]night  {c:(234)} [C7]

[E7] Think of all the fun I've missed 
[A7]Think of all the fellas that I haven't kissed  [D] Next year I could be just as good if 
[G/]you'll check off my [G7/]Christmas list

[C] Santa [A7]Honey, I [F]want a yacht 
And [G7]really that's [C]not a [A7]lot     [F]  I've been an [G7]angel all [C]year, Santa [A7]Baby  So [F]hurry down the [G7]chimney 
To[C]night   [A7]/ /    [F]/ /    [G7]/ /

[C] Santa [A7]cutie, there's [F]still one thing I 
[G7]Really do [C]need... the [A7]deed   [F]  
To a [G7]platinum [C]mine, Santa [A7]Baby  So [F]hurry down the [G7]chimney 
To[C]night   [A7]/ /    [F]/ /    [G7]/ /

[C] Santa [A7]baby, [F]fill my stocking [G7]with a 
Du[C]plex and [A7]cheques     [F]  Sign your [G7]"X" on the [C]line, Santa [A7]cutie  So [F]hurry down the [G7]chimney to[C]night {c:(234)}[C7]

[E7] Come and trim my Christmas tree
[A7]Leave a ukulele just for little old me  [D] I really do believe in you 
Let's [G/]see if you be[G7/]lieve in me

[C] Santa [A7]Baby
For[F]got to mention [G7]one little 
[C]Thing... a [A7]ring   [F]    
And I don't [G7]mean on the [C]phone, Santa [A7]Baby  So [F]hurry down the [G7]chimney to[C]night [A7] 
Yes [F]Hurry down the [G7]chimney 
to[C]night [A7]     
Yeah [F]Hurry down the [G7]chimney 
To[C6]ni…ght  















