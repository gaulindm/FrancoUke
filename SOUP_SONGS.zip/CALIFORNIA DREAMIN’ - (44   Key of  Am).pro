

{title:CALIFORNIA DREAMIN’   } 
{subtitle:(4/4   Key of  Am)}
{subtitle:(John & Michelle Phillips)}
{time:2:33}
{metronome: 116}

{c:(Please turn the tablet HORIZONTAL)}


Ellen


[Count-in:]  [1234]           [E7/]   
  

All the leaves are [Am]brown   [G]              [F]    and the [G]sky is [E7sus4]gray                         [E7]/ /
                             [Am]{c:(all the }[G]{c:leaves are }[F]{c:brow...    }[G]{c:own)  }[E7sus4]{c:       (and the sky is }[E7]{c:gra…)}          

[F]I’ve been for a [C]walk       [E7]         [Am]     On a [F]winter’s [E7sus4]day                      [E7]
[F]{c:ay                   (}[C]{c:I’ve been }[E7]{c:for a }[Am]{c:wa…      }[F]{c:alk)      }[E7sus4]{c:      (on a winter’s}[E7]{c: day)}

I'd be safe and [Am]warm    [G]             [F]      If I [G]was in L.[E7sus4]A.                      [E7]
                        [Am]{c:(I’d be   }[G]{c:safe and  }[F]{c:wa…}[G]{c:arm)    }[E7sus4]{c:      (if I was in L.  }[E7]{c:A.)}

{c:CHORUS}
{soc}
California [Am]dreamin’ [G]          [F]                On [G]such a winter's  [E7sus4]day…         [E7]
                [Am]{c:Cali…    }[G]{c:fornia  }[F]{c:dreamin’, on }[G]{c:such a winter’s }[E7sus4]{c:day…)       }[E7]{c:     }
{eoc}

Stopped into a [Am]church   [G]       [F]       I passed a[G]long the [E7sus4]way      {c:(234)}   
[E7]       Well I [F]got down on my 

[C]Knees      [E7]         [Am]      And I pre[F]tend to [E7sus4]pray                    [E7]
{c:(}[C]{c:Got down }[E7]{c:on my }[Am]{c:knee…    }[F]{c:ees     }[E7sus4]{c:         I pretend to }[E7]{c:pray)}

You know the preacher likes the [Am]cold       [G]              [F]    He knows I'm [G]gonna                       
                                                        {c:(}[Am]{c:preacher }[G]{c:likes the }[F]{c:co…                 }[G]{c:old)}    

[E7sus4]stay                                         [E7]           
{c:}[E7sus4]{c:         (he knows I'm gonna }[E7]{c:stay)}
                                    
{soc}
California [Am]dreamin’ [G]          [F]                   On [G]such a winter's  [E7sus4]day…         [E7]
                [Am]{c:Cali…    }[G]{c:fornia  }[F]{c:dreamin’, on }[G]{c:such a winter’s }[E7sus4]{c:day…)       }[E7]{c:     }
{eoc}

[Am]/ / / /   / / / /   / / / /   / /    [F]/ /    
[C]/ /     [E7]/ /     [Am]/ /     [F]/ /      [E7sus4]/ / / /           [E7]/     {c:(beat)}

All the leaves are [Am]brown   [G]                  [F]       and the [G]sky is [E7sus4]gray                      [E7]/ /
                              [Am]{c:(all the }[G]{c:leaves are }[F]{c:brow...      }[G]{c:own)  }[E7sus4]{c:       (and the sky is }[E7]{c:gra…)}          

[F]I’ve been for a [C]walk        [E7]        [Am]        On a [F]winter’s [E7sus4]day                    [E7]
[F]{c:ay                 (}[C]{c:I’ve been }[E7]{c:for a }[Am]{c:wa…      }[F]{c:alk)      }[E7sus4]{c:      (on a winter’s}[E7]{c: day)}


If I didn't [Am]tell her  [G]           [F]     I could [G]leave to[E7sus4]day                                [E7]
               [Am]{c:If    I     }[G]{c:didn’t  }[F]{c:tell her…   }[G]{c:              }[E7sus4]{c:           (I could leave to}[E7]{c:day)}

{soc}
California [Am]dreamin’  [G]          [F]                  On [G]such  a  winter's  
                  [Am]{c:Cali…     }[G]{c:fornia  }[F]{c:dreamin’, on }[G]{c:such a winter’s)} 

[Am]Day, Cali[G]fornia [F]dreamin’ on [G]such a winter's 

[Am]Day, Cali[G]fornia [F]dreamin’ on [G]such a winter's 
     
[E7sus4]da…      {c:(234)   (}[E7]{c:1234)…}  [A/]    
{eoc}


____________________________________



{define: E7sus4 0 2 2 0 2}









