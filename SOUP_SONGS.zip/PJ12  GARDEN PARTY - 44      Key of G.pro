{title: GARDEN PARTY     }
{subtitle: 4/4      Key of G}
{subtitle:(Rickie Nelson)}
{metronome: 142 }
{time:3:50}






{c:INTRO:}
[G]/ / / /    [C]/ / / /    
[G]/ / / /   / / / /

I [G]went to a garden [C]party 
To remi[G]nisce with my old [C]friends
A [G]chance to share old [Em]memories  
[C]  And play our [D7]songs a[G]gain
When I got to the garden [C]party 
[G]They all knew my [C]name
But [G]no one recog[Em]nized me  
[C]  I didn't [D7]look the [G]same

{soc}
But it's [C]    all [D7]right [G]now 
I [C]learned my [D7]lesson [G]well
You see you [C]       can't please [G]everyone, so you 
[C]    Got to [D7]please your[G]self  {c:(234,1234)}
{eoc}
 
[G]People came from [C]miles around 
[G]Everyone was [C]there
[G]Yoko brought her [Em]walrus, there was 
[C]   Magic [D7]in the [G]air
And over in the [C]corner, [G]much to my sur[C]prise
[G]Mr. Hughes hid in [Em]Dylan's shoes 
[C]   Wearing [D7]his dis[G]guise
 
{soc}
But it's [C]    all [D7]right [G]now 
I [C]learned my [D7]lesson [G]well
You see you [C]      can't please [G]every[Em]one, so you 
[C]    Got to [D7]please your[G]self 
[C]    Lot [D7]da…  [G]da   {c:(234)}
[C]    Lot ’n  [D7]da da  [G]da   {c:(234)}

[C]/ / / /    [G]/ /    [Em]/ /    
[C]/ /    [D7]/ /    [G]/ / / / 
{eoc}
 
I [G]played them all the [C]old songs 
I [G]thought that's why they [C]came
[G]No one heard the [Em]music 
[C]   We didn't [D7]look the [G]same
I said hello to [C]Mary Lou 
[G]   She belongs to [C]me
When I [G]sang a song about a [Em]honky tonk 
[C]  It was [D7]time to [G]leave
  
{soc}
But it's [C]    all [D7]right [G]now 
I [C]learned my [D7]lesson [G]well
You see you [C]   can't please [G]every[Em]one, so you 
[C]    Got to [D7]please your[G]self
[C]    Lot [D7]da…  [G]da   {c:(234)}
[C]    Lot ’n  [D7]da da  [G]da   {c:(234)}

[C]/ / / /    [G]/ /    [Em]/ /    
[C]/ /    [D7]/ /    [G]/ / / 
{eoc}

Someone [G]opened up the [C]closet door 
And [G]out stepped Johnny B. [C]Goode
[G]Playing guitar like a [Em]ringin' a bell 
[C]   And lookin [D7]‘like he [G]should
If you [G]gotta play at garden [C]parties 
I [G]wish you a lotta [C]luck
But if [G]memories were [Em]all I sang 
[C]   I’d rather [D7]drive a [G]truck
 
{soc}
But it's [C]    all [D7]right [G]now 
I [C]learned my [D7]lesson [G]well
You see you [C]   can't please [G]every[Em]one, so you 
[C]    Got to [D7]please your[G]self
[C]    Lot [D7]da…  [G]da   {c:(234)}
[C]    Lot ’n  [D7]da da  [G]da   {c:(234)}

[C]/ / / /    [G]/ /    [Em]/ /    
[C]/ /    [D7]/ /    [G/]

But it's, [C]    all [D7]right [G]now 
I [C]learned my [D7]lesson [G]well, you see you
[C]  Can't please [G]every[Em]one, so you 
[C]  Got to [D7]please your[G/]self  
{eoc}