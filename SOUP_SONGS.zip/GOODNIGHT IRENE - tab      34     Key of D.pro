{title:GOODNIGHT IRENE    }
{subtitle: tab      3/4     Key of D    }
{subtitle: (Lead Belly)}
{metronome:140 }
{time:2:40 }






{c:INTRO:}
{c: A7 / / /   / / / }
{c: D / / /   / / /}

{soc}
  [D]Irene good[A7]ni-i-ight, Irene good[D]night  
  Goodnight I[D7]rene, good[G]night Irene
  I'll [A7]see you in my [D]dreams  
{eoc}

Last Saturday night I got [A7]married  
Me and my wife settled [D]down  
Now me and my [D7]wife are [G]parted  
I'm gonna [A7]take another stroll down[D]town

{soc}
  [D]Irene good[A7]ni-i-ight, Irene good[D]night  
  Goodnight I[D7]rene, good[G]night Irene
  I'll [A7]see you in my [D]dreams  
{eoc}

Sometimes I live in the [A7]country  
Sometimes I live in [D]town  
Sometimes I [D7]take a great [G]notion
To [A7]turn my life upside [D]down

Stop [D]rambling, stop your [A7]gambling 
Stop staying out late at [D]night  
Go home to your [D7]wife and [G]family
Stay [A7]there by your fireside [D]bright 

{soc}
  [D]Irene good[A7]ni-i-ight, Irene good[D]night  
  Goodnight I[D7]rene, good[G]night Irene
  I'll [A7]see you in my [D]dreams   [D/]
{eoc}
