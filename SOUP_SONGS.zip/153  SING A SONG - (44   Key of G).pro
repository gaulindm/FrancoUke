

{title:153  SING A SONG   }
{subtitle:(4/4   Key of G)}
{subtitle:(Joe Raposo) }
{subtitle:(As sung by Karen Carpenter)}
{time:4:06}
{metronome: 130}




{c:(la-la’s)}
[G]/ / / /      [Gmaj7]/ / / /      
[Am]/ / / /      [D]/ / / /
[G]/ / / /      [Gmaj7]/ / / /      
[Am]/ / / /      [D]/ / / /  

[G]Sing… sing a [Am]song
Sing out [Gmaj7]loud, sing out [Dm]strong [G7]  [Cmaj7] Sing of good things not [G]bad 
[Em7] Sing of [A7]happy not [Am]sad   [D7] 

[G]Sing… sing a [Am]song
Make it [G]simple to [Gmaj7]last     your 
Whole life [Dm]long  [G7]  Don't [Cmaj7]worry that it's not [Em]good enough 
For [G]anyone else to [A7]hear  Just [D]sing…   [D7]      sing a [G]song 

[G]La la-la-la-la,   la [Gmaj7]la la-la-la-la
La [Am]la la la-la-la- [D]la 
[G]La la-la-la-la,   la [Gmaj7]la la-la-la-la
La [Am]la la la-la-la- [D]la 

[G]Sing… sing a [Am]song 
Let the [Gmaj7]world sing a[Dm]long  [G7]  [Cmaj7]  Sing of love there could [G]be 
[Em7]  Sing for [A7]you and for [Am]me   [D7] 

[G]La la-la-la-la,  la [Gmaj7]la la-la-la-la,      {c:(Sing...                           sing a)}   
La [Am]la la la-la-la- [D]la 
    {c:(song…             )}
              [G]La la-la-la-la, la [Gmaj7]la la-la-la-la,           {c:(Make it simple… to         last your whole life)} 
La [Dm]la la la-la-la la [G7]la      {c:(long…                        )}

Don't [Cmaj7]worry that it's not [Em]good enough 
For [G]anyone else to [A7]hear  Just [D]sing,   [D7]      sing a [G]song 
Just [D]sing,   [D7]      sing a [G]song 
Just [D]sing,   [D7]      sing a [G]song  {c:(234,1234)}

{c:OUTRO: (la-la’s)}  
[G]/ / / /     [Gmaj7]/ / / /      [Am]/ / / /      [D]/ / / / 
[G]/ / / /     [Gmaj7]/ / / /      [Am]/ / / /     [G]/ 

____________________________________


{define: D7 0 2 0 2 0}







