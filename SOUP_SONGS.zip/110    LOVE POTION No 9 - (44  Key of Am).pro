

{title:110    LOVE POTION No. 9  }
{subtitle:(4/4  Key of Am)}  
{subtitle:(Jerry Leiber and Mike Stoller) }
{time:3:01}
{metronome:136}





[Am]Ooh, [Dm]ah,      [Am]Ooh, [Dm]ah
[Am]Ooh, [Dm]ah,      [Am]Ooh, [Dm]ah

[Am]  I took my troubles down to [Dm]Madame Ruth
[Am]  You know that gypsy with the 
[Dm]Gold-capped tooth
[C]She's got a pad down on [Am]Thirty-Fourth and Vine
[Dm]Sellin' little bottles of [E7/]      Love Potion Number 
[Am]Nine  [Dm]aah    [Am]ooh   [Dm]aah       
[Am]Ooh   [Dm]aah    [Am]ooh   [Dm]aah     

                                                                     
[Am]  I told her that I was a [Dm]flop with chicks
[Am]  I've been this way since nineteen [Dm]     fifty-six
She [C]looked at my palm and she 
[Am]Made a magic sign
She [Dm]said what you need is 
[E7/]   Love Potion Number 
[Am]Nine   [Dm]aah    [Am]ooh  [Dm]aah       
[Am]Ooh    [Dm]aah    [Am]ooh  [Dm]aah     
                                                                                                                                                          
{c: BRIDGE}
{sob}
She [Dm]bent down and turned around 
And gave me a wink
She [B7]said "I'm gonna make it up right 
Here in the sink"
It [Dm]smelled like turpentine, it looked like Indian ink
I [E7/]held my nose, I [E7/]closed my eyes 
[E7/]      I took a [E7/]drink  
[Am]ooh  [Dm]aah     [Am]ooh   [Dm]aah      
[Am]ooh  [Dm]aah     [Am]ooh   [Dm]aah    
                                                                               
[Am]        I didn't know if it was [Dm]day or night
[Am]        I started kissin' every[Dm]thing in sight
But [C]when I kissed a cop down on 
[Am]Thirty-Fourth and Vine 
He [Dm]broke my little bottle of 
[E7/]  Love Potion Number 
[Am]Nine   [Dm]aah    [Am]ooh  [Dm]aah       
[Am]Ooh   [Dm]aah     [Am]ooh  [Dm]aah                                                                                                                                                                
{eob}

{sob}
She [Dm]bent down and turned around 
And gave me a wink
She [B7]said "I'm gonna make it up right 
Here in the sink"
It [Dm]smelled like turpentine, it looked like Indian ink
I [E7/]held my nose, I [E7/]closed my eyes 
[E7/]      I took a [E7/]drink  
[Am]ooh [Dm]aah    [Am]ooh [Dm]aah   
[Am]ooh [Dm]aah    [Am]ooh [Dm]aah    
                                                                               
[Am]        I didn't know if it was [Dm]day or night
[Am]        I started kissin' every[Dm]thing in sight
But [C]when I kissed a cop down on 
[Am]Thirty-Fourth and Vine                                                                                                                                                                
{eob}

He [Dm]broke my little bottle of [E7/]      Love Potion Number 
[Am]Nine [Dm]       [E7/]      Love Potion Number 
[Am]Nine [Dm]       [E7/]      Love Potion Number  
[Am]Nine [Dm]       [E7/]      Love Potion Number [Am]Ni-i-i-i-ine

_____________________________________________



{define:  E7/  0 1 2 0 2}






