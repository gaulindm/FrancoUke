{title: WHEN THE SAINTS} 
{title:GO MARCHING IN}
{subtitle:(4/4     Key of C)    }
{time: 2:40}
{metronome: 184}
 





      
[C]/ / / /      [G7]/ / / /     
[C]/ / / /    /

{c:CHORUS}
{soc}
     Oh, when the [C]Saints, (oh, when the Saints) 
     Go marching in, (go marching in) 
     Oh, when the Saints go marching [G7]in
     Oh Lord, I [C]want to [C7]be in that [F]number 
     When the [C]Saints go [G7]marching [C]in [C/]
{eoc}

Oh, when the [C]sun, (oh, when the sun) 
Refuse to shine, (refuse to shine)
Oh, when the sun refuse to [G7]shine
Oh Lord, I [C]want to [C7]be in that [F]number 
When the [C]sun re[G7]fuse to [C]shine  [C/]

{soc}
     Oh, when the [C]Saints, (oh, when the Saints) 
     Go marching in, (go marching in) 
     Oh, when the Saints go marching [G7]in
     Oh Lord, I [C]want to [C7]be in that [F]number 
     When the [C]Saints go [G7]marching [C]in  [C/]

Oh, when the [C]trumpet, (oh, when the trumpet) 
Sounds the call, (sounds the call)
Oh, when the trumpet sounds the [G7]call
Oh Lord, I [C]want to [C7]be in that [F]number
When the [C]trumpet [G7]sounds the [C]call   [C/]

{soc}
     Oh, when the [C]Saints, (oh, when the Saints) 
     Go marching in, (go marching in) 
     Oh, when the Saints go marching [G7]in
     Oh Lord, I [C]want to [C7]be in that [F]number 
     When the [C]Saints go [G7]marching [C]in  [C/]


     Oh, when the [C]Saints, (oh, when the Saints) 
     Go marching in, (go marching in) 
     Oh, when the Saints go marching [G7]in
     Oh Lord, I [C]want to [C7]be in that [F]number 
     When the [C]Saints go [G7]marching [C]in 
     When the [C]Saints go [G7]marching [C]in
     When the [C]Saints go [G7]marching [C]in   [C/] [G7/] [C/]
{eoc}
