
{title:MOON SONGS  }
{subtitle:(4/4     Key of C)} 
{subtitle:(Moonlight Bay}
{subtitle:(Shine On Harvest Moon)}
{subtitle:(By The Light of the Silvery Moon)}
{time:3:15}
{metronome: 114}


{c:INTRO:}  
[C]/ / / /      [G7]/ / / /     
[C]/ / / /    /

{c:(Moonlight Bay)}
[C]We were sailing along {c:(234)}  [C7]   
On [F]Moonlight [C]Bay
We could hear the voices [G7]ringing 
They seemed to [C//]say  [F]//   [C]/ 
You have stolen my heart  {c:(234)}  [C7]      
Now [F]don't go [C]'way
As we [G7]sang love's old sweet song 
On Moonlight [C//]Bay  [F//]    [C//]    [E7//]

{c:(Shine on, Harvest Moon)}
[A7]Shine on shine on harvest 
[D7]Moon up in the sky
[G7]I ain't had no loving since 
[C/]January, [C/]February, [C/]June or Jul[C/]y [C/]
[A7]Snow time ain't no time to 
[D7]Sit outside and spoon
[G7]Shine on shine on harvest [C]moon 
For [F]me and my [C]gal
 
{c:(By The Light of the Silvery Moon)}
By the [C]light of the Silvery 
[D7]Moon I want to [G7]spoon
To my honey I'll [C]croon [C#dim]love's [G7]tune 
Honey [C]moon, keep a shining in 
[F]Ju- [A7]u- [Dm]une 
Your silv'ry [C]beams will [Fm]bring love [C]dreams 
We'll be [Am]cuddling [D7]soon
By the [G7]sil-v'ry [C]moon

By the [C]light (not the dark, but the light) 
Of the Silvery [D7]Moon (not the sun, but the moon) 
I want to [G7]spoon (not knife, but spoon) 
To my honey I'll [C]croon [C#dim]love's [G7]tune 
Honey [C]moon, (not the sun, but the moon) 
Keep a-shining in [F]Ju- [A7]u- [Dm]une 
Your sil-v'ry [C]beams will [Fm]bring love [C]dreams
We'll be [Am]cuddling [D7]soon
By the [G7]silv'ry [C/]moon

_________________________________________









{define: C#dim 0 0 1 0 1}
{define: D7 0 2 0 2 0}



