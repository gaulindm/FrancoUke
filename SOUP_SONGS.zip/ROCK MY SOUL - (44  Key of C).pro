{title:ROCK MY SOUL }
{subtitle:(4/4  Key of C)}   
{subtitle:(Peter, Paul & Mary)}
{metronome: 150}
{time: 2:30}







{c:This song is usually sung as a 'Round'}
{c:but you don't have to}

{c:INTRO:}  
[G7]/ / / /     [C]/ / / / 

{c:Verse 1}
[C]Rock my soul in the bosom of Abraham
[G7]Rock my soul in the bosom of Abraham
[C]Rock my soul in the bosom of Abraham
[G7]Oh, rock-a my [C]soul***

{c:Verse 2}
[C]So high I can‟t get over it
[G7]So low I can‟t get under it
[C]So wide I can‟t get round it
[G7]Oh, rock-a my [C]soul

{c:Verse 3}
[C]Rock my soul
[G7]Rock my soul
[C]Rock my soul
[G7]Oh, rock-a my [C]soul  [G7/] [C/]

