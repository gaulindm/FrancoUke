{title:GET TOGETHER}
{subtitle:4/4      Key of G}
{subtitle: (Chet Powers)}
{metronome: 102}
{time:4:20}



{c:(Optional riff is played)}
{c:(twice through the INTRO)}

{sot}
E| - 3 - 3 - 3 - 3 - 1 - 1 - 1 - 1    
C| 2 - 4 - 2 - 4 - 0 - 4 - 0 - 4 -  
{eot}

{c:INTRO:}
   
[G/]     {c:(234)}   [F/]    {c:(234)}   
[G/]     {c:(234)}   [F/]    {c:(234)}     
[G]/ / / /   / / / /
   
[G] Love is but the song we sing {c:(4,12)}
And fear's the way we d[F]ie {c:(34,1234)}

[G] You can make the mountains ring 
Or make the angels c[F]ry {c:(34,1234)}

[G] Though the bird is on the wing 
And you may not know wh[F]y {c:(34,1234)}

{soc}
[C] C'mon people now, [D]   smile on your brother 
Every[G]body get together,try to 
[C]Love one a[D]nother right [G]now {c:(234,1234)}
{eoc} 

[G] Some may come and some may go {c:(4,12)}
We will surely p[F]ass {c:(234,1234)}

[G] When the one that left us here 
Returns for us at l[F]ast {c:(234,1234)}

[G] We are but a moments sunlight 
Fading in the gr[F]ass {c:(234,1234)} 

{soc}
[C] C'mon people now, [D]   smile on your brother 
Every[G]body get together,try to 
[C]Love one a[D]nother right [G]now {c:(234,1234)}
{eoc} 

{soc}
[C] C'mon people now, [D]   smile on your brother 
Every[G]body get together,try to 
[C]Love one a[D]nother right [G]now {c:(234,1234)}
{eoc} 

[G] If you hear the song I sing {c:(4,12)}
You will under[F]stand...{c:(234)} listen {c:(234)}

[G] You hold the key to love and fear
All in your trembling han[F]d {c:(234,1234)}

[G] Just one key unlocks them both 
It's there at your comma[F]nd {c:(234,1234)}

{soc}
[C] C'mon people now, [D]   smile on your brother 
Every[G]body get together,try to 
[C]Love one a[D]nother right [G]now {c:(234,1234)}

[C] C'mon people now, [D]   smile on your brother 
Every[G]body get together,try to 
[C]Love one a[D]nother right [G]now {c:(234,12)}
Right n[G]ow… {c:(234,12)} right n[G/]ow
{eoc}
