

{title: 013  A HARD DAY'S NIGHT}
{subtitle:    4/4    Key of G}
{subtitle:(The Beatles)}
{metronome: 148    }
{time:  3:30}

{c:Note: After the count-in,}
{c:strum the D7 chord strongly and let it ring out,}
{c:then follow the counts before singing}




[D7/] {c:(234,123)}
It's been a [G]hard [C]day's [G]night
And I've been [F]working like a [G]dog
It's been a [G]hard [C]day's [G]night
I should be [F]sleeping like a [G]log
But when I [C]get home to you
I find the [D]things that you do
Will make me [G]feel [C]all [G]right

You know I [G]work [C]all [G]day
To get you [F]money to buy you [G]things
And it's [G]worth it just to [C]hear you [G]say 
You're gonna [F]give me everyth[G]ing
So why on [C]earth should I moan
Cause when I [D]get you alone 
You know I [G]feel [C]o[G]kay

When I'm [Bm]home
[Em]Everything seems to be [Bm]right
When I'm [G]home 
[Em]Feeling you holding me 
[C]Tight, [D]tight yeah

It's been a [G]hard [C]day's [G]night
And I've been [F]working like a [G]dog
It's been a [G]hard [C]day's [G]night 
I should be [F]sleeping like a [G]log
But when I [C]get home to you
I find the [D]things that you do 
Will make me [G]feel [C]all [G]right

[G]/ /   [C]/ /   [G]/ / / /   [F]/ / / /   [G]/ / / /
[G]/ /   [C]/ /   [G]/ / / /   [F]/ / / /   [G]/ / /

So why on [C]earth should I moan
Cause when I [D]get you alone 
You know I [G]feel [C]o[G]kay

When I'm [Bm]home
[Em]Everything seems to be [Bm]right
When I'm [G]home 
[Em]Feeling you holding me 
[C]Tight, [D]tight yeah

It's been a [G]hard [C]day's [G]night 
And I've been [F]working like a [G]dog
It's been a [G]hard [C]day's [G]night 
I should be [F]sleeping like a [G]log
But when I [C]get home to you
I find the [D]things that you do 
Will make me [G]feel [C]all [G]right
You know I [G]feel [C]all [G]right
You know I [G]feel [C]all [G/]right

_________________________________











