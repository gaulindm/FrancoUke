{title:BOBCAYGEON}
{subtitle:  4/4      Key of G  }
{subtitle:The Tragically Hip}

[C]/ / / /   / / / /    [Dm]/ / / /   / / / /
 
{c:(}[C]{c:1234)} I left your house this [Dm]morning 
{c:(}[C]{c:123)}  'Bout a quarter after ni[Dm]ne 
{c:(}[C]{c:123)}  Coulda been the Willie Nel[Dm]son
{c:(}[C]{c:1234)}  Coulda been the wi[Dm]ne
{c:(}[Em]{c:123)}  When I left your house this [F]morning {c:(34,123)}
It was a [C]little a...fter ni-[Dm]i-i-ine 
It was in Bob[Em]caygeon 
I saw the constel[F]lations
Re[C]veal themselves one star at a [Dm]time 
 
[C]/ / / /   / / / /   	[Dm]/ / / /   / / / /
 		     
{c:(}[C]{c:123)}  Drove back to town this [Dm]morning 
{c:(}[C]{c:123)} With working on my [Dm]mind
{c:(}[C]{c:1234)} I thought of maybe [Dm]quitting
{c:(}[C]{c:123)} I thought of leaving it be[Dm]hind
{c:(}[Em]{c:123)} Went back to bed this [F]morning 
{c:(}[C]{c:123)} And as I'm pulling down the [Dm]blind
Yeah the [Em]sky was dull and hypo[F]thetical
And [C]falling one cloud at a [Dm]time
 
That night in Tor[Am]onto 
with its [F]checkerboard floors 
Riding on [C]horseback and keeping [G]order restored 
Til the men they [Am] couldn't hang 
Stepped to the [F]mic and sang 
And their [G]voices rang with that Aryan twang 
 
[C]/ / / /   / / / /    	[Dm]/ / / /   / / / /
  
{c:(}[C]{c:123)} I got to your house this [Dm]morning 
{c:(}[C]{c:123)} Just a little after [Dm]nine
{c:(}[C]{c:123)} In the middle of that [Dm]riot
{c:(}[C]{c:123)} Couldn't get you off my [Dm]mind
{c:(}[C]{c:123)} So I'm at your house this morning {c:(34,123)}
Just a [C]little a...fter ni-[Dm]i-i-ine
Cause it was in Bob[Em]caygeon 
Where I saw the conste[F]llations
Re[C]veal themselves one star at a time

[C]/ / / /   / / / /    	[Dm]/ / / /   / / / /    [C/]

___________________________________________
















