{title:  SUGARTIME  }
{subtitle:(4/4   Key of C)}   
{subtitle:(Charlie Phillips & Odis Echols)}
{time: 2:50}
{metronome: 180}







{c:INTRO: }
[G7]/ / / /    / / / /     
[C]/ /     [F]/ /     [C]/ / / /  

[C]Sugar in the mornin', [C7]sugar in the evenin'
[F]Sugar at supper[C]time
[G7]Be my little sugar and 
[C]Love me [F]all the [C]time
[C]Honey in the mornin', [C7]honey in the evenin' 
[F]Honey at supper[C]time
[G7]be my little honey and 
[C]Love me [F]all the [C]time

{soc}
[G7]Put your arms a[C]round me
And [G7]swear by the stars a[C]bove
[G7]You'll be mine for[C]ever in a 
[D7]Heaven of [G7]love

[C]Sugar in the mornin', [C7]sugar in the evenin'
[F]Sugar at supper[C]time
[G7]Be my little sugar and 
[C]Love me [F]all the [C]time

    Now sugar[G7]time is any[C]time 
    That you're [G7]near, or just ap[C]pear
    So, don't you [G7]roam, just be my 
    [C]Honeycomb (honeycomb, honeycomb)
    And [D7]live in a heaven of [G7]love

[C]Sugar in the mornin', [C7]sugar in the evenin'
[F]sugar at supper[C]time
[G7]Be my little sugar and 
[C]Love me [F]all the [C]time
{eoc}

{soc}
[G7]Put your arms a[C]round me
And [G7]swear by the stars a[C]bove
[G7]You'll be mine for[C]ever in a 
[D7]Heaven of [G7]love

[C]Sugar in the mornin', [C7]sugar in the evenin'
[F]Sugar at supper[C]time
[G7]Be my little sugar and 
[C]Love me [F]all the [C]time

    Now sugar[G7]time is any[C]time 
    That you're [G7]near, or just ap[C]pear
    So, don't you [G7]roam, just be my 
    [C]Honeycomb (honeycomb, honeycomb)
    And [D7]live in a heaven of [G7]love

[C]Sugar in the mornin', [C7]sugar in the evenin'
[F]sugar at supper[C]time
[G7]Be my little sugar and 
[C]Love me [F]all the [C]time
{eoc}

{c:OUTRO}
[C]Sugar in the mornin', [C7]sugar in the evenin', 
[F]sugar at supper[C]time
{c:(slowly)}  
[G7]Be my little sugaaaar and 
[C]love me… [F]all the… [C]time… 


{define: D7 0 2 0 2 0}

