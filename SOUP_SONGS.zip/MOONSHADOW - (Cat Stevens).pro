{title:MOONSHADOW}
{subtitle:(Cat Stevens)}
{metronome: 132}
{time:4:00}

 



{c:This gentle song sounds best picked}

{c:INTRO:}

[Gm]/ /     [C7]/ /    [F]/    [A]/    [Dm]/
[Gm]/ /    [C]/ /    [F]/ / / /


Oh, [F]I'm bein' followed by a [Bb]moon[F]shadow 
[Bb]moonshadow, [C7]moon[F]shadow
[F]Leapin and hoppin' on a [Bb]moon[F]shadow 
[Bb]moonshadow, [C7]moon[F]shadow

Verse 1:
[Bb]And if I [F]ever lose [Bb]my [F]hands 
[Bb]lose my [F]plough, lose [Gm]my [C7]land
Oh [Bb]if I [F]ever lose [Bb]my [F]hands 
Oh [Gm]if…   [C7]…      [F/]   [A/]  [Dm/] 
I [Gm]won't have to [C]work no [F]more


Oh,[F]I'm bein' followed by a [Bb]moon[F]shadow 
[Bb]moonshadow, [C7]moon[F]shadow
[F]Leapin and hoppin' on a [Bb]moon[F]shadow 
[Bb]moonshadow, [C7]moon[F]shadow

And [Bb]if I [F]ever [Bb]lose my [F]eyes 
[Bb]if my [F]colours [Gm]all run [C7]dry 
Yes [Bb]if I [F]ever [Bb]lose my [F]eyes 
Oh [Gm]if…   [C7]…      [F/]   [A/]  [Dm/] 
I [Gm]won't have to [C]cry no [F]more

Oh,[F]I'm bein' followed by a [Bb]moon[F]shadow 
[Bb]moonshadow, [C7]moon[F]shadow
[F]Leapin and hoppin' on a [Bb]moon[F]shadow 
[Bb]moonshadow, [C7]moon[F]shadow

Verse 3:
And [Bb]if I [F]ever [Bb]lose my [F]legs 
[Bb]I won'[F]t moan, [Gm]and I wo[C7]n't beg
Yes [Bb]if I [F]ever [Bb]lose my [F]legs 
Oh [Gm]if…   [C7]…      [F/]   [A/]  [Dm/] 
I [Gm]won't have to [C]walk no [F]more

Oh,[F]I'm bein' followed by a [Bb]moon[F]shadow 
[Bb]moonshadow, [C7]moon[F]shadow
[F]Leapin and hoppin' on a [Bb]moon[F]shadow 
[Bb]moonshadow, [C7]moon[F]shadow

And [Bb]if I [F]ever [Bb]lose my [F]mouth 
[Bb]all my[F] teeth, [Gm]north an[C7]d south 
Yes [Bb]if I [F]ever [Bb]lose my [F]mouth 
Oh [Gm]if…   [C7]…      [F/]   [A/]  [Dm/] 
I [Gm]won't have to [C]talk no [F]more

Oh,[F]I'm bein' followed by a [Bb]moon[F]shadow 
[Bb]moonshadow, [C7]moon[F]shadow
[F]Leapin and hoppin' on a [Bb]moon[F]shadow 
[Bb]moonshadow, [C7]moon[F]shadow

[G7]Did it take long to [C]find me  
I [G7]asked the faithful [C]light
[G7]Did it take long to [C]find me  
[And G7]are you gonna stay the [C]night

Oh,[F]I'm bein' followed by a [Bb]moon[F]shadow 
[Bb]moonshadow, [C7]moon[F]shadow
[F]Leapin and hoppin' on a [Bb]moon[F]shadow 
[Bb]moonshadow, [C7]moon[F]shadow
[Bb]moonshadow, [C7]moon[F]shadow

