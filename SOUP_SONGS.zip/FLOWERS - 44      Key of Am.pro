{title: FLOWERS      }
{subtitle:4/4      Key of Am  }
{subtitle: (Miley Cyrus, Gregory Hein, Michael Pollack)}
{metronome: 128}
{time:3:59}

[C]/ / /

We were  [Am]good, we were [Dm]gold 
Kind of  [G]dream that can't be [C]sold
We were  [Am]right, 'til we [Dm]weren't 
Built a [G]home and watched it [C]burn {c:(23)}
 
Mmm...  [Am]I didn't wanna leave you, [Dm]I didn't wanna lie
[E7/]Started to cry, but then re[E7/]membered I..  {c:(beat)}


{soc} 
   [Am]      I can buy myself  flo[Dm]wers  {c:(234)}  
   [G]       Write my name in the sa-[C]and  
   [Am]      Talk to myself for  ho[Dm]urs  {c:(234)}  
   [G]       Say things you don't under[C]stand
   [Am]      I can take myself [Dm]dancing {c:(34)} 
   [G]       And I can hold my own  [C]hand 
   Yeah, I can [F]love me better  [E7/]than {c:(23)} you 
 
   {c:(}[Am]{c:Can)} Can love me better,  [Dm]I can love me better, Baby
   [G]   Can love me better,  [C]I can love me {soh}(better, Baby){eoh}
{eoc} 

{soh}(Paint my){eoh} [Am]nails cherry [Dm]red 
Match the [G]roses that you [C]left  
No rem[Am]orse, no re[Dm]gret
I for[G]give every word you [C]said  {c:(23)}
 
Oooh, [Am]I didn't wanna leave, baby, [Dm]I didn't wanna fight
 [E7/]Started to cry, but then re[E7/]membered I...  {c:(beat)}
 
{soc} 
   [Am]      I can buy myself  flo[Dm]wers {c:(234)}  
   [G]       Write my name in the sa-[C]and  
   [Am]      Talk to myself for ho[Dm]urs  {c:(23)} 
   (Yeah-[G]eah) say things you don't under[C]stand
   [Am]       I can take myself [Dm]dancing {c:(beat)} 
   (Yeah-[G]eah) and I can hold my own  [C]hand 

   Yeah, I can [F]love me better  [E7/]than {c:(23)} you  
 
   {c:(}[Am]{c:Can)} Can love me better,  [Dm]I can love me better, Baby
   [G] Can love me better,  [C]I can love me better, Baby 
   [Am] Can love me better,  [Dm]I can love me better, baby
   [G]   Can love me better, (oooh) [C]I... {c:(234)}
{eoc}

[Am/]I didn't wanna leave you, [Dm/]I didn't wanna fight
[E7/]Started to cry, but then remembered I... {c:(beat)}
 
{soc} 
   [Am]      I can buy myself  flo[Dm]wers {c:(23)}  
   (Uh-[G]huh) write my name in the sa-[C]and  
   [Am]      Talk to myself for  ho[Dm]urs  {c:(23)} 
   (Yeah-[G]eah)  say things you don't under[C]stand
   [Am]       I can take myself [Dm]dancing {c:(beat)} 
   (Yeah-[G]eah)  and I can hold my own  [C]hand 
   Yeah, I can [F]love me better  [E7]than {c:(23)}  
   Yeah, I can [F]love me better  [E7]↑than {c:(23)} you              

   {c:(}[Am]{c:↑Ca...n)} Can love me better,  [Dm]I can love me better, Baby
   [G]   Can love me better,  [C]I can love me better, Baby
   {c:(You} [Am]{c:↑ca...n)} Can love me better, [Dm]I can love me better, Baby
   [G]   Can love me better,  [C/]I... 
{eoc}

___________________________________________


















 
 