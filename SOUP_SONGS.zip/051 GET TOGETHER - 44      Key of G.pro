

{title:051  GET TOGETHER}
{subtitle:4/4      Key of G}
{subtitle: (Chet Powers)}
{metronome: 103}
{time:4:24}



{c:(Optional riff is played)}
{c:(twice through the INTRO)}

{sot}
E| - 3 - 3 - 3 - 3 - 1 - 1 - 1 - 1    
C| 2 - 4 - 2 - 4 - 0 - 4 - 0 - 4 -  
{eot}

{c:INTRO:}
{soc}   
[G/]     {c:(234)}   [G/][F/]    {c:(234)}   
[F/][G/]     {c:(234)}   [G/][F/]    {c:(234)} 
{eoc}

[F/] [G]/ / / /   / / / /
   
{c:(}[G]{c:12)} Love is but the song we sing {c:(4,12)}
And fear's the way we d[F]ie 

{c:(}[G]{c:12)} You can make the mountains ring {c:(4,12)}
Or make the angels c[F]ry 

{c:(}[G]{c:12)} Though the bird is on the wing {c:(4,12)}
And you may not know wh[F]y 

{soc}
[C]   C'mon people now, [D]   smile on your brother 
Every[G]body get together, try to 
[C]Love one a[D]nother right [G]now {c:(234,1234)}
{eoc} 

{c:(}[G]{c:12)}  Some may come and some may go {c:(4,12)}
We will surely p[F]ass 

{c:(}[G]{c:12)} When the one that left us here {c:(4,12)}
Returns for us at l[F]ast 

{c:(}[G]{c:12)} We are but a moments sunlight {c:(12)}
Fading in the gr[F]ass 

{soc}
[C]   C'mon people now, [D]   smile on your brother 
Every[G]body get together, try to 
[C]Love one a[D]nother right [G]now {c:(234,1234)}
{eoc} 

{soc}
[C]   C'mon people now, [D]   ↑smile on your brother 
↑Every[G]body get together, try to 
[C]↑Love one a[D]nother right [G]now {c:(234,1234)}
{eoc} 

{c:INSTRUMENTAL TABS  }
{sot}
E| - 3 - 3 - 3 - 3 - 1 - 1 - 1 - 1    
C| 2 - 4 - 2 - 4 - 0 - 4 - 0 - 4 -  
{eot}

{soc}   
[G/]     {c:(234)}   [G/][F/]    {c:(234)}   
[F/][G/]     {c:(234)}   [G/][F/]    {c:(234)} 
{eoc}

[F/] [G]/ / / /   / / / /

{c:(}[G]{c:12)}  If you hear the song I sing {c:(4,12)}
You will under[F]stand...{c:(234)} listen 

[G] You hold the key to... love and fear {c:(4,12)}
All in your trembling han[F]d 

{c:(}[G]{c:12)}  Just one key unlocks them both {c:(12)}
It's there at your comma[F]nd 

{soc}
[C]   C'mon people now, [D]   smile on your brother 
Every[G]body get together, try to 
[C]Love one a[D]nother right [G]now {c:(234,1234)}

[C]   C'mon people now, [D]   ↑smile on your brother 
↑Every[G]body get together, try to 
[C]↑Love one a[D]nother right [G]now {c:(234,1234)}

[C]   C'mon people now, [D]   ↑smile on your brother 
↑Every[G]body get together, try to 
[C]↑Love one a[D]nother right [G]now {c:(23)}

Right n[G]ow… {c:(23)} right [G]no...{c:(234)} [G/]ow
{eoc}

________________________________________












