{title:THIS LAND IS YOUR LAND }
{subtitle:(4/4   Key of C)}
{subtitle:(Woody Guthrie)}
{time: 3:15}
{metronome: 174}







{c:INTRO:} 
[D7]/ / / /     [G7]/ / / /     
[C]/ / / /    /  
         
{c:CHORUS}
{soc}
This land is [F]your land, this land is [C]my land
From Bona[G7]vista to Vancouver [C]Island [C7]
From the Arctic [F]Circle to the Great Lake [C]waters
[D7]This land was [G7]made for you and [C]me 
{eoc}

As I was [F]walking that ribbon of [C]highway 
I saw [G7]above me that endless [C]skyway [C7]
I saw be[F]low me that golden [C]valley
[D7]This land was [G7]made for you and [C]me   

{soc}
This land is [F]your land, this land is [C]my land
From Bona[G7]vista to Vancouver [C]Island [C7]
From the Arctic [F]Circle to the Great Lake [C]waters
[D7]This land was [G7]made for you and [C]me 
{eoc}

I've roamed and [F]rambled 
And followed my [C]footsteps
To the fir-clad [G7]forests 
O her mighty [C]mountains [C7] 
And all a[F]round me, a voice was [C]sounding
[D7]This land was [G7]made for you and [C]me  

{soc}
This land is [F]your land, this land is [C]my land
From Bona[G7]vista to Vancouver [C]Island [C7]
From the Arctic [F]Circle to the Great Lake [C]waters
[D7]This land was [G7]made for you and [C]me 
{eoc}

As the sun came [F]shining and I was [C]strolling
The wheat fields [G7]waving 
And the dust clouds [C]rolling [C7]
As the fog was [F]lifting, a voice was [C]chanting, 
[D7]This land was [G7]made for you and [C]me  

{soc}
This land is [F]your land, this land is [C]my land
From Bona[G7]vista to Vancouver [C]Island [C7]
From the Arctic [F]Circle to the Great Lake [C]waters
[D7]This land was [G7]made for you and [C]me 
[D7]This land was [G7]made for you and [C]me [G7/]  [C/]
{eoc}


{define: D7 0 2 0 2 0}