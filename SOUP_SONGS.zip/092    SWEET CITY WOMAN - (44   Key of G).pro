

{title:092    SWEET CITY WOMAN }
{subtitle:(4/4   Key of G)}
{subtitle:Rich Dodson (The Stampeders)}
{time:4:09}
{metronome: 166}

{c:(See tutorial for strum pattern)}





[G]/ / / /    / / / /    [C6]/ / / /    / / / /    
[Am]/ / / /   / / / /    [G]/ / / /   / / / /   

Well, I'm [G]on my way, to the [Am]city life 
To a pretty face that shines her light 
On the [G]city nights
And I gotta catch a noon train 
Gotta [Am]be there on time
Oh, it feels so good to know she waits at the 
[G]End of the line

{c:CHORUS}
{soc}
     [G]Swee-ee-eet, sweet city [Am]woman 
     I can see your face, I can hear your voice
     I can [G]almost touch you
     Swee-ee-eet, sweet city [Am]woman 
     Oh my banjo and me we got a feel for 
     [G]Singing, yeah
{eoc}

[G/]Bon c'est [G/]bon, [G/]bon bon c'est [G/]bon, bon... 
[G/]Bon c'est [G/]bon, bon, bon, [C/]bon, [G/]bon
[G/]Bon c'est [G/]bon, [G/]bon bon c'est [G/]bon, bon... 
[G/]Bon c'est [G/]bon, bon, bon, [C/]bon, [G/]bon
[C/]So... [G/]long ma, [D/]so... [G/]long pa 
[D/]So... [D7/]long {c:(beat)}  [G]Neighbors and friends

Like a [G]country mornin', all [Am]snuggled in dew
Ah she's got a way to make a man feel 
[G]Shiny and new
And she sing in the evenin', oh [Am]familiar tunes
And she feeds me love and tenderness and 
[G]Macaroons    

{soc}
     [G]Swee-ee-eet, sweet city [Am]woman 
     I can see your face, I can hear your voice
     I can [G]almost touch you
     Swee-ee-eet, sweet city [Am]woman 
     Oh my banjo and me we got a feel for 
     [G]singing, yeah
{eoc}

{c:INSTRUMENTAL}
[G]/ / / /    / / / /    [C6]/ / / /   / / / /     
[Am]/ / / /   / / / /    [G]/ / / /   / / / / 

[G]Swee-ee-eet, sweet city [Am]woman 
(Oh, she's my)  sweet sweet, sweet 
Sweet city [G]woman
Swee-ee-eet, Sweet city [Am]woman 
(Whoa my) sweet, sweet, sweet, sweet city 
[G]Woman (everybody)

{c:OUTRO:}
   [G]Sweet! Sweet! Sweet! Sweet city [Am]woman 
   (ba da da da, ba da da da)
   Sweet! sweet! Swee-eet sweet city [G]woman 
   (ba da da da, ba da da da) 

   [G]Sweet! Sweet! Sweet! Sweet city [Am]woman 
    (ba da da da, ba da da da)
    Sweet! Sweet! Swee-eet sweet city [G]woman 
    (ba da da da, ba da da da)[G/]

_______________________________________________


{define: D7 0 2 0 2 0}
{define: C6 0 0 0 0 0}
{define: D7/ 0 2 0 2 0}













