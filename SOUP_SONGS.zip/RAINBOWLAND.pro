{title:RAINBOWLAND}
{subtitle:4/4      Key of D}
{subtitle: (Miley Cirus, Dolly Parton)}
 

[A]/ / / /   / / / /

[A]Livin' in a rainbowland
Where everything goes as planned and 
[E]I smile {c:(34,1234,1234)}
’Cause I know if [E]we tried
We could really make a difference in this [A]world

I [D]won’t give up or sleep a wink 
It's the only thought I think
You know [A]where I stand
I be[E]lieve we ca...n 
Start livin’ in a rainbow[A]land
 
{soc}
[A]Livin' in a rainbowland 
Where you and I go hand in hand
Oh, I'd [E]be lyin' (I’d be lyin') 
If I said this was fine
All the hurt and the hate going on [A]    here 
(hate going on here)
[D]We are rainbows, me and you
Every color, every hue, let's [A]shine through
To[E]gether we ca...n 
Start livin' in a rainbo[A]wland
{eoc} 
 
[A]Living in a rainbowland
Where skies are blue and things are grand
Oh, wouldn't [E]it be nice to live in paradise
Where we're free to be exactly who we [A]are
[D]Let's all dig down deep inside
 
Brush the judgment and fear aside
Make [A]wrong things right (wrong things right)
And [E]end the fight 'cause I promise ain't nobody gonna[A] win

{soc}
[A]Livin' in a rainbowland 
Where you and I go hand in hand
Oh, I'd [E]be lyin' (I’d be lyin') 
If I said this was fine
All the hurt and the hate going on [A]    here 
(hate going on here)
[D]We are rainbows, me and you
Every color, every hue, let's [A]shine through
To[E]gether we ca...n 
Start livin' in a rainbo[A]wland
{eoc} 

[A]Livin' in a rainbowland
Where you and I go hand in hand [E]together 
(let's do it together)
Change things for[E]ever (forever)
I know there's got to be a greater [A]plan
[D]We are rainbows, me and you
Every color, every hue, let's [A]shine through
To[E]gether we ca...n 
Start livin' in a rainbo[A]wland
 