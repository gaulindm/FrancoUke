{title:ALL I HAVE TO DO IS DREAM  }
{subtitle:(4/4   Key of C)}
{subtitle:(Boudleaux Bryant)}
{time: 3:10}
{metronome: 94}







{c:INTRO:}
[C]/ /    [Am]/ /    [F]/ /    [G7]/    {c:(hold)}  

[C]Dree-ee-ee-ee-[Am]eam
[F]Dream dream [G7]dree-eam
[C]Dree-ee-ee-ee-[Am]eam 
[F]Dream dream [G7]dream

When [C]I want [Am]you  [F]    in my [G7]arms
When [C]I want [Am]you  [F]    and all your [G7]charms
When[C]ever I [Am]want you  
[F]All I have to [G7]do is
[C]Dree-ee-ee-ee-[Am]eam 
[F]Dream dream [G7]dree-eam

When [C]I feel [Am]blue    [F]    in the [G7]night
And [C]I need [Am]you    [F]    to hold me [G7]tight
When[C]ever I [Am]want you, [F]all I have to [G7]do is
[C]Dree-ee-ee-ee-[F]ee-ee-[C]eam [C7]

{soc}
   [F]I can make you mine, [Em]taste your lips of wine
   [Dm]Any time [G]    night or [C]day
   [F]Only trouble is  [Em]      gee wiz
   I’m [D7]dreamin' my life a[G7]way

   I [C]need you [Am]so     [F]    that I could [G7]die
   I [C]love you [Am]so     [F]    and that is [G7]why
   When[C]ever I [Am]want you, [F]all I have to [G7]do is
   [C]Dree-ee-ee-ee-[Am]eam 
   [F]Dream dream [G7]dree-eam
   [C]Dree-ee-ee-ee-[F]ee-ee-[C]eam  [C7]     

   [F]I can make you mine, [Em]taste your lips of wine
   [Dm]Any time [G]     night or [C]day
   [F]Only trouble is  [Em]        gee wiz
   I'm [D7]dreamin' my life a[G7]way

   I [C]need you [Am]so     [F]    that I could [G7]die
   I [C]love you [Am]so     [F]     and that is [G7]why
   When[C]ever I [Am]want you 
   [F]All I have to [G7]do, is
   [C]Dree-ee-ee-ee-[Am]eam 
   [F]Dream dream [G7]dree-eam
   [C]Dree-ee-ee-ee-[F]ee-ee-[C/]eam    
{eoc}
