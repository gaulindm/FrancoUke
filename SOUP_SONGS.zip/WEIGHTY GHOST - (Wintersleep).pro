{title:WEIGHTY GHOST }
{subtitle:(Wintersleep) }
{time: 3:00}







{c:INTRO (pattern throughout):}
{c:G / / / /    C / /    G / /}
{c:C / / / /   / /    G / /}

[G] I got outa [C]bed to[G]day
[C] Swear to God I couldn't see my [G]face
I got out of [C]bed to[G]day [C]staring at a ghost  [G]
Who forgot to [C]float [G]away
[C] Didn't have all that much to [G]say
Wouldn't even tell me [C]his own [G]name and 
[C]Where'd my body go?  [G]
Where oh where'd my [C]bo[G]dy go? 
[C] Africa or Mexi[G]co
Oh where'd my [C]bo[G]dy go 
And [C]where did my bo[G]dy go

{soc}
[G] Oh, have you [C]seen my [G]ghost
[C] Seen my ghost, seen my [G]ghost
[G] Oh, have you [C]seen my [G]ghost 
[C]Staring at the ground  [G]
[G] Oh, have you [C]seen my [G]ghost 
[C] Seen my ghost, see my [G]ghost
[G] Oh, have you [C]seen my [G]ghost 
[C]Sick of those goddamn [G]clouds
{eoc}

{c:G / / / /    C / /    G / /}
{c:C / / / /   / /    G / /}

Are you some kind of medicine man
Cut the demons out of my head
You can't kill something that's already dead 
so leave my soul alone
I don't need no surgery 
Take those knives away from me
Just wanna die in my own body 
A ghost just needs a home

{c:REPEAT CHORUS}

{c:Na-na’s} {c:G / / / /    C / /    G / / }
{c:   (shh) C / / / /   / /    G / /}
{c:Na-na’s} {c:G / / / /    C / /    G / / }
{c:   (shh) C / / / /   / /    G / /}

{c:CHORUS (with na-na’s)}
{soc}
[G] Oh, have you [C]seen my [G]ghost
[C] Seen my ghost, seen my [G]ghost
[G] Oh, have you [C]seen my [G]ghost 
[C]Staring at the ground  [G]
[G] Oh, have you [C]seen my [G]ghost 
[C] Seen my ghost, see my [G]ghost
[G] Oh, have you [C]seen my [G]ghost 
[C]Sick of those goddamn [G]clouds
{eoc}

{c:Na-na’s} {c:G / / / /    C / /    G / / }
{c:   (shh) C / / / /   / /    G / /}
{c:Na-na’s} {c:G / / / /    C / /    G / /  }
{c:  (shh) C / / / /   / /    G / /}
{c:Na-na’s} {c:G / / / /    C / /    G / /  }
{c:  (shh) C / / / /   / /    G / /}
{c:Na-na’s} {c:G / / / /    C / /    G / /  }
{c:  (shh) C / / / /   / /    G / }