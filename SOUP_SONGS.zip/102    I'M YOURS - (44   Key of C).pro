

{t:102    I'M YOURS    }
{subtitle:(4/4   Key of C)}   
{subtitle:(Jason Mraz)}
{metronome:156}
{time:3:54}







[C]/ / / /   / / / /    
[G]/ / / /   / / / /    
[Am]/ / / /   / / / /    
[F]/ / / /   / / /  

Well [C]you done done me and you bet I felt it 
I [G]tried to be chill but you're so hot that I melted 
I [Am]fell right through the cracks
Now I'm [F]trying to get back  
Before the [C]cool done run out 
I'll be giving it my bestest 
And [G]nothing's gonna stop me 
But divine intervention 
I [Am]reckon it's again my turn 
To [F]win some or learn some

{soc}
But [C]I won't hes-i-[G]tate no more, no [Am]more
It cannot [F]wait, I'm yo..ou..[C]ours 
{eoc}
                                                                              
Well open up your mind and see like [G]me 
Open up your plans and damn you're [Am]free 
Look into your heart and you'll find 
[F]Love love love love 
[C]Listen to the music of the moment 
People dance and [G]sing 
We’re just one big fami[Am]ly    
And it's our God-forsaken right to be 
[F]love, love, love, love, [D/]loved {c:(hold)}
 
{soc}                                                                          
So [C]I won't hes-i-[G]tate no more, no [Am]more 
It cannot [F]wait, I'm yours, there's no 
[C]Need to compli[G]cate
Our time is [Am]short; this is our [F]fate
I'm yo..ou.. [C]ours / / /   / / / /    

  [G] / / / /   / / / /    
  [Am]/ / / /   / / / /  
  [F]/ / / /   / /
{eoc}  
I've been spending [C]way too long checking my 
Tongue in the mirror, and 
[G]Bending over backwards just to 
Try to see it clearer  
But my [Am]breath fogged up the glass 
So I [F]drew a new face and laughed
I [C]guess what I'm be saying is 
There ain't no better reason 
To [G]rid yourself of vanity and 
Just go with the seasons
It's [Am]what we aim to do 
Our [F]name is our virtue

But [C]I won't hesi-[G]tate no more
No [Am]more It cannot [F]wait, I'm su-u-u
*[C]Sure, well open up your mind and 
See like [G]me, open up your plans 
And damn you're [Am]free 
Look into your heart and you'll find the 
[F]Sky is yours
So [C]please don't, please don't, please don't
There's no [G]need to complicate cause our 
[Am]Time is short, my dis, oh dis, oh dis is our 
[F]Fate, I'm you...[D/]ours 

______________________________________










