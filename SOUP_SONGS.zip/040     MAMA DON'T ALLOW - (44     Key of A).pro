

{title:040     MAMA DON'T ALLOW   }
{subtitle:(4/4     Key of A)}
{time: 2:40}
{metronome: 186}





[A]/ / / /     [A7]/ / / /     
[D]/ / / /     [D7]/ / / /     
[A]/ / / /     [E7]/ / / /      
[A]/ / / /    / / / / 
             
[A]Mama don’t allow no music playin’ ‘round here   
(No she don’t)
Mama don’t allow no music playin’ ‘round [E7]here  
(No she don’t)
Well [A]we don’t care what [A7]Mama don’t allow
We’re gonna [D]play our music [D7]anyhow
[A]Mama don’t allow no [E7]music playin’ ‘round [A]here 

[A]Mama don’t allow no ukulele playin’ ‘round here  
(No, she don’t)
Mama don’t allow no ukulele playin’ ‘round [E7]here  
(No, she don’t)
Well [A]we don’t care what [A7]Mama don’t allow
We’re gonna [D]play our ukuleles [D7]anyhow
[A]Mama don’t allow no 
[E7]Ukulele playin’ ‘round [A]here

[A]Mama don’t allow no toe tappin’ ‘round here  
(No, she don’t)
Mama don’t allow no toe tappin’ ‘round [E7]here  
(No, she don’t)
Well [A]we don’t care what [A7]Mama don’t allow
We’re gonna [D]tap our little toes [D7]anyhow
[A]Mama don’t allow no [E7]toe tappin’ ‘round [A]here

[A]Mama don’t allow no whoopdidooin’ around here 
(No, she don’t)
Mama don’t allow no whoopdidooin’ around [E7]here 
(No, she don’t)
Well [A]we don’t care what [A7]Mama don’t allow 
We’re gonna [D]whoop our doodoos [D7]anyhow
[A]Mama don’t allow no 
[E7]Whoopdidooin’ around  [A]here 
Mama don’t allow no 
[E7]Music playin’ ‘round [A]here
Mama don’t allow no 
[E7]Ukulele playing ‘round [A]here

{c:(slow)}   
No we don’t care what [A7]Mama don’t allow
We’re gonna [D]play our ukuleles [D7]anyhow! 
{c:(faster)}   
[A]Mama don’t allow no [E7]music playing ‘round 

[A////]here      [A7]/ / / /     [D]/ / / /     [D7]/ / / /,     
[A]/ / / /     [E7]/ / / /      [A]/ / / /    /       [E7]/    [A]/

__________________________________










