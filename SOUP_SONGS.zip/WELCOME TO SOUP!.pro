


{title:WELCOME TO SOUP!}

We're SO glad that you're here tonight. :) 

Please welcome others to your table, 
tune up your ukulele and sync your tablet!

It's ANY SONG tonight!
NOTE- this week is out last SOUP session 
before the summer break. 
We will return to our regular Tuesday night jams 
here on September 8! 

There are a few gigs during the summer - 
if you havent signed up yet please do so! 
Remember to ensure your email address is 
VERY readable! 

Please add your favourite song (1 or 2 please) 
to the whiteboard, which is on the stage. 

We won’t know what your favourite is 
if you don’t get it on the board!


