{title:FATHER AND SON }
{subtitle: 4/4    Key of G}
{subtitle:(Cat Stevens)}
{metronome: 134}
{time: 4:30}


{c:TURN TABLET HORIZONTAL!}

{c:RIFF}
{sot}
A| - - - - - - 0 - -
E| - - - 3 - - - - -
C| - 0 - - 0 - - -
{eot}



{c:INTRO:}
[G]/   {c:(rest)}  [G]/ /    [C5]/       {c:RIFF}
[G]/   {c:(rest)} [G]/ /     [C5]/       {c:RIFF}
[G]/ / / /   / /

{c:(father)} It’s not [G]time to make a cha[D]nge 
Just re[C]lax and take it [Am]easy
You’re still [G]young, that’s your [Em]fault
There’s so [Am]much you have to know [D]
Find a [G]boy, settle do[D]wn
If you [C]want, you can [Am]marry
Look at [G]me, I am [Em]old but I’m 
[Am]Happy  [C]/ /     [D]/ /

I was [G]once like you are [D]now 
And I [C]know that it’s not [Am]easy
To be [G]calm, when you’ve [Em]found 
Something going [Am]on {c:(234)}  [D]
But take your [G]time, think a lo[D]t
Why think of [C]everything you’ve go[Am]t
For you will [G]still be here [Em]tomorrow 
But your [D]dreams may [G]not  

{c:starts on "not”)}
[G]/ /    [C5]/ /     
[G]/ /    [C5]/ / 
[G]/ /    [C5]/ /     
[G]/ /    [C5]/ / 

{c:(son)} How can [G]I try to ex[D]plain? 
When I [C]do he turns a[Am]way again
It’s [G]always been the [Em]same
Same old [Am]story  [C]/ /    [D]/ /
From the [G]mo…ment I could talk[D]   
I was [C]o…rdered to listen [Am]
Now there’s a [G]way and I [Em]know 
That I [D]have to [G]go away  {c:(2,3)}
I [D/]know {c:(2,3)} I [C]have to [G]go  

{c:(on "go”}
[G]/   {c:(rest)}  [G]/ /    [C5]/       {c:RIFF}
[G]/   {c:(rest)}  [G]/ /     [C5]/       {c:RIFF}
[G]/ / / /   / /

{c:(INSTRUMENTAL picking)}

[G]/ / / /    [D]/ / / /    [C]/ / / /    [Am]/ / / /
[G]/ / / /    [Em]/ / / /   [Am]/ /  [C]/ /    [D]/ / / /
[G]/ / / /    [D]/ / / /    [C]/ / / /    [Am]/ / / /
[G]/ / / /    [Em]/ / / /   [D]/ /    [G]/ / / /   / / 
[D]/  {c:(stop, 2,3)} [C]/ / 

[G]/   {c:(rest)}  [G]/ /    [C5]/       {c:RIFF}
[G]/   {c:(rest)} [G]/ /     [C5]/       {c:RIFF}

[G]/ / / /   / /



It’s not [G]time to make a cha[D]nge, just sit [C]down and take it [Am]slowly
          {c:(away                  away             away)}
You’re still [G]young, that’s your [Em]fault
                        {c:( I                          know)}
There’s so [Am]much you have to go [D]through
                         {c:(I have to           make this )}
Find a [G]boy, settle do[D]wn, if you [C]want, you can [Am]marry
      {c:(decision                         alone)}
Look at [G]me, I am [Em]old but I'm [Am]happy  [C]/ /   [D]/ /
                {c:(no)}


All the [G]times that I [D]cried, keeping [C]all the things I [Am]knew inside
         {c:(stay           stay                 stay)}
It's [G]hard, but it's [Em]harder to ig[Am]nore it                 [D]
          {c:(why               must         you go and make this)}
If they were [G]right, I'd a[D]gree, but it's [C]them they know, not [Am]me
               {c:(decision                        alone)}
Now there's a [G]way, and I [Em]know that I [D]have to [G]go away  {c(2,3)}
I [D/]know, {c(2,3)}  I [C/]have to [G/]go