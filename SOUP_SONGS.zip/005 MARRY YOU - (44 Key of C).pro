

{title:005 MARRY YOU }
{subtitle:(4/4 Key of C)} 
{subtitle: (Bruno Mars, Philip Lawrence)}
{subtitle:(& Ari Levine)}
{time:4:15}
{metronome:164}




[C]/ / / /   / / / /
[Dm]/ / / /   / / / /
[F]/ / / /   / / / /
[C]/ / / /   / / /  

{soc}
It’s a [C]beautiful night 
We're looking for something [Dm]dumb to do
Hey [F]Baby, I think I wanna marry you    [C]
Is it the look in your eyes 
Or is it this [Dm]dancing juice
Who [F]cares Baby
I think I wanna marry you     [C]   
{eoc}

Well I [C]know this little chapel 
On the boulevard we can 
[Dm]Go-o-o-o-o (go-o-o-o-o)
No one will [F]kno-o-o-o-ow  (know-o-o-o-ow)
Oh come [C]on, girl
Who cares if we're trashed
Got a pocket full of cash we can 
[Dm]Blo-o-o-o-ow  (blo-o-o-o-ow)
Shots of pa[F]tro-o-o-o-on (tro-o-o-o-on) 
And its [C]on, girl
Don't say no, no, no, no-no 
Just say  [Dm]ya, ya, ya-ya-ya
and we'll [F]go, go, go-go-go
If you're [C]ready, like I'm ready

{soc}
'Cause it’s a [C]beautiful night 
We're looking for something [Dm]dumb to do
Hey [F]Baby, I think I wanna marry you    [C]
Is it the look in your eyes 
Or is it this [Dm]dancing juice
Who [F]cares Baby
I think I wanna marry you     [C]   
{eoc}

[C]I'll go get a ring
Let the choir bells sing like 
[Dm]Oo-o-o-o-o (oo-o-o-o-o) 
So watcha wanna [F]Do-o-o-o-oo (do-o-o-o-o)
Let's just [C]run, girl
If we wake up and you wanna break up 
That's [Dm]o-o-o-o-ol (co-o-o-o-ool) 
No, I won't blame [F]yo-o-o-o-ou (yo-o-o-o-ou) 
It was [C]fun, girl
Don't say no, no, no, no-no
Just say [Dm]ya, ya, ya-ya-ya
and we'll [F]go, go, go-go-go
If you're [C]ready
Like I'm ready, 'cause   

{soc}
It’s a [C]beautiful night 
We're looking for something [Dm]dumb to do
Hey [F]Baby, I think I wanna marry you    [C]
Is it the look in your eyes 
Or is it this [Dm]dancing juice
Who [F]cares Baby
I think I wanna marry you     [C]   
{eoc}

{sob}
  Just say I [C]do-oo-oo-[Dm]oo  
  Tell me right [F]now baby 
  Tell me right [C]now baby, baby 
  Just say I [C]do-oo-oo-[Dm]oo  
  Tell me right [F]now baby
  Tell me right [C]now baby, baby, ‘cause 
{eob}

{soc}
It’s a [C]beautiful night 
We're looking for something [Dm]dumb to do
Hey [F]Baby, I think I wanna marry you    [C]
Is it the look in your eyes 
Or is it this [Dm]dancing juice
Who [F]cares Baby
I think I wanna marry you     [C]   

Yeah who [F]cares Baby 
I think I wanna marry you    [C/]
{eoc}


____________________________________











