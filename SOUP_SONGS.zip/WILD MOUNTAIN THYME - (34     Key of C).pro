
{t:WILD MOUNTAIN THYME }
{subtitle:(3/4     Key of C)} 
{subtitle:(Francis McPeak 1st)}
{time:3:26}
{metronome: 142}

Sean starts

[C]/ / /    [F]/ / /    [C]/ / /   /  

[C]/ / /    [F]/ / /    [C]/ / /   /  

Oh the [C]summer [F]time is [C]comin' 
And the [F]trees are sweetly [C]bloomin'
And the [F]wild [C]mountain [Am]thyme 
Grows a[Dm]round the bloomin' [F]heather
Will ye [C]go [F]lassie [C]go?

{soc}
     And we'll [F]all go to[C]gether 
     To pull [F]wild [C]mountain [Am]thyme
     All a[Dm]round the bloomin' [F]heather  
     Will ye [C]go [F]lassie [C]go?
{eoc}

I will [C]build my [F]love a [C]bower 
By yon [F]clear crystal [C]fountain
And [F]all a[C]round the [Am]bower 
I'll pile [Dm]flowers from the [F]mountain
Will ye [C]go [F]lassie [C]go?

{soc}
     And we'll [F]all go to[C]gether 
     To pull [F]wild [C]mountain [Am]thyme
     All a[Dm]round the bloomin' [F]heather  
     Will ye [C]go [F]lassie [C]go?
{eoc}

If my [C]true love [F]she won't [C]come 
I will [F]surely find a[C]nother
To pull [F]wild [C]mountain [Am]thyme 
All a[Dm]round the bloomin' [F]heather
Will ye [C]go [F]lassie [C]go?

{soc}
     And we'll [F]all go to[C]gether 
     To pull [F]wild [C]mountain [Am]thyme
     All a[Dm]round the bloomin' [F]heather  
     Will ye [C]go [F]lassie [C]go?
{eoc}

{soc}
     And we'll [F]all go to[C]gether
     To pull [F]wild [C]mountain [Am]thyme
     All a[Dm]round the bloomin' [F]heather  
     Will ye [C]go [F]lassie [C]go?
     Will ye [C]go [F]lassie [C]go?   
     Will ye [C]go [F]lassie [C/]go? 
{eoc}

__________________________________________







