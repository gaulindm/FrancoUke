{title: HEY SOUL SISTER    }    
{subtitle:(4/4   Key of C)}     
{subtitle:(Patrick Monahan)}
{subtitle:(Amund Bjorkland & Espen Lind)}
{time: 4:35}
{metronome: 180}







{c:INTRO:}
[Z]/ / / /   / / / /    [C]/ / / /   / / 

Hey-[G]ay {c:(234)}, Hey-ay-AY-ay-[Am]ay, {c:(234)} 
Hey-ay-AY-ay-[F]ay {c:(234,123)}
Your [C]lipstick stains {c:(234,} [G]{c:12)} 
On the front lobe of my 
[Am]Left side brains {c:(234,} [F]{c:123)}
I knew I wouldn't for[C]get you and so I went and 
[G]Let you blow my [Am]mind {c:(234, 1234,} 
[F]{c:1234,} [G]{c:123)}
Your [C]sweet moonbeam {c:(234)}  
[G]  The smell of you in every 
[Am]Single dream I [F]dream {c:(23)}
I knew when we co[C]llided you're the one I have 
De[G]cided who's one of my 
[Am]Kind {c:(234, 1234,} 
[F]{c:1234,}  [G]{c:1234)}

{soc}
[F]Hey soul sister [G]ain't that mister [C]mister [G]on the 
[F]Radio stereo, the [G]way you move 
Ain't [C]fair you [G]know
[F]Hey soul sister [G]I don't want to [C]miss a [G]single 
[F]Thing you do-hoo…  {c:(}[G]{c:1234)}  [G/]    {c:(2,3)}
{eoc}

To-[C]night {c:(234,12)}  Hey-[G]ay {c:(234)} 
Hey-ay-AY-ay-[Am]ay, {c:(234)} 
Hey-ay-AY-ay-[F]ay {c:(234,1234)}
[C]Just in ti-i-i-[G]ime I'm so glad you have a 
[Am]One track mind like m[F]e
You gave my love di[C]rection 
A game show love co[G]nnection 
We can't de[Am]ny {c:(234)} [F]ii... {c:(234)} [G]i-i-i-i 
I'm [C]so obsessed {c:(234)}  
[G]    My heart is bound to beat right 
[Am]Outta my untrimmed [F]chest {c:(234)}
I believe in [C]you, like a virgin you're Ma[G]donna 
And I'm always gonna [Am]wanna blow your 
[F]Mind {c:(234, }[G]{c:1234)}   

{soc}
[F]Hey soul sister [G]ain't that mister [C]mister [G]on the 
[F]Radio stereo, the [G]way you move ain't 
[C]Fair you [G]know
[F]Hey soul sister [G]I don't want to [C]miss a [G]single 
[F]Thing you do-hoo…  {c:(}[G]{c:1234)}  [G/]    {c:(2,3)}
{eoc}

To[C]night. The way you can cut a rug 
[G]Watching you's the only drug I [Am]need
You're so gangster I'm so thug, You're the [F]only one I'm 
Dreaming of you [C]see, I can be myself now fina[G]lly
In fact there's nothing I can't [Am]be
I want the world to see you [F]be with [G]me

[F]Hey soul sister [G]ain't that Mister [C]mister [G]on the 
[F]Radio stereo, the [G]way you move ain't 
[C]Fair you [G]know
[F]Hey soul sister [G]I don't want to [C]miss a [G]single 
[F]Thing you do ton[G]i…ght {c:(234)}  [C//] [G//]

[F]Hey soul sister [G]I don't want to [C]miss a [G]single 
[F]Thing you do-hoo…  {c:(}[G]{c:1234)}  [G/]    {c:(2,3)}

To-[C]night {c:(234,12)} Hey-[G]ay {c:(234)} 
Hey-ay-AY-ay-[Am]ay, {c:(234)} 
Hey-ay-AY-ay-[F]ay {c:(234,123)}

To-[C]night {c:(234,12)} Hey-[G]ay {c:(234)} 
Hey-ay-AY-ay-[Am]ay, {c:(234)} 
Hey-ay-AY-ay-[F]ay {c:(234) (}[G]{c:123)}   
To[C/]night

