{title: I GOT YOU BABE    }
{subtitle: 6/8   Key of G}
{subtitle: Sonny and Cher}
{metronome:72  }
{time:3:21}

{c:Count in is in 4/4 time "1234}


Sonny & {c:Cher}



{c:INTRO:}
[G]/ /    [C]/ /    [G]/ /    [C]/ / 

[G]{c:They say we're young and }[C]{c:we don't know}
{c:We }[G]{c:won't find out u}[C]{c:nti-i-}[F]{c:il  we }[D]{c:grow}
Well [G]I don't know if [C]all that's true
Cause [G]you got me and [C]baby [F]I got [D]you

{soc:}
{c:(both)} [G]Babe... [C]     I got [G]you babe  [C]     I got [G]you babe  [C]
{eoc}

[G]{c:They say our love won't }[C]{c:pay the rent}
{c:Be}[G]{c:fore it's earned our }[C]{c:money's }[F]{c:all been }[D]{c:spent}
I [G]guess that's so, we don't [C]have a pot
But at [G]least I'm sure of [C]all the [F]things we [D]got

{soc}
{c:(both)} [G]Babe...  [C]     I got [G]you babe  [C]    I got [G]you babe  [G/]
{eoc}

I got [Am]flowers in the [D]spring I got [Am]you to wear my [D]ring

{c:And when I'm }[G]{c:sad you're a }[C]{c:clown}
{c:And if I get }[Am]{c:scared you're always a}[D]{c:ro-o-o-ound }

[G]{c:So let them say your }[C]{c:hair's too long}
{c:But }[G]{c:I don't care with }[C]{c:you I }[F]{c:can't go} [D]{c:wrong}

Then [G]put your little [C]hand in mine
[G]There ain't no hill or [C]mountain [F]we can't [D]climb

{soc}
[G]Babe... [C]     I got [G]you babe  [C]      I got [G]you babe [C]
{eoc}

[G]/ /   [C]/ /   [G]/ /   [D]/ / 

[G] I got you to [C]hold my hand     [G]{c:I got you to }[D]{c:understand}
[G] I got you to [C]walk with me      [G]{c:I got you to }[D]{c:talk with me}
[G] I got you to [C]kiss goodnight    [G]{c:I got you to }[D]{c:hold me tight}
[G] I got you I [C]won't let go           [G]{c:I got you to }[D]{c:love me so}

[G]/ /   [C]/ /   [G]/ /   [D]/ /
 
{c:(slow)} I [C/]got... [G/]you babe...
{c:(reg speed)}  [G]       [C]     I got [G]you babe
[C] I got [G] you babe [C]     I got [G] you babe 
[C] I got [G] you babe [C]     I got [G/] you babe 