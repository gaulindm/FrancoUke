{title:HAPPY BIRTHDAY (original)}
{subtitle:3/4     Key of C}




Happy [C]Birthday to [G]you,
Happy Birthday to [C]you
Happy Birthday, Dear   [G]____  [F]_____   
Happy [C]Birthday [G/]to [C/]you!   
And many [C7]more…..

