

{title:159  ON THE ROAD AGAIN  }
{subtitle:    4/4      Key of G}
{subtitle:(Willie Nelson)}
{time:3:07}
{metronome:200 }







[G]/ / / /   / / / /   
/ / / /   / /   

On the [G]road again {c:(4,1234,12)}
Just can't wait to get on the [B7]road again {c:(4,1234,12)}
The life I love is making [Am]music with my friends
And [C]I can't wait to get [D7]on the road a[G]gain {c:(234,12)}

On the [G]road again  {c:(4,1234,12)}
Goin' places that I've [B7]never been  {c:(4,1234,12)}
Seein' things that I may [Am]never see again
And [C]I can't wait to get [D7]on the road a[G]gain  {c:(234,12)}

{soc}
  On the [C]road again
  Like a band of gypsies we go down the [G]highway
  We're the [C]best of friends
  Insisting that the world keep turning 
  [G]Our way, and [D]our way  [D/]
{eoc}

On the [G]road again  {c:(4,1234,12)}
I just can't wait to get on the [B7]road again {c:(4,1234,1)}
The life I love is making [Am]music with my friends
And [C]I can't wait to get [D7]on the road a[G]gain {c:(234,1234)}

{c:(Kazoo like verse ) }
[G]/ / / /   / / / /   / / / /   / / / /

[B7]/ / / /   / / / /   / / / /   / / / /

[Am]/ / / /   / / / /
   
[C]/ / / /    [D7]/ / / /    [G]/ / / /   / /

{soc}
  On the [C]road again  
  Like a band of gypsies we go down the [G]highway
  We're the [C]best of friends
  Insisting that the world keep turning 
  [G]Our way, and [D]our way  [D/]
{eoc}

On the [G]road again {c:(4,1234,12)}
Just can't wait to get on the [B7]road again {c:(4,1234,1)}
The life I love is making [Am]music with my friends
And [C]I can't wait to get [D7]on the road aga[G]in {c:(234,1234)}
And [C]I can't wait to get 
[D7]On the road aga[G]in {c:(234,1234)}

[C]/ / / /   [D7]/ / / /   [G]/ / / /   /


_______________________________________


{define: D7 0 2 0 2 0}








