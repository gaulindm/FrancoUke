{title:THE BEAT GOES ON}
{subtitle:Sonny and Cher}

[D]The beat goes on, the beat goes on.
[D7]Dru[D]ms keep pounding rhythm to the brain.
[D7]La [G]de[D] da de de...la de da de da.

[D]Charleston was once the rage, uh huh.
[D7]His[D]tory has turned the page, uh huh.

The mini skirts the current thing, uh huh.
[D7]Tee[D]nybopper is our newborn king, uh huh.

CHORUS:
[D]The beat goes on, the beat goes on.
[D7]Dru[D]ms keep pounding rhythm to the brain.
[D7]La [G]de[D] da de de...la de da de da.


[D]The grocery store's the super mart, uh huh.
[D7]Lit[D]tle girls still break their hearts, uh huh.
[D]And men still keep on marching off to war.
[D7]Ele[D]ctrically they keep a baseball score.

CHORUS:
[D]The beat goes on, the beat goes on.
[D7]Dru[D]ms keep pounding rhythm to the brain.
[D7]La [G]de[D] da de de...la de da de da.


[D]Grandmas sit in chairs and reminisce.
[D7]Boy[D]s keep chasing girls to get a kiss.
[D]The cars keep going faster all the time.
[D7]Bums still cry,' Hey buddy, have you got a dime?'

CHORUS:
[D]The beat goes on, the beat goes on.
[D7]Dru[D]ms keep pounding rhythm to the brain.
[D7]La [G]de[D] da de de...la de da de da.

