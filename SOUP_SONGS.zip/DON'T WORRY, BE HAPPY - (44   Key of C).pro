{title:DON'T WORRY, BE HAPPY }
{subtitle:(4/4   Key of C)}   
{subtitle:(Bobby McFerrin)}
{time: 3:30}
{metronome: 148}



 




{c:INTRO:}  
[C]/ / / /    / / / /      
[Dm]/ / / /    / / / /      
[F]/ / / /     / / / /      
[C]/ / / /     / / / /
 [C] Here’s a little song I wrote 
You [Dm]might want to sing it note for note
Don’t [F]worry… be [C]happy 
[C] In every life we have some trouble
[Dm] When you worry you make it double
Don’t [F]worry…. be [C]happy 
{c:(don't worry, be happy now)}

{c:CHORUS (“Doo” or whistle) }
{soc}
[C]/ / / /    / / / /      
[Dm]/ / / /    / / / / 
{c:(don't worry)}     
[F]/ / / /     / / / /      
{c:(be happy… }        
[C]/ / / /     / / / /  don't worry, be happy now)}

[C]/ / / /    / / / /      [Dm]/ / / /    / / / / 
                             {c:(don't worry)}     
[F]/ / / /     / / / /      [C]/ / / /     / / / /
  {c:(be happy…           don't worry, be happy now)}
{eoc}

[C]  Ain’t got no place to lay your head 
[Dm] Somebody came and took your bed
Don’t [F]worry…  be [C]happy  
The [C]landlord says your rent is late 
[Dm] He may have to litigate Don’t [F]worry…. be [C]happy 

{soc}
[C]/ / / /    / / / /      [Dm]/ / / /    / / / / 
                             {c:(don't worry)}     
[F]/ / / /     / / / /      [C]/ / / /     / / / /
  {c:(be happy…           don't worry, be happy)}

[C]/ / / /    / / / /      [Dm]/ / / /    / / / / 
                             {c:(don't worry)}     
[F]/ / / /     / / / /      [C]/ / / /     / / / /
  {c:(be happy…           don't worry, be happy)}
{eoc}

[C] Ain’t got no cash, but I’ve got style 
[Dm]  My ukulele makes me smile 
Don’t [F]worry…. be [C] happy 
Cause [C]when you worry your face will frown
And [Dm]that will bring everybody down, so 
Don’t [F]worry…. be [C] happy 

{soc}
[C]/ / / /    / / / /      [Dm]/ / / /    / / / / 
                             {c:(don't worry)}     
[F]/ / / /     / / / /      [C]/ / / /     / / / /
  {c:(be happy…           don't worry, be happy)}

[C]/ / / /    / / / /      [Dm]/ / / /    / / / / 
                             {c:(don't worry)}     
[F]/ / / /     / / / /      [C]/ / / /     / / / /
  {c:(be happy…           don't worry, be happy)}
{eoc}




