{title: Surfin USA}
{subtitle:4/4   Key of C (Beach Boys)}
{metronome:159  }
{time: 2:55 }





{c:Strum pattern starts on *:}
{c:The first D comes on the chord change. }
          [*]
          uD dududu  D

{c:INTRO:}   [C*]      /       /     /       /     [C/]
                  u    D   du  du  du   D


[C]If everybody had *an [G7]ocean across the U.S.*[C]A.
Then everybody’d be *[G7]surfin like Californ-i-*[C]a
You’d see em wearin’ their *[F]baggies. Huarachi sandals, *[C]too
A bushy bushy blonde *[G7]hairdo...Surfin’ U.S.[C]A

[C]You’ll catch em surfin’ at [G7]Del Mar...                            
                                       (Inside, outside U.S.A.)
Ventura County [C]Line.
                        (Inside, outside, U.S.A.)
Santa Cruz and [G7]Trestles...          
                         (Inside, outside, U.S.A.)
Australias Nara[C]bine
                        (Inside, outside, U.S.A.)
All over Man[G7]hattan,             
                   (Inside, outside, U.S.A.)                  
and down Doheny [C]way.
                              (Inside, outside, U.S.A.)

Everybody’s gone [G7]surfin’. Surfin’ U.S.[C]A. 

[C]We’ll all be plannin’ out *a [G7]rou-oute...
we’re gonna take real *[C]soon.
We’re waxin’ down our *[G7]surfboards. 
We can’t wait for *[C]June.
We’ll all be gone for the *[F]summer. 
We’re on safari to *[C]stay.
Tell the teacher we’re *[G7]surfin’...Surfin’ U.S.[C]A.

[C]At Haggarty’s and [G7]Swamis...                          
                             (Inside, outside, U.S.A.) 
Pacific Pali[C]sades.
                 (Inside, outside, U.S.A.)
San Onofre and [G7]Sunset...                      
                         (Inside, outside, U.S.A.)  
Redondo Beach, L.[C]A.
                             (Inside, outside, U.S.A.)
All over La [F]Jolla,   
                 (Inside, outside, U.S.A.)                                                   and Waimea [C]Bay.
             (Inside, outside, U.S.A)
Everybody’s gone [G7]surfin’...Surfin’ U.S.[C]A.

[C]/ / / /    [G7]/ / / /    [C]/ / / /
[G7]/ / / /    [C]/ / / /
[F]/ / / /    [C]/ / / /
[G7]/ / / /    [C]/ / / /  

[C]  We’ll all be plannin’ out *a [G7]rou-oute...
we’re gonna take real *[C]soon.
We’re waxin’ down our *[G7]surfboards. 
We can’t wait for *[C]June.
We’ll all be gone for the *[F]summer. 
We’re on safari to *[C]stay.
Tell the teacher we’re *[G7]surfin’...Surfin’ U.S.[C]A.

[C]At Haggarty’s and [G7]Swamis...  
                          (Inside, outside, U.S.A.)                         
Pacific Pali[C]sades.
              (Inside, outside, U.S.A.)
San Onofre and [G7]Sunset...                    
                       (Inside, outside, U.S.A.)
Redondo Beach, L.[C]A.
                        (Inside, outside, U.S.A.)
All over La [F]Jolla.                                          
                (Inside, outside, U.SA.)    
and Waimea [C]Bay.
                  (Inside, outside, U.S.A.)
Everybody’s gone [G7]surfin’...Surfin’ U.S.*[C]A. [C/]
