{title: BAD BAD LEROY BROWN}
{subtitle:  (4/4  Key of G)}
{subtitle: (Jim Croce)}
{metronome: 148}
{time:3:00  }


[G]/    [Em]/    [G]/    [Em]/      [D7]/ / / 

Well, the [G]south side of Chicago
Is the [A7]baddest part of town
And if you [B7]go down there
You better [C]just beware of a [D]man named [C]Leroy Br[G]own  [D7]
Now [G]Leroy more than trouble
You see he [A7]stand 'bout six foot four
All the [B7]downtown ladies call him "[C]treetop lover"
All the [D]men just [C]call him "[G]sir" [D7]

{soc}
  And he's [G]bad, bad, Leroy Brown
  The [A7]baddest man in the whole damn town
  [B7]Badder than old King [C]Kong
  And [D]meaner than a [C]junkyard [G]dog  [D7]
{eoc}

Now, [G]Leroy, he a gambler
And he [A7]like his fancy clothes
And he [B7]like to wave his [C]diamond rings
In front of [D]everyb[C]ody's nose [G]  [D7]
He got a [G]custom Continental
He got an [A7]Eldorado too
He got a [B7]thirty-two gun in his [C]pocket for fun
He got a [D]razor [C]in his shoe [G]  [D7]

{soc}
  And he's [G]bad, bad, Leroy Brown
  The [A7]baddest man in the whole damn town
  [B7]Badder than old King [C]Kong
  And [D]meaner than a [C]junkyard [G]dog  [D7]
{eoc}

Well, [G]Friday 'bout a week ago
[A7]Leroy's shootin' dice
And at the [B7]edge of the bar sat a [C]girl name of Doris
And [D]oh, that [C]girl looked [G]nice [D7]
Well, he [G]cast his eyes upon her
And the [A7]trouble soon began
And [B7]Leroy Brown, he learned a [C]lesson 'bout messin'
with the [D]wife of a [C]jealous man [G]  [D7]

{soc}
  And he's [G]bad, bad, Leroy Brown
  The [A7]baddest man in the whole damn town
  [B7]Badder than old King [C]Kong
  And [D]meaner than a [C]junkyard [G]dog  [D7]
{eoc}

Well, the [G/]two men took to fightin'
And when they [A7/]pulled them from the floor
[B7]Leroy looked like a [C]jigsaw puzzle 
With a [D]couple of [C]pieces gone [G]  [D7]

{soc}
  And he's [G]bad, bad, Leroy Brown
  The [A7]baddest man in the whole damn town
  [B7]Badder than old King [C]Kong
  And [D]meaner than a [C]junkyard [G]dog   [D7]

  And he's [G]bad, bad, Leroy Brown
  The [A7]baddest man in the whole damn town
  [B7]Badder than old King [C]Kong
  And [D]meaner than a [C]junkyard [G]dog   [D7]

  Yeah, you were [B7]badder than old King [C]Kong
  And [D]meaner than a [C]junkyard [G(dudu)]dog
{eoc}





 

