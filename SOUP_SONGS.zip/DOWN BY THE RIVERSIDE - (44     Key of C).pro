{title:DOWN BY THE RIVERSIDE}
{subtitle:(4/4     Key of C)}
{subtitle:(Unknown)}
{time: 2:50}
{metronome: 168}

{c: (*) is "bu dum" (quick up-down)}





{c:INTRO:}  
[G7]/ / / /     / / / /        
[C]/ / / /      / / /

I [C]met my little bright eyed gal {c:(where?)}
[*][C]    Down by the riverside {c:(where?)}
[*][G7]      Down by the riverside {c:(where?)}
[*][C]    Down by the riverside
I met my little bright eyed gal {c:(where?)}
[*][C]     Down by the riverside
[G7]Down by the river[C]side 

She [C]asked me for a little kiss {c:(where?)}
[*][C]    Down by the riverside {c:(where?)}
[*][G7]      Down by the riverside {c:(where?)}
[*][C]     Down by the riverside
She asked me for a little kiss {c:(where?)}
[*][C]     Down by the riverside
[G7]Down by the river[C]side  [C7]

{soc}
     She said have [F]patience little man
     I [C]know you'll understand
     [G7]       I hardly know your [C]name
     I said if [F]I could have my way
     [C]Maybe some sweet [Am]day
     [D7]      Your name and mine will be the [G7]same
{eoc}

I [C]wed my little bright eyed gal {c:(where?)}
[*][C]    Down by the riverside {c:(where?)}
[*][G7]      Down by the riverside {c:(where?)}
[*][C]     Down by the riverside
I wed my little bright eyed gal {c:(where?)}
[*][C]      Down by the riverside
[G7]Down by the river[C]side

{soc}
     She said have [F]patience little man
     I [C]know you'll understand
     [G7]     I hardly know your [C]name
     I said if [F]I could have my way
     [C]Maybe some sweet [Am]day
     [D7]    Your name and mine will be the [G7]same
{eoc}

I [C]met my little bright eyed gal {c:(where?)}
[*][C]       Down by the riverside {c:(where?)}
[*][G7]      Down by the riverside {c:(where?)}
[*][C]     Down by the riverside 
I met my little bright eyed gal {c:(where?)}
[*][C]     down by the riverside
[G7]Down by the river[C]side 
[G7]Down by the river[C]side [F/] [C/]


{define: D7 0 2 0 2 0}