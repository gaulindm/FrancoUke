

{title:068 ROYALS      }
{subtitle:(4/4   Key of C)}          
{subtitle:(Lorde & Joel Little)}
{time:4:23}
{metronome: 166}

{c:INTRO: (continue STT pattern}
{c:through the verses)} 




[C]{c:Strum Tap Tap - S T T - S T T -  S T}  
I’ve never seen a diamond in the flesh…  
I cut my teeth on wedding rings in the movies
And I’m not proud of my address…  
In a torn-up town… 
No post code envy… {c:(tap)}

{c:BRIDGE}
{sob}
 But every song’s like [C]gold teeth  
 Grey Goose, trippin’ in the bathroom
 Blood stains, ball gowns
 Trashin’ the hotel room
 [Bb]We don’t care
 We’re driving [F]Cadillacs in our dreams 
 But every song’s like [C]Cristal Maybach
 Diamonds on your timepiece
 Jet planes, islands 
 Tigers on a gold leash
 [Bb]We don’t care… we aren’t 
 [F]Caught up in your love affair
{eob}

{c:CHORUS}
{soc}
  And we’ll never be [C]Royals (Royals) 
  It don’t run in our blood
  That kind of [Bb]lux just ain’t for us 
  We crave a [F]different kind of buzz
  Let me be your [C]ruler (ruler)  
  You can call me Queen Bee
  And baby I’ll [Bb]rule I’ll rule 
  I’ll rule, I'll rule I’ll [F]rule     
  Let me live that fantasy  
{eoc}

[C]{c:S T T - S T T - S T T - S T}  
My friends and I we've cracked the code…
We count our dollars on the train to the party… 
And everyone who knows us kno-o-o-o-ows
That we’re fine with this… 
We didn’t come from money  {c:(stop)}

{sob}
   But every song’s like [C]gold teeth  
   Grey Goose, trippin’ in the bathroom
   Blood stains, ball gowns, trashin’ the hotel room
   [Bb]We don’t care
   We’re driving [F]Cadillacs in our dreams 
   But every song’s like [C]Cristal Maybach
   Diamonds on your timepiece, jet planes, islands 
   Tigers on a gold leash
   [Bb]We don’t care… we aren’t 
   [F]Caught up in your love affair
{eob}

{soc}
  And we’ll never be [C]Royals (Royals) 
  It don’t run in our blood
  That kind of [Bb]lux just ain’t for us 
  We crave a [F]different kind of buzz
  Let me be your [C]ruler (ruler)  
  You can call me Queen Bee
  And baby I’ll [Bb]rule I’ll rule 
  I’ll rule, I'll rule I’ll [F]rule     
  Let me live that fantasy  
{eoc}

{c:(regular strum)}
{c:(}[C]{c:1,2)}  Oh-oh-oh {c:(234,12)}  
Oh-oh-oh, oh [Bb]ohhh
We’re bigger than we’ve ever dreamed
[F]   And I’m in love with being queen
{c:(}[C]{c:1,2)}  Oh-oh-oh {c:(234,12)}  
Oh-oh-oh, oh [Bb]ohhh
Life is great without a care, we aren’t 
[F]Caught up in your love affair

{soc}
  And we’ll never be [C]Royals (Royals) 
  It don’t run in our blood
  That kind of [Bb]lux just ain’t for us 
  We crave a [F]different kind of buzz
  Let me be your [C]ruler (ruler)  
  You can call me Queen Bee
  And baby I’ll [Bb]rule I’ll rule 
  I’ll rule, I'll rule I’ll [F]rule     
  Let me live that fantasy    [C/]
{eoc}

________________________________














