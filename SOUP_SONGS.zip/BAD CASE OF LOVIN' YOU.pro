{title:BAD CASE OF LOVIN' YOU}
{subtitle:}

[D]/ / / /   / / /   [C]/ 
[D]/ / / /   Whoa-oa-oa-oa
[D]/ / / /   / / /   [C]/ 
[D]/ / / /   / 
A hot summer [D]night 
Fell [C]like a [D]net {c:(234,123)}
I gotta  [G]fi... [A]ind my baby [D]yet
I need [D]you to [C]soothe my [D]hea-↑ad
Turn my [G]blu...[A]ue heart to [D]red {c:(234,123)}

{soc} 
 [C/][D/]Doc[tap...]tor Doctor, gimme the news 
 I got a [D/]      [tap...]bad case of lovin' you
 [G]   No pill's gonna cure my ill I got a
 [D]   Bad ca...se of [A]lo...vin' [D]you 
 {c:(234,123}[C]{c:4)}  [D]/ / / /   / / 
{eoc}
 
A pretty [D]fa...ce don't make no [C]pretty [D]hea-a-art
I learned [G]tha...[A]at buddy from the [D]start
Ya think I'm cute {c:(234,12)} a [C]little bit [D]shy-↑y {c:(34,12)}
Maama, [G]I-I-I-I [A]ain't that kind of [D]guy {c:(234,123)}
 
{soc} 
 [C/][D/]Doc[tap...]tor Doctor, gimme the news 
 I got a [D/]      [tap...]bad case of lovin' you
 [G]   No pill's gonna cure my ill I got a
 [D]   Bad ca...se of [A]lo...vin' [D]you 
 {c:(234,123}[C]{c:4)}   [D]/ / / / 
 Who-o-o-oa
 {eoc} 
 
[G]  I know you like it  [D]   you like it on top
[G]Tell me Ma...mma, [B]    are you gonna[A] stop?  [D] [C] [D]
 
 
[Verse 3]
 
[D]You [C]had me [D]down...twenty-[C]one to [D]zip
smile of [G]Ju..[A]das on your [D]lip
[C]Shake my [D]fist [C]knock on [D]wood
I got it [G]baaad, [A]   and I got it [D]good.
 
 
[Chorus]
 
[D]Doctor Doctor, gimme the news..
 
I got a bad case of lovin' you.
[G]No pill's gonna cure my ill..I got 
a bad case of [A]looovvvin' [D]you. [C] [D]
