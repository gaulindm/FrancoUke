{title:004  COME SAIL AWAY }{subtitle:4/4    Key of C }{subtitle:Dennis DeYoung (Styx)}
{metronome:136}{time:5:15}{c:RIFF is played through INTRO chords}{c:RIFF}
{sot}A|-----5-----3--------------5----3-E|--0--------------0---1-----------
A|----------5----3-----------5---3-E|--1---3------------3--1----------
A|--3-2-0-2--3-----232323202E|-------------------------------{eot}
[C]/ / / /    [Dm]/ / / /    [Em]/ / / /    [Dm]/ / / /     [C]/ / / /    [G]/ / / / [C]I'...m [Em]sailing a[Am]way {c:(234,12)} [Am/] [G/]                      {c:(}[F]{c:12)} Set an open course for the [G]virgin sea'Cause [C]I'...ve [Em]got to be [Am]free {c:(234,12)} [Am/] [G/]                      {c:(}[F]{c:12)} Free to face the [Am]life that's a[G]head of me [Am] On board I'm the captain[G]   So climb aboard[Am] We'll search for tomorrow[G]   On every shoreAnd I'll [C]try... [G]oh Lord 
I'll [Am]try {c:(234,12)} [Am/] [G/]                      {c:(}[F]{c:12)} To [G]ca...rry [C]on {c:(234)} [Dm]/ / / /    [Em]/ / / /    [Dm]/ / / /    [C]/ / / /    [G]/ / / / [C]I... [Em]look to the [Am]sea {c:(234,12)} [Am/] [G/]                      {c:(}[F]{c:12)} Reflections in the waves 
Spark my [G]memory[C]Some... [Em]happy, some [Am]sad {c:(234,12)} [Am/] [G/]                      {c:(}[F]{c:12)} I think of childhood [Am]friendsAnd the [G]dreams we had [Am]    We lived happily forever[G]     So the story goes[Am]    But somehow we missed out[G]     On the pot of goldBut we'll [C]try... [G]best that we [Am]can {c:(234,12)} [Am/] [G/]                      {c:(}[F]{c:12)} To [G]ca...rry [C(Faster)]on {c:(234)}  [Dm]/ / / /    [Em]/ / / /    [Dm]/ / / /    [C]/ / / /    [Dm]/ / / /    [Em]/ / / /    [Dm]/ / / / A [C]gathering of [F]angelsA[G]ppeared above my [F]headThey [C]sang to me this [F]song of hopeAnd [G]this is what they [F]said, they said [C]Come sail away, [F]come sail awayCome [C]sail away with [F]me, lads[C]Come sail away, [F]come sail awayCome [C]sail away with [F]me I [C]thought that they were [F]angelsBut [G]much to my sur[F]priseWe [C]climbed aboard their [F]starshipAnd [G]headed for the [F]skies[C]Come sail away, [F]come sail awayCome [C]sail away with [F]me, lads[C]Come sail away, [F]come sail awayCome [C]sail away with [F]me
{c:(Gradually get softer)}[C]Come sail away, [F]come sail awayCome [C]sail away with [F]me, lads[C]Come sail away, [F]come sail awayCome [C]sail away with [F/]me

_______________________________________










