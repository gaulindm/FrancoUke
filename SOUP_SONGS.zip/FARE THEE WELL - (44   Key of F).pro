{title: FARE THEE WELL  } 
{subtitle:(4/4   Key of F)}
{subtitle:(“Dink’s Song”, John Lomax)}
{time: 3:00}
{metronome: 160}





   
{c:INTRO:}
[F]/ / / /    [C]/ / / /    [F]/ / / /   /   

If I had [F]wings, like [Bb]Noah's [F]dove
I'd fly the [Dm]river to the one I [F]love
Fare thee we..ll, [Bb]my [F]honey 
[C]Fare thee [F]well 
{c:(234,1234,1234,1)}

Well I had a [F]man who was [Bb]long and [F]tall
Moved his [Dm]body like a cannon[F]ball
Fare thee we…ll, [Bb]my [F]honey 
[C]Fare thee [F]well 
{c:(234,1234,1234,1)}

I remember one [F]evening in the [Bb]pouring [F]rain
In my [Dm]heart was an aching [F]pain
Fare thee we…ll, [Bb]my [F]honey 
[C]Fare thee [F]well 
{c:(234,1234,1234,1)}

One of these [F]mornings, and it [Bb]won’t be [F]long
You’ll call my [Dm]name and I’ll be [F]gone
Fare thee we…ll, [Bb]my [F]honey 
[C]Fare thee [F]well 
{c:(234,1234,1234,12)}

Show us a [F]bird, flying [Bb]high a[F]bove
Life ain't worth [Dm]living without the one you [F]love
Fare thee we…ll, [Bb]my [F]honey
[C]Fare thee [F]well   {c:(234,12)}
Fare thee we…ll, [Bb]my [F]honey [C]fare thee [F]well 
{c:(234,1)}  [C/] [F/]


