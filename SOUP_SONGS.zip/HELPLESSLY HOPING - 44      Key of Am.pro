{title:O!  HELPLESSLY HOPING   (Orchestra)}
{subtitle:4/4      Key of Am}
{subtitle: (Stephen Stills)}
{time:3:02}


Sean starts


[Am]/ / / /   / / / /
[C]/ / / /   / / / /
[G]/ / / /   / / / /
[D]/ / / /   / / / /

 Twice
[Am]Helplessly hoping her  [C]Harlequin  hovers 
Near[G]by, awaiting   a   wo[D]rd
[Am]Gasping at glimpses of [C]gentle true spirit 
He [G]runs wishing he could [D]fly-y
Only to [Am7]trip at the sou[C]nd of goodb[G]y... [D]ye
  
[Am]Wordlessly watching he  [C]waits  by the window 
And wo[G]nders at the empty place insi[D]de
[Am]Heartlessly helping him[C]self to her bad dreams
He wo[G]rries did he hear a goodb[D]y-ye 
Or [Am7]even    [C]      hel-l[G]o...o-o-[C]o
 
{soc}
They are [G]one person, they are two alone
They are three together
they are fo... [Dm]ur   {soh}each [C]other{eoh} {c:(34,1234)}  [G] [Em] [G/]
{eoc}

[Am]Stand by the stairway you'll [C]see something certain 
to te[G]ll you confusion has its co[D]st
[Am]Love isn't lying it's [C]loose in a lady 
who li[G]ngers, saying she is l[D]o-ost and
[Am7]choking    [C]    on hel-l[G]o...o-o-[C]o

{soc} 
They are [G]one person, they are two alone
They are three together
they are fo...[Dm]ur   {soh}each [C]other{eoh} {c:(34,1234)} [G][Em] [G/]
{eoc}






