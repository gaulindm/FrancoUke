{title:RUN AWAY TO MARS}
{subtitle:}
 

[G]  Your color's fading
[D]  'Cause I kept you waiting
It's a [Em]wild, wild world
And you're a [C]wild, wild girl
[G]  Our sun's still shining
[D]  But it seems half the size
And it's a [Em]wild, wild world
Out [C]    here
 
 
[Pre-Chorus]
[Em]Before my time runs out [D]
 
 
[Chorus]
What if I [Em]       run away to [C]Mars  [G] [D]
[Em]Would you find me in the stars? [C] [G] [D]
[Em]Would you miss me in the end [C]
If[G] I run out of oxygen? [D]
When I run a[Em]way to Mars [C] [G] [D]
 
 
[Verse 2]
[G]I can't tell which way's home
[D]I've been gone for so long
It's an [Em]empty world up here [C]
[G]I skip stones and wonder
[D]How long 'til I'm discovered?
It's a q[Em]uiet life up here [C]
 
 
[Pre-Chorus]
[Em]Before my time runs out [D]
 
 
[Chorus]
[Em]What if I run away to Mars? [C] [G] [D]
[Em]Would you find me in the stars? [C] [G] [D]
[Em]Would you miss me in the end [C]
If[G] I run out of oxygen? [D]
When I run a[Em]way to Mars [C] [G] [D]
 
 
[Bridge]
[Em]Three, two, one, I miss [C]you [G] [D]
[Em]I'm sorry I got[C] issues [G] [D]
 
 
[Chorus]
[Em]What if I run away to Mars? [C] [G] [D]
[Em]Would you find me in the stars? [C] [G] [D]
[Em]Would you miss me in the end [C]
If[G] I run out of oxygen? [D]
When I run a[Em]way to Mars [C] [G] [D]
