{title:LET IT BE}
{subtitle:}
 
[Intro]
| C G | Am F | C G | F   C G | C |
 
[Verse 1]
When I [C]find myself in [G]times of trouble [Am]mother Mary [F]comes to me

[C]Speaking words of [G]wisdom let it [F]be  cgc
And [C]in my hour of [G]darkness she is [Am]standing right in [F]front of me
[C]Speaking words of [G]wisdom let it [F]be 

 
[Chorus]

Let it be[Am], let it be[C], let it be[F], let it [C]be
[C]Whisper words of [G]wisdom, let it [F]be cgc
 
[Verse 2]
And [C]when the broken [G]hearted people [Am]living in the [F]world agree
[C]here will be an [G]answer, let it [F]be  cgc
For [C]though they may be [G]parted there is [Am]still a chance that [F]they will see
[C]There will be an [G]answer, let it [F]be
 
[Chorus]
Let it be[Am], let it be[C], let it be[F], let it [C]be
Yeah, [C]there will be n'[G]answer, let it [F]be
 
[Chorus]

Let it be[Am], let it be[C], let it be[F], let it [C]be
[C]Whisper words of [G]wisdom, let it [F]be
 
[Link]
| F   C G C   C7 Am | G  F  C     |
| F   C G C   C7 Am | G  F  C     |
 
[Solo]
| C G | Am F | C G | F  C G C       |
| C G | Am F | C G | F  C G C       |
 
[Chorus]
Let it [Am]be, let it [G]be, let it [F]be, yeah, let it [C]be
[C]Whisper words of [G]wisdom, let it [F]be
 
[Verse 3]
And [C]when the night is [G]cloudy, there is [Am]still a light that [F]shines on me
[C]Shine until to[G]morrow, let it [F]be
I [C]wake up to the [G]sound of music [Am]mother Mary [F]comes to me
[C]Speaking words of [G]wisdom, let it [F]be(e-e-e, yeah)
 
[Chorus]
Let it [Am]be, let it [G]be, let it [F]be, yeah, let it [C]be
[C]There will be an [G]answer, let it [F]be(e-e-e)
 
(repeat this chorus for the album version)
 
[Chorus]
Let it [Am]be, let it [G]be, let it [F]be, yeah, let it [C]be
[C]Whisper words of [G]wisdom, let it [F]be(e-e-e)
 
 
[Coda]
| F   C G C   C7 Am | G  F  C