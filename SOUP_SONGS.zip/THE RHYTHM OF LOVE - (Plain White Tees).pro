{title:THE RHYTHM OF LOVE}
{subtitle: 4/4      Key of G}
{subtitle: (Plain White Tees)}
{time: 3:35 }
{metronome:174}






{c:INTRO: count ”1234,12”}

[D]/ /    [G]/ / / /   / /  
[D]/ /    [G]/ / / /   / /      [D]/ /

{c:(shaker)}
[G]  My head is stuck in the [D]clouds
[G]  She begs me to come [D]down
Says, "[Em]Boy, quit [D]foolin' a[C]round" {c:(234,12)}
I told her, "[G]    I love the view from up [D]here
[G] Warm sun and wind in my [D]ear
We'll [Em]wa…tch the [D]wo…rld from a[C]bove
As it [D]turns to the rhythm of [G]    love" 

{soc}
We may [Em]only [C]have to[G]night
But till the [Em]morning [C]sun, you're-mi…[G]ine
[B7]A-a-all [Em]mine, play the [D]music [C]low
And [D]sway to the rhythm of [G]     love {c:(34,12)}
[D]/ /    [G]/ / / /   / /      [D]/ /
{eoc}

{c:tambourine slow}
[G]  My heart beats like a [D]drum***
[G]  A guitar string to the [D]strum
A [Em]beautiful [D]song to be [C]sung  {c:(234,12)}
She's got [G]     blue eyes deep like the [D]sea
[G]  That roll back when she's laughing at [D]me
She [Em]ri…ses [D]u…p like the [C]tide
The [D]moment her lips meet [G]      mine

{soc}
We may [Em]only [C]have to[G]night
But till the [Em]morning [C]sun, you're-mi…[G]ine
[B7]A-a-all [Em]mine, play the [D]music [C]low
And [D]sway to the rhythm of [G]     love {c:(34,12)}
{c:one Riff ONLY}   [D]/ /    [G]/ / / /   / /      [D]/ /
{eoc}


[B7]  When the [C]moon is [G]low-o-o-[D]ow  {c:(234)}
[B7]  We can [C]dance in [G]slo-o-ow [D]mo-o-o- [C]   -tion
And all your [D]tears… will sub[C]side
All your [D/]te-e-e-e-ears will 


[G](dry) Bop-ba, bop-ba, bop-[D]ba
[G] Bop-ba, bop-ba, bop-[D]ba
[Em]Daaah, da-da [D]dum da-da  [C]   dum  {c:(234,1234)}

[G] Bop-ba, bop-ba, bop-[D]ba
[G] Bop-ba, bop-ba, bop-[D]ba
[Em]Daaah, da-da [D]dum da-da  [C]   dum

[G]  And long after I've [D]gone
[G]  You'll still be humming a[D]long
And [Em]I… will keep [D]you… in my [C]mind
The [D]way you make love so [G]   fine

{soc}
We may [Em]only [C]have to[G]night
But till the [Em]morning [C]sun, you're-mi…[G]ine
[B7]A-a-all [Em]mine, play the [D]music [C]low
And [D]sway to the rhythm of [G]     love {c:(34,12)} [D]oh-oh

[Em]   Play the [D]music [C]lo-o-ow
And [D]sway to the rhythm of 
[G]    love {c:(34,12)  riff 3 X} [D]/ /   [G]/ / /  
Yeah, sway to the [D]rhythm of 
[G]    love  {c:(34,12)}  [D]/ /   [G]/

