{title:THE GLORY OF LOVE  }
{subtitle:(4/4     Key of C)}
{subtitle:(Billy Hill)}
{metronome: 104}
{time: 3:55}
 



                                               




{c:INTRO:}  
[C]/ /     [F]/ /      [C]/ /     [G7]/

You've got to [C]give a little, [G7]take a little
[C] Let your poor heart [F]break a little
[C] That’s the story of 
[G7]  That’s the glory of [C]love [G7]

You've got to [C]laugh a little, [G7]cry a little
[C] Let the clouds roll [F]by a little
[C] That’s the story of 
[G7]  That’s the glory of [C]love [C7]

{soc}
   As [F]long as there’s the two of us
   We've got the [C]world and all its charms
   But [F]when the world is through with us
   [C/]    We’ve got each others [G7]arms
{eoc}

You've got to [C]win a little, [G7]lose a little
[C] And always have the [F]blues a little
[C] That’s the story of [G7]     that’s the glory of 
[C]love  [G7]

{c:INSTRUMENTAL…}
You've got to [C]give a little, [G7]take a little
[C] Let your poor heart [F]break a little
[C] That’s the story of [G7]     that’s the glory of 
[C]love [G7]

You've got to [C]laugh a little, [G7]cry a little
[C] Let the clouds roll [F]by a little
[C] That’s the story of [G7]     that’s the glory of  
[C]love [C7] 

{c:SING}
{soc}
   As [F]long as there’s the two of us
   We've got the [C]world and all its charms
   But [F]when the world is through with us
   [C/]   We’ve got each others [G7]arms


You've got to [C]win a little, [G7]lose a little
[C]  And always have the [F]blues a little
[C]  That's the story of,  [G7]     that’s the glory of
[C]  That's the story of,  [G7]     that’s the glory of
[C]  That’s the story of,  [G7]     that’s the glory of 
[C]love [G7/][C/]
 
