{title:STILL THE ONE}
{subtitle:4/4     Key of C}
{subtitle:(Shania Twain)}
{metronome:130}
{time:3:45}



[C]/ / / /   / / / /    
[F]/ / / /    [G]/ / / /
 
[C]  Looks like we made it 
[F]Look how far we've [G]come my baby
[C] We mighta took the long way 
[F]We knew that we'd [G]get there someday
 
[C] They said, "I bet [F]  they'll never [G]make it"
But just [C]look at us [F]holding [G]on 
We're still toge[C]ther still [F]going [G]strong

{soc} 
You're still the [C]one
You're still the one I [F]run to
[Dm]      The one that I be[G]long to [C]    
You're still the one I wa[F]nt for [G]life
You're still the o[C]ne
You're still the one that [F]I love
[Dm]      The only one I [G]dream of  
[C]   You're still the one I [F]kiss good [G]night
{eoc}

[C] Ain't nothin' better
[F]   We beat the [G]odds together
[C] I'm glad we didn't listen 
[F]Look at what we [G]would be missin'

[C] They said, "I bet [F]  they'll never [G]make it"
But just [C]look at us [F]holding [G]on 
We're still to[C]gether, still [F]going [G]strong

{soc} 
You're still the [C]one 
You're still the one I [F]run to
[Dm]      The one that I be[G]long to [C]    
You're still the one I wa[F]nt for [G]life
You're still the o[C]ne
You're still the one that [F]I love
[Dm]      The only one I [G]dream of  
[C]   You're still the one I [F]kiss good [G]night
{eoc}

[C] I'm so glad we made it
[F]Look how far we've [G]come my baby   [Cgliss]

___________________________________
























