

{title:C11: LITTLE SAINT NICK      4/4      Key of Am}
{subtitle:Brian Wilson & Mike Love (The Beach Boys)}
{metronome:137}
{time:1:59}


{c:INTRO}
[G]Christmas  [Gmaj7]comes this  [G6]time each  [G7]year  
[Am7]Ooooooh      [D7]Oooooh 

Well a [Am7]way up [D7]north 
Where the [Am7]air gets [D7]cold there’s a 
[G]Tale about [Gmaj7]Christmas 
That you've [G6]all been [E7]told
And a [Am7]real famous [D7]cat 
All dressed [Am7]up in [D7]red
And he [G]spends the whole [Gmaj7]year 
Workin’ [G6]out on his [G7]sled 

It’s the [C]little Saint Nick 
{c:   (oooh…            little Saint Nick}  
It’s the [Am7]little Saint Nick     [D7]
{c:   (oooh…            little Saint Nick}
 
Just a [Am7]little bob[D7]sled 
We call the [Am7]old Saint [D7]Nick 
But she'll [G]walk a to[Gmaj7]boggan 
With a [G6]four speed [E7]stick
She's [Am7]candy apple [D7]red 
With a [Am7]ski for a [D7]wheel 
And when [G]Santa gives it [Gmaj7]gas 
Man just [G6]watch her [G7]peel 

It’s the [C]little Saint Nick 
{c:   (oooh…            little Saint Nick}  
It’s the [Am7]little Saint Nick     [D7]
{c:   (oooh…            little Saint Nick}

[C]Run run reindeer  [F]Run run reindeer, who-o-oaa
[C]Run run reindeer  [A]Run run reindeer 
(he [D7/]don't miss no one)

He's a [Am7]haulin' through [D7]the snow 
At a [Am7]frightenin' [D7]speed 
With a [G]half a dozen [Gmaj7]deer 
With a-[G6]Rudy to [E7]lead
He's gotta [Am7]wear his [D7]goggles 
‘Cause the [Am7]snow really [D7]flies
And he's [G]cruisin' every [Gmaj7] pad 
With a [G6]little [G7]surprise

It’s the [C]little Saint Nick 
{c:   (oooh…            little Saint Nick}  
It’s the [Am7]little Saint Nick     [D7]
{c:   (oooh…            little Saint Nick}


Aah ah ahhhh Oooo[Am7]ooo   [D7]Merry Christmas
[G]Christmas [Gmaj7]comes this [G6]time each [E7]year

Aah ah ahhhh Oooo[Am7]ooo   [D7]Merry Christmas
[G]Christmas [Gmaj7]comes this [G6]time each [E7]year [G/]
















