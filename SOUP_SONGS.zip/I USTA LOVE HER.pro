{title:I USTA LOVE HER}
{subtitle:(The Saw Doctors)}
{metronome: 176 }
{time: 3:00  }


{c:"1234,} [G/]{c:12"}

I have [G/]fallen for another 
She can make her own way [C]home {c:(234,123)}
And even if she asked me now 
I’d let her walk a[G]lone {c:(234,123)}
 
Well I [G]useta see her up-the-chapel 
When-she-went to Sunday [C]mass {c:(234,123)}
She’d [C]go up to receive I’d kneel down 
There and watch her [G]pass {c:(234)}   [G/]
The glory of the [D]lass  {c:(234)}  [D/]     Whoa!
 
{soc}
  {soh}[G]I{eoh} useta to love her, {soh}I{eoh} useta love her [C]once
  A long, long time ago
  {soh}[G]I{eoh} useta to love her, I {soh}useta{eoh} love her [C]once
  A long, long time ago, it’s [F]gone 
  [Bb]All my lovin’ is [C]gone...  whoa, whoa
  It’s [F]gone, ↑[Bb]all my lovin’ is [C]gone {c:(234,123)}
{eoc} 

D’you re[G/]member her collecting 
for concern on Christmas [C]eve {c:(234,123)}
Well she was on a forty-eight hour fast 
just water and black [G]tea  {c:(234,123)}
 
I [G]walked right up and made 
an ostentatious contri[C]bution {c:(34,123)}
And I winked at her to tell her 
I’d seduce her in the [G]future {c:(234)} [G/]
When she’s feelin [D]looser  [D/]     Whoa!
 
{soc}
  {soh}[G]I{eoh} useta to love her, {soh}I{eoh} useta love her o[C]nce
  A long, long time ago
  {soh}[G]I{eoh} useta to love her, I {soh}useta{eoh} love her o[C]nce
  A long, long time ago, it’s [F]gone 
  [Bb]All my lovin’ is g[C]one...  whoa, whoa
  It’s [F]gone, ↑[Bb]all my lovin’ is [C]gone {c:(234,123)}
{eoc} 
 
So [G/]now you know the truth of it 
She’s no longer my ob[C]session {c:(34,123)}
Though the [C]thoughts and dreams I had of her 
would take six months in con[G]fession!  {c:(34,123)}
 
See I [G]met this young one Thursday night 
and she’s inta free ex[C]pression {c:(34,123)}
And her [C]mission is to rid the world 
of this sinful repr[G]ession {c:(234)}  [G/]
Then we had a [D]session!  [D/]      Whoa!

{soc}
  {soh}[G]I{eoh} useta to love her, {soh}I{eoh} useta love her o[C]nce
  A long, long time ago
  {soh}[G]I{eoh} useta to love her, I {soh}useta{eoh} love her o[C]nce
  A long, long time ago, it’s [F]gone 
  [Bb]All my lovin’ is g[C]one...  whoa, whoa
  It’s [F]gone, ↑[Bb]all my lovin’ is [C]gone

Well it’s [F]go...ne,     [Bb]gone gone [C]gone
All my lovin is-a [F/]     [F/]gone, [Bb]long long [C]gone 
All my lovin is-a [F/]     [F/]gone, [Bb]long long [C]gone 
All my lovin is-a [F/]     [F/]gone, [Bb]long long [C]gone {c:(234)} [C/]
{eoc} 
 
I have fa[G/]llen for another 
She can make her own way [C/]     home
