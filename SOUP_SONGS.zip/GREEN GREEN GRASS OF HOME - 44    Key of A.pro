{title:GREEN GREEN GRASS OF HOME }
{subtitle:   4/4    Key of A}
{subtitle: (“Curly” Putnam Jr.)}
{metronome:124}
{time: }








{c:INTRO:}
[A]/ / / /    [E7]/ / / /    
[A]/ / / /   / / / /

The [A]old home town looks the same
As I [D]step down from the [A]train
And there to meet me is my mama and [E7]papa
Down the [A]road I look and [A7]there runs Mary
[D]  Hair of gold and lips like cherries
It's [A]good to touch the [E7]green green grass of [A]home 
Yes, they'll [A]all come to meet me
Arms a-[D]reaching, smiling sweetly
It's [A]good to touch the [E7]green green grass of [A]home
 
The [A]old house is still standing 
Though the [D]paint is cracked and [A]dry
And there's that old oak tree that I used to [E7]play on
Down the [A]lane I walk with [A7]my sweet Mary
[D] Hair of gold and lips like cherries
It's [A]good to touch the [E7]green green grass of [A]home
 
{c:spoken by Gord, with ooh’s from everyone else} 
And [A]suddenly I awake and look around me
At the [D]four gray walls that sur[A]round me 
and I realize… that I was only [E7]dreaming

{c:all sing}
For there's a [A]guard and there's a [A7]sad old padre
[D]  Arm and arm we'll walk at daybreak 
A[A]gain I'll touch the green [E7]green grass of [A]home 
Yes, they'll [A]all come to see me 
In the [D]shade of that old oak tree
As they [A]lay me 'neath 
The [E7]green, green grass of [D]home [A/]

