{title:BRING ME SUNSHINE   }
{subtitle:(4/4     Key of C)}
{subtitle:(Arthur Kent & Sylvia Dee)}
{time: 3:30}
{metronome: 120}

{c:INTRO: Using a muted strum on Calt (5433)}  
{c:(A muted strum is made by releasing the  } 
{c:pressure on the strings between the strums)}




{c:INTRO: (Muted)}
[Calt] / / / /   / /

Bring me [C]sunshine in your [Dm]smile 
Bring me [G7]laughter all the [C]while
In this [C7]world where we live 
There should [F]be more happiness 
So much [D7]joy we can give to each  
[G7/]Brand new bright tomorrow 

Make me [C]happy through the [Dm]years 
Never [G7]bring me any [C]tears 
Let your [C7]arms be as warm 
As the [F]sun from up above 
Bring me [D7]fun, bring me [G7]sunshine
Bring me [C]love  

{c:(speed up tempo)}
Bring me [C]sunshine in your [Dm]smile 
Bring me [G7]laughter all the [C]while
In this [C7]world where we live  
There should [F]be more happiness 
So much [D7]joy we can give to each  
[G7/]Brand new bright tomorrow 

Make me [C]happy through the [Dm]years
Never [G7]bring me any [C]tears 
Let your [C7]arms be as warm 
As the [F]sun from up above 
Bring me [D7]fun, bring me [G7]sunshine 
Bring me [C]love  

Bring me [C]sunshine in your [Dm]eyes 
Bring me [G7]rainbows from the [C]skies
Life’s too [C7]short to be spent 
Having [F]anything but fun 
We can [D7]be so content 
If we  [G7/]gather little sunbeams

Be light- [C]hearted, all day [Dm]long
Keep me [G7]singing happy [C]songs
Let your [C7]arms be as warm 
As the [F]sun from up above
Bring me [D7]fun, bring me [G7]sunshine 
Bring me [C]love [A7] 
Bring me [D7]fun, bring me [G7]sunshine
Bring me [C]love [A7]

Bring me [D7]fu-u-u-n; bring me [G7]su-u-nshi-i-ine;
Bring me [C]lo... (12 count) …[C/]ove [G7/] [C/]   


                       
{define: D7 0 2 0 2 0}
{define: Calt 0 5 4 3 3}