{title: DANCE, DANCE, DANCE   }
{subtitle:(4/4    Key of  G)}
{subtitle:(Steve Miller) }
{time: 2:30}
{metronome: 145}









[G/]My Grandpa he's [C/]ninety five, and he 
[G/]Keeps on dancin' he's [D7/]still alive
[G/]My Grandma she's [C/]ninety two, she 
[G/]Loves to dance and [D7/]sing some [D7/]too

{c:(speed up a bit (170))}
[G]I don't know but [C]I've been told If you 
[G]Keep on dancin' you'll [D7]never grow old
[G]Come on darlin' put a [C]pretty dress on we're 
[G]Gonna go [D7]out to[G]night

[C]Dance, dance, [Am]dance     
[C]Dance, dance, [Am]dance 
[C]Dance, dance, [Am]dance    
[D7]All night [G]long  {c: (234,123) }

I'm a [G]hard workin' man, I'm a [C]son-of-a-gun
I've been [G]working all week in the [D7]noonday sun
[G]Wood's in the kitchen and the [C]cows in the barn
I'm [G]all cleaned up and my [D7]chores are all done

[G]Take my hand and [C]come along
[G]Let's go out and [D7]have some fun
[G]Come on Darlin' put a [C]pretty dress on
We're [G]gonna go [D7]out to[G]night

[C]Dance, dance, [Am]dance      
[C]Dance, dance, [Am]dance
[C]Dance, dance, [Am]dance    
[D7]All night [G]long {c: (234, 1234)}

[G]Come on darlin' don't [C]look that way
Don't you [G]know when you smile I've [D7]got to say
You're my [G]honey-pumpkin-lover, you're my [C]hearts delight
[G]Don't you want to go [D7]out tonight?
You're [G]such a pretty lady, you're [C]such a sweet girl, 
[G]When you dance it brightens [D7]up my world
So [G]come on Darlin' put a [C]pretty dress on 
We're [G]gonna go [D7]out to[G]night

And [C]dance, dance, [Am]dance    
[C]Dance, dance, [Am]dance
[C]Dance, dance, [Am]dance    
[D7]All night [G]long {c: (234, 1234)}

[C]Dance, dance, [Am]dance     
[C]Dance, dance, [Am]dance
[C]Dance, dance, [Am]dance     
[D7]All night [G]long {c: (234, 1)} [Gdim/] [G/] 



{define: D7 0 2 0 2 0}
[Gdim]
{define: Gdim 0 0 1 0 1}
