

{title:113  MR. TAMBOURINE MAN   }
{subtitle:(4/4    Key of C)}
{subtitle:(Bob Dylan)}
{time:4:00}
{metronome: 130}





[G]/ / / /    [C]/ / / /    
[D]/ / / /    [G]/ / / /   / / / /

{c:CHORUS}
{soc}
     [C]Hey Mr. [D]Tambourine Man 
     [G]Play a song for [C]me
     I'm not [G]sleepy and there 
     [C]is no place I'm [D]going to 
     [C]Hey Mr. [D]Tambourine Man 
     [G]Play a song for [C]me
     In the [G]jingle jangle [C]morning I'll come 
     [D]Followin' [G]you  {c:(234,12)}   
{eoc}

Though I [C]know that evening’s [D]empire 
Has [G]returned into [C]sand
[G]Vanished from my [C]hand
Left me [G]blindly here to [Am]stand 
But still not [D]sleeping 
My [C]weariness a[D]mazes me 
I'm [G]branded on my [C]feet
I [G]have no one to [C]meet
And the [G]ancient empty [Am]street's too dead 
For [D]dreaming  

{soc}
     [C]Hey Mr. [D]Tambourine Man 
     [G]Play a song for [C]me
     I'm not [G]sleepy and there 
     [C]is no place I'm [D]going to 
     [C]Hey Mr. [D]Tambourine Man 
     [G]Play a song for [C]me
     In the [G]jingle jangle [C]morning I'll come 
     [D]Followin' [G]you {c:(234,1234)}   
{eoc}

[C]Take me on a [D]trip upon your 
[G]Magic swirlin' [C]ship
My [G]senses have been [C]stripped
My [G]hands can't feel to [C]grip
My [G]toes too numb to [C]step 
Wait [G]only for my [Am]boot heels to be 
[D]Wanderin' 
I'm [C]ready to go [D]anywhere 
I'm [G]ready for to [C]fade
On[G]to my own pa[C]rade 
Cast your [G]dancing spell my [C]way 
I [Am]promise to go [D]under it 

{soc}
      [C]Hey Mr. [D]Tambourine Man 
     [G]Play a song for [C]me
     I'm not [G]sleepy and there 
     [C]is no place I'm [D]going to 
     [C]Hey Mr. [D]Tambourine Man 
     [G]Play a song for [C]me
     In the [G]jingle jangle [C]morning I'll come 
     [D]Followin' [G/]you
{eoc}

______________________________________














