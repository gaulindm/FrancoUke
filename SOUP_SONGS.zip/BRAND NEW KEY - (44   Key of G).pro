{t:BRAND NEW KEY}
{subtitle:(4/4   Key of G)}     
{subtitle:(Melanie Safka-Schekeryk)}
{time:3:25}
{metronome: 166}







{c:INTRO: } 
[G]/ / / /     [D]/ / / /      
[G]/ / / /    / / / /     

[G] I rode my bicycle past your window last night
[D] I roller skated to your door at daylight 
[G] It almost seems that you're avoiding me
[C] I'm ok alone but you've got [D]something I need
    Well..

{soc}
     [G]I've gotta brand new pair of roller skates
     You got a brand new key      
     I think that we should get together and 
     Try them out ya see      
     [C]I've been lookin' around a while
     You got somethin' for me, oh      
     [G]I gotta brand new pair of roller skates
     [D]You got a brand new [G]key {c:(234,1234)}
{eoc}

[G] I ride my bike, I roller skate, don't drive no car
[D] Don't go too fast, but I go pretty far 
For [G]somebody who don't drive 
I've been all around the world
[C] Some people say I've done all [D]right for a girl
Well…  

{soc}
     [G]I've gotta brand new pair of roller skates
     You got a brand new key      
     I think that we should get together and 
     Try them out ya see      
     [C]I've been lookin' around a while
     You got somethin' for me, oh      
     [G]I gotta brand new pair of roller skates
     [D]You got a brand new [G]key  {c:(234,1234)}
{eoc}

[G] I asked your mother if you were at home
[D] She said yes, but you weren't alone, oh
[G] Sometimes I think that you're avoiding me 
[C] I'm ok alone but you got [D]something I need
Well…
 
{soc}
     [G]I've gotta brand new pair of roller skates
     You got a brand new key      
     I think that we should get together and 
     Try them out ya see      
     
     [C]La, la, la,   la-la,   la, la, la...   
     La, la, la,   la-la, la, oh    
     [G]I gotta brand new pair of roller skates
     [D]You got a brand new [G]key    

     [C]La, la, la,   la-la,   la, la, la...   
     La, la, la,   la-la, la, oh
     [G]I gotta brand new pair of roller skates      
     [D]You got a brand new [G]key  {c:(234, 1)} [D/] [G/]                                                                                 
{eob}



