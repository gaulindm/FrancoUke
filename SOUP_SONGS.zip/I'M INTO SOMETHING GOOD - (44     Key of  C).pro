{t:I'M INTO SOMETHING GOOD }
{subtitle:(tab   4/4     Key of  C)}       
{subtitle:(Gerry Goffin & Carole King)}
{time: 3:00}
{metronome: 140}









[C]/ /     [F]/ /     [C]/ /     [F]/ /   
[C]/ /     [F]/ /     [C]/ /     [F]/ /    
              
[C]  Woke up this [F]morning [C]feeling [F]fine
[C]There's something [F]special [C]on my [C7]mind
[F]Last night I met a new girl 
In the neighbor[C]hood, [F]    whoa [C]yeah  [F]
[G]Something tells me [F]I'm into something 
[C]good..........[F]..............[C]...........[F].....
{c:(something tells me I'm into something)}

                                                                     
[C]She's the kind of [F]girl who's [C]not too [F]shy  
[C]And I can [F]tell I'm [C]her kind of [C7]guy
[F]She danced close to me like I hoped she 
[C]would…………….……[F]…………[C]……….…[F]….
         {c:(she danced with me like I hoped she would)}

[G]Something tells me [F]I'm into something 
[C]good..........[F].............[C]............[F].................. 
{c:(something tells me I'm into something)}
 
{sob}                                                                     
   [G7]      We only danced for a minute or two
   And then she [C]stuck close to [F]me 
   The [C]whole night through
   [G7]      Can I be falling in love?  
   [D]She's everything I've been [A]dreaming [G7]of
{eob}

[C]  I walked her [F]home and she [C]held my [F]hand
I [C]knew it couldn't [F]be just a [C]one-night [C7]stand
So [F]I asked to see her next week and she told me I 
[C]could ……..…[F]………………..[C]………….[F]….
      {c:(I asked to see her and she told me I could)}

[G]Something tells me [F]I'm into something 
[C]good..........[F]..............[C]............[F]..................
{c:(something tells me I'm into something)}

{c:(something tells me I'm into something)}


[G]Something tells me [F]I'm into something 
[C]good..........[F].............[C].............[F]
{c:(something tells me I'm into something)}


[C]  I walked her [F]home and she [C]held my [F]hand 
I [C]knew it couldn't [F]be just a [C]one-night [C7]stand
So [F]I asked to see her next week and she told me I 
[C]could …………[F]……………….[C]………….[F]
    {c:(I asked to see her and she told me I could)}


[G]Something tells me [F]I'm into something 
[C]good..........[F]............[C]............[F]something
{c:(something tells me I'm into something)}


[G]Good, oh [F]yeah, something 
[C]good...........[F]............[C]...........[F]something                          
{c:(something tells me I’m into something)}


[G]Good, something [F]good, something [C/]good 

