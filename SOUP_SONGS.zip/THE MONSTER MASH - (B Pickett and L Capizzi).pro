{title:THE MONSTER MASH}
{subtitle:   (B. Pickett and L. Capizzi)  }
{subtitle:(4/4         Key of G)}
{metronome:150}
{time:3:30}







{c:G  / / / /   / / / /    }

{c:Em  / / / /   / / / /    }

{c:C  / / / /   / / / /    }

{c:D  / / / /   / / / }

I was [G]working in the lab, late one night When my [Em]eyes beheld an eerie sight For my [C]monster from his slab, began to rise And [D/]suddenly... to my surprise

(He did the [G]mash) he did the monster mash
(The monster [Em]mash) It was a graveyard smash
(He did the [C]mash) it caught on in a flash (He did the [D]mash) he did the monster mash

From my [G]laboratory in the castle east
{c:(Wha-oo...                        )} To the [Em]master bedroom, where the vampires feast
{c:(Wha-oo...                       )} The [C]ghouls all came from their humble abodes
{c:(Wha-wha-oo...                  )}     To [D/]get a jolt from my electrodes
{c:(Whaoo!/)}
 
(They did the [G]mash)  they did the monster mash (The monster [Em]mash) it was a graveyard smash
(They did the [C]mash) it caught on in a flash (They did the [D]mash) they did the monster mash

The [C]zombies were having fun
{c:(wha-oo...          in a shoop)}
The [D]party had just begun
{c:(wha-oo...    in a shoop)}                    
The [C]guests included Wolf Man,      
{c: (wha-oo...       in a shoop)}                
[D/]Dracula and his son
{c:(whaoo!/)}

{c:(wha-oo...)} 
The [G]scene was rockin', all were digging the sounds [Em]Igor on chains, backed by his baying hounds The [C]coffin-bangers were about to arrive With their [D/]vocal group, "The Crypt-Kicker Five"

(They played the [G]mash) They played the monster mash
(The monster [Em]mash)  It was a Graveyard smash
(They played the [C]mash)  It caught on in a flash
(They played the [D]mash)  They played the monster mash

{c:(wha-oo...)}
[G]Out from his coffin, Drac's voice did ring [Em]Seems he was troubled by just one thing He [C]opened the lid and shook his fist and said,  {c:(everyone)}
[D/]”Whatever happened to my Transylvania twist?"

(It's now the [G]mash) it's now the monster mash (The monster [Em]mash) and it's a graveyard smash (It's the [C]mash) it's caught on in a flash (It's the [D]mash) it's now the monster mash

{c:(wha-oo...)}
Now [G]everything's cool, Drac's a part of the band And my [Em]monster mash is the hit of the land For [C]you, the living, this mash was meant too When you [D/]get to my door, tell them Boris sent you

(And you can [G]mash) then you can monster mash (The monster [Em]mash) and do my graveyard smash (Then you can [C]mash) you'll catch on in a flash (Then you can [D]mash) then you can monster mash

Wha[G]oo (234,1) monster mash
wha[Em]oo (234,1) monster mash 
wha[C]oo (234,1) monster mash
wha[D]oo (234,1) monster mash, wha[G/]oo....
