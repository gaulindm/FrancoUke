{title: For No One}
{subtitle: Lennon/McCartney}

[G] Your day breaks [Gmaj7]           your mind aches
[Em7] You find that [G7] all her words of [C] kindness linger [F] on
When she no [G] longer needs you

[G] She wakes up [Gmaj7]           she makes up
[Em7] She takes her [G7] time and doesn't [C] feel she has to [F] hurry
She no [G] longer needs you

{soc}
{c:CHORUS:}
And in her [Am/C] eyes you see [C+7+5] nothing
[Am/C] No sign of love behind the tears cried for [C+7+5] no one
[Am/C] A love that should have lasted [D7/Csus4]years            [D7/C]
{eoc}


[G] You want her [Gmaj7]           you need her
[Em7] And yet you [G7] don't believe her
[C]When she says her [F]love is dead
You [G]think she needs you

{soc}
{c:CHORUS:}
And in her [Am/C] eyes you see [C+7+5] nothing
[Am/C]          No sign of love behind the tears cried for [C+7+5] no one
[Am/C]          A love that should have lasted [D7/Csus4]years           [D7/C]
{eoc}


[G]    You stay home [Gmaj7]        she goes out
[Em7]       She says that [G7]long ago she
[C]Knew someone but [F]now he's gone
She [G]doesn't need him

[G]     Your day breaks [Gmaj7]           your mind aches
[Em7]        There will be [G7] times when all the
[C]Things she said will [F]fill your head
You [G]won't forget her

{soc}
{c:CHORUS:}
And in her [Am/C] eyes you see [C+7+5] nothing
[Am/C]         No sign of love behind the tears
Cried for [C+7+5] no one
[Am/C]         A love that should have lasted [D7/Csus4]years             [D7/C]
{eoc}

