

{title:091 ELEANOR RIGBY      }
{subtitle:  4/4      Key of Em}
{metronome: 158}
{subtitle:(Paul McCartney, John Lennon)}
{metrtonome:136  }
{time:2:59}

{c:Jam leader: C/ "2,3,4..."}
{c:Starting note is E}





[C]Ah… look at all the lonely [Em(34,1234)]people   

{sot}
A| - 0 2 - 2 - 2 - 2 - 2 - - 
E| - - - 3 - 2 - 3 - 0 - - - 
{eot}

[C]Ah… look at all the lonely [Em(34,1234)]people   
{sot}
A| - 0 2 - 2 - 2 - 2 - 2 - - 
E| - - - 3 - 2 - 3 - 0 - - - 
{eot}

[Em]Eleanor Rigby, picks up the rice 
In the church where a wedding has bee[C]n {c:(234)} 
Lives in a [Em]dre-eam
Waits at the window, wearing the face that she 
Keeps in a jar by the do[C]or {c:(234)} 
Who is it [Em]fo-or

[Em7]All the lonely pe[Em6]ople
Where d[C]o they all come fr[Em]om
[Em7]All the lonely pe[Em6]ople
Where d[C]o they all be[Em]long

[Em]Father McKenzie, writing the words 
Of a sermon that no one will he[C]ar, {c:(234)} 
No one comes [Em]near
Look at him working, darning his socks in the 
Night when there’s nobody th[C]ere, {c:(234)} 
What does he [Em]ca-are?

[Em7]All the lonely pe[Em6]ople
Where d[C]o they all come fr[Em]om
[Em7]All the lonely pe[Em6]ople
Where d[C]o they all be[Em]long

[C]Ah… look at all the lonely pe[Em(34,1234)]ople  

{sot}
A| - 0 2 - 2 - 2 - 2 - 2 - - 
E| - - - 3 - 2 - 3 - 0 - - - 
{eot}

[C]Ah… look at all the lonely pe[Em(34,1234)]ople 

{sot}
A| - 0 2 - 2 - 2 - 2 - 2 - - 
E| - - - 3 - 2 - 3 - 0 - - - 
{eot}

[Em]Eleanor Rigby, died in the church 
And was buried along with her na[C]me, {c:(234)} 
Nobody [Em]ca-ame
Father McKenzie, wiping the dirt from his hands
As he walks from the gr[C]ave, {c:(234)} 
No one was [Em]sa-aved

[Em7]All the lonely pe[Em6]ople, 
{c:Ah…    look at all the lonely)  }

Were d[C]o they all come fr[Em]om
{c:         (people)}

[Em7]All the lonely pe[Em6]ople 
{c:Ah…    look at all the lonely)  }

Where [C]do they all be[Em]long    {c:(234)}  [Em/]
{c:         (people)}

{sot}
A|7 2 0 -
E|- - - 3
{eot}
{c:(tab starts on the Em on "belong")}

________________________________________











 