{t:YES, SIR THAT'S MY BABY}
{subtitle:(4/4    Key of C)}    
{subtitle:(Walter Donaldson & Gus Khan)}
{time: 2:00}
{metronome: 178}







{c:INTRO:}
[C]/ / / /      [G7]/ / / /      
[C]/ / / /    / / / /

[C]Yes, sir, that's my baby
[G7]No, sir, I don't mean maybe
Yes, sir, that's my baby [C]now

[C]Yes, ma'am, we've decided
[G7]No, ma'am, we won't hide it
Yes, ma'am, you're invited [C]now

{c:BRIDGE}
{soc}
     By the [C7]way 
     By the [F]way 
     When we [D7]reach the preacher
     I'll [G7]say- [G7+5]a-ay
{eoc}

[C]Yes, sir, that's my baby
[G7]No, sir, I don't mean maybe
Yes, sir, that's my baby [C]now

{c:INSTRUMENTAL (Ukes and Kazoos) } 
[C]Yes, sir, that's my baby
[G7]No, sir, I don't mean maybe
Yes, sir, that's my baby [C]now

[C]Yes, ma'am, we've decided
[G7]No, ma'am, we won't hide it
Yes, ma'am, you're invited [C]now

{c:(SING)}
{soc}
     By the [C7]way 
     By the [F]way 
     When we [D7]reach the preacher
     I'll [G7]say- [G7+5]a-ay
{eoc}

[C]Yes, sir, that's my baby
[G7]No, sir, I don't mean maybe
Yes, sir, that's my baby [C]now [G7/]  [C/]

{define: D7 0 2 0 2 0}
{define: G7+5 0 0 3 1 2}