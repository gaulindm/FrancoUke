{title:	 WALK ME HOME}
{subtitle: 4/4      Key of C}
{subtitle:(Pink, Nate Ruess, Scott Harris)}
{metronome:182}
{time:2:45}








[C]/ / / /   / / / /

There's [C]something in the way you 
[F]Roll your [C]eyes {c:(234,1234)}
[C]Takes me back to a [F]better [C]time {c:(234,12)}
When I saw [Dm]every[C]thing is [G7]good {c:(234,12)}
But now you're the 
[Dm]Only [C]thing that's [G7]good {c:(234,1234)}

[C]Trying to stand up on my [F]own two [C]feet {c:(234,1234)}
This [C]conversation ain't coming [F]easi[C]ly {c:(234,12)}
And darling I [Dm]know it's [C]getting [G7]late {c:(234,12)}
So what do you [Dm]say we [C]leave this [G7]place {c:(234,1234)}


{c:CHORUS}
{soc}
[Am]Walk me home in the [F]dead of [C]night 
[Am]I can't be [F]alo…ne with [C]a…ll that's 
[G7]on my mind,  mmm hm hmm
[Am]say you'll stay with [F]me to[C]ni…ght {c:(234,123)}
Cause there is [G7]so much wrong 
[F/]going on out[C]side {c:(234,1234,1234,1234)}
{eoc}


There's [C]something in the way I [F]wanna [C]cry {c:(234,1234)}
That [C]makes me think we'll [F]make it out [C]alive {c:(234)}
So come on and [F]show me [C]how we're [G7]good {c:(234,12)}
I think that [F]we could [C]do some [G7]good {c:(34,1234)}


{soc}
[Am]Walk me home in the [F]dead of [C]ni…ght 
[Am]I can't be [F]alo…ne with [C]a…ll that's 
[G7]on my mind,  mmm hm hmm
[Am]say you'll stay with [F]me to[C]ni…ght {c:(234,123)}
Cause there is [G7]so much wrong 
[F/]going on out[C]side {c:(234,1234)}
{eoc}


[C]Oo… oo-oo-[F]↑oo[C]ooh {c:(234,1234)} 
[F]Oo… oo-oo-[C]oo [G7]ooh {c:(234,1234)}
[F]oo [C]ooh [G7]ooh {c:(234,1234)} 
[F]oo [C]↑ooh [G7]ooh {c:(234,1234)} 

{soc}
[Am/]Walk me home in the  [F/]dead of [C/]night
Cause [Am/]I can't be [F/]alone with [C/]all that's 
[G7/]on my mi-i-ind  
[Am/]say you'll stay with [F/]me to[C/]night
Cause there is [G7/]so much wrong [F/]going on 

[Am]Walk me home in the [F]dead of [C]ni…ght 
[Am]I can't be [F]alo…ne with [C]a…ll that's 
[G7]on my mind,  mmm hm hmm
 [Am]say you'll stay with [F]me to[C]night {c:(234,123)}
Cause there is [G7]so much wrong 
There is so much [F]↑wrong
There is [G7]so much wrong [F/]going on out[C/]side
{eoc}