{title:I'LL BE SEEING YOU   }
{subtitle:(4/4     Key of G )}
{subtitle:Irving Kahal and Sammy Fain)        }
{time: 2:00}
{metronome: 104}









{c: INTRO:}  
[G]/ / / /     [Em]/ / / /      
[Am]/ /       [D7]/ /      
[G]/ / / / 
 
[G]I'll be [B7]seeing you  
In [Am]all the [E7]old fa-[Am]miliar [E7]places
[Am]That this [E7]heart of [Am]mine em[D7]braces 
[G]   All day [G6]through   [B7] 

[Em]  In the small cafe 
The [Am]park across the way
The [D7]children's carousel, the [G6/]chestnut trees 
The [Gdim/]wishing well

[G]I'll be [B7]seeing you 
In [Am]every [E7]lovely [Am]summer's [E7]day
In [Am]every-[E7]thing that's [Am]bright and [D7]gay 
I'll [G9]always think of [E7]you that way
 
I'll [Am]find you in the [B7]morning sun 
And [Em]when the night is [A7/]new (hold 2,3)
          
{c: (slower)}
I'll be [Am/]looking at the moon, 
[Cm]  But I'll be seeing [G/]you 



[Gdim]
{define: G9 0 0 2 1 0}
{define: G6 0 0 2 0 2}
{define: D7 0 2 0 2 0}
{define: Gdim 0 0 1 0 1}

