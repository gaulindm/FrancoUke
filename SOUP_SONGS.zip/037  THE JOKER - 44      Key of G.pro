{title:037  THE JOKER }
{subtitle:4/4      Key of G}
{subtitle: Steve Miller}
{metronome:168}
{time:4:39}







[G]/ / / /    [C]/ / / /    [D]/ / / / 
[C]/ /    [D]/ /
[G]/ / / /    [C]/ / / /    [D]/ / / / 
[C]/ /    [D]/ /

{c:(}[G]{c:123)}  Some [C]people call me the space [D]cowboy  
{c:(}[C]{c:12)}   Yea-ah  
{c:(}[G]{c:123)}  Some [C]call me the gangster of [D]lo...↑ove   [C] 
{c:(}[G]{c:123)} ↑Some [C]people call me Mau[D]rice (reh- [C]rrow) 
Cause I [G]speak of the [C]pompatus of lo-[D]ove   [C]
 
{c:(}[G]{c:1234)}   [C]People talk a[D]bout me, baby  [C]  
{c:(}[G]{c:12)} Say I'm [C]doin' you wrong, do[D]in' you wro-ong  [C]
{c:(}[G]{c:1234)} Well ↑[C]don't you worry ba[D]by, don't wo-[C]orry   
Cause I'm [G]right here, right here 
[C]Right here, right here at [D]home {c:(34,}[C]{c:123)} 

{soc}
  Cause I'm a [G]picker, I'm a [C]grinner
  I'm a [G]lover and I'm a [C]sinner
  {c:(}[G]{c:12)} I play my [C]music in the [D]su...[C]un  
  I'm a [G]joker, I'm a [C]smoker, I'm a [G]midnight to[C]...ker
  {c:(}[G]{c:12)} I get my [C]lovin' on the [D]run 
{eoc}

[D7] Oo-oo-oo-oo-oo[D]oo  {c:(234)}
[D7] Oo-oo-oo-oo-[G]ooo  {c:(234)}

[C]/ / / /    [D]/ / / /    [C]/ /    [D]/ /
[G]/ / / /    [C]/ / / /    [D]/ / / / 
[C]/ /    [D]/ /
 

[G]You're the cutest [C]thing that I e-[D]ever did se-[C]e-ee 
I ↑[G]really love your [C]peaches
Want to [D]shake your tre-[C]e-ee 
{c:(}[G]{c:12)}  Lovey-[C]dovey, lovey-dovey
Lovey-[D]dovey all the ti-[C]ime 
{c:(lovey dovey (234)}  [C]{c:reh-rrow) }

[G] Ooo-eee [C]baby, I'll sure show [D]you a good ti-ime [C]

{soc} 
Cause I'm a [G]picker, I'm a [C]grinner
I'm a [G]lover and I'm a [C]sinner
[G]     I play my [C]music in the [D]su...[C]un 
I'm a [G]joker, I'm a [C]smoker, I'm a [G]midnight to[C]...ker
[G]    I sure don't [C]want to hurt no [D]o...[C]one 
{eoc}
 
[G]/ / / /    [C]/ / / /
[G]/ / / /    [C]/ / / /
[G]/ / / /    [C]/ / / /    [D]/ / / /

[D7] Oo-oo-oo-oo-[D]oo    Oo-oo-oo-oo-  Ooo  {c:(234)}
 
{c:(}[G]{c:1234)}    [C]People keep talking a[D]bout me, baby [C]
{c:(}[G]{c:1234)}    [C]Say I'm doin' you [D]wro-o-ong [C]
{c:(}[G]{c:1234)}  Well, [C]don't you worry, don't [D]worry
No, don't wo-o[C]rry, mama
{c:(}[G]{c:123)}  Cause I'm [C]right here at ho-[D]o-ome  [C]
 
{c:(}[G]{c:1234)}  [C]↑You're the cutest thing I [D]ever did se-ee [C]
I [G]really love your [C]peaches
Want to [D]shake your tre-[C]ee-ee
{c:(}[G]{c:12)}  Lovey-[C]dovey, lovey-dovey, lovey-[D]dovey 
All the ti[C]me (reh-[G]rrow) 
Come on [C]baby and I'll... [D]show you a good ti-[C]ime   [G/]

------------------------------------------------










