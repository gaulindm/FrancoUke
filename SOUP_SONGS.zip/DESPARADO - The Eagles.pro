{title:DESPARADO}
{subtitle:The Eagles}

{c:[G] [G7] [C] [Cm] [G] [Em] [A7][D7]


Despe[G]rado,[G7]  why don't you [C]come to your [Cm]senses
You've been [G]out ridin' [Em]fences,
for [A7]so long - [D7]now.
Oh you're a [G]hard one. [G7]
I know that [C]you've got your [Cm]reasons.
These [G]things that are [Em]pleasin' you
Can [A7]hurt you [D7]some[G]how. [D]
 
Don't you [Em]draw the queen of [Bm]diamonds boy
She'll [C]beat you if she's [G]able.
You know the [Em]queen of hearts is [C]always your best [G]bet. [D]
Now it [Em]seems to me, some [Bm]fine things
Have been [C]laid upon your [G]table.
But you [Em]only want the [A7]ones
That you can't [Am]get. [D]
 
Despe[G]rado,
[G7] Ohhhh you ain't [C]getting no [Cm]younger.
Your [G]pain and your [Em]hunger,
They're [A7]driving you [D7]home.
And [G]freedom, oh [G7]freedom.
Well that's just [C]some people [Cm]talking.
Your [G]prison is [Em]walking through this [A7]world [D7]all a[G]lone. [D]
 
Don't your [Em]feet get cold in the [Bm]winter time?
The [C]sky won't snow and the [G]sun won't shine.
It's [Em]hard to tell the [C]night time from the [G]day. [D]
And you're [Em]losing all your [Bm]highs and lows
ain't it [C]funny how the [G]feeling goes
a[Am]way.[D].. [D7]
 
Despe[G]rado,
[G7] Why don't you [C]come to your [Cm]senses?
come [G]down from your [Em]fences, [A7]open the [D7]gate.
It may be [G]rainin'[G7], but there's a [C]rainbow a[Cm]bove you.
You better [G]let somebody [Em]love you.
([C]let somebody [Am]love you)
You better [G]let some[B7]body [Em]love you...ohhh..hooo
be[Am]fore it's [D7]too..oooo.. [G]late.
 
G7  C Cm  G
 