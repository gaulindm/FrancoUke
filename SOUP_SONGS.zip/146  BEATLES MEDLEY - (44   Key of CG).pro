

{title:146  BEATLES MEDLEY  }
{subtitle:(4/4   Key of C/G)}
{time:5:25}
{metronome: 168}

{c:INTRO: Count in “1234,1"… right into the song}






Well, she was [C7]just seventeen 
You [F]know what I [C]mean
And the way she looked 
Was way beyond com[G7]pare
So [C]how could I [C7]dance 
With a[F]nother ([Fm]ooooh)
When I [C]saw her [G7]standing [C]there
Well my [F]heart went boom 
When I crossed that room
And I held her hand in [G7]mi-ee… 
[F]Een {c:(234)}  [mute]X   {c:(234)}
 
I'll [C7]buy you a diamond ring, my friend 
If it makes you feel all right
I'll [F]give you anything, my friend 
If it [C]makes you feel all right
Cause [G/]I don’t care too [F/]    much for money
[G/]money can't buy me [C]love {c:(234,12)}

Close your [Am]eyes and I'll [D]kiss you
To[G]morrow I'll [Em]miss you
Re[C]member I'll [Am]always be [F]true [D]
And then [Am]while I'm a[D]way 
I'll write [G]home every [Em]day
And I'll [C]send all my [D]loving to 
[G]You {c:(234)}    [G]/ / / / {c:(slow-down)}

I [G]think I'm gonna be sad
I think it's today, yeah
The girl that's drivin' me mad 
Is going a[Am]way  [D]
[Em]She's got a ticket to [C]ride 
[Em]She's got a ticket to [F]ri-i-ide
[Em]She's got a ticket to [D]ride
And she don't [G]care [G/]      My baby don’t 

[G]Care {c:(234)}  ‘cause he's a real [D]nowhere man 
[C]Sitting in his [G]nowhere land 
[C]Making all his [Cm]nowhere plans for [G]nobody  
Doesn’t have a [D]point of view 
[C]Knows not where he's [G]going to
[C]Isn't he a [Cm]bit like you and [G]me {c:(234)}   
[G]/ / / /  

[G]Love, love me [C]do,  you [G]know I love [C]you
I'll [G]always be [C]true so ple-e-e-e-e-e-[C/]ease 

Love me [G]do   [C]     Whoa [G]love me do   [C]
[D]Someone to love, [C]somebody [G]new 
[D]Someone to love    [C]someone like [G/]you 

[G/]Hey [G]Jude, don't be a[D]fraid
You were [D7]made to go out and [G]get her

The [C]minute you let her under your [G]skin
Then you can be[D7]gin to make it 
[G/]better [G/]better [G/]better [G/]better 

[G]Naa, naa naa 
[F]Na-na-na naa 
[C]Na-na-na naa 

Hey [G]Jude (Jude Jude-a Judy, Judy, Judy, Judy ow!) 
Naa, naa naa [F]na-na-na naa… [C]na-na-na naa, 

Hey [G/]Jude, all you [A/]need is [D]love  
[G]   All you [A]need is [D]love  
[G]   All you [B7]need is [Em]love [G]love
[C]   Love is [D7]all you need [G] 
 
        All you [A]need is [D]love  
[G]   All you [A]need is [D]love  
[G]   All you [B7]need is [Em]love [G]love
[C]   Love is [D7]all you need [G/]

_____________________________________



[B7alt]
{define: D7 0 2 0 2 0}
{define: B7alt 0 4 3 2 0}








