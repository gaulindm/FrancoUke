{title: GIVE ME LOVE}
{subtitle: 4/4      Key of G} 
{subtitle: (George Harrison)}
{metronome:142}
{time:3:42}



{c:(start very slow, acapella)}

[G]
		  
Give me love, give me love   
Give me   peace on earth   
Give me light, give me life 
Keep me    free from birth 
Give me hope, help me cope with this 
Heavy load, trying to touch and 
Reach you with       heart and 
So…o-o [G]oul… {c:(8)}  

[Gmaj7]/ / / /   / / / /
          
{c:(}[G7]{c:123)}  My-y-y {c:(34)}  
[C]Lo-o-ord {c:(34,1234)}
{c:(}[G]{c:12)}  Plea…   [Gmaj7]ease…{c:(8)}    
      
{c:(}[G7]{c:123)} Take hold of my [C]hand {c:(34,1234)} 

That [A]I... {c:(23)} mig[A7]ht    under[D7]sta-a-and you 
[D7/]Won't you please oh won't you...! 

  
[G]Give me love, oh [Gmaj7]give me love-give-me 
[Am7] Peace on [D7]earth, give me [Cm]light
Give me [D7]life, keep me [F]   free from [C]birth 
Give me [G]hope, help me [Gmaj7]cope with this 
[Am7]  Heavy [D7]load trying [Cm]to touch and 
[D7]Reach you with [F]   heart and 
[C]So…o-o  [G]oul…{c:(8)}  

[Gmaj7]/ / / /   / / / / 
          
{c:(}[G7]{c:123)}  My-y-y {c:(34)}  
[C]Lo-o-ord {c:(34,1234)}

[G]/ / / /   / / / /    
[Gmaj7]/ / / /   / / / /        
[G7]/ / / /   / / / /
[C]/ / / /   / / / / 

[A]/ / / /    [A7]/ / / /    
[D7]/ / / / [D7/]Won't you please 
oh won't you...!

[G]Give me love, oh [Gmaj7]give me love-give-me 
[Am7] Peace on [D7]earth, give me [Cm]light  
Give me [D7]life, keep me 
[F]    Free from [C]birth 
Give me [G]hope, help me [Gmaj7]cope with this 
[Am7] Heavy [D7]load trying [Cm]to touch and 
[D7]Reach you with  [F]     heart and 
[C]So…o-o  

[G]Give me love, oh [Gmaj7]give me love-give-me 
[Am7] Peace on [D7]earth, give me [Cm]light  
Give me [D7]life, keep me 
[F]  Keep me [C]free from birth 
Ah [G]give me hope a-help [Gmaj7]me cope with this 
[Am7] Hea...vy [D7]load trying [Cm]to… {c:(234,12)} 
Touch and [D7]reach…     you-ou…    with 
[F]Hea…  rt and [C]so…o-o

[G]oul…{c:(8)}  
[Gmaj7]/ / / /   / / / /          
{c:(}[G7]{c:123)}  My-y-y {c:(34)}  
[C]Lo-o-ord {c:(34,1234)}
[G]/ / / /   / / / /  
[Gmaj7]/ / / /   / / / /      
{c:(slow Ellen }[G7]My-y-y... [C/]lo-o-ord

{define: D7 0 2 0 2 0}
	  
 