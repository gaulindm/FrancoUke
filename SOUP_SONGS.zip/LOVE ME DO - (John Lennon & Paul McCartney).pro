{title:LOVE ME DO}
{subtitle: (John Lennon & Paul McCartney)}
{subtitle: 4/4      Key of G}
{metronome:145}
{time:2:26}




{c:(KAZOO at instumental)}
{c:(harmonica with INTRO (quieter ukes))}

{c:LYNDA counts in regular 4/4 count}

{c:INTRO:}
{c:G / / / /    C / / / /    G / / / /    C / / / /}
{c:G / / / /    C / / / /    G / / / /   / / / /}

[G]Love, love me [C]do, you [G]know I love [C]you
I'll [G]always be [C]true, so ple…ee…    [C/]ease
Love me [G]do, [C]   whoa, [G]love me do    [C]

[G]Love, love me [C]do, you [G]know I love [C]you
I'll [G]always be [C]true, so ple…[C/]ease
Love me [G]do, [C]   whoa, [G]love me do  

{sob}
[D]Someone to love, [C]somebody [G]new
[D]Someone to love, [C]someone like [G/]you [G/][G/]
{eob}

[G]Love, love me [C]do, you [G]know I love [C]you
I'll [G]always be [C]true, so ple…[C/]ease
Love me [G]do, [C]   whoa, [G]love me do {c:(4,1234)}

{c:LOTS of Kazoo!}
{c:D / / / /   / / / /    C / / / /    G / / / /}
{c:D / / / /   / / / /    C / / / /    G / / / /}
{c:G / / / /   / / / /   / (stop)}   Tap!

[G]Love, love me [C]do, you [G]know I love [C]you
I'll [G]always be [C]true, so ple…[C/]ease
Love me [G]do, [C]   whoa, [G]love me do    
[C] Yeah, well [G]love me do
[C] Whoa, oh, [G]love me do  [G/]


