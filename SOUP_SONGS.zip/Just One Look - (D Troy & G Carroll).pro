{title:Just One Look}
{subtitle:(D. Troy & G. Carroll)}
{subtitle: 4/4      Key of D}
{time:3:22}
{metronome:112}







{c:INTRO:}
[D]/ / / /     [G]/ / / /     [D]/ / / /     [A7]/ / / /
 
[D]Just one look and I fell so [Bm]ha..aa..ard
In [G]love with [A]you, [A7]oh-oh, oh-oh
 
[D]I found out how good it [Bm]fe..eee..els
To [G]have your [A]love, [A7]oh-oh, oh-oh
 
[D]Say you will, will be [Bm]mi..ii..ine
For[G]ever and al[A]ways, [A7]oh-oh, oh-oh
 
[D]Just one look and I [Bm]knew..ew...ew
That [G]you [A]  were my only [D]one
Oh oh-oh [D7]oh!
 
[G] I thought I was dreamin' but I was 
[D]Wrong, yeah, yeah, [D7]yeah
Oh, but-a, [E7]I'm gonna keep on schemin'
Till I can a-[A]make you, [A7/]make [A7/]you [A7/]my [A7/]own!
 
[D]So you see, I really [Bm]care..are..are
With[G]out you I'm [A]nothin', [A7]oh-oh, oh-oh
 
[D]Just one look and I [Bm]know..oh..oh
I'll [G]get you some[A]day, [A7]oh-oh, oh-oh
 
[D]Just one look, [G]     that's all it [A7]took
[D]Just one look, [G]     that's all it [A7]took
[D]Just one look, [G]     that's all it [A7]took
[D]Just one look, [G]     that's all it [A7]took  [D/]

