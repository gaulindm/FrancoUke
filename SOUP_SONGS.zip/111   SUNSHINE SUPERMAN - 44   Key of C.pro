

{title:111   SUNSHINE SUPERMAN        }
{subtitle:  (4/4   Key of C) }
{metronome: 140}
{subtitle: (Donovan)}
{metronome 136}
{time:4:47}



 



[C]/ / / /    / / / /    / / / /    / / / / 
  
[C7]Sunshine came softly a-through my 
A-window today
Could've tripped out easy a-but I've 
A-changed my way
[F]  It'll take time I know it, but in a while
[C7] You're gonna be mine I know it 
We'll do it in style

{soc}
 [G7]'Cause I made my mind up you're 
 [F]Going to be mine
 I'll tell you right [C7]now
 Any trick in the book a-now baby
 All {soh}that{eoh} I can find
{eoc}

[C7]  Superman or Green Lantern ain't got
A-nothing on me
I can make like a turtle and dive for 
A pearl in the sea
[F]    A-you can just sit there a-thinkin'
On your velvet throne, yes
[C7]  About all the rainbows a-you can 
A-have for your own

{soc}
  [G7]'Cause I made my mind up you're 
  [F]Going to be mine
  I'll tell you right [C7]now
  Any trick in the book a-now baby
  All {soh}that{eoh} I can find
{eoc}

[C7] Everybody's hustlin' just to 
Have a little scene
When I say we'll be cool I think that 
You know what I mean
[F]  We stood on a beach at sunset 
Do you remember when
[C7]  I know a beach where baby 
A-it never ends

{soc}
  [G7]When you've made your mind up 
  For[F]ever to be mine  
  Hmm hmm hmm hmm [C7]hmmmm
  I'll pick up your hand and slowly 
  Blow your little mind
  [G7]Cause I made my mind up you're 
  [F]Going to be mine
  I'll tell you right [C7]now
  Any trick in the book a-now baby
  All {soh}that{eoh} I can find
{eoc}

[C7] Superman or Green Lantern ain't got
A-nothin' on me
I can make like a turtle and dive for
Your pearls in the sea, yeah!
[F] A-you-you-you can just sit there a-thinking
On your velvet throne
[C7]  'Bout all the rainbows a-you can 
A-have for your own

{soc}
  [G7]When you've made your mind up 
  For[F]ever to be mine
  Hmm hmm hmm hmm [C7]hmmmm
  I'll pick up your hand and slowly
  Blow your little mind

  [G7]When you've made your mind up 
  For[F]ever to be mine 
  I'll pick up your [C7]hand
  I'll pick up your hand and slowly
  Blow your little mind

  [G7]When you've made your mind up 
  For[F]ever to be mine
  Hmm hmm hmm hmm [C7/]hmmmm
{eoc}

________________________________









