{title:DANCE MONKEY}
{subtitle: 4/4      Key of Am}
{subtitle:(Tones and I)}
{time:3:32}
{metronome:  }

{c:(Throughout the song, mute the strings }
{c:after the single or double slashes)}

[Am/]    [mute]            [Am/]          [mute]  
[F/]       [mute]            [F/]          [mute]
[G/]       [mute]            [G/]          [mute]
[Em/]  [mute]            [Em/]          [mute]


They say, [Am/]Oh, my God I [Am/]see the way you 
[F/]Shine  [F/]
Take your [G/]hand, my dear and [G/]place them both in 
[Em]Mine   [Em/]           You know you 
[Am/]Stopped me dead while [Am/]I was passing 
[F/]By    [F/]       and now I 
[G/]Beg to see you [G/]dance just one more 
[Em/]Time    [Em/]Ooh, I
 
[Am//]See you, see you, [Am//]see you every 
[F//]Ti-i-ime   [F//]      and oh, my 
[G//]I,     [G//]I-I like your 
[Em//]Style     [Em//]you, you
[Am//]Make me, make me, [Am//]make me wanna 
[F//]Try   [F//]     and now I 
[G//]Beg to see you [G//]dance just one more [Em/]ti-ime 

So I say [Am]dance for me, dance for me
Dance for me, oh-oh-[F]oh
I never [G]seen anybody do the 
Things you do be-[Em]fo-ore
They say [Am]move for me, move for me
Move for me, ay-ay-[F]ay
And when you're [G]done I'll make you 
Do it all a-[Em]gain   [Em/]
 
I said, [Am/]oh, my God, I [Am/]see you walking [F/]by   [F/]
Take my [G/]hands, my dear, and [G/]look me in my  [Em/]eyes    [Em/]
Just like a [Am/]monkey I've been [Am/]dancing my whole [F/]life   [F/]
And you just [G/]beg to see me [G/]dance just one  more [Em/]time
 
Oh, I [Am] see you, see you, see you every [F] time
And oh, my, [G] I, I, I, I like your [Em] style
You, you [Am] make me, make me, make me wanna [F]try
And now I [G]beg to see you dance just one more [Em/]time
 
So I say [Am]dance for me, dance for me, dance for me, oh-oh-[F]oh
I've never [G]seen anybody do the things you do be-[Em]fore
They say [Am]move for me, move for me, move for me, ay-ay-[F]ay
And when you're [G]done I'll make you do it all a-[Em]gain
 
They say [Am]dance for me, dance for me, dance for me, oh-oh-[F]oh
I've never [G]seen anybody do the things you do be-[Em]fore
They say [Am]move for me, move for me, move for me, ay-ay-[F]ay
And when you're [G]done I'll make you do it all a-[Em]gain
 
[Am] Ooh (all a-[F]gain, all a-[G]gain)
Woah-[Em] oh, woah-oh, oh
[Am] Ooh (all a-[F]gain, all a-[G]gain)
[NC] Ah ah, ah ah, ay
 
They say [Am]dance for me, dance for me, dance for me, oh-oh-[F]oh
I've never [G]seen anybody do the things you do be-[Em]fore
They say [Am]move for me, move for me, move for me, ay-ay-[F]ay
And when you're [G]done I'll make you do it all a-[Em]gain
 
They say [Am]dance for me, dance for me, dance for me, oh-oh-[F]oh
I've never [G]seen anybody do the things you do be-[Em]fore
They say [Am]move for me, move for me, move for me, ay-ay-[F]ay
And when you're [G]done I'll make you do it all a-[Em]gain
 
All a-[Em]gain,  [NC] All again
