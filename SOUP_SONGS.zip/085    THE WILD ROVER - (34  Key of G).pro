

{title:085    THE WILD ROVER  }
{subtitle:(3/4  Key of A)}
{key:A}              
{time:3:29}
{metronome: 176}






[A]/ / /    / / /     [E7]/ / /     [A]/ / 

I've [A]been a Wild Rover for many's a [D]year
And I've [A]spent all me money 
On [E7]whiskey and [A]beer
But now I'm returning with gold in great [D]store
And I [A]swear I will play the 
Wild [E7]Rover no [A]more

{c:CHORUS:}
{soc}
     And it's [E7/]no, [E7/]nay, [E7/]never   
     {c:(tap, tap, tap)} 
     [A]    no nay never no [D]more!
     Will I [A]play the Wild [D]Rover
     No [E7]never...  no [A]more! 
{eoc}
  
I [A]went to an alehouse I used to fre[D]quent
And I [A]told the landlady me [E7]money was [A]spent
I asked her for credit, she answered me "[D]Nay
Such [A]custom as yours I could [E7]have any [A]day!"              

{soc}
     And it's [E7/]no, [E7/]nay, [E7/]never
     {c:(tap, tap, tap)} 
     [A]    no nay never no [D]more!
     Will I [A]play the Wild [D]Rover
     No [E7]never...  no [A]more! 
{eoc}
  
I [A]took from me pocket my ten sovereigns [D]bright
And the [A]landlady's eyes 
Opened [E7]wide with de[A]light
She said "I have whiskeys and wines of the [D]best
And the [A]words that I spoke
They were [E7]only in [A]jest!"       

{soc}
     And it's [E7/]no, [E7/]nay, [E7/]never
     {c:(tap, tap, tap)} 
     [A]    no nay never no [D]more!
     Will I [A]play the Wild [D]Rover
     No [E7]never...  no [A]more! 
{eoc}
  
I'll go [A]home to my parents
Confess what I've [D]done
And I'll [A]ask that they pardon 
Their [E7]prodigal [A]son
And if they caress me, as oft' times be[D]fore
I [A]never will play the Wild [E7]Rover no [A]more                         

{soc}
     And it's [E7/]no, [E7/]nay, [E7/]never
     {c:(tap, tap, tap)} 
     [A]    no nay never no [D]more!
     Will I [A]play the Wild [D]Rover
     No [E7]never...  no [A]more! 

{c:ACAPELLA, slowing down the last line}
     And it's no, nay, never
     {c:(tap, tap, tap, tap)}  
     No nay never no more!
     Will I play the Wild Rover
     No never...  no more! 
{eoc}

___________________________________











