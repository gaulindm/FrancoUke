{title:EVERYBODY TALKS}
{subtitle:(NEON TREES)}
 
[D] Hey baby won't you look my way
I can [G]be your new addiction
[D] Hey baby what you gotta say?
All you're [G]giving me is fiction
[D]I'm a sorry sucker and this 
[G]happens all the time
[A7]I found out that everybody talks
Everybody talks, everybody [A7/]talks
 
{soc}
It started with a [D]whisper
And that was when I[G] kissed her
And then she made my l[A]ips hurt [G]
I could hear the [D]chit chat
Take me to your [F#m]love shack
Mamas always gotta [G]back tra...[A]ack
When everybody [D]talks back
{eoc} 

[D]Hey honey you could be my drug
[G]You could be my new prescription
[D]Too much could be an overdose
All this [G]trash talk make me itchin
[A7]Oh my mouth Yeah
Everybody talks, everybody talks
Everybody talks, too much
 
It started with a [D]whisper
And that was when I[G] kissed her
And then she made my l[A]ips hurt [G]
I could hear the [D]chit chat
Take me to your [F#m]love shack
Mamas always gotta [G]back tra...[A]ack
When everybody [D]talks back
 
[G]Never thought I'd live
To see the d[D]ay
[G]When everybody's words got in the [A]way [A7]
 
[D]/ / / /   / / / /   / / / /   / / / /

[D/]Hey sugar show me all your love
All you're [G/]giving me is friction
[D/]Hey sugar what you gotta say? {c:(234,1)}
 
It started with a [D]whisper
And that was when I [G]kissed her
And then she made my l[A]ips hurt [G]
I could hear the [D]chit chat
Take me to your [F#m]love shack
Mamas always gotta [G]back tra...[A]ack  [A7]
When everybody [D]talks back
 
[D]Everybody talks, everybody talks
[G]Everybody talks, everybody talks
[A]Everybody talks, every[G]body talks...b[D]ack
 
It started with a whisper
                {c:(everybody talks, everybody talks)}
And that was when I [G]kissed her
                       {c:(everybody talks, everybody talks)}
 
[A]Everybody talks, ev[G]erybody talks...[D/]    back
