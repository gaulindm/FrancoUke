

{title:THE CIRCLE GAME}
{subtitle:(4/4  Key of G)}
{subtitle:(Joni Mitchell)}
{time:4:55}
{metronome: 134}

{c:NOTE:  to make the Gsus4}
{c: just stay on G and add your pinkie!}





[C]/ / / /    [G]/ /    [D7]/ /    
[G]/ / / /   / / / /  

[G]Yesterday a [C]child came out to [G]wonder  {c:(34,1234)}
Caught a dragon[C]fly inside a [D7]jar  {c:(234,1234)}
[G]Fearful, when the [C]sky was full of [Bm7]thunder  {c:(34,1234)}
And [C]tearful at the [G]falling [D7]of  a  
[G//]Star      [Gsus4]/ /             [G]/ / /

{c:CHORUS:}
{soc}
     And the [G]seasons, they go ‘[D]round and ‘[G]round
     And the painted ponies go [D]up and [G]down
     [C]     We're captive on a carousel of 
     [G//]time   [Gsus4]/ /              [G]/ / / /
     [C]     We can't return, we can only look
     Be[Bm7]hind from where we [C]came
     And go ‘[Bm7]round and ‘round and ‘[C]round in the 
     [D]Circle [G//]game   [Gsus4]/ /              [G]/ / / /
{eoc}

[G]Then the child moved [C]ten times 'round the 
[G]Seasons  {c:(34,1234)}
Skated over [C]ten clear frozen [D7]streams {c:(234,1234)}
[G]Words like, when you're [C]older 
Must ap[Bm7]pease him   {c:(34,1234)}
And [C]promises of [G]someday [D7]make his 
[G//]Dreams   [Gsus4]/ /            [G]/ / /  

{soc}
     And the [G]seasons, they go ‘[D]round and ‘[G]round
     And the painted ponies go [D]up and [G]down
     [C]     We're captive on a carousel of 
     [G//]time   [Gsus4]/ /              [G]/ / / /
     [C]     We can't return, we can only look
     Be[Bm7]hind from where we [C]came
     And go ‘[Bm7]round and ‘round and ‘[C]round in the 
     [D]Circle [G//]game   [Gsus4]/ /              [G]/ / / /
{eoc}

[G]Sixteen springs and [C]sixteen summers 
[G]Gone now   {c:(34,1234)}
Cartwheels turn to [C]car wheels through the 
[D7]Town   {c:(234,123)}
And they [G]tell him, take your [C]time it won't be 
[Bm7]Long now   {c:(34,123)}
'Till you [C]drag your feet to [G]slow the 
[D7]Circles [G//]down   [Gsus4]/ /            [G]/ / /     

{soc}
     And the [G]seasons, they go ‘[D]round and ‘[G]round
     And the painted ponies go [D]up and [G]down
     [C]     We're captive on a carousel of 
     [G//]time   [Gsus4]/ /              [G]/ / / /
     [C]     We can't return, we can only look
     Be[Bm7]hind from where we [C]came
     And go ‘[Bm7]round and ‘round and ‘[C]round in the 
     [D]Circle [G//]game   [Gsus4]/ /              [G]/ / / /
{eoc}

So the [G]years spin by and [C]now the boy is 
[G]Twenty   {c:(34,123)}
Though his dreams have lost some 
[C]Grandeur coming [D]true   {c:(234,123)}
There'll be [G]new dreams, maybe 
[C]Better dreams and [Bm7]plenty   {c:(34,1234)}
Be[C]fore the last re[G]volving [D]year is 
[G//]Through   [Gsus4]/ /        [G]/ / /  

{soc}
     And the [G]seasons, they go ‘[D]round and ‘[G]round
     And the painted ponies go [D]up and [G]down
     [C]     We're captive on a carousel of 
     [G//]time   [Gsus4]/ /              [G]/ / / /
     [C]     We can't return, we can only look
     Be[Bm7]hind from where we [C]came
     And go ‘[Bm7]round and ‘round and ‘[C]round in the 
     [D]Circle [G//]game   [Gsus4]/ /              [G]/ / 

     And go ‘[Bm7]round and ‘round and ‘[C]round in the 
     [D]Circle [G//]game   [Gsus4]/ /              [Ggliss]/ 
{eoc}

*********************************








