

{title:064    COUNTRY ROADS  }
{subtitle:(4/4   Key of C)}
{subtitle:(John Denver)}
{time:4:26}
{metronome: 158}






[F]/ / / /    / / / /      
[C]/ / / /    / / / /

[C] Almost heaven [Am]        West Virginia
[G] Blue Ridge mountains 
[F]Shenandoah [C]River {c:(4,1234)}
[C] Life is old there, [Am]older than the trees
[G]Younger than the mountains 
[F]Growing like a [C]breeze

{c:CHORUS}
{soc}
     Country [C]roads take me [G]home to the 
     [Am]Place I be[F]long
     West Vir[C]ginia mountain [G]momma
     Take me [F]home country [C]roads {c:(34,1234)}
{eoc}

[C] All my memories [Am]      gather round her 
[G] Miner's lady [F]stranger to blue [C]water {c:(4,1234)}
[C] Dark and dusty [Am]painted on the sky
[G]Misty taste of moonshine [F]tear drop in my [C]eye  

{soc}
     Country [C]roads take me [G]home to the 
     [Am]Place I be[F]long
     West Vir[C]ginia mountain [G]momma
     Take me [F]home country [C]roads {c:(34,1234)}
{eoc}

[Am] I hear her [G]voice in the 
[C]Mornin' hours she [C7]calls me
The [F]radio re[C]minds me of my [G]home far away
And [Am]drivin' down the [Bb]road I get a 
[F]Feelin' that I [C]should have been home 
[G]Yesterday yester[G7]day   [G7/]

{soc}
     Country [C]roads take me [G]home to the 
     [Am]Place I be[F]long
     West Vir[C]ginia mountain [G]momma
     Take me [F]home country [C]roads {c:(34,12)}
{eoc}

Country [C]roads take me [G]home to the 
[Am]Place I be[F]long
West Vir[C]ginia mountain [G]momma
Take me [F]home country [C]roads
Take me [G]home country [C]roads
Take me [G]home country [C]roads {c:(34)} [C/]

__________________________________













