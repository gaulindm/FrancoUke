{title: YOU ARE MY SUNSHINE (a la Anne Murray)}
{subtitle:(4/4     Key of C  )}
{time: 3:00}
{metronome:166 }

{c:TURN TABLET HORIZONTAL}





{c:C / / / /    G7 / / / /    C / / / /   /}

The other [C]night dear as I lay [C7]sleeping
I dreamt I [F]held you in my [C]arms
When I a[F]woke dear, I was mis[C]taken [Am]
So I [C]hung my  [G7]head and [C]cried

You are my [C]sunshine, my only [C7]sunshine
You make me [F]happy when skies are [C]grey
You’ll never [F]know dear how much I [C]love you 
Please don’t [C]take my [G7]sunshine a[C]way


So let the [F]sunshine in, [C]face it with a grin
[G7]Smilers never lose, and [C]frowners never win
So let the [F]sunshine in [C]face it with a grin
[G7]Open up your heart and let the 
[C]sun [G7]shine [C]in     


My [C]mother told me [F]something 
That [C]everyone should know
Its [G7]all about the devil 
And I’ve [C]learned to hate him so
I know he’ll be  un[F]happy 
‘Cause I’ll [C]never wear a frown
Maybe [G7]if we keep on smiling 
He'll get [C]tired of [G7]hangin' [C]round


  So  let  the   [F]sunshine in,            [C]face it with a grin
{c:(You are my }[F]{c:sunshine, my only }[C]{c:sunshine)}
                         [G7]Smilers never lose, and [C]frowners never win
{c:(You make me }[G7]{c:happy, when skies are }[C]{c:grey)}
      So let the [F]sunshine in,                     [C]face it with a grin
{c:(You'll never }[F]{c:know Dear, how much I }[C]{c:love you)}
[G7]Open up your heart and let the [C]sun [G7]shine [C]in 


  So  let  the   [F]sunshine in,            [C]face it with a grin
{c:(You are my }[F]{c:sunshine, my only }[C]{c:sunshine)}
                         [G7]Smilers never lose, and [C]frowners never win
{c:(You make me }[G7]{c:happy, when skies are }[C]{c:grey)}
      So let the [F]sunshine in,                     [C]face it with a grin
{c:(You'll never }[F]{c:know Dear, how much I }[C]{c:love you)}
[G7]Open up your heart and let the 
[C]sun… {c:(234)} [G7]shine… {c:(234)} [C]in… {c:(234,1)} [G7/] [C/]  








