{title:KNOCK THREE TIMES }
{subtitle:4/4     Key of C & D}
{subtitle: (Irwin Levine & L. Russell Brown)}
{metronome:120 }
{time:3:16}


{c:"X" means "knock"}





{c:(kazoos)}
[C]/ / / /    [F]/ / / /
[F]/ /    [G]/ /    [F]/ /    [G7]/ /

[C]Hey, girl, whatcha doin' down there
Dancin' alone every night
While I live right a[G]bove you
[G7]I can hear your music playing
I can feel your body swaying
[G]One floor below me
You [G7]don't even know me   I [C]love you

[C7]  Oh, my darling  [F/]knock [F/]three [F/]times
On the ceiling if you [C]want me
Mmm-hmm, [G]twice on the pipe  
[G7]  If the answer is [C]no
[C7]  Oh my sweetness  [F/]     {c:X  X}
Means you'll [F/]meet me
In the [C]hallway ohh, ohh 
[G/]Twice on the [G/]pipe  {c:X  X}
Means you ain't gonna [C]show   [F]

If [C]you look out your window tonight
Pull in the string with the note that's
Attached to my [G]heart
[G7]Read how many times I saw you
How in my silence I adore you
[G]Only in my dreams did [G7]that wall
Between us come a[C]part

[C7]  Oh, my darling [F/]knock [F/]three [F/]times
On the ceiling if you [C]want me
Mmm-hmm, [G]twice on the pipe  
[G7]  If the answer is [C]no
[C7]  Whoa my sweetness  [F/]      {c:X  X}
Means you'll [F/]meet me
In the [C]hallway whoa ohh 
[G/]Twice on the [G/]pipe  {c:X  X}
Means you ain't gonna [C]show 

{c:INSTRUMENTAL with key change}
[D]/ / / /   / / / / 
[D]/ / / /   / / / /
[A]/ / / /   / / / 

Whoa, [A]I can hear the music playin'
I can feel your body swaying
[A]One floor below me
You [A7]don't even know me I [D]love you

[D7]  Oh, my darling [G/]Knock [G/]three [G/]times
On the ceiling if you [D]want me
Mmm-hmm, [A]twice on the pipe  
[A7]  If the answer is [D]no
[D7]  Whoa my sweetness  [G/]     {c:X  X}
Means you'll [G/]meet me
In the [D]hallway whoa oh 
[A/]Twice on the [A/]pipe  {c:X  X}
Means you ain't gonna [D]show  [D/]      [A/]      [D/]