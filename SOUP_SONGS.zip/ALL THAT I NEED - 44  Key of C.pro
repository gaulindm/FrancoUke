{title:ALL THAT I NEED}
{subtitle: 4/4  Key of C}
{subtitle: He & She}
{metronome: 140}
{time: 2:50}






{c:INTRO:}
{c:C / / / /   / / / /  }
{c:C / / / /   F / / / /   }

[C]{c:(12)} Buttered toast and jam
The Sunday news in hand I
[F]Read about the strangest things
[C]{c:(12)} A robber gets away
And leaves the store to pay for
[F]All the wrongs they didn't do  
[Dm]{c:(12)} There is one thing I [G]know {c:(234,}[G/]{c:12)}

{soc}
     Some only [C]want, all that they see
     But all that I [Dm]have is all I need [F] 
     Some only [C]want, all that they see
     But all that I [Dm]have is all I need 
    [F]    Is all that I [C]nee-eed 
{eoc}

[C]{c:(12)} A golden throne of jewels
A nation known to rule I'd
[F]Rather sit beside the lake
[C]{c:(12)} And watch the clouds role by
If money is made of time then
[F]I'm the richest one alive 
[Dm]{c:(12)} There is one thing I [G]know {c:(234,}[G/]{c:12)}
  
{soc}
     Some only [C]want, all that they see
     But all that I [Dm]have is all I need [F] 
     Some only [C]want, all that they see
     But all that I [Dm]have is all I need [F]   

     Some only [C]want, all that they see
     But all that I [Dm]have is all I need [F] 
     Some only [C]want, all that they see
     But all that I [Dm]have is all I need [F]    
     Is all that I [C]nee-eed  {c:(234,1234)}
{eoc}

{c:Dm  / /    F  / /    C  /}


