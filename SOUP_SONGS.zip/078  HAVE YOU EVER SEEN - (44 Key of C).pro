

{title:078  HAVE YOU EVER }
{title:SEEN THE RAIN}
{subtitle:(4/4 Key of C)}    
{subtitle:(John Fogerty)  }
{time:3:41}
{metronome: 120}






[F]/ / / /     [G7]/ / / /    
[C]/ /    [Em7]/ /       [Am]/ / / /
[F]/ / / /     [G7]/ / / /    
[C]/ / / /   {c:RIFF }

{sot}
A| - 3 - 2 - 0 - - - - - - - - 
E| - - - - - - - 3 - 0 - - - - 
{eot}

[C] Someone told me long ago    [Csus4]/              [C]/    
[C]There's a calm before the storm, I [G7]know
It’s been coming [C]for some time  [Csus4]/ /          [C]/ /  

[C] When it's over, so they say   [Csus4]/              [C]/    
[C]It'll rain a sunny day, I [G7]know 
Shining down like [C//]water  [Csus4]/ /         [C]/ /    [C7]/ /

{c:CHORUS}
{soc}
     [F]    I wanna [G7]know
     Have you [C]ever [Em7]seen the [Am]rain    [G]
     [F]    I wanna [G7]know
     Have you [C]ever [Em7]seen the [Am]rain    [G]
     [F]    Coming [G7]down on a sunny 
     [C]Day {c:(234)} {c:RIFF}
{eoc}

{sot}
A| - 3 - 2 - 0 - - - - - - - - 
E| - - - - - - - 3 - 0 - - - - 
{eot}

[C] Yesterday and days before  [Csus4]/             [C]/    
[C]Sun is cold and rain is hard, I [G7]know
Been that way for [C]all my time  {c:RIFF} 

{sot} 
A - 3 - 2 - 0 - - - - - - - - 
E - - - - - - - 3 - 0 - - - - 
{eot}

[C] 'Til forever on it goes   [Csus4]/             [C]/    
[C]Thru the circle fast and slow, I [G7]know
And it can't stop I 
[C//]wonder  [Csus4]/ /          [C]/ /    [C7]/ /

{soc}
     [F]    I wanna [G7]know
     Have you [C]ever [Em7]seen the [Am]rain    [G]
     [F]    I wanna [G7]know
     Have you [C]ever [Em7]seen the [Am]rain    [G]
     [F]    Coming [G7]down on a sunny 
     [C]Day {c:(234)} {c:RIFF}
{eoc}

{sot}
A - 3 - 2 - 0 - - - - - - - - 
E - - - - - - - 3 - 0 - - - - 
{eot}

{soc}
     [F]    I wanna [G7]know
     Have you [C]ever [Em7]seen the [Am]rain    [G]
     [F]    I wanna [G7]know
     Have you [C]ever [Em7]seen the [Am]rain    [G]
     [F]    Coming [G7]down on a sunny 
     [C]Day {c:(234)} {c:RIFF}
{eoc}

{sot}
A - 3 - 2 - 0 - - - - - - - - 
E - - - - - - - 3 - 0 - - - - 
{eot}

[F]    Coming [G7]down on a sunny 
[C]Day {c:(234)} {c:RIFF} 

{sot}
A - 3 - 2 - 0 - - - - - - - - 
E - - - - - - - 3 - 0 - - - - 
{eot}

[C/]

{define: Csus4 0 0 0 1 3}
{define: Em7 0 0 2 0 2}
_____________________________








