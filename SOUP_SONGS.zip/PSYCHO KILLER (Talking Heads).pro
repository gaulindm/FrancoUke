{title:PSYCHO KILLER (Talking Heads)}

{c: A  / / / /   / / /    G  /    A  / / / /    / / /    G  /}
{c:(Hit the G's hard, then immediately get soft on the A's)}

[A] I can't seem to face up to the facts [G]
[A] I'm tense and nervous and I can't relax [G]
[A] I can't sleep cause my bed's on fire [G]
[A] Don't touch me I'm a real live wire [G]

{soc} 
  [F]  Psycho killer, [G]   qu'est-ce que c'est
  [Am]  Fa fa fa fa fa fa fa fa fa better
  [F]Run run run [G]run run run run a[C]way  Oh oh oh oh...
  [F] Psycho killer, [G]  qu'est-ce que c'est
  [Am]  Fa fa fa fa fa fa fa fa fa better
  [F]Run run run [G]run run run run a[C]way
  Oh oh oh [F]oh... [G]ay ay ay ay ay ay
{eoc}

{c: A  / / / /   / / /    G  /    A  / / / /    / / /    G  /}

[A] You start a conversation, you can't even finish it [G]
[A] You're talking a lot, but you're not saying anything [G]
[A] When I have nothing to say, my lips are sealed [G]
[A] Say something once, why say it again [G]

{c:REPEAT CHORUS}

{c: A  / / / /   / / /    G  /    A  / / / /    / / /    G  /}



