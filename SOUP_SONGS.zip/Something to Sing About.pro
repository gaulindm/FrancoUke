
{title: SOMETHING TO SING ABOUT-pdf version to print}
{subtitle: 4/4      Key of G  (Oscar Brand)}

[G]/ / / /    [Em]/ / / /    [D7]/ / / /    [G/]     (stop)

I have [G]walked cross the sands by the[C]  Grand Banks of Newfoundland
[G]Lazed on the [Em]ridge of the [C]Miram[D7]achi
Seen the[G] waves tear and roar on the[C] stone coast of Labrador
[G]Watched them roll[Em] back to the [Am7]great Nor[D7]thern [G/]sea

{soc}
  From the [D7]Vancouver Island to the [G]   Alberta highland
  Cross the [Em]prairies, the [D]lakes to On[A7]tario's  [D]towers
  From the [G]sound of Mount Royal's chimes  [C]    Out to the Maritimes
  [G]Something to [Em]sing about [D7]This land of [G]ours
{eoc}

I have [G]welcomed the dawn from the [C]fields of Saskatchewan.
[G]Followed the [Em]sun to the [C]Vancouver [D7]shore
Watched it [G]climb shiny newn up the [C]    snow peaks of Cariboo
[G]Up to the [Em]clouds where the [Am7]wild Ro[D7]ckies [G/]soar

{soc}
  From the [D7]Vancouver Island to the [G]   Alberta highland
  Cross the [Em]prairies, the [D]lakes to On[A7]tario's  [D]towers
  From the [G]sound of Mount Royal's chimes  [C]    Out to the Maritimes
  [G]Something to [Em]sing about [D7]This land of [G]ours
{eoc}

I have [G]heard the wild wind sing of [C]Places that I have been
[G]Bay Bull and [Em]Red Deer and the [C] Strait of Belle [D7]Isle
Names like [G] Grande-mere and Silverthrone [C]Moose Jaw and Marrowbone
[G]Trails of the [Em]pioneer [Am7] named [D7]with a[G] smile

{soc}
  From the [D7]Vancouver Island to the [G]   Alberta highland
  Cross the [Em]prairies, the [D]lakes to On[A7]tario's  [D]towers
  From the [G]sound of Mount Royal's chimes  [C]    Out to the Maritimes
  [G]Something to [Em]sing about [D7]This land of [G]ours
{eoc}

I have [G]wandered my way to the [C]Wild woods of Hudson's Bay
[G]Treated my [Em]toes to Que[C]bec's morning [D7]dew
Where the [G]sweet summer breeze kissed the [C]leaves of the maple trees
[G]Singing this [Em] song that I'm [Am7]sharin[D7]g with [G]you

{soc}
  From the [D7]Vancouver Island to the [G]   Alberta highland
  Cross the [Em]prairies, the [D]lakes to On[A7]tario's  [D]towers
  From the [G]sound of Mount Royal's chimes  [C]    Out to the Maritimes
  [G]Something to [Em]sing about [D7]This land of [G]ours
{eoc}

Yes there's[G] something to sing about [C]Tune up a string about
[G]Call out in [Em]chorus or [C]quietly [D7]hum
Of a [G]land that's still young with a [C]ballad that's still unsung
[G]Telling the [Em]promise of [D7]Great things to [G]come

{soc}
  From the [D7]Vancouver Island to the [G]   Alberta highland
  Cross the [Em]prairies, the [D]lakes to On[A7]tario's  [D]towers
  From the [G]sound of Mount Royal's chimes  [C]    Out to the Maritimes
  [G]Something to [Em]sing about [D7]This land of [G]ours
Yes there's [G]something [Em]to sing about
[Em]This....[D7]land of [G/]ours 
{eoc}
______________________________

















