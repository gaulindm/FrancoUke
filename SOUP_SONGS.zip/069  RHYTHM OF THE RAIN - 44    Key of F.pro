

{title:069  RHYTHM OF THE RAIN}
{subtitle: 4/4    Key of F}
{subtitle: (John Gummoe)}
{metronome:126}
{time:2:42}


{c:RIFF:played through the intro }

{sot}
  F         Dm        F         C7
A|- 8 - 8 – - 5 - 5 – - 8 - 8 - - 10 7 -
E|- - 8 - 8 - - 5 - 5 - - 8 - 8 - - - - 10 8 -
{eot}

{c:INTRO}
[F]/ / / /    [Dm]/ / / /  
[F]/ / / /    [C7]/ / / /

[F]Listen to the rhythm of the [Bb]falling rain
[F]Telling me just what a fool I've [C7]been
I [F]wish that it would [F7]go and let me 
[Bb]Cry in vain
And [F]let me be a[C7]lone a[F]gain  [C7]

The [F]only girl I care about has [Bb]gone away
[F]Looking for a brand new [C7]start
But [F]little does she [F7]know
That when she [Bb]left that day
A[F]long with her she [C7]took my [F]heart   [F7]

[Bb]Rain please tell me now does 
[Am]That seem fair
For [Bb]her to steal my heart away 
When [F]she don't care
I [Dm]can't love another when my 
[G7]Heart’s some[C]where far [F]away 
{c:(234,}[C7]{c:1234)}

{sot}
    C7
A|- 3 3 1 1 0 0 - The… 
E|- - - - - - - 3 3 -
{eot}

The [F]only girl I care about has [Bb]gone away
[F]Looking for a brand new [C7]start
But [F]little does she [F7]know
That when she [Bb]left that day
A[F]long with her she [C7]took my [F]heart

{c:KAZOOS ONLY for this verse}
The [F]only girl I care about has [Bb]gone away
[F]Looking for a brand new [C7]start
But [F]little does she [F7]know
That when she [Bb]left that day
A[F]long with her she [C7]took my [F]heart

{c:Start singing again}
[Bb]Rain won't you tell her that I [Am]love her so
[Bb]Please ask the sun to set her [F]heart aglow
[Dm]Rain in her heart and let the 
[G7]Love we [C]knew start to [F]grow 
{c:(234,}[C7]{c:1234)}

{sot}
    C7
A|- 3 3 1 1 0 0 - - -
E|- - - - - - - 3 3 -
{eot}

[F]Listen to the rhythm of the [Bb]falling rain
[F]Telling me just what a fool I've [C7]been
I [F]wish that it would [F7]go and 
let me [Bb]cry in vain
And [F]let me be a[C7]lone a[F]gain [C7]

[F]  Oh, listen to the [Dm]falling rain
[F]  Pitter patter, pitter [Dm]patter
Oh, oh, oh, oh 
[F]Listen, listen to the [Dm]falling rain
[F]   Pitter patter, pitter [Dm]patter
Oh-oh-oh-[F/gliss]oh

________________________________

{define: F7 0 2 3 1 0}








