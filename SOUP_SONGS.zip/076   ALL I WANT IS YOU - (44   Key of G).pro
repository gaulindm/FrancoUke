

{title:076   ALL I WANT IS YOU  }
{subtitle:(4/4   Key of G)}   
{subtitle:(Barry Louis Polisar)}
{time:2:41}
{metronome: 160}






[G]/ / / /     [C]/ /    [G]/ /     
[G]/ / / /     [D]/ /    [G]/ /  
[G]/ / / /     [C]/ /    [G]/ /     
[G]/ / / /     [D]/ /    [G]/ /  
                                                               
If [G]I was a flower growing [C]wild and [G]free
All I'd [G]want is you to be my [D]sweet honey [G]bee
And if [G]I was a tree growing [C]tall and [G]green
All I'd [G]want is you to shade me and [D]be my [G]leaves 

{soc}
All I [G]want is you, will you [C]be my [G]bride
Take me by the hand and [D]stand by my [G]side
All I want is you, will you [C]stay with [G]me?
Hold me in your arms and [D]sway me like the [G]sea   
{eoc}
 
If [G]you were a river in the [C]mountains [G]tall
The rumble of your water would [D]be my [G]call
If you were the winter, I [C]know I’d be the [G]snow
Just as long as you were with me
When the [D]cold winds [G]blow         

{soc}
All I [G]want is you, will you [C]be my [G]bride
Take me by the hand and [D]stand by my [G]side
All I want is you, will you [C]stay with [G]me?
Hold me in your arms and [D]sway me like the [G]sea   
{eoc}
 
If [G]you were a wink, I'd [C]be a [G]nod
If you were a seed, well [D]I'd be a [G]pod
If you were the floor, I'd [C]wanna be the [G]rug
And if you were a kiss, I [D]know I’d be a [G]hug         

{soc}
All I [G]want is you, will you [C]be my [G]bride
Take me by the hand and [D]stand by my [G]side
All I want is you, will you [C]stay with [G]me?
Hold me in your arms and [D]sway me like the [G]sea   
{eoc}

If [G]you were the wood, I'd [C]be the [G]fire
If you were the love, I'd [D]be the de[G]sire
If you were a castle, I'd [C]be your [G]moat
And if you were an ocean, I'd [D]learn to [G]float         

{soc}
All I [G]want is you, will you [C]be my [G]bride
Take me by the hand and [D]stand by my [G]side
All I want is you, will you [C]stay with [G]me?
Hold me in your arms  and [D]sway me like the 
[G]sea {c:(234,1)}   [D/]  [G/]  
{eoc}

______________________________________










