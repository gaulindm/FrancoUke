

{title:C13: MELE KALIKIMAKA      4/4      Key of C}
{subtitle: (Robert Anderson)}
{metronome: 194}
{time:3:15}


{c:INTRO:}
[C]/ / / /    [A]/ / / /    
[Dm]/ /    [G7]/ /    [C]/ /    [G7]/ / 

{c:(Only men)}
[C]Mele Kalikimaka is the thing to say 
On a bright Hawaiian Christmas [G7]day 

That's the island greeting that we send to you 
From the land where palm trees [C]sway   [C7]
[F]Here we know that Christmas will be 
Green and bright 
The [A7]sun to shine by day and all the 
[D7]Stars at [G7]night 
[C]Mele Kalikimaka is Hawaii's [A7]way 
To [Dm]say Merry [G7]Christmas to [C]you 

{c:(women)}
[C]Mele Kalikimaka is the thing to say 
On a bright Hawaiian Christmas [G7]day 

That's the island greeting that we send to you 
From the land where palm trees [C]sway   [C7]
[F]Here we know that Christmas will be 
Green and bright 
The [A7]sun to shine by day and all the 
[D7]Stars at [G7]night 
[C]Mele Kalikimaka is Hawaii's [A7]way 
To [Dm]say Merry [G7]Christmas to [C]you 

{c:INSTRUMENTAL WITH KAZOOS *NO SINGING*}
[C]Mele Kalikimaka is the thing to say 
On a bright Hawaiian Christmas [G7]day 

That's the island greeting that we send to you 
From the land where palm trees [C]sway   [C7]
[F]Here we know that Christmas will be 
Green and bright 
The [A7]sun to shine by day and all the 
[D7]Stars at [G7]night 
[C]Mele Kalikimaka is Hawaii's [A7]way 
To [Dm]say Merry [G7]Christmas to [C]you 

{c:(Men and women)}
[C]Mele Kalikimaka is the thing to say 
On a bright Hawaiian Christmas [G7]day 

That's the island greeting that we send to you 
From the land where palm trees [C]sway   [C7]
[F]Here we know that Christmas will be 
Green and bright 
The [A7]sun to shine by day and all the 
[D7]Stars at [G7]night 
[C]Mele Kalikimaka is Hawaii's [A7]way 
To [Dm]say Merry [G7]Christmas 
A [Dm]very Merry [G7]Christmas
A [Dm]very-very Merry-Merry [G7]Christmas 
To [C]you    [G7/]  [C/]















