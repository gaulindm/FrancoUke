{title:ONE CALL AWAY  (CHARLIE PUTH)}
{subtitle:}
{time: 3:30}







{c:(the first note is E)} 

{c:COUNT-IN: 1234,1} 
    
I’m only [C/]one [G/]call a[Am/]way
I'll be there to [F/]save [C/]the [G/]day
Superman got [C/]no…[G/]thing on [Am/]me-e-e
I'm only [F/]one [Dm/]call a[C/]way  {c:(234,1234)}


[Am] Call me, [G]Baby, if you [C]need a [F]friend
[Am] I just [G]wanna give you [C]love
C’[F]mon, c'mon, c’[Am]mon
Reaching [G]out to you, so [C]take a [F]chance
No [F]matter where you go {c:(234)}
You [G/]know you're not alone

{c:CHORUS}
{soc}
I'm only [C]one [G]call a[Am]way
I'll be there to [F]save [C]the [G]day
Superman got [C]no[G]thing on [Am]me-e-e
I'm only [F]one [Dm]call a[C]way {c:(234,1234)}
{eoc}

[Am] Come a[G]long with me and [C]don't be [F]scared
[Am] I just [G]wanna set you [C]free
C’[F]mon, c'mon, c’[Am]mon
You and [G]me can make it [C]any[F]where
For [Am]now, we can [G]stay here for a [C]while [F]
Cause you [Am]know
I just [G]wanna see you [C]smi-i-i-[F]ile

No [F/]matter where you go  {c:(234)}
You [G/]know you're not alone

{soc}
I'm only [C]one [G]call a[Am]way
I'll be there to [F]save [C]the [G]day
Superman got [C]no[G]thing on [Am]me-e-e
I'm only [F]one [Dm]call a[C]way {c:234,1)}
{eoc}

{c:BRIDGE}
{sob}
And when you're [F]wea…k [Am]I’ll be [G]strong
I'm gonna [F]kee…p [Am]holding [G]on
Now don't you [F]worry, it [Am]won't be [G]long
Da…rling, and when you [F]feel like hope is gone
Just [G]run into my arms
{eob}

I'm only [C/]one [G/]call a[Am/]way
I'll be there to [F/]save [C/]the [G/]day
Superman got [C]noth[G7]ing on [Am]me
I'm only [F]one {c:(234,1)}

I'm only [G]wo-o-o-o- [C]one [G]call a[Am]way
I'll be there to [F]save [C]the [G]day
Superman got [C]no[G]thing on [Am]me
I'm only [F]one [Dm]call a[C]way
I'm only [F/]one [Dm/]call a[C/]way  
