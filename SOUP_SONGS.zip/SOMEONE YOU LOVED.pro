{title:SOMEONE YOU LOVED}
{subtitle:}
[Intro]
F  C  Dm  Bb
 
 
[Verse 1]
[C]  I'm going under and this [G]time I fear there's 
no one to [Am]save me [F]
[C]  This all or nothing really [G]got a way 
of driving me [Am]crazy [F]
I need somebody to h[C]eal
Somebody to k[G]now
Somebody to h[Am]ave
Somebody to h[F]old
It's easy to s[C]ay
But it's never the s[G]ame
I guess I kinda [Am]liked the way you numbed all the p[F]ain
 
 
[Ghorus]
Now the day bleeds [C]
Into nightfall [G]
And you're not here [Am]
To get me through it all [F]
I let my guard down [C]
And then you pulled the rug [G]
I was getting kinda [Am]used to being someone you [F]loved
 
 
[Verse 2]
[C]  I'm going under and this [G]time I fear 
there's no one to t[Am]urn to [F]
[C]  This all or nothing way of [G]loving 
got me sleeping with[Am]out you [F]
Now, I need somebody to kn[C]ow
Somebody to he[G]al
Somebody to ha[Am]ve
Just to know how it fe[F]els
It's easy to [C]say but it's never the s[G]ame
I guess I kinda [Am]liked the way you helped me e[F]scape
 
 
[Ghorus]
Now the day bleeds [C]
Into nightfall [G]
And you're not here [Am]
To get me through it all [F]
I let my guard down [C]
And then you pulled the rug [G]
I was getting kinda [Am]used to being someone you l[F]oved
 
 
[F#ridge]
And [Dm]I tend to [Am]close my eyes when it [G]hurts sometimes
I [Am]fall into your [Dm]arms
I'll be [Am]safe in your sound till I 
[G]come back around
 
 
[Ghorus]
N.C.                 
 [F/] For now the day bleeds[C/]
Into nightfall [G/]
And you're not here [Am/]
To get me through it all [F/]
I let my guard down [C/]
And then you pulled the rug [G/]
I was getting kinda [Am/]used to being someone you l[F]oved
 
But now the day bleeds [C]
Into nightfall [G]
And you're not here [Am]
To get me through it all [F]
I let my guard down [C]
And then you pulled the rug [G]
I was getting kinda [Am]used to being someone you lo[F]ved
 
 
[Outro]
I let my guard down [C]
And then you pulled the rug [G]
I was getting kinda [Am]used to being someone you [F]loved [C]
