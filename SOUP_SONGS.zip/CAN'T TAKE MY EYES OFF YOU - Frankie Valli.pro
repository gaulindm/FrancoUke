{title: CAN'T TAKE MY EYES OFF YOU}
{subtitle: Frankie Valli}
{metronome: 116}
{time: 4:00}











{c:INTRO:}
[Dm]/ / / /    [Fm]/ / / /    [C]/ / / /   / /

{c:(ooo’s as back-up)}
[C]You're just too good to be true
Can't take my [Cmaj7]eyes off of you 
You'd be like [C7]heaven to touch 
I wanna [F]hold you so much   
At long last [Fm]love has arrived
And I thank [C]God I'm alive 
You're just too [Dm]good to be true, [Fm]   
Can't take my [C]eyes off of you 

{c:(with harmony)}
Pardon the [C]way that I stare 
There's nothing [Cmaj7]else to compare 
The sight of [C7]you leaves me weak 
There are no [F]words left to speak
But if you [Fm]feel like I feel
Please let me [C]know that it's real
You're just too [Dm]good to be true, [Fm]    
Can't take my [C]eyes off you  [A7/]

{soc}
I love you [Dm]baby, and if it's [G7] quite all right
I need you [Cmaj7] baby, to warm my [A7]lonely night
I love you [Dm]baby, trust in [G7]me when I [C]say   [A7/]
Oh pretty [Dm]baby, don't bring me [G7] down I pray
Oh pretty [C]baby, now that I've [A7]found you stay
And let me [Dm/] love you baby, let me [G7/]love you {c:(234)}
{eoc}
[C]You're just too good to be true
Can't take my [Cmaj7]eyes off of you 
You'd be like [C7]heaven to touch 
I wanna [F]hold you so much   
At long last [Fm]love has arrived
And I thank [C]God I'm alive 
You're just too [Dm]good to be true, [Fm]   
Can't take my [C]eyes off of you [A7/]

{soc}
I love you [Dm]baby, and if it's [G7] quite all right
I need you [Cmaj7] baby, to warm my [A7] lonely night
I love you [Dm]baby, trust in [G7]me when I [C]say   [A7/]
Oh pretty [Dm]baby, don't bring me [G7] down I pray
Oh pretty [C]baby, now that I've [A7]found you stay
And let me [Dm/] love you baby, let me [G7/]love you  {c:(234)}
{eoc}

[C]You're just too good to be true
Can't take my [Cmaj7]eyes off of you 
You'd be like [C7]heaven to touch 
I wanna [F]hold you so much   
At long last [Fm]love has arrived
And I thank [C]God I'm alive 
You're just too [Dm]good to be true, [Fm]   
Can't take my [C]eyes off of you 
You're just too [Dm]good to be true, [Fm]   
Can't take my [C]eyes off of you [C/]

{tag: Shared by The Wedding Singers}