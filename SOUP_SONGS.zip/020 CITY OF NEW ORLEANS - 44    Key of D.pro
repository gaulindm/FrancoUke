

{title:020 CITY OF NEW ORLEANS}
{subtitle:4/4    Key of G}
{subtitle:Steve Goodman (performed by Arlo Guthrie)}
{time:4:39}
{metronome:167}






[G]/ / / /     / / / /

[G]Riding on the [D]City of New [G]Orleans 
[Em]Illinois Central
[C]Monday morning [G]rail {c:(234)}  {c:(}[D]{c:1234)}
[G]Fifteen cars and [D]fifteen restless [G]riders 
[Em]Three conductors and 
[D]Twenty five sacks of [G]mail {c:(234,123)}

All a[Em]long the southbound odyssey 
The [Bm]train pulls out at Kankakee
[D]Rolls along past houses, farms and [A]fields 
[Em]Passing trains that have no name
[Bm]Freight yards full of old black men
And the [D]graveyards of the [D7]rusted automo[G]biles 

{soc}
  [C]Good morning A[D]merica, how [G]are you?  
  Say, [Em]don't you know me? 
  [C]I'm your native [G]son  {c:(234)} [D7/]
  I...'m the [G]train they call the 
  [D]City of New [Em]Orleans {c:(34)} {c:(}[A7]{c:123)}
  I'll be [F]gone five [C]hundred [D]miles 
  When the [D7]day is [G]done 
{eoc}

Dealin' [G]card games with the 
[D]Old men in the [G]club car 
[Em]Penny a point ain't {soh}[C]no one{eoh} keepin' 
[G]Score {c:(234)} {c:(}[D]{c:1234)} 
[G]Pass the paper [D]bag that holds the [G]bottle 
[Em]Feel the wheels 
[D]Rumblin' 'neath the [G]floor {c:(234,123)}

And the [Em]sons of Pullman porters
And the [Bm]sons of engineers
Ride their [D]father's magic carpets 
Made of [A]steel 
[Em]Mothers with their babes asleep 
Are [Bm]rockin' to the gentle beat 
And the [D]rhythm of the [D7]rails is all they [G]feel 
{soc}
  [C]Good morning A[D]merica, how [G]are you?  
  Say, [Em]don't you know me? 
  [C]I'm your native [G]son  {c:(234)} [D7/]
  I...'m the [G]train they call the 
  [D]City of New [Em]Orleans {c:(34)} {c:(}[A7]{c:123)}
  I'll be [F]gone five [C]hundred [D]miles 
  When the [D7]day is [G]done 
{eoc}

[G]Nighttime on the [D]City of New [G]Orleans 
[Em]Changing cars ↑in [C]Memphis,
Tennes[G]see {c:(234)} {c:(}[D]{c:1234)}
[G]Halfway home and [D]we'll be there by [G]morning 
Through the [Em]Mississippi darkness 
[D]Rolling down to the [G]sea  

But [Em]all the towns and people seem  
To [Bm]fade into a bad dream
And the [D]steel rail still ain't heard the [A]news 
The [Em]conductor sings his song again 
The [Bm]passengers will please refrain
This [D]train's got 
The disa[D7]ppearing railroad [G]blues 

{soc}  
  [C]Good night A[D]merica, how [G]are you?  
  Say, [Em]don't you know me 
  [C]I'm your native [G]son  {c:(234)} [D7/]
  I...'m the [G]train they call the 
  [D]City of New [Em]Orleans {c:(34)} {c:(}[A7]{c:123)}
  I'll be [F]gone five [C]hundred [D]miles 
 When the [D7]day is [G]done 
  I'll be [F]gone five [C]hundred [D]miles 
  When the [D7]day is [G]done  {c:(234)}
  [C]/ / / /    [D]/ / / /    [G/]
{eoc}

_____________________________________________











